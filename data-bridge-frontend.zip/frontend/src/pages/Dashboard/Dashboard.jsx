import { useEffect, useState, useCallback } from 'react';
import {
  Database, CheckCircle2, Activity, XCircle, TrendingUp, RefreshCw, ChevronDown,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';
import dayjs from 'dayjs';

import PageHeader from '../../components/common/PageHeader';
import StatCard from '../../components/dashboard/StatCard';
import StatusBadge from '../../components/common/StatusBadge';
import Loader from '../../components/common/Loader';
import ErrorState from '../../components/common/ErrorState';
import EmptyState from '../../components/common/EmptyState';
import dashboardService from '../../services/dashboardService';
import jobConfigService from '../../services/jobConfigService';
import { colors } from '../../constants/tokens';
import './Dashboard.css';

const TIME_FILTERS = [
  { value: 'LAST_24_HOURS', label: 'Last 24 hours', hours: 24 },
  { value: 'LAST_7_DAYS', label: 'Last 7 days', hours: 24 * 7 },
  { value: 'LAST_30_DAYS', label: 'Last 30 days', hours: 24 * 30 },
];

export default function Dashboard() {
  const [jobs, setJobs] = useState([]);
  const [selectedJob, setSelectedJob] = useState('ALL_JOBS');
  const [timeFilter, setTimeFilter] = useState('LAST_7_DAYS');

  const [stats, setStats] = useState(null);
  const [series, setSeries] = useState([]);
  const [recent, setRecent] = useState([]);
  const [topFailed, setTopFailed] = useState([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    jobConfigService.getConfigs().then(setJobs).catch(() => {});
  }, []);

  const loadDashboard = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const jobName = selectedJob === 'ALL_JOBS' ? undefined : selectedJob;
      const range = TIME_FILTERS.find((f) => f.value === timeFilter);
      const to = dayjs().toISOString();
      const from = dayjs().subtract(range.hours, 'hour').toISOString();

      const overview = await dashboardService.getOverview(jobName, from, to);

      setStats(overview.stats);
      setSeries(overview.executionTrends || []);
      setRecent(overview.recentExecutions?.content || overview.recentExecutions || []);
      setTopFailed(overview.topFailedJobs || []);
    } catch (e) {
      setError(e.message || 'Failed to load dashboard data. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [timeFilter, selectedJob]);

  useEffect(() => {
    loadDashboard();
  }, [loadDashboard]);

  if (error) {
    return (
      <div>
        <PageHeader title="Dashboard" />
        <ErrorState description={error} onRetry={loadDashboard} />
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title="Dashboard"
        actions={
          <>
            <div className="select-wrapper">
              <select
                className="select-control"
                value={selectedJob}
                onChange={(e) => setSelectedJob(e.target.value)}
                disabled={loading}
              >
                <option value="ALL_JOBS">All Jobs</option>
                {jobs.map((job) => (
                  <option key={job.name} value={job.name}>{job.name}</option>
                ))}
              </select>
              <ChevronDown size={15} className="select-chevron" />
            </div>

            <div className="select-wrapper">
              <select
                className="select-control"
                value={timeFilter}
                onChange={(e) => setTimeFilter(e.target.value)}
                disabled={loading}
              >
                {TIME_FILTERS.map((f) => (
                  <option key={f.value} value={f.value}>{f.label}</option>
                ))}
              </select>
              <ChevronDown size={15} className="select-chevron" />
            </div>

            <button className="btn-primary" onClick={loadDashboard} disabled={loading}>
              <RefreshCw size={16} className={loading ? 'spin' : ''} />
              Refresh
            </button>
          </>
        }
      />

      <div className="stats-grid">
        <StatCard icon={Database} label="Total Executions" value={stats?.totalExecutions} variant="primary" loading={loading} />
        <StatCard icon={Activity} label="Active Job Configs" value={stats?.activeJobConfigs} variant="info" loading={loading} />
        <StatCard icon={CheckCircle2} label="Completed" value={stats?.completedCount?.toLocaleString()} variant="success" loading={loading} />
        <StatCard icon={XCircle} label="Failed" value={stats?.failedCount} variant="danger" loading={loading} />
        <StatCard icon={TrendingUp} label="Success Rate" value={stats ? `${stats.successRate}%` : undefined} variant="warning" loading={loading} />
      </div>

      <div className="dashboard-grid">
        <div className="dashboard-card fade-in-up">
          <h2 className="card-heading">Success vs Failure</h2>
          {loading ? (
            <Loader label="Loading chart…" />
          ) : series.length === 0 ? (
            <EmptyState title="No execution data" description="Nothing ran in this window yet." />
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={series}>
                <CartesianGrid strokeDasharray="3 3" stroke={colors.line} vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 12, fill: colors.inkMuted }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: colors.inkMuted }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ borderRadius: 10, border: `1px solid ${colors.line}`, fontSize: 13 }}
                />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="successCount" name="Success" fill={colors.success} radius={[6, 6, 0, 0]} />
                <Bar dataKey="failedCount" name="Failed" fill={colors.danger} radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="dashboard-card fade-in-up">
          <h2 className="card-heading">Top Failed Jobs</h2>
          {loading ? (
            <Loader label="Loading…" />
          ) : topFailed.length === 0 ? (
            <EmptyState title="No failures" description="Nothing failed in this window." />
          ) : (
            <ul className="top-failed-list">
              {topFailed.map((job) => (
                <li key={job.jobName}>
                  <span className="top-failed-name">{job.jobName}</span>
                  <span className="top-failed-count">{job.failureCount}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <div className="dashboard-card fade-in-up">
        <h2 className="card-heading">Recent Executions</h2>
        {loading ? (
          <Loader label="Loading executions…" />
        ) : recent.length === 0 ? (
          <EmptyState title="No recent executions" description="Runs will show up here once a job executes." />
        ) : (
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Job Name</th>
                  <th>Status</th>
                  <th>Triggered By</th>
                  <th>Started</th>
                </tr>
              </thead>
              <tbody>
                {recent.map((row) => (
                  <tr key={row.id}>
                    <td className="mono">{row.jobName}</td>
                    <td><StatusBadge status={row.status} size="sm" /></td>
                    <td>{row.triggeredBy || '—'}</td>
                    <td className="mono">{dayjs(row.createdAt).format('MMM D, HH:mm')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

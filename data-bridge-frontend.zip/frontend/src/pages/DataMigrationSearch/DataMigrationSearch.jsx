import { useState, Fragment } from 'react';
import { Search, Database, ChevronDown, ChevronRight as ChevronRightIcon } from 'lucide-react';
import dayjs from 'dayjs';

import PageHeader from '../../components/common/PageHeader';
import Loader from '../../components/common/Loader';
import EmptyState from '../../components/common/EmptyState';
import StatusBadge from '../../components/common/StatusBadge';
import migrationSearchService from '../../services/migrationSearchService';
import { JOB_NAMES } from '../../services/mockData';
import './DataMigrationSearch.css';

export default function DataMigrationSearch() {
  const [jobName, setJobName] = useState('');
  const [searchValue, setSearchValue] = useState('');
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [expandedId, setExpandedId] = useState(null);

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchValue.trim()) return;
    setLoading(true);
    setExpandedId(null);
    try {
      const data = await migrationSearchService.search(jobName, searchValue);
      setResults(data);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <PageHeader title="Data Migration Search" />

      <form className="panel-card migration-search-form" onSubmit={handleSearch}>
        <div className="select-wrapper">
          <select className="select-control" value={jobName} onChange={(e) => setJobName(e.target.value)}>
            <option value="">All Jobs</option>
            {JOB_NAMES.map((name) => <option key={name} value={name}>{name}</option>)}
          </select>
          <ChevronDown size={15} className="select-chevron" />
        </div>
        <input
          className="text-input migration-search-input"
          placeholder="Search by policy number, batch ID, or key…"
          value={searchValue}
          onChange={(e) => setSearchValue(e.target.value)}
        />
        <button className="btn-primary" type="submit" disabled={loading || !searchValue.trim()}>
          <Search size={16} />
          Search
        </button>
      </form>

      {loading ? (
        <Loader label="Searching migrated records…" />
      ) : results === null ? (
        <EmptyState
          icon={Database}
          title="Search migrated records"
          description="Enter a policy number, batch ID, or key above to find migration records and their reader/processor/writer detail."
        />
      ) : results.length === 0 ? (
        <EmptyState icon={Database} title="No records found" description="Try a different search term or job filter." />
      ) : (
        <div className="panel-card">
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Search Key</th>
                  <th>Job</th>
                  <th>Batch ID</th>
                  <th>Status</th>
                  <th>Read Time</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {results.map((row) => (
                  <Fragment key={row.id}>
                    <tr className="migration-row" onClick={() => setExpandedId(expandedId === row.id ? null : row.id)}>
                      <td className="mono">{row.searchKey}</td>
                      <td className="mono">{row.jobName}</td>
                      <td className="mono">{row.batchId}</td>
                      <td><StatusBadge status={row.itemStatus} size="sm" /></td>
                      <td className="mono">{dayjs(row.readTime).format('MMM D, HH:mm')}</td>
                      <td>
                        <ChevronRightIcon size={16} className={`migration-chevron ${expandedId === row.id ? 'migration-chevron--open' : ''}`} />
                      </td>
                    </tr>
                    {expandedId === row.id && (
                      <tr className="migration-detail-row">
                        <td colSpan={6}>
                          <div className="migration-detail fade-in-up">
                            {row.errorMessage && (
                              <p className="migration-error">
                                Failed at <strong>{row.errorStage}</strong>: {row.errorMessage}
                              </p>
                            )}
                            <div className="migration-detail-grid">
                              <div>
                                <span className="step-detail-label">Reader</span>
                                <pre className="migration-json">{JSON.stringify(row.readerDetails, null, 2)}</pre>
                              </div>
                              <div>
                                <span className="step-detail-label">Processor</span>
                                <pre className="migration-json">{row.processorDetails ? JSON.stringify(row.processorDetails, null, 2) : '— not reached —'}</pre>
                              </div>
                              <div>
                                <span className="step-detail-label">Writer</span>
                                <pre className="migration-json">{row.writerDetails ? JSON.stringify(row.writerDetails, null, 2) : '— not reached —'}</pre>
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </Fragment>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

import { useEffect, useState, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Briefcase } from 'lucide-react';

import PageHeader from '../../components/common/PageHeader';
import SearchBar from '../../components/common/SearchBar';
import Loader from '../../components/common/Loader';
import ErrorState from '../../components/common/ErrorState';
import EmptyState from '../../components/common/EmptyState';
import JobCard from '../../components/jobs/JobCard';
import TriggerJobModal from '../../components/jobs/TriggerJobModal';
import jobConfigService from '../../services/jobConfigService';
import './JobsList.css';

export default function JobsList() {
  const navigate = useNavigate();
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [triggerJob, setTriggerJob] = useState(null);

  // Real backend: a "job" here IS a job config, joined with its latest
  // execution + scheduler state via /v1/job-configs/summary.
  const loadJobs = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await jobConfigService.getConfigSummaries(50, 0);
      setJobs(data);
    } catch (e) {
      setError(e.message || 'Failed to load jobs. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadJobs();
  }, [loadJobs]);

  const filteredJobs = useMemo(() => {
    if (!search.trim()) return jobs;
    return jobs.filter((j) => j.name.toLowerCase().includes(search.toLowerCase()));
  }, [jobs, search]);

  if (error) {
    return (
      <div>
        <PageHeader title="Jobs" />
        <ErrorState description={error} onRetry={loadJobs} />
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="Jobs" />

      <SearchBar
        value={search}
        onChange={setSearch}
        placeholder="Search jobs by name…"
        resultLabel={loading ? undefined : `${filteredJobs.length} ${filteredJobs.length === 1 ? 'job' : 'jobs'} found`}
      />

      {loading ? (
        <Loader label="Loading jobs…" />
      ) : filteredJobs.length === 0 ? (
        <EmptyState
          icon={Briefcase}
          title="No jobs found"
          description={search ? 'Try adjusting your search query.' : 'No scheduler jobs are registered yet.'}
        />
      ) : (
        <div className="jobs-grid">
          {filteredJobs.map((job) => (
            <JobCard
              key={job.name}
              job={job}
              onOpen={(j) => navigate(`/jobs/${encodeURIComponent(j.name)}/instances`)}
              onTrigger={(j) => setTriggerJob(j)}
            />
          ))}
        </div>
      )}

      {triggerJob && (
        <TriggerJobModal job={triggerJob} onClose={() => setTriggerJob(null)} />
      )}
    </div>
  );
}

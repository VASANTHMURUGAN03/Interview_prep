import { useEffect, useState, useCallback, Fragment } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Layers, Square, ChevronRight, ChevronDown, GitPullRequest } from 'lucide-react';
import dayjs from 'dayjs';

import PageHeader from '../../components/common/PageHeader';
import Loader from '../../components/common/Loader';
import ErrorState from '../../components/common/ErrorState';
import EmptyState from '../../components/common/EmptyState';
import StatusBadge from '../../components/common/StatusBadge';
import Pagination from '../../components/common/Pagination';
import { useToast } from '../../context/ToastContext';
import jobInstancesService from '../../services/jobInstancesService';
import executionService from '../../services/executionService';
import './JobInstances.css';

const STATUSES = ['IN_PROGRESS', 'COMPLETED', 'FAILED', 'ABORTED'];

export default function JobInstances() {
  const { jobName } = useParams();
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [page, setPage] = useState(0);
  const [status, setStatus] = useState('');

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Read/write batches per execution — fetched lazily on row expand (not
  // eagerly for every row, to avoid an N+1 fan-out of batch calls just to
  // render a list). Cached by execution id so re-expanding doesn't refetch.
  const [expandedId, setExpandedId] = useState(null);
  const [batchCache, setBatchCache] = useState({});
  const [batchLoading, setBatchLoading] = useState(null);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await jobInstancesService.getInstances(jobName, { status, page, size: 10 });
      setData(result);
    } catch (e) {
      setError(e.message || 'Failed to load job instances.');
    } finally {
      setLoading(false);
    }
  }, [jobName, status, page]);

  useEffect(() => { load(); }, [load]);

  const handleStop = async (row) => {
    try {
      await jobInstancesService.stopInstance(row.jobUuid);
      showToast(`Execution ${row.jobUuid} aborted.`, 'success');
      load();
    } catch (e) {
      showToast(e.message || 'Failed to abort execution.', 'error');
    }
  };

  const toggleExpand = async (executionId) => {
    if (expandedId === executionId) {
      setExpandedId(null);
      return;
    }
    setExpandedId(executionId);
    if (batchCache[executionId]) return; // already fetched, reuse

    setBatchLoading(executionId);
    try {
      const overview = await executionService.getExecutionOverview(executionId);
      setBatchCache((prev) => ({
        ...prev,
        [executionId]: { readBatches: overview.readBatches || [], writeBatches: overview.writeBatches || [] },
      }));
    } catch (e) {
      showToast(e.message || 'Failed to load batches for this execution.', 'error');
      setExpandedId(null);
    } finally {
      setBatchLoading(null);
    }
  };

  const goToRetries = (executionId, batchId, batchType) => {
    navigate(`/jobs/${encodeURIComponent(jobName)}/instances/${executionId}/batches/${batchId}/retries?batchType=${batchType}`);
  };

  const trail = [{ label: 'Jobs', onClick: () => navigate('/jobs') }, { label: jobName }];

  if (error) {
    return (
      <div>
        <PageHeader title="Job Instances" trail={trail} />
        <ErrorState description={error} onRetry={load} />
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title="Job Instances"
        trail={trail}
        actions={
          <div className="select-wrapper">
            <select className="select-control" value={status} onChange={(e) => { setStatus(e.target.value); setPage(0); }}>
              <option value="">All Statuses</option>
              {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
            <ChevronDown size={15} className="select-chevron" />
          </div>
        }
      />

      {loading ? (
        <Loader label="Loading instances…" />
      ) : !data || data.content.length === 0 ? (
        <EmptyState icon={Layers} title="No instances found" description="Try adjusting the filters above, or trigger this job to create one." />
      ) : (
        <div className="panel-card">
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th></th>
                  <th>Execution ID</th>
                  <th>Status</th>
                  <th>Triggered By</th>
                  <th>Started</th>
                  <th>Last Updated</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {data.content.map((row) => {
                  const isOpen = expandedId === row.id;
                  const batches = batchCache[row.id];
                  return (
                    <Fragment key={row.id}>
                      <tr className="instance-row" onClick={() => toggleExpand(row.id)}>
                        <td>
                          <ChevronRight size={16} className={`instance-chevron ${isOpen ? 'instance-chevron--open' : ''}`} />
                        </td>
                        <td className="mono">{row.jobUuid?.slice(0, 8) || row.id}</td>
                        <td><StatusBadge status={row.status} size="sm" /></td>
                        <td>{row.triggeredBy || '—'}</td>
                        <td className="mono">{dayjs(row.createdAt).format('MMM D, HH:mm')}</td>
                        <td className="mono">{dayjs(row.updatedAt).format('MMM D, HH:mm')}</td>
                        <td>
                          <div className="row-actions" onClick={(e) => e.stopPropagation()}>
                            {row.status === 'IN_PROGRESS' && (
                              <button className="btn-ghost row-action-btn" onClick={() => handleStop(row)}>
                                <Square size={13} /> Abort
                              </button>
                            )}
                            <button
                              className="btn-ghost row-action-btn"
                              onClick={() => navigate(`/jobs/${encodeURIComponent(jobName)}/instances/${row.id}`)}
                            >
                              Full Detail <ChevronRight size={13} />
                            </button>
                          </div>
                        </td>
                      </tr>

                      {isOpen && (
                        <tr className="instance-detail-row">
                          <td colSpan={7}>
                            <div className="instance-detail fade-in-up">
                              {batchLoading === row.id ? (
                                <Loader label="Loading batches…" />
                              ) : (
                                <div className="instance-batches-grid">
                                  <div>
                                    <h4 className="instance-batches-heading">Read Batches ({batches?.readBatches?.length ?? 0})</h4>
                                    {!batches?.readBatches?.length ? (
                                      <p className="req-hint">No read batches yet.</p>
                                    ) : (
                                      <div className="instance-batch-scroll">
                                        <table className="data-table instance-batch-table">
                                          <thead>
                                            <tr>
                                              <th>Batch #</th>
                                              <th>Next Cursor</th>
                                              <th>Status</th>
                                              <th>Retry Count</th>
                                              <th>Created</th>
                                              <th>Updated</th>
                                              <th></th>
                                            </tr>
                                          </thead>
                                          <tbody>
                                            {batches.readBatches.map((b) => (
                                              <tr key={b.id}>
                                                <td className="mono">{b.batchNo}</td>
                                                <td className="mono instance-cursor-cell">{b.nextCursor || '—'}</td>
                                                <td><StatusBadge status={b.status} size="sm" /></td>
                                                <td>{b.retryCount ?? 0}</td>
                                                <td className="mono">{dayjs(b.createdAt).format('MMM D, HH:mm:ss')}</td>
                                                <td className="mono">{dayjs(b.updatedAt).format('MMM D, HH:mm:ss')}</td>
                                                <td>
                                                  {b.status === 'FAILED' && (
                                                    <button className="btn-ghost row-action-btn" onClick={() => goToRetries(row.id, b.id, 'READ')}>
                                                      <GitPullRequest size={12} /> Info
                                                    </button>
                                                  )}
                                                </td>
                                              </tr>
                                            ))}
                                          </tbody>
                                        </table>
                                      </div>
                                    )}
                                  </div>

                                  <div>
                                    <h4 className="instance-batches-heading">Write Batches ({batches?.writeBatches?.length ?? 0})</h4>
                                    {!batches?.writeBatches?.length ? (
                                      <p className="req-hint">No write batches yet.</p>
                                    ) : (
                                      <div className="instance-batch-scroll">
                                        <table className="data-table instance-batch-table">
                                          <thead>
                                            <tr>
                                              <th>Reference ID</th>
                                              <th>Entity</th>
                                              <th>Status</th>
                                              <th>Error Message</th>
                                              <th>Retried From</th>
                                              <th>Created</th>
                                              <th>Updated</th>
                                              <th></th>
                                            </tr>
                                          </thead>
                                          <tbody>
                                            {batches.writeBatches.map((b) => (
                                              <tr key={b.id}>
                                                <td className="mono">{b.referenceId || '—'}</td>
                                                <td className="mono">{b.entity}</td>
                                                <td><StatusBadge status={b.status} size="sm" /></td>
                                                <td className="exec-remarks">{b.errorMessage || '—'}</td>
                                                <td className="mono">{b.retriedFromBatchId ? b.retriedFromBatchId.slice(0, 8) : '—'}</td>
                                                <td className="mono">{dayjs(b.createdAt).format('MMM D, HH:mm:ss')}</td>
                                                <td className="mono">{dayjs(b.updatedAt).format('MMM D, HH:mm:ss')}</td>
                                                <td>
                                                  <button className="btn-ghost row-action-btn" onClick={() => goToRetries(row.id, b.id, 'WRITE')}>
                                                    <GitPullRequest size={12} /> Retries
                                                  </button>
                                                </td>
                                              </tr>
                                            ))}
                                          </tbody>
                                        </table>
                                      </div>
                                    )}
                                  </div>
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
          <Pagination page={data.currentPage} isLastPage={data.isLastPage} onChange={setPage} />
        </div>
      )}
    </div>
  );
}

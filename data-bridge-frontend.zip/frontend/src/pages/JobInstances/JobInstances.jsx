import { useEffect, useState, useCallback } from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import { Layers, Square, Play, ChevronRight, ChevronDown } from 'lucide-react';
import dayjs from 'dayjs';

import PageHeader from '../../components/common/PageHeader';
import Loader from '../../components/common/Loader';
import ErrorState from '../../components/common/ErrorState';
import EmptyState from '../../components/common/EmptyState';
import StatusBadge from '../../components/common/StatusBadge';
import Pagination from '../../components/common/Pagination';
import { useToast } from '../../context/ToastContext';
import jobsService from '../../services/jobsService';
import jobInstancesService from '../../services/jobInstancesService';
import { STATUSES, TRIGGER_TYPES } from '../../services/mockData';
import './JobInstances.css';

export default function JobInstances() {
  const { jobId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { showToast } = useToast();

  const [job, setJob] = useState(location.state?.job || null);
  const [page, setPage] = useState(0);
  const [status, setStatus] = useState('');
  const [triggeredBy, setTriggeredBy] = useState('');

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Resolve the job when arriving via direct URL (no router state).
  useEffect(() => {
    if (job) return;
    jobsService.getAllJobs().then((jobs) => {
      const found = jobs.find((j) => String(j.id) === String(jobId));
      setJob(found || { id: jobId, name: `Job #${jobId}` });
    });
  }, [job, jobId]);

  const load = useCallback(async () => {
    if (!job) return;
    try {
      setLoading(true);
      setError(null);
      const result = await jobInstancesService.getInstances(job.name, { status, triggeredBy, page, size: 8 });
      setData(result);
    } catch (e) {
      setError('Failed to load job instances.');
    } finally {
      setLoading(false);
    }
  }, [job, status, triggeredBy, page]);

  useEffect(() => { load(); }, [load]);

  const handleStop = async (instanceId) => {
    try {
      await jobInstancesService.stopInstance(job.name, instanceId);
      showToast(`Instance #${instanceId} stopped.`, 'success');
      load();
    } catch (e) {
      showToast('Failed to stop instance.', 'error');
    }
  };

  const handleResume = async (instanceId) => {
    try {
      await jobInstancesService.resumeInstance(job.name, instanceId);
      showToast(`Instance #${instanceId} resumed.`, 'success');
      load();
    } catch (e) {
      showToast('Failed to resume instance.', 'error');
    }
  };

  if (error) {
    return (
      <div>
        <PageHeader title="Job Instances" trail={[{ label: 'Jobs', onClick: () => navigate('/jobs') }, { label: job?.name }]} />
        <ErrorState description={error} onRetry={load} />
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title="Job Instances"
        trail={[{ label: 'Jobs', onClick: () => navigate('/jobs') }, { label: job?.name || '…' }]}
        actions={
          <>
            <div className="select-wrapper">
              <select className="select-control" value={status} onChange={(e) => { setStatus(e.target.value); setPage(0); }}>
                <option value="">All Statuses</option>
                {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
              <ChevronDown size={15} className="select-chevron" />
            </div>
            <div className="select-wrapper">
              <select className="select-control" value={triggeredBy} onChange={(e) => { setTriggeredBy(e.target.value); setPage(0); }}>
                <option value="">All Triggers</option>
                {TRIGGER_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
              </select>
              <ChevronDown size={15} className="select-chevron" />
            </div>
          </>
        }
      />

      {loading ? (
        <Loader label="Loading instances…" />
      ) : !data || data.content.length === 0 ? (
        <EmptyState icon={Layers} title="No instances found" description="Try adjusting the filters above." />
      ) : (
        <div className="panel-card">
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Instance ID</th>
                  <th>Status</th>
                  <th>Executions</th>
                  <th>Duration</th>
                  <th>Triggered By</th>
                  <th>Last Updated</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {data.content.map((row) => (
                  <tr key={row.id}>
                    <td className="mono">#{row.id}</td>
                    <td><StatusBadge status={row.lastStatus} size="sm" /></td>
                    <td>{row.executionCount}</td>
                    <td className="mono">{row.duration}</td>
                    <td>{row.triggeredBy}</td>
                    <td className="mono">{dayjs(row.lastUpdated).format('MMM D, HH:mm')}</td>
                    <td>
                      <div className="row-actions">
                        {row.lastStatus === 'RUNNING' ? (
                          <button className="btn-ghost row-action-btn" onClick={() => handleStop(row.id)}>
                            <Square size={13} /> Stop
                          </button>
                        ) : row.lastStatus === 'STOPPED' ? (
                          <button className="btn-ghost row-action-btn" onClick={() => handleResume(row.id)}>
                            <Play size={13} /> Resume
                          </button>
                        ) : null}
                        <button
                          className="btn-ghost row-action-btn"
                          onClick={() => navigate(`/jobs/${job.id}/instances/${row.id}/execution`, { state: { job } })}
                        >
                          View <ChevronRight size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination page={data.currentPage} totalPages={data.totalPages} totalElements={data.totalElements} onChange={setPage} />
        </div>
      )}
    </div>
  );
}

import { useEffect, useState, useCallback, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Save, ChevronDown } from 'lucide-react';

import PageHeader from '../../components/common/PageHeader';
import Loader from '../../components/common/Loader';
import ErrorState from '../../components/common/ErrorState';
import StepReferenceList from '../../components/pipeline/StepReferenceList';
import SqlQueryPanel from '../../components/pipeline/SqlQueryPanel';
import RequestBuilder from '../../components/steptypes/RequestBuilder';
import { useToast } from '../../context/ToastContext';
import jobConfigService from '../../services/jobConfigService';
import processStepService from '../../services/processStepService';
import { STRATEGIES, READ_TYPES, ACK_TYPES, FAILURE_STRATEGIES, PAGINATION_TYPES, REFERENCE_ID_TYPES } from '../../constants/pipeline';
import { isValidCron, describeCron, nextRunTimes } from '../../utils/cron';
import dayjs from 'dayjs';
import './JobConfigBuilder.css';

function emptyConfig() {
  return {
    name: '',
    entity: '',
    strategy: 'SIMULTANEOUS_READ_WRITE',
    trigger: null,
    read: {
      type: 'API',
      parallelThreads: 1,
      maxRetryCount: 3,
      failureStrategy: 'ABORT',
      params: { request: { endpoint: {}, headers: {}, body: [], variables: [] }, response: null, pagination: { type: 'offset', offsetVariable: 'OFFSET', batchSize: 1000, hasNext: 'data' } },
    },
    process: [],
    sink: { maxRetryCount: 3, batchSize: 1000, referenceId: { type: 'context', value: '' }, steps: [] },
    ack: null,
    postComplete: null,
    report: { emails: [], notificationTemplateId: '', jobName: '' },
  };
}

function Section({ title, description, children, actions }) {
  return (
    <div className="panel-card builder-section">
      <div className="builder-section-header">
        <div>
          <h2 className="card-heading" style={{ marginBottom: description ? '0.25rem' : 0 }}>{title}</h2>
          {description && <p className="builder-section-desc">{description}</p>}
        </div>
        {actions}
      </div>
      {children}
    </div>
  );
}

export default function JobConfigBuilder() {
  const { name } = useParams();
  const navigate = useNavigate();
  const { showToast } = useToast();
  const isNew = !name;

  const [config, setConfig] = useState(isNew ? emptyConfig() : null);
  const [catalog, setCatalog] = useState([]);
  const [otherJobs, setOtherJobs] = useState([]);
  const [loading, setLoading] = useState(!isNew);
  const [error, setError] = useState(null);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const [steps, jobs] = await Promise.all([
        processStepService.getSteps(),
        jobConfigService.getConfigs(50, 0),
      ]);
      setCatalog(steps);
      setOtherJobs(jobs.filter((j) => j.name !== name));

      if (!isNew) {
        const existing = await jobConfigService.getConfigByName(name);
        setConfig(existing);
      }
    } catch (e) {
      setError('Failed to load job configuration.');
    } finally {
      setLoading(false);
    }
  }, [name, isNew]);

  useEffect(() => { load(); }, [load]);

  const update = (patch) => setConfig((c) => ({ ...c, ...patch }));
  const updateRead = (patch) => setConfig((c) => ({ ...c, read: { ...c.read, ...patch } }));
  const updateReadParams = (patch) => setConfig((c) => ({ ...c, read: { ...c.read, params: { ...c.read.params, ...patch } } }));
  const updateSink = (patch) => setConfig((c) => ({ ...c, sink: { ...c.sink, ...patch } }));
  const updateAck = (patch) => setConfig((c) => ({ ...c, ack: { ...(c.ack || { type: 'POLL', steps: [] }), ...patch } }));
  const updateReport = (patch) => setConfig((c) => ({ ...c, report: { ...(c.report || {}), ...patch } }));

  const cronValidation = useMemo(
    () => (config?.trigger?.cron ? isValidCron(config.trigger.cron) : { valid: true }),
    [config?.trigger?.cron]
  );
  const cronDescription = config?.trigger?.cron && cronValidation.valid ? describeCron(config.trigger.cron) : null;
  const cronPreview = useMemo(() => {
    if (!config?.trigger?.cron || !cronValidation.valid) return [];
    try { return nextRunTimes(config.trigger.cron, 3); } catch { return []; }
  }, [config?.trigger?.cron, cronValidation.valid]);

  const handleSave = async () => {
    if (!config.name.trim()) {
      showToast('Job name is required.', 'error');
      return;
    }
    setSaving(true);
    try {
      await jobConfigService.upsertConfig(config);
      showToast(`${config.name} saved.`, 'success');
      navigate('/job-configuration');
    } catch (e) {
      showToast(e.message || 'Failed to save job configuration.', 'error');
    } finally {
      setSaving(false);
    }
  };

  if (error) {
    return (
      <div>
        <PageHeader title="Job Configuration" trail={[{ label: 'Job Configuration', onClick: () => navigate('/job-configuration') }]} />
        <ErrorState description={error} onRetry={load} />
      </div>
    );
  }

  if (loading || !config) {
    return (
      <div>
        <PageHeader title="Job Configuration" trail={[{ label: 'Job Configuration', onClick: () => navigate('/job-configuration') }]} />
        <Loader label="Loading…" />
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title={isNew ? 'New Job Configuration' : `Edit — ${config.name}`}
        trail={[{ label: 'Job Configuration', onClick: () => navigate('/job-configuration') }, { label: isNew ? 'New' : config.name }]}
        actions={
          <button className="btn-primary" onClick={handleSave} disabled={saving}>
            <Save size={16} />
            {saving ? 'Saving…' : 'Save Job Configuration'}
          </button>
        }
      />

      <Section title="Basics">
        <div className="field-grid">
          <label className="field-label">
            Name
            <input className="text-input mono" value={config.name} disabled={!isNew} onChange={(e) => update({ name: e.target.value })} />
          </label>
          <label className="field-label">
            Entity
            <input className="text-input mono" value={config.entity || ''} onChange={(e) => update({ entity: e.target.value })} />
          </label>
          <label className="field-label">
            Strategy
            <select className="select-control" value={config.strategy} onChange={(e) => update({ strategy: e.target.value })}>
              {STRATEGIES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </label>
        </div>
      </Section>

      <Section
        title="Trigger"
        description="Most jobs here run manually or via another job's post-complete chain — a schedule is optional."
      >
        <div className="field-grid" style={{ marginBottom: config.trigger ? '0.85rem' : 0 }}>
          <label className="field-label">
            Mode
            <select
              className="select-control"
              value={config.trigger ? 'SCHEDULER' : 'MANUAL'}
              onChange={(e) => update({ trigger: e.target.value === 'SCHEDULER' ? { type: 'SCHEDULER', cron: '0 0 6 * * *' } : null })}
            >
              <option value="MANUAL">Manual / chained only</option>
              <option value="SCHEDULER">Scheduled (cron)</option>
            </select>
          </label>
        </div>

        {config.trigger && (
          <div>
            <label className="field-label" style={{ marginBottom: '0.6rem' }}>
              Cron expression
              <input
                className={`text-input mono ${!cronValidation.valid ? 'jolt-textarea--error' : ''}`}
                value={config.trigger.cron}
                onChange={(e) => update({ trigger: { ...config.trigger, cron: e.target.value } })}
              />
            </label>
            {!cronValidation.valid ? (
              <p className="jolt-error">{cronValidation.message}</p>
            ) : (
              <p className="req-hint" style={{ color: 'var(--color-primary)', fontWeight: 600 }}>{cronDescription}</p>
            )}
            {cronPreview.length > 0 && (
              <p className="req-hint">Next: {cronPreview.map((d) => dayjs(d).format('MMM D, HH:mm')).join(' · ')}</p>
            )}
            <p className="builder-warning">Note: cron changes currently require a service restart to take effect.</p>
          </div>
        )}
      </Section>

      <Section title="Read Config" description="Where records are pulled from.">
        <div className="field-grid" style={{ marginBottom: '0.85rem' }}>
          <label className="field-label">
            Type
            <select className="select-control" value={config.read.type} onChange={(e) => updateRead({ type: e.target.value })}>
              {READ_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </label>
          <label className="field-label">
            Max retry count
            <input className="text-input" type="number" value={config.read.maxRetryCount ?? ''} onChange={(e) => updateRead({ maxRetryCount: Number(e.target.value) })} />
          </label>
          <label className="field-label">
            Failure strategy
            <select className="select-control" value={config.read.failureStrategy || 'ABORT'} onChange={(e) => updateRead({ failureStrategy: e.target.value })}>
              {FAILURE_STRATEGIES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </label>
          {config.read.type === 'API' && (
            <label className="field-label">
              Parallel threads
              <input className="text-input" type="number" value={config.read.parallelThreads ?? ''} onChange={(e) => updateRead({ parallelThreads: Number(e.target.value) })} />
            </label>
          )}
        </div>

        {config.read.type === 'SQL' ? (
          <>
            <div className="field-grid" style={{ marginBottom: '0.85rem' }}>
              <label className="field-label">
                Data source
                <input className="text-input mono" value={config.read.params?.source || ''} onChange={(e) => updateReadParams({ source: e.target.value })} />
              </label>
            </div>
            <SqlQueryPanel
              request={config.read.params?.request}
              onChange={(request) => updateReadParams({ request })}
            />
          </>
        ) : (
          <RequestBuilder value={config.read.params} onChange={(params) => updateRead({ params: { ...config.read.params, ...params } })} />
        )}

        <h4 className="builder-subheading">Pagination</h4>
        <div className="field-grid">
          <label className="field-label">
            Type
            <select className="select-control" value={config.read.params?.pagination?.type || 'offset'} onChange={(e) => updateReadParams({ pagination: { ...config.read.params.pagination, type: e.target.value } })}>
              {PAGINATION_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </label>
          <label className="field-label">
            Batch size
            <input className="text-input" value={config.read.params?.pagination?.batchSize ?? ''} onChange={(e) => updateReadParams({ pagination: { ...config.read.params.pagination, batchSize: e.target.value } })} />
          </label>
          <label className="field-label">
            Offset/cursor variable
            <input className="text-input mono" value={config.read.params?.pagination?.offsetVariable || ''} onChange={(e) => updateReadParams({ pagination: { ...config.read.params.pagination, offsetVariable: e.target.value } })} />
          </label>
          {config.read.params?.pagination?.type === 'cursor' ? (
            <label className="field-label">
              Next-cursor JSON path
              <input className="text-input mono" value={config.read.params?.pagination?.nextCursorPath || ''} onChange={(e) => updateReadParams({ pagination: { ...config.read.params.pagination, nextCursorPath: e.target.value } })} />
            </label>
          ) : (
            <label className="field-label">
              "Has next" path
              <input className="text-input mono" value={config.read.params?.pagination?.hasNext || ''} onChange={(e) => updateReadParams({ pagination: { ...config.read.params.pagination, hasNext: e.target.value } })} />
            </label>
          )}
        </div>
      </Section>

      <Section title="Process Steps" description="Runs once per read batch, before the sink.">
        <StepReferenceList steps={config.process || []} onChange={(process) => update({ process })} catalog={catalog} />
      </Section>

      <Section title="Sink Config" description="Where transformed records are written.">
        <div className="field-grid" style={{ marginBottom: '1rem' }}>
          <label className="field-label">
            Max retry count
            <input className="text-input" type="number" value={config.sink.maxRetryCount ?? ''} onChange={(e) => updateSink({ maxRetryCount: Number(e.target.value) })} />
          </label>
          <label className="field-label">
            Batch size
            <input className="text-input" type="number" value={config.sink.batchSize ?? ''} onChange={(e) => updateSink({ batchSize: Number(e.target.value) })} />
          </label>
          <label className="field-label">
            Reference ID type
            <select className="select-control" value={config.sink.referenceId?.type || 'context'} onChange={(e) => updateSink({ referenceId: { ...config.sink.referenceId, type: e.target.value } })}>
              {REFERENCE_ID_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </label>
          <label className="field-label">
            Reference ID value
            <input className="text-input mono" value={config.sink.referenceId?.value || ''} onChange={(e) => updateSink({ referenceId: { ...config.sink.referenceId, value: e.target.value } })} />
          </label>
        </div>
        <StepReferenceList steps={config.sink.steps || []} onChange={(steps) => updateSink({ steps })} catalog={catalog} />
      </Section>

      <Section
        title="Ack Config"
        description="Optional — polls or confirms the sink's outcome and records success/failure per record."
        actions={
          <label className="req-toggle">
            <input type="checkbox" checked={!!config.ack} onChange={(e) => update({ ack: e.target.checked ? { type: 'POLL', successRecords: '', failedRecords: '', steps: [] } : null })} />
            Enabled
          </label>
        }
      >
        {config.ack && (
          <>
            <div className="field-grid" style={{ marginBottom: '1rem' }}>
              <label className="field-label">
                Type
                <select className="select-control" value={config.ack.type} onChange={(e) => updateAck({ type: e.target.value })}>
                  {ACK_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
              </label>
              <label className="field-label">
                Success records path
                <input className="text-input mono" value={config.ack.successRecords || ''} onChange={(e) => updateAck({ successRecords: e.target.value })} />
              </label>
              <label className="field-label">
                Failed records path
                <input className="text-input mono" value={config.ack.failedRecords || ''} onChange={(e) => updateAck({ failedRecords: e.target.value })} />
              </label>
            </div>
            <StepReferenceList steps={config.ack.steps || []} onChange={(steps) => updateAck({ steps })} catalog={catalog} />
          </>
        )}
      </Section>

      <Section title="Post-Complete" description="Trigger other jobs automatically when this one finishes.">
        {otherJobs.length === 0 ? (
          <p className="req-hint">No other job configs to chain to yet.</p>
        ) : (
          <div className="post-complete-grid">
            {otherJobs.map((job) => {
              const checked = config.postComplete?.triggerJobs?.includes(job.name) || false;
              return (
                <label key={job.name} className="post-complete-item">
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={(e) => {
                      const current = config.postComplete?.triggerJobs || [];
                      const next = e.target.checked ? [...current, job.name] : current.filter((n) => n !== job.name);
                      update({ postComplete: next.length ? { triggerJobs: next } : null });
                    }}
                  />
                  <span className="mono">{job.name}</span>
                </label>
              );
            })}
          </div>
        )}
      </Section>

      <Section title="Report" description="Email notification sent when the job finishes.">
        <div className="field-grid">
          <label className="field-label">
            Emails (comma-separated)
            <input
              className="text-input mono"
              value={(config.report?.emails || []).join(', ')}
              onChange={(e) => updateReport({ emails: e.target.value.split(',').map((s) => s.trim()).filter(Boolean) })}
            />
          </label>
          <label className="field-label">
            Notification template ID
            <input className="text-input mono" value={config.report?.notificationTemplateId || ''} onChange={(e) => updateReport({ notificationTemplateId: e.target.value })} />
          </label>
        </div>
      </Section>
    </div>
  );
}

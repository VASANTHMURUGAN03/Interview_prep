import { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { GitPullRequest } from 'lucide-react';
import dayjs from 'dayjs';

import PageHeader from '../../components/common/PageHeader';
import Loader from '../../components/common/Loader';
import ErrorState from '../../components/common/ErrorState';
import EmptyState from '../../components/common/EmptyState';
import StatusBadge from '../../components/common/StatusBadge';
import StepRow from '../../components/execution/StepRow';
import executionService from '../../services/executionService';
import './ExecutionDetail.css';

export default function ExecutionDetail() {
  const { jobName, jobExecutionId } = useParams();
  const navigate = useNavigate();

  const [overview, setOverview] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await executionService.getExecutionOverview(jobExecutionId);
      setOverview(data);
    } catch (e) {
      setError(e.message || 'Failed to load execution detail.');
    } finally {
      setLoading(false);
    }
  }, [jobExecutionId]);

  useEffect(() => { load(); }, [load]);

  const trail = [
    { label: 'Jobs', onClick: () => navigate('/jobs') },
    { label: jobName, onClick: () => navigate(`/jobs/${encodeURIComponent(jobName)}/instances`) },
    { label: jobExecutionId?.slice(0, 8) },
  ];

  if (error) {
    return (
      <div>
        <PageHeader title="Execution Detail" trail={trail} />
        <ErrorState description={error} onRetry={load} />
      </div>
    );
  }

  const execution = overview?.execution;
  const readBatches = overview?.readBatches || [];
  const writeBatches = overview?.writeBatches || [];
  const stepSummary = overview?.stepSummary || [];

  const goToRetries = (batchId, batchType) => {
    navigate(`/jobs/${encodeURIComponent(jobName)}/instances/${jobExecutionId}/batches/${batchId}/retries?batchType=${batchType}`);
  };

  return (
    <div>
      <PageHeader title="Execution Detail" trail={trail} />

      {loading ? (
        <Loader label="Loading execution…" />
      ) : (
        <>
          <div className="panel-card exec-summary">
            <div className="exec-summary-item">
              <span className="exec-summary-label">Status</span>
              <StatusBadge status={execution.status} />
            </div>
            <div className="exec-summary-item">
              <span className="exec-summary-label">Triggered By</span>
              <span className="mono">{execution.triggeredBy || '—'}</span>
            </div>
            <div className="exec-summary-item">
              <span className="exec-summary-label">Created</span>
              <span className="mono">{dayjs(execution.createdAt).format('MMM D, HH:mm:ss')}</span>
            </div>
            <div className="exec-summary-item">
              <span className="exec-summary-label">Updated</span>
              <span className="mono">{dayjs(execution.updatedAt).format('MMM D, HH:mm:ss')}</span>
            </div>
            {execution.errorMessage && (
              <div className="exec-summary-item exec-summary-item--full">
                <span className="exec-summary-label">Error</span>
                <span className="exec-error-message">{execution.errorMessage}</span>
              </div>
            )}
          </div>

          <div className="panel-card exec-steps">
            <h2 className="card-heading">Step Summary</h2>
            <p className="exec-steps-hint">
              Aggregated success/failed/running counts per step, across every batch that ran it in this execution.
            </p>
            {stepSummary.length === 0 ? (
              <EmptyState title="No step data yet" description="Steps will appear here once batches start processing." />
            ) : (
              stepSummary.map((step) => <StepRow key={step.stepName} step={step} />)
            )}
          </div>

          <div className="panel-card exec-steps">
            <h2 className="card-heading">Read Batches</h2>
            {readBatches.length === 0 ? (
              <EmptyState title="No read batches yet" />
            ) : (
              <div className="table-scroll">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Batch #</th>
                      <th>Status</th>
                      <th>Retry Count</th>
                      <th>Remarks</th>
                      <th>Updated</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {readBatches.map((batch) => (
                      <tr key={batch.id}>
                        <td className="mono">{batch.batchNo}</td>
                        <td><StatusBadge status={batch.status} size="sm" /></td>
                        <td>{batch.retryCount ?? 0}</td>
                        <td className="exec-remarks">{batch.remarks || '—'}</td>
                        <td className="mono">{dayjs(batch.updatedAt).format('MMM D, HH:mm')}</td>
                        <td>
                          {batch.status === 'FAILED' && (
                            <button className="btn-ghost row-action-btn" onClick={() => goToRetries(batch.id, 'READ')}>
                              <GitPullRequest size={13} /> Retry Info
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <div className="panel-card exec-steps">
            <h2 className="card-heading">Write Batches</h2>
            {writeBatches.length === 0 ? (
              <EmptyState title="No write batches yet" />
            ) : (
              <div className="table-scroll">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Entity</th>
                      <th>Status</th>
                      <th>Error</th>
                      <th>Updated</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {writeBatches.map((batch) => (
                      <tr key={batch.id}>
                        <td className="mono">{batch.entity}</td>
                        <td><StatusBadge status={batch.status} size="sm" /></td>
                        <td className="exec-remarks">{batch.errorMessage || '—'}</td>
                        <td className="mono">{dayjs(batch.updatedAt).format('MMM D, HH:mm')}</td>
                        <td>
                          <button className="btn-ghost row-action-btn" onClick={() => goToRetries(batch.id, 'WRITE')}>
                            <GitPullRequest size={13} /> Related Retries
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}

import { useEffect, useState, useCallback, Fragment } from 'react';
import { ChevronDown, ChevronRight, History, ArrowUpDown } from 'lucide-react';
import dayjs from 'dayjs';

import PageHeader from '../../components/common/PageHeader';
import Loader from '../../components/common/Loader';
import ErrorState from '../../components/common/ErrorState';
import EmptyState from '../../components/common/EmptyState';
import Pagination from '../../components/common/Pagination';
import auditService from '../../services/auditService';
import './AuditHistory.css';

const ACTIONS = ['CONFIG_CREATED', 'CONFIG_UPDATED', 'JOB_ENABLED', 'JOB_DISABLED', 'CRON_CHANGED', 'MANUAL_EXECUTION'];
const SORT_FIELDS = [
  { value: 'timestamp', label: 'Timestamp' },
  { value: 'jobName', label: 'Job Name' },
  { value: 'action', label: 'Action' },
  { value: 'username', label: 'User' },
];

const ACTION_LABELS = {
  CONFIG_CREATED: 'Config Created',
  CONFIG_UPDATED: 'Config Updated',
  JOB_ENABLED: 'Job Enabled',
  JOB_DISABLED: 'Job Disabled',
  CRON_CHANGED: 'Cron Changed',
  MANUAL_EXECUTION: 'Manual Execution',
};

const ACTION_TONE = {
  CONFIG_CREATED: 'audit-tone-success',
  CONFIG_UPDATED: 'audit-tone-info',
  JOB_ENABLED: 'audit-tone-success',
  JOB_DISABLED: 'audit-tone-danger',
  CRON_CHANGED: 'audit-tone-warning',
  MANUAL_EXECUTION: 'audit-tone-info',
};

function prettyValue(raw) {
  if (!raw) return null;
  try {
    return JSON.stringify(JSON.parse(raw), null, 2);
  } catch {
    return raw; // not JSON (e.g. a plain cron string) — show as-is
  }
}

export default function AuditHistory() {
  const [jobName, setJobName] = useState('');
  const [userId, setUserId] = useState('');
  const [action, setAction] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [sortBy, setSortBy] = useState('timestamp');
  const [sortDirection, setSortDirection] = useState('DESC');
  const [page, setPage] = useState(0);

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [expandedId, setExpandedId] = useState(null);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await auditService.search({
        jobName, userId, action,
        from: from ? dayjs(from).startOf('day').toISOString() : undefined,
        to: to ? dayjs(to).endOf('day').toISOString() : undefined,
        page, size: 20, sortBy, sortDirection,
      });
      setData(result);
    } catch (e) {
      setError(e.message || 'Failed to load audit history.');
    } finally {
      setLoading(false);
    }
  }, [jobName, userId, action, from, to, page, sortBy, sortDirection]);

  useEffect(() => { load(); }, [load]);

  const applyFilters = (e) => {
    e.preventDefault();
    setPage(0);
    load();
  };

  const toggleDirection = () => setSortDirection((d) => (d === 'DESC' ? 'ASC' : 'DESC'));

  if (error) {
    return (
      <div>
        <PageHeader title="Audit History" />
        <ErrorState description={error} onRetry={load} />
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="Audit History" />

      <form className="panel-card audit-filters" onSubmit={applyFilters}>
        <input
          className="text-input"
          placeholder="Job name…"
          value={jobName}
          onChange={(e) => setJobName(e.target.value)}
        />
        <input
          className="text-input"
          placeholder="User ID…"
          value={userId}
          onChange={(e) => setUserId(e.target.value)}
        />
        <div className="select-wrapper">
          <select className="select-control" value={action} onChange={(e) => setAction(e.target.value)}>
            <option value="">All Actions</option>
            {ACTIONS.map((a) => <option key={a} value={a}>{ACTION_LABELS[a]}</option>)}
          </select>
          <ChevronDown size={15} className="select-chevron" />
        </div>
        <input className="text-input" type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        <input className="text-input" type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        <button className="btn-primary" type="submit">Apply</button>
      </form>

      <div className="audit-sort-row">
        <span className="audit-sort-label">Sort by</span>
        <div className="select-wrapper">
          <select className="select-control" value={sortBy} onChange={(e) => { setSortBy(e.target.value); setPage(0); }}>
            {SORT_FIELDS.map((f) => <option key={f.value} value={f.value}>{f.label}</option>)}
          </select>
          <ChevronDown size={15} className="select-chevron" />
        </div>
        <button className="btn-ghost row-action-btn" onClick={toggleDirection}>
          <ArrowUpDown size={13} /> {sortDirection === 'DESC' ? 'Newest first' : 'Oldest first'}
        </button>
      </div>

      {loading ? (
        <Loader label="Loading audit history…" />
      ) : !data || data.content.length === 0 ? (
        <EmptyState icon={History} title="No audit records found" description="Try adjusting the filters above." />
      ) : (
        <div className="panel-card">
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th></th>
                  <th>Timestamp</th>
                  <th>Job Name</th>
                  <th>Action</th>
                  <th>User</th>
                  <th>Remarks</th>
                </tr>
              </thead>
              <tbody>
                {data.content.map((row) => {
                  const isOpen = expandedId === row.id;
                  const before = prettyValue(row.previousValue);
                  const after = prettyValue(row.newValue);
                  return (
                    <Fragment key={row.id}>
                      <tr className="audit-row" onClick={() => setExpandedId(isOpen ? null : row.id)}>
                        <td>
                          <ChevronRight size={15} className={`audit-chevron ${isOpen ? 'audit-chevron--open' : ''}`} />
                        </td>
                        <td className="mono">{dayjs(row.timestamp).format('MMM D, HH:mm:ss')}</td>
                        <td className="mono">{row.jobName || '—'}</td>
                        <td><span className={`audit-tone ${ACTION_TONE[row.action] || ''}`}>{ACTION_LABELS[row.action] || row.action}</span></td>
                        <td>{row.username || row.userId || 'system'}</td>
                        <td className="exec-remarks">{row.remarks || '—'}</td>
                      </tr>

                      {isOpen && (before || after) && (
                        <tr className="audit-detail-row">
                          <td colSpan={6}>
                            <div className="audit-detail fade-in-up">
                              <div className="audit-detail-grid">
                                <div>
                                  <span className="req-hint">Before</span>
                                  <pre className="audit-json">{before || '— none —'}</pre>
                                </div>
                                <div>
                                  <span className="req-hint">After</span>
                                  <pre className="audit-json">{after || '— none —'}</pre>
                                </div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
          <Pagination
            page={data.currentPage}
            totalPages={data.totalPages}
            totalElements={data.totalElements}
            onChange={setPage}
          />
        </div>
      )}
    </div>
  );
}

import { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { GitPullRequest } from 'lucide-react';
import dayjs from 'dayjs';

import PageHeader from '../../components/common/PageHeader';
import Loader from '../../components/common/Loader';
import ErrorState from '../../components/common/ErrorState';
import EmptyState from '../../components/common/EmptyState';
import StatusBadge from '../../components/common/StatusBadge';
import relatedRetriesService from '../../services/relatedRetriesService';

export default function RelatedRetries() {
  const { jobName, jobExecutionId, batchId } = useParams();
  const [searchParams] = useSearchParams();
  const batchType = searchParams.get('batchType') || 'WRITE';
  const navigate = useNavigate();

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await relatedRetriesService.getRetries(jobExecutionId, batchId, batchType);
      setData(result);
    } catch (e) {
      setError(e.message || 'Failed to load related retries.');
    } finally {
      setLoading(false);
    }
  }, [jobExecutionId, batchId, batchType]);

  useEffect(() => { load(); }, [load]);

  const trail = [
    { label: 'Jobs', onClick: () => navigate('/jobs') },
    { label: jobName, onClick: () => navigate(`/jobs/${encodeURIComponent(jobName)}/instances`) },
    { label: jobExecutionId?.slice(0, 8), onClick: () => navigate(`/jobs/${encodeURIComponent(jobName)}/instances/${jobExecutionId}`) },
    { label: 'Related Retries' },
  ];

  if (error) {
    return (
      <div>
        <PageHeader title="Related Retries" trail={trail} />
        <ErrorState description={error} onRetry={load} />
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="Related Retries" trail={trail} />

      {loading ? (
        <Loader label="Loading retry info…" />
      ) : batchType === 'READ' ? (
        // Read-side: no chain to walk — a read-batch retry mutates the same
        // document in place. Show current state, not a fake attempt history.
        <div className="panel-card">
          <p className="exec-steps-hint" style={{ marginBottom: '1rem' }}>
            Read-batch retries don't create a linked history the way write-batch retries do —
            this is the batch's current state after however many retry attempts it's had.
          </p>
          <div className="exec-summary">
            <div className="exec-summary-item">
              <span className="exec-summary-label">Batch #</span>
              <span className="mono">{data.batchNo}</span>
            </div>
            <div className="exec-summary-item">
              <span className="exec-summary-label">Status</span>
              <StatusBadge status={data.status} />
            </div>
            <div className="exec-summary-item">
              <span className="exec-summary-label">Retry Count</span>
              <span className="mono">{data.retryCount}</span>
            </div>
            {data.remarks && (
              <div className="exec-summary-item exec-summary-item--full">
                <span className="exec-summary-label">Remarks</span>
                <span className="exec-error-message">{data.remarks}</span>
              </div>
            )}
          </div>
        </div>
      ) : !data || data.length === 0 ? (
        <EmptyState icon={GitPullRequest} title="No retries linked to this batch" />
      ) : (
        <div className="panel-card">
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Batch ID</th>
                  <th>Entity</th>
                  <th>Status</th>
                  <th>Error</th>
                  <th>Created</th>
                </tr>
              </thead>
              <tbody>
                {data.map((batch, i) => (
                  <tr key={batch.id}>
                    <td className="mono">{i === 0 ? 'Original' : `Retry ${i}`} · {batch.id.slice(0, 8)}</td>
                    <td className="mono">{batch.entity}</td>
                    <td><StatusBadge status={batch.status} size="sm" /></td>
                    <td className="exec-remarks">{batch.errorMessage || '—'}</td>
                    <td className="mono">{dayjs(batch.createdAt).format('MMM D, HH:mm:ss')}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

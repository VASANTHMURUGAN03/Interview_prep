import { useState } from 'react';
import { Plus, Trash2, Play } from 'lucide-react';

import Modal from '../common/Modal';
import { useToast } from '../../context/ToastContext';
import jobConfigService from '../../services/jobConfigService';
import './TriggerJobModal.css';

export default function TriggerJobModal({ job, onClose, onTriggered }) {
  const { showToast } = useToast();
  const [params, setParams] = useState([{ key: '', value: '' }]);
  const [submitting, setSubmitting] = useState(false);

  const updateParam = (index, field, value) => {
    setParams((prev) => prev.map((p, i) => (i === index ? { ...p, [field]: value } : p)));
  };

  const addParam = () => setParams((prev) => [...prev, { key: '', value: '' }]);
  const removeParam = (index) => setParams((prev) => prev.filter((_, i) => i !== index));

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      // Backend expects a plain { key: value } map, not an array of pairs.
      const paramsMap = Object.fromEntries(
        params.filter((p) => p.key.trim() !== '').map((p) => [p.key.trim(), p.value])
      );

      const result = await jobConfigService.triggerJob(job.name, paramsMap);
      showToast(`${job.name} triggered — execution ${result.jobExecutionId} started.`, 'success');
      onTriggered?.(result);
      onClose();
    } catch (err) {
      showToast(err.message || 'Failed to trigger job.', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Modal
      title={`Trigger ${job.name}`}
      onClose={onClose}
      width={520}
      footer={
        <>
          <button className="btn-secondary" onClick={onClose} disabled={submitting}>
            Cancel
          </button>
          <button className="btn-primary" onClick={handleSubmit} disabled={submitting}>
            <Play size={16} />
            {submitting ? 'Triggering…' : 'Trigger Job'}
          </button>
        </>
      }
    >
      <p className="trigger-modal-hint">
        This runs {job.name} immediately, outside its regular schedule. Any parameters below are
        stored against the execution — the pipeline doesn't yet consume them to override reader
        behavior, so leave these blank unless you specifically know why you're adding one.
      </p>

      <div className="param-rows">
        {params.map((p, i) => (
          <div className="param-row" key={i}>
            <input
              className="text-input"
              placeholder="Parameter name"
              value={p.key}
              onChange={(e) => updateParam(i, 'key', e.target.value)}
            />
            <input
              className="text-input"
              placeholder="Value"
              value={p.value}
              onChange={(e) => updateParam(i, 'value', e.target.value)}
            />
            <button
              className="param-row-remove"
              onClick={() => removeParam(i)}
              aria-label="Remove parameter"
              disabled={params.length === 1}
            >
              <Trash2 size={16} />
            </button>
          </div>
        ))}
      </div>

      <button className="btn-ghost add-param-btn" onClick={addParam}>
        <Plus size={16} />
        Add Parameter
      </button>
    </Modal>
  );
}

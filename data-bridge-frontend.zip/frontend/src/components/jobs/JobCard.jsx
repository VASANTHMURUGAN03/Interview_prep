import { Play, ChevronRight, Clock, CalendarClock } from 'lucide-react';
import dayjs from 'dayjs';

import StatusBadge from '../common/StatusBadge';
import './JobCard.css';

export default function JobCard({ job, onOpen, onTrigger }) {
  return (
    <div className={`job-card stagger-in job-card--${(job.lastStatus || '').toLowerCase()}`} onClick={() => onOpen(job)}>
      <div className="job-card-header">
        <div className="job-card-identity">
          <div className="job-card-icon">
            <span className="job-card-icon-initial">{job.name?.[0]?.toUpperCase() || '?'}</span>
          </div>
          <h3 className="job-card-title mono">{job.name}</h3>
        </div>
        {job.lastStatus ? <StatusBadge status={job.lastStatus} size="sm" /> : <span className="step-ref-type">{job.active ? 'ACTIVE' : 'INACTIVE'}</span>}
      </div>

      <div className="job-card-stats">
        <div className="job-card-stat">
          <span className="job-card-stat-value job-card-stat-value--time">
            {job.lastRun ? dayjs(job.lastRun).format('MMM D, HH:mm') : '—'}
          </span>
          <span className="job-card-stat-label"><Clock size={11} /> Last Run</span>
        </div>
        <div className="job-card-stat-divider" />
        <div className="job-card-stat">
          <span className="job-card-stat-value job-card-stat-value--time">
            {job.nextRun ? dayjs(job.nextRun).format('MMM D, HH:mm') : '—'}
          </span>
          <span className="job-card-stat-label"><CalendarClock size={11} /> Next Run</span>
        </div>
      </div>

      <div className="job-card-footer">
        <button
          className="btn-secondary btn-sm job-card-trigger"
          onClick={(e) => { e.stopPropagation(); onTrigger(job); }}
          disabled={!job.active}
        >
          <Play size={13} />
          Trigger
        </button>
        <span className="job-card-view">
          View details
          <ChevronRight size={16} className="job-card-chevron" />
        </span>
      </div>
    </div>
  );
}

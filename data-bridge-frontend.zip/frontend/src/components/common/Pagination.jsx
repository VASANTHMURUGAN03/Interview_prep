import { ChevronLeft, ChevronRight } from 'lucide-react';
import './Pagination.css';

/**
 * Two modes:
 * - totalPages/totalElements known (not available from most real endpoints
 *   in this app, which return a plain array — see backend/README.md's
 *   documented limitation) → shows "Page N of M · X total".
 * - isLastPage only (real-world default here) → shows "Page N" and
 *   disables Next once a short/empty page comes back.
 */
export default function Pagination({ page, totalPages, totalElements, isLastPage, onChange }) {
  const hasTotals = typeof totalPages === 'number';
  if (hasTotals && totalPages <= 1) return null;

  return (
    <div className="pagination">
      <span className="pagination-summary">
        {hasTotals ? `Page ${page + 1} of ${totalPages} · ${totalElements} total` : `Page ${page + 1}`}
      </span>
      <div className="pagination-controls">
        <button
          className="pagination-btn"
          onClick={() => onChange(page - 1)}
          disabled={page === 0}
          aria-label="Previous page"
        >
          <ChevronLeft size={16} />
        </button>
        <button
          className="pagination-btn"
          onClick={() => onChange(page + 1)}
          disabled={hasTotals ? page >= totalPages - 1 : isLastPage}
          aria-label="Next page"
        >
          <ChevronRight size={16} />
        </button>
      </div>
    </div>
  );
}

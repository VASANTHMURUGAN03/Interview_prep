import { CheckCircle2, XCircle, Loader2 } from 'lucide-react';
import './StepRow.css';

/**
 * Real implementation — replaces the old fixed 5-step read/process/write
 * timeline, which was fabricated mock data. The real
 * GET .../step-executions/summary endpoint only gives aggregated
 * success/failed/running counts per step (across every batch that ran
 * it), not per-batch timing — so this shows a proportional success/fail
 * bar and counts, not a Gantt chart. Honest to what the data actually is.
 */
export default function StepRow({ step }) {
  const total = step.totalCount || 1;
  const successPct = Math.round((step.successCount / total) * 100);
  const failedPct = Math.round((step.failedCount / total) * 100);
  const runningPct = Math.max(0, 100 - successPct - failedPct);

  return (
    <div className="step-row">
      <div className="step-row-header">
        <span className="step-row-name mono">{step.stepName}</span>
        <span className="step-ref-type">{step.stepType}</span>
        <span className="step-row-counts">
          <span className="step-count step-count--success"><CheckCircle2 size={13} /> {step.successCount}</span>
          <span className="step-count step-count--failed"><XCircle size={13} /> {step.failedCount}</span>
          {step.runningCount > 0 && (
            <span className="step-count step-count--running"><Loader2 size={13} /> {step.runningCount}</span>
          )}
        </span>
      </div>

      <div className="step-bar-track">
        <div className="step-bar">
          <span className="step-bar-seg step-bar-seg--write" style={{ width: `${successPct}%` }} title="Success" />
          <span className="step-bar-seg step-bar-seg--read" style={{ width: `${failedPct}%` }} title="Failed" />
          {runningPct > 0 && <span className="step-bar-seg step-bar-seg--process" style={{ width: `${runningPct}%` }} title="Running" />}
        </div>
      </div>
    </div>
  );
}

import { LayoutDashboard, Briefcase, SlidersHorizontal, Layers, History } from 'lucide-react';

export const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', path: '/', icon: LayoutDashboard, group: 'Overview' },
  { id: 'jobs', label: 'Jobs', path: '/jobs', icon: Briefcase, group: 'Overview' },
  { id: 'job-configuration', label: 'Job Configuration', path: '/job-configuration', icon: SlidersHorizontal, group: 'Configuration' },
  { id: 'process-steps', label: 'Process Step Library', path: '/process-steps', icon: Layers, group: 'Configuration' },
  { id: 'audit', label: 'Audit History', path: '/audit', icon: History, group: 'Configuration' },
];

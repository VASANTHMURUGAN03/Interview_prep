import { LayoutDashboard, Briefcase, SlidersHorizontal, Database, Layers } from 'lucide-react';

export const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', path: '/', icon: LayoutDashboard, group: 'Overview' },
  { id: 'jobs', label: 'Jobs', path: '/jobs', icon: Briefcase, group: 'Overview' },
  { id: 'data-migration-search', label: 'Migration Search', path: '/data-migration-search', icon: Database, group: 'Overview' },
  { id: 'job-configuration', label: 'Job Configuration', path: '/job-configuration', icon: SlidersHorizontal, group: 'Configuration' },
  { id: 'process-steps', label: 'Process Step Library', path: '/process-steps', icon: Layers, group: 'Configuration' },
];

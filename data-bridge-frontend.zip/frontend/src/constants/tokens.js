/**
 * JS-readable mirror of src/styles/tokens.css. Palette anchored on Star
 * Health's real brand navy (#173172, sampled from the provided logo).
 */

export const gradient = {
  start: '#173172',
  end: '#2D4F9E',
  css: 'linear-gradient(135deg, #173172 0%, #2D4F9E 100%)',
};

export const colors = {
  canvas: '#F5F7FC',
  surface: '#FFFFFF',
  surfaceHover: '#F7F9FD',
  surfaceSunken: '#EEF1F9',
  ink: '#10182C',
  inkMuted: '#57607F',
  inkFaint: '#96A0BE',
  line: '#E2E6F2',

  panel: '#080D1B',
  panelElevated: '#131C33',
  panelLine: '#1E2A48',
  panelText: '#C7CFE8',
  panelTextMuted: '#6F7CA0',

  primary: '#173172',
  primaryHover: '#0F2456',
  accent: '#C9962E',

  success: '#158F52',
  successBg: '#DEF7E9',
  successText: '#0D5C34',

  danger: '#D33636',
  dangerBg: '#FBE3E3',
  dangerText: '#8A1F1F',

  info: '#2F5FE0',
  infoBg: '#E1E9FD',
  infoText: '#1B3A9C',

  warning: '#C9962E',
  warningBg: '#FBF3E1',
  warningText: '#7A5A16',

  orange: '#D6752A',
  orangeBg: '#FBE7D6',
  orangeText: '#813F0F',

  purple: '#7449C9',
  purpleBg: '#EAE1FA',
  purpleText: '#472A82',

  neutralBg: '#EEF1F9',
  neutralText: '#57607F',
};

export const statusColorMap = {
  COMPLETED: colors.success,
  SUCCESS: colors.success,
  FAILED: colors.danger,
  FAILURE: colors.danger,
  PARTIAL_FAILURE: '#DD6A5C',
  RUNNING: colors.info,
  STARTED: colors.info,
  IN_PROGRESS: colors.info,
  STOPPED: colors.orange,
  STOPPING: colors.orange,
  PENDING: colors.warning,
  QUEUED: colors.warning,
  ABANDONED: colors.purple,
};

export const layout = {
  sidebarWidth: 280,
  sidebarWidthCollapsed: 84,
  headerHeight: 68,
};

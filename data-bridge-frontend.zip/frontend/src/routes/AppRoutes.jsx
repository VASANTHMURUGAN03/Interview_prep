import { Suspense, lazy } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

import MainLayout from '../components/layout/MainLayout';
import ProtectedRoute from './ProtectedRoute';
import Loader from '../components/common/Loader';

const Dashboard = lazy(() => import('../pages/Dashboard/Dashboard'));
const JobsList = lazy(() => import('../pages/JobsList/JobsList'));
const JobInstances = lazy(() => import('../pages/JobInstances/JobInstances'));
const ExecutionDetail = lazy(() => import('../pages/ExecutionDetail/ExecutionDetail'));
const RelatedRetries = lazy(() => import('../pages/RelatedRetries/RelatedRetries'));
const JobConfiguration = lazy(() => import('../pages/JobConfiguration/JobConfiguration'));
const JobConfigBuilder = lazy(() => import('../pages/JobConfigBuilder/JobConfigBuilder'));
const ProcessStepLibrary = lazy(() => import('../pages/ProcessStepLibrary/ProcessStepLibrary'));
const AuditHistory = lazy(() => import('../pages/AuditHistory/AuditHistory'));
const NotFound = lazy(() => import('../pages/NotFound/NotFound'));

export default function AppRoutes() {
  return (
    <Suspense fallback={<div style={{ paddingTop: '4rem' }}><Loader label="Loading page…" /></div>}>
      <Routes>
        <Route
          element={
            <ProtectedRoute>
              <MainLayout />
            </ProtectedRoute>
          }
        >
          <Route path="/" element={<Dashboard />} />
          <Route path="/jobs" element={<JobsList />} />
          <Route path="/jobs/:jobName/instances" element={<JobInstances />} />
          <Route path="/jobs/:jobName/instances/:jobExecutionId" element={<ExecutionDetail />} />
          <Route path="/jobs/:jobName/instances/:jobExecutionId/batches/:batchId/retries" element={<RelatedRetries />} />
          <Route path="/job-configuration" element={<JobConfiguration />} />
          <Route path="/job-configuration/new" element={<JobConfigBuilder />} />
          <Route path="/job-configuration/:name/edit" element={<JobConfigBuilder />} />
          <Route path="/process-steps" element={<ProcessStepLibrary />} />
          <Route path="/audit" element={<AuditHistory />} />
          <Route path="*" element={<Navigate to="/not-found" replace />} />
        </Route>
        <Route path="/not-found" element={<NotFound />} />
      </Routes>
    </Suspense>
  );
}

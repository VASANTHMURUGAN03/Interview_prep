import apiClient from './apiClient';

/**
 * Real implementation — replaces the in-memory mock. Every method here
 * maps 1:1 to a real backend endpoint, proxied through the BFF at
 * /api/v1/job-configs/**. See backend/README.md and docs/GAP_ANALYSIS.md
 * for the full endpoint list this was built against.
 */
const jobConfigService = {
  /** Plain list — the real backend does not return page metadata (no
   *  totalElements/totalPages), unlike the old mock. */
  async getConfigs(limit, pageNumber) {
    return apiClient.get('/v1/job-configs', { params: { limit, pageNumber } });
  },

  /** Configs joined with latest execution + JobRunr scheduler state
   *  (lastRun, lastStatus, nextRun) — what the Job Configuration list page
   *  actually renders. */
  async getConfigSummaries(limit, pageNumber) {
    return apiClient.get('/v1/job-configs/summary', { params: { limit, pageNumber } });
  },

  async getConfigByName(name) {
    return apiClient.get(`/v1/job-configs/${encodeURIComponent(name)}`);
  },

  async upsertConfig(dto) {
    return apiClient.post('/v1/job-configs', dto);
  },

  /** Soft delete/disable. */
  async deleteConfigByName(name) {
    return apiClient.delete(`/v1/job-configs/${encodeURIComponent(name)}`);
  },

  /** Re-enable a disabled config. */
  async activateConfig(name) {
    return apiClient.post(`/v1/job-configs/${encodeURIComponent(name)}/activate`);
  },

  /** Dedicated cron-only update — doesn't touch the rest of the config. */
  async updateCron(name, cron) {
    return apiClient.patch(`/v1/job-configs/${encodeURIComponent(name)}/cron`, { cron });
  },

  /**
   * `params` are accepted and stored on the execution's context, but see
   * the backend's JobExecutionService.triggerJobWithContext() javadoc for
   * the honest limitation on how far they currently reach into the
   * pipeline — they're not yet consumed by VariableResolver.
   */
  async triggerJob(name, params) {
    return apiClient.post(
      `/v1/jobs/trigger/${encodeURIComponent(name)}`,
      params && Object.keys(params).length ? { params } : undefined
    );
  },

  async abortJob(jobUuid) {
    return apiClient.post(`/v1/jobs/abort/${encodeURIComponent(jobUuid)}`);
  },
};

export default jobConfigService;

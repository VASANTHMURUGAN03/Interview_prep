import apiClient from './apiClient';

/**
 * Real implementation. IMPORTANT asymmetry, not a bug: WRITE batches
 * return an array (a real retry chain — each retry is a linked, separate
 * document). READ batches return a single object (no chain exists — a
 * read-batch retry mutates the same document in place). See
 * docs/GAP_ANALYSIS.md for the full explanation.
 */
const relatedRetriesService = {
  async getRetries(jobExecutionId, batchId, batchType) {
    return apiClient.get(`/v1/jobs/executions/${jobExecutionId}/batches/${batchId}/retries`, {
      params: { batchType },
    });
  },
};

export default relatedRetriesService;

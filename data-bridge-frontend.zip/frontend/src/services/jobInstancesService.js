import apiClient from './apiClient';

/**
 * Real implementation. A "job instance" IS a JobExecutionEntity — there's
 * no separate instance-vs-execution split in the real model (that was a
 * mock-era assumption). "Stop" maps to the real abort endpoint; there is
 * no "Resume" — confirmed in the retry-mechanism analysis that abort is
 * terminal and no resume concept exists in this architecture, so that
 * action is intentionally not implemented here (see docs/GAP_ANALYSIS.md).
 */
const jobInstancesService = {
  async getInstances(jobName, { status, page = 0, size = 10 } = {}) {
    const content = await apiClient.get('/v1/jobs/executions', {
      params: { jobName, status: status || undefined, limit: size, pageNumber: page },
    });
    // Real backend returns a plain array, no page metadata — approximate
    // "last page" by whether a full page came back.
    return {
      content,
      currentPage: page,
      pageSize: size,
      isLastPage: content.length < size,
    };
  },

  async stopInstance(jobUuid) {
    return apiClient.post(`/v1/jobs/abort/${encodeURIComponent(jobUuid)}`);
  },
};

export default jobInstancesService;

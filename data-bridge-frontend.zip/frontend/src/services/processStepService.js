import apiClient from './apiClient';

/** Real implementation — replaces the in-memory mock. */
const processStepService = {
  async getSteps(limit, pageNumber) {
    return apiClient.get('/v1/process-steps/configs', { params: { limit, pageNumber } });
  },

  async getStepByName(name) {
    return apiClient.get(`/v1/process-steps/configs/${encodeURIComponent(name)}`);
  },

  async upsertStep(dto) {
    return apiClient.post('/v1/process-steps/configs', dto);
  },
};

export default processStepService;

import axios from 'axios';

/**
 * All real API calls go through the BFF (databridge-bff), not the core
 * backend directly — the BFF proxies everything under /api/v1/... and
 * aggregates a couple of endpoints (Dashboard, Execution Detail overview).
 *
 * Base URL is configurable via VITE_BFF_BASE_URL (see .env.example) so
 * this doesn't need a code change between local/QA/prod — defaults to the
 * BFF's local dev port.
 */
const API_BASE = import.meta.env.VITE_BFF_BASE_URL || 'http://localhost:8081/api';
const BFF_ROOT = API_BASE.replace(/\/api\/?$/, '');

const apiClient = axios.create({
  baseURL: API_BASE,
  headers: { 'Content-Type': 'application/json' },
});

/**
 * The BFF's two aggregation endpoints (/aggregate/dashboard/overview,
 * /aggregate/jobs/executions/{id}/overview) live at the BFF's root, not
 * under /api/** like every proxied backend call — they're not a
 * pass-through, they're BFF-native logic. Same envelope-unwrapping/error
 * handling as apiClient, just a different base path.
 */
const aggregateClient = axios.create({
  baseURL: BFF_ROOT,
  headers: { 'Content-Type': 'application/json' },
});

// Placeholder user identity until real auth/session exists (standing open
// item across this whole project) — the backend's audit system reads
// these two headers and defaults to "system" if absent, so sending a real
// name here just makes the Job Audit trail meaningful sooner rather than
// later. Swap for a real auth token/user context once that's decided.
const attachUserHeaders = (config) => {
  config.headers['X-User-Id'] = 'vasanth.murugan';
  config.headers['X-User-Name'] = 'Vasanth M';
  return config;
};

// Every backend response is wrapped as { statusCode, message, data } —
// unwrap it here so every service file can just deal with plain data,
// same as when they returned mock data directly. Errors are normalized to
// a plain Error(message) so existing `catch (e) { showToast(e.message) }`
// call sites across the app keep working unchanged.
const unwrapResponse = (response) => response.data?.data;
const normalizeError = (error) => {
  const message = error.response?.data?.message || error.message || 'Request failed';
  return Promise.reject(new Error(message));
};

apiClient.interceptors.request.use(attachUserHeaders);
apiClient.interceptors.response.use(unwrapResponse, normalizeError);

aggregateClient.interceptors.request.use(attachUserHeaders);
aggregateClient.interceptors.response.use(unwrapResponse, normalizeError);

export { aggregateClient };
export default apiClient;

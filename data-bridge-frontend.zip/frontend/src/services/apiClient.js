import axios from 'axios';

/**
 * All real API calls go through the BFF (databridge-bff), not the core
 * backend directly — the BFF proxies everything under /api/v1/... and
 * aggregates a couple of endpoints (Dashboard, Execution Detail overview).
 *
 * Base URL is configurable via VITE_BFF_BASE_URL (see .env.example) so
 * this doesn't need a code change between local/QA/prod — defaults to the
 * BFF's local dev port.
 */
const apiClient = axios.create({
  baseURL: import.meta.env.VITE_BFF_BASE_URL || 'http://localhost:8081/api',
  headers: { 'Content-Type': 'application/json' },
});

// Placeholder user identity until real auth/session exists (standing open
// item across this whole project) — the backend's audit system reads
// these two headers and defaults to "system" if absent, so sending a real
// name here just makes the Job Audit trail meaningful sooner rather than
// later. Swap for a real auth token/user context once that's decided.
apiClient.interceptors.request.use((config) => {
  config.headers['X-User-Id'] = 'vasanth.murugan';
  config.headers['X-User-Name'] = 'Vasanth M';
  return config;
});

// Every backend response is wrapped as { statusCode, message, data } —
// unwrap it here so every service file can just deal with plain data,
// same as when they returned mock data directly. Errors are normalized to
// a plain Error(message) so existing `catch (e) { showToast(e.message) }`
// call sites across the app keep working unchanged.
apiClient.interceptors.response.use(
  (response) => response.data?.data,
  (error) => {
    const message = error.response?.data?.message || error.message || 'Request failed';
    return Promise.reject(new Error(message));
  }
);

export default apiClient;

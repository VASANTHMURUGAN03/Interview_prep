import apiClient from './apiClient';

/**
 * GET /v1/audit returns a real Spring Data Page<AuditEntity> (unlike
 * almost every other list endpoint in this app, which return a plain
 * array — this is the one deliberate exception, since a filterable audit
 * table genuinely needs total counts). Default Jackson serialization of
 * PageImpl exposes the current page index as `number`, not `currentPage`
 * — normalized here so the page component doesn't need to know that.
 *
 * NOT verified against a live response — flagging so this is the first
 * place to check if the Audit screen shows a page-count mismatch.
 */
function normalizePage(raw) {
  return {
    content: raw?.content || [],
    totalElements: raw?.totalElements ?? 0,
    totalPages: raw?.totalPages ?? 1,
    currentPage: raw?.number ?? 0,
  };
}

const auditService = {
  async search({ jobName, userId, action, from, to, page = 0, size = 20, sortBy = 'timestamp', sortDirection = 'DESC' } = {}) {
    const raw = await apiClient.get('/v1/audit', {
      params: {
        jobName: jobName || undefined,
        userId: userId || undefined,
        action: action || undefined,
        from: from || undefined,
        to: to || undefined,
        page,
        size,
        sortBy,
        sortDirection,
      },
    });
    return normalizePage(raw);
  },

  async getHistoryByJob(jobName, page = 0, size = 20) {
    const raw = await apiClient.get(`/v1/audit/job/${encodeURIComponent(jobName)}`, {
      params: { page, size },
    });
    return normalizePage(raw);
  },
};

export default auditService;

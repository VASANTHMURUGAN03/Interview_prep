import { aggregateClient } from './apiClient';

/**
 * Real implementation. Uses the BFF's aggregate endpoint, which combines
 * the execution itself + read batches + write batches + step summary in
 * one call (fetched in parallel on the BFF side).
 */
const executionService = {
  async getExecutionOverview(jobExecutionId) {
    return aggregateClient.get(`/aggregate/jobs/executions/${encodeURIComponent(jobExecutionId)}/overview`);
  },
};

export default executionService;

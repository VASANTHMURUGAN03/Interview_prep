import { aggregateClient } from './apiClient';

/**
 * Real implementation. Uses the BFF's /aggregate/dashboard/overview
 * endpoint — one call that combines stats + top-failed-jobs +
 * execution-trends + recent-executions server-side (fetched in parallel
 * on the BFF), instead of 4 separate frontend requests.
 */
const dashboardService = {
  async getOverview(jobName, from, to) {
    return aggregateClient.get('/aggregate/dashboard/overview', {
      params: { jobName: jobName || undefined, from, to },
    });
  },
};

export default dashboardService;

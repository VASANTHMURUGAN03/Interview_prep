# Data Bridge

Scheduler & batch monitor — a redesigned UI, using the internal `sync-relay` project as a
visual/architectural reference, plus a new Job Configuration screen sync-relay doesn't have.

## What this is

- 7 real screens: Dashboard, Jobs, Job Instances, Execution Detail, Related Retries,
  Job Configuration (enable/disable schedulers, edit cron with validation, trigger one-time
  runs), Process Step Library, and Audit History. **Data Migration Search was removed** — it
  existed as a mock-era placeholder; the real search-by-execution API it would have needed
  (`GET /v1/jobs/executions/{id}/sync-records`) still exists on the backend if this ever comes
  back, but there's no UI for it right now, by explicit decision, not oversight.
- **Fresh visual identity** — moved off sync-relay's purple gradient/glassmorphism entirely.
  Now: deep teal accent (`#0E7C86`) on a cool slate-navy ink/canvas, a dark navy sidebar
  (`#101B2C`) instead of white, flat solid surfaces (no blur), Manrope for headings/wordmark +
  Inter for UI text + JetBrains Mono for anything literal (job names, timestamps, IDs). The
  status-badge color language (green/red/blue/orange/amber/purple) is kept since it's a
  functional convention, not a stylistic one. New signature motif: a "signal ping" — a small
  expanding ring on the live-status indicator — replacing the old spinning logo.
- Tech: React 18, **plain JS/JSX (no TypeScript)**, Vite, plain CSS (no Tailwind/MUI — matches
  sync-relay's actual approach rather than introducing a component library), react-router-dom,
  recharts, dayjs, lucide-react, axios.

## Backend integration status — complete

**Every service file is real.** No mock data remains anywhere in the app — `mockData.js`,
`mockUtils.js`, `jobsService.js`, `jobConfigsData.js`, `processStepsData.js`, and
`migrationSearchService.js` have all been deleted; nothing references them. Every one of the 8
remaining service files (`apiClient.js` plus 7 domain services) calls the BFF via
`apiClient`/`aggregateClient` — verified by grep, zero `delay()`-wrapped mock calls left.

- `services/apiClient.js` — Axios pointed at the BFF (`VITE_BFF_BASE_URL`, defaults to
  `http://localhost:8081/api`), unwraps the `{statusCode, message, data}` envelope, sends
  `X-User-Id`/`X-User-Name` headers (placeholder identity until real auth exists — those headers
  are what makes the Audit trail's "who did this" column meaningful today).
- `services/apiClient.js` also exports `aggregateClient` — same envelope handling, pointed at the
  BFF's root (`/aggregate/**`) rather than `/api/**`, since those two endpoints
  (Dashboard overview, Execution Detail overview) are BFF-native logic, not proxied pass-throughs.
- `services/auditService.js` (new) — the one endpoint that returns a real Spring `Page<T>`
  (everything else is a plain array, a documented backend limitation) — normalized in this
  service so the page component doesn't need to know that quirk.

**One real shape difference worth knowing**: most real endpoints return a plain array (no
`totalElements`/`totalPages`) — `Pagination.jsx` supports both a full-metadata mode (used only by
Audit History, since that's the one endpoint with real totals) and an `isLastPage`-only mode
(used everywhere else, including Job Instances).

## New — Audit History

`GET /v1/audit`, filterable by job name, user ID, action type, and date range, sortable, paginated
with real totals. Each row expands to show before/after values (pretty-printed JSON when the
stored value is JSON — e.g. a full job config snapshot; shown as plain text otherwise, e.g. a
before/after cron string) — satisfies the original "show before/after values where applicable"
requirement directly.


## Design refresh #2 — real palette change (latest)

The first "premium pass" only refined spacing/shadows within the same invented teal palette —
fair feedback that it didn't read as different. This pass actually changes the color system and
several structural visual choices:

- **New palette, anchored on the real brand**: primary is `#173172` — sampled directly from the
  Star Health logo file you uploaded (via `PIL.Image.getpixel`), not invented. Paired with a gold
  accent (`#C9962E`) — ties thematically to the star/rating mark and gives the UI a second color
  to work with instead of one hue everywhere.
- **Sidebar is now near-black** (`#080D1B` → gradient), not the previous mid-tone navy — a much
  bigger light/dark contrast against the canvas, closer to Linear's panel treatment.
- **Pill-shaped components**: buttons, nav items, and status badges all moved from rounded-rect to
  full pill radius — status badges now use a small color dot instead of a left border (which
  clips oddly on a pill shape).
- **Serif/sans pairing**: page titles and stat-card numbers use Fraunces (serif) against Inter/
  Manrope everywhere else — a deliberate editorial accent used by a lot of premium fintech/data
  dashboards, and a clear visual tell that this isn't the same design as before.
- **Two-tone accent bar**: page headers now have a navy→gold gradient top edge instead of a flat
  single-color one.
- Every old hardcoded teal value (there were a few backdoor ones — button hover shadows, card
  hover borders, text selection color) has been swapped to the new palette; verified with a
  project-wide grep, nothing from the old scheme should remain.

## Design refresh #1 — token/motion system (superseded by the above)

A full design-system pass across the whole app, not a page-by-page reskin — done at the token
and shared-component layer so it cascades everywhere automatically:

- **New token system** (`styles/tokens.css` + `constants/tokens.js`): a real type scale (12px→30px
  on a considered ratio), a 4px spacing scale, layered/soft elevation (Stripe-style multi-shadow,
  not one hard drop-shadow), and named motion tokens (`--ease-out`, `--duration-fast/base/slow`)
  used consistently for hover/press/entrance animation instead of ad hoc `0.15s ease` scattered
  around.
- **Sidebar redesign**: grouped navigation ("Overview" / "Configuration"), an original brand mark
  (`components/common/Logo.jsx` — see note below), refined active-state indicator, smoother
  collapse animation.
- **Header redesign**: a QA environment badge, and a real user menu (avatar → name/role/sign-out)
  replacing the static avatar.
- **Motion vocabulary**: staggered entrance for card grids (`.stagger-in`), press feedback on every
  button/card (`.press-on-click`, built into `.btn-*` and `.job-card`), a proper scale+fade modal
  entrance (was a flat fade), slide-in toasts with a status-colored left border.
- **Component polish**: buttons (hover/active/disabled states, small variant), inputs/selects
  (focus ring using the brand color), stat cards (icon micro-scale on hover, bigger display-font
  numbers), page headers (a 3px gradient top accent), tables and panels retuned to the spacing scale.
- **Accessibility**: focus-visible ring is global and unchanged in intent, but now consistent
  everywhere the new tokens are used; the user menu supports Escape-to-close and click-outside.

**On the logo**: I don't have Star Health's actual registered logo artwork, and recreating a
specific real trademark from memory isn't something I do. `components/common/Logo.jsx` is an
original placeholder mark (star + pulse motif in the brand teal) — swap the SVG in that one file
for the real logo asset whenever you have it, and it'll update everywhere (sidebar, and anywhere
else it gets used later) automatically.

**Scope note**: this pass covers everything shared (layout, buttons, forms, tables, cards, modals,
toasts) plus the Dashboard/Jobs List surfaces that use them. Page-specific layouts (the pipeline
builder's section styling, migration search's JSON detail view, etc.) inherit the new tokens for
color/spacing/motion but haven't each had a bespoke redesign pass — flag any specific screen that
needs more attention and I'll go deeper there.

## Job Configuration + Process Step Library — done, grounded in real data

You shared the real backend source and QA exports (job_configs, process_steps, and sample Mongo
docs for read/write batches, sync records, and step executions). These two screens are now built
against that real shape, not a guess:

- **Process Step Library** (`/process-steps`): list + create/edit for the shared, reusable step
  catalog. Each of the 8 real step types gets its own structured form — `JWT` (flat fields),
  `API`/`BANCS_API` (a request-builder: endpoint, headers, body-or-raw-body, variables, response
  mapping), `FIELD_TRANSFORM`/`DECRYPT`/`CSV_TO_JSON`/`JSON_TO_CSV` (field-mapping tables), and
  `JOLT_TRANSFORM` (a JSON code editor with validation — its wildcard spec doesn't map to a form).
- **Job Configuration** (`/job-configuration`): list + a full pipeline builder (`/job-configuration/new`,
  `/job-configuration/:name/edit`) with sections for Basics, Trigger (manual vs. scheduled — cron
  now supports Spring's real 6-field format, e.g. `0 0 6 * * *`), Read Config (separate `API` and
  `SQL` sub-forms — SQL jobs use base/where/order-by queries with cursor pagination, matching the
  real `leadSyncGreyLabs` config), Process/Sink/Ack step lists (pick from the Process Step Library,
  reorder, attach pre/post-execution rules via a condition+effect builder), Post-Complete (chain
  other jobs to trigger on completion), and Report (emails + template ID).
- `constants/pipeline.js` holds every enum pulled from the real data (step types, read types,
  strategies — all three: `READ_FIRST`, `SIMULTANEOUS_READ_WRITE`, `SIMULTANEOUS_SINGLE_TRIGGER`
  — ack types, operators, rule effects).
- Mock data (`jobConfigsData.js`, `processStepsData.js`) is trimmed-down but structurally real:
  actual job names, actual step names/params shapes, an actual reused auth chain
  (`salesForceJWT` → `salesForceAccessToken`), an actual post-complete chain
  (`migrateCustomersToSF` → `migratePoliciesToSF`), and the one real scheduled+disabled job.
- Enable/disable calls `deleteConfigByName` (soft delete, matches the real `DELETE` endpoint) and
  `activateConfig` (the endpoint you said you'd add — swap this one line once it exists).

**Known gap to flag:** Dashboard, Jobs List, Job Instances, Execution Detail, Related Retries, and
Data Migration Search still run on the earlier, simpler mock model (generic job names, fixed
step-timeline) from before the real backend was shared — they haven't been rebuilt against the
real `JobExecution`/`ReadBatchExecution`/`WriteBatchExecution`/`StepExecution`/`SyncRecord` shapes
yet. That's next, whenever you're ready.

## Phase 1 — done

- Project scaffold, design tokens (`constants/tokens.js` + `styles/tokens.css`), global/shared
  styles (buttons, forms, tables)
- Layout: `Sidebar`, `Header`, `MainLayout` — responsive, collapsible on desktop, drawer on mobile
- Routing for all 7 pages (lazy-loaded, matches sync-relay's URL scheme) + `ProtectedRoute` scaffold
- **Dashboard fully built**: job/time filters, 5 stat cards, success-vs-failure bar chart, recent
  executions table, top-failed-jobs list — all wired to mock data with loading/error states

## Phase 2 — done

- **Jobs List fully built**: search-by-name (live count), a responsive job-card grid (gradient
  icon, instance count, last run, status badge, Trigger button, drill-in chevron), loading/error/
  empty states, click-through to `/jobs/:jobId/instances`
- New reusable primitives added (used again in later phases): `Modal`, `SearchBar`
- New `ToastProvider` (`context/ToastContext.jsx`) — app-wide success/error toasts, wired in at
  the root so any page can call `useToast().showToast(...)`
- `TriggerJobModal` — dynamic key/value job parameters, submits through `jobsService.triggerJob`
  (mock, ~1-in-10 simulated failure so the error path is visible too), shows a toast on result

## Phase 3 — done

- **Job Instances fully built**: status/trigger-type filters, paginated table, stop/resume actions
  (persisted in-session via a mock instance cache), drill into Execution Detail
- **Execution Detail fully built**: a Gantt-style step timeline — each step is a bar whose width
  is proportional to its duration, split into read/process/write segments; click a step to expand
  read/write counts, timestamps, and error detail on failure
- **Related Retries fully built**: table of retry attempts linked to an execution, links back into
  Execution Detail

## Phase 4 — done

- **Data Migration Search fully built**: job filter + search input, results table, click a row to
  expand reader/processor/writer detail (pretty-printed JSON) and the failure stage/message when
  a record failed

## Phase 5 — done

- **Job Configuration fully built** (the new page sync-relay doesn't have): table of all scheduler
  jobs with description, cron schedule (raw expression + live human-readable translation), an
  enable/disable toggle (behind a confirmation dialog), Edit Cron, and Trigger Once
- **`CronEditor`**: live validation, human-readable description, and a preview of the next 5 run
  times as you type — built on a small custom cron parser (`utils/cron.js`, no external dependency)
  since this needed to actually work in the mock, not just look like it does
- New shared primitives: `Modal`, `ConfirmationDialog`, `Toggle`, `Pagination`

## What's mocked, end to end

Every page above is backed by a `services/*.js` module returning realistic generated data through
a `delay()`-wrapped Promise — nothing is hardcoded in a component. A few services (job instances,
scheduler enable/disable, cron updates) mutate an in-memory store so your changes (stop an
instance, disable a job, edit a cron) persist as you navigate around within the session, the way a
real backend would, without needing one.

## Remaining phase

- **Phase 6** — Polish pass: skeleton loaders instead of spinners, deeper responsive check on
  tables at narrow widths, and any of the extra UI ideas from before you'd like added (sparklines
  on stat cards, an activity heatmap, a command-palette search, etc.)

## Running locally

```bash
npm install
npm run dev
```

## Open questions carried over

1. **Auth** — same as before: what's the real mechanism (cookie/SSO like sync-relay, JWT,
   something else)? `ProtectedRoute.jsx` is a pass-through until specified.
2. **Real API contract** — when you're ready to point this at a backend, the mock `services/*.js`
   functions are the place to swap in real Axios calls; the shapes already mirror sync-relay's
   DTOs (`Job`, `JobInstance`, `ExecutionDetail`, `PageResponse<T>`) so the swap should be mechanical.
3. **Cron validation** — currently validated entirely client-side (`utils/cron.js`). If a real
   backend also validates and returns field-level errors, `CronEditor`'s save handler is the
   place to surface those alongside the client-side check.

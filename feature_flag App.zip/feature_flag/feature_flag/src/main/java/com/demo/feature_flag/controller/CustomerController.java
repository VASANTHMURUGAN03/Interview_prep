package com.demo.feature_flag.controller;

import com.demo.feature_flag.dto.CustomerRequest;
import com.demo.feature_flag.service.CustomerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/customers")
@RequiredArgsConstructor
public class CustomerController {

    private final CustomerService customerService;

    @GetMapping("/process")
    public ResponseEntity<String> processCustomer() {

        String response =
                customerService.process();

        return ResponseEntity.ok(response);
    }
}
package com.demo.feature_flag.enums;

import org.togglz.core.Feature;
import org.togglz.core.annotation.Label;

public enum MyFeatures implements Feature {
    @Label("Mobile Hashing Feature")
    MOBILE_HASHING;
}

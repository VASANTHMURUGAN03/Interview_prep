package com.demo.feature_flag.config;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FeatureConfig {
//
//    @Bean
//    public Unleash unleash() {
//
//        return new DefaultUnleash(
//                UnleashConfig.builder()
//                        .appName("customer-service")
//                        .instanceId("instance-1")
//                        .unleashAPI("http://localhost:4242/api")
//                        .apiKey("YOUR_API_TOKEN")
//                        .build());
//    }
}
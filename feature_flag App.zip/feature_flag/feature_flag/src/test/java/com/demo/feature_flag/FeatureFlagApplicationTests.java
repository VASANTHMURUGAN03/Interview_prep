package com.demo.feature_flag;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeatureFlagApplicationTests {

	@Test
	void contextLoads() {
	}

}

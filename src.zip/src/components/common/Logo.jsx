import logoIcon from '../../assets/star-health-logo-icon.png';
import './Logo.css';

/**
 * Star Health Insurance's real logo mark (star icon, cropped from the
 * uploaded brand logo). Sits on a white chip since the mark is navy and
 * the sidebar panel is dark — swap the asset in src/assets if a different
 * logo file (e.g. a white/reversed variant) becomes available later.
 */
export default function Logo({ size = 26 }) {
  return (
    <div className="logo-chip" style={{ width: size + 14, height: size + 14 }}>
      <img src={logoIcon} alt="Star Health Insurance" style={{ height: size }} />
    </div>
  );
}

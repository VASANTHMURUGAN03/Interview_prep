import { Search, X } from 'lucide-react';
import './SearchBar.css';

export default function SearchBar({ value, onChange, placeholder = 'Search…', resultLabel }) {
  return (
    <div className="search-bar-row">
      <div className="search-bar">
        <Search size={17} className="search-bar-icon" />
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="search-bar-input"
        />
        {value && (
          <button className="search-bar-clear" onClick={() => onChange('')} aria-label="Clear search">
            <X size={16} />
          </button>
        )}
      </div>
      {resultLabel && <span className="search-bar-count">{resultLabel}</span>}
    </div>
  );
}

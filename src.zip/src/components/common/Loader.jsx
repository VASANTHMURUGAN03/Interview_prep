import { RefreshCw } from 'lucide-react';
import './Loader.css';

export default function Loader({ label = 'Loading…', size = 22 }) {
  return (
    <div className="loader">
      <RefreshCw size={size} className="spin" />
      <span>{label}</span>
    </div>
  );
}

import { AlertTriangle, RefreshCw } from 'lucide-react';
import './ErrorState.css';

export default function ErrorState({
  title = 'Something went wrong',
  description = 'Please try again.',
  onRetry,
}) {
  return (
    <div className="error-state fade-in-up">
      <div className="error-state-icon">
        <AlertTriangle size={28} />
      </div>
      <h3>{title}</h3>
      <p>{description}</p>
      {onRetry && (
        <button className="btn-primary" onClick={onRetry}>
          <RefreshCw size={16} />
          Retry
        </button>
      )}
    </div>
  );
}

import { ChevronRight } from 'lucide-react';
import './PageHeader.css';

export default function PageHeader({ title, trail, actions, children }) {
  return (
    <div className="page-header glass-surface fade-in-up">
      <div className="page-header-main">
        {trail && trail.length > 0 && (
          <nav className="page-trail">
            {trail.map((crumb, i) => (
              <span className="page-trail-item" key={i}>
                {i > 0 && <ChevronRight size={14} className="page-trail-sep" />}
                {crumb.onClick ? (
                  <button className="page-trail-link" onClick={crumb.onClick}>
                    {crumb.label}
                  </button>
                ) : (
                  <span className="page-trail-current">{crumb.label}</span>
                )}
              </span>
            ))}
          </nav>
        )}
        <h1 className="page-title">{title}</h1>
      </div>

      {(actions || children) && (
        <div className="page-header-actions">
          {children}
          {actions}
        </div>
      )}
    </div>
  );
}

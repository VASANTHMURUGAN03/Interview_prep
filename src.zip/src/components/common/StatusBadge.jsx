import './StatusBadge.css';

const STYLES = {
  COMPLETED: { bg: 'var(--color-success-bg)', text: 'var(--color-success-text)', border: 'var(--color-success)' },
  SUCCESS: { bg: 'var(--color-success-bg)', text: 'var(--color-success-text)', border: 'var(--color-success)' },
  FAILED: { bg: 'var(--color-danger-bg)', text: 'var(--color-danger-text)', border: 'var(--color-danger)' },
  FAILURE: { bg: 'var(--color-danger-bg)', text: 'var(--color-danger-text)', border: 'var(--color-danger)' },
  PARTIAL_FAILURE: { bg: 'var(--color-danger-bg)', text: '#da5b5b', border: '#e97f7f' },
  RUNNING: { bg: 'var(--color-info-bg)', text: 'var(--color-info-text)', border: 'var(--color-info)' },
  STARTED: { bg: 'var(--color-info-bg)', text: 'var(--color-info-text)', border: 'var(--color-info)' },
  IN_PROGRESS: { bg: 'var(--color-info-bg)', text: 'var(--color-info-text)', border: 'var(--color-info)' },
  STOPPED: { bg: 'var(--color-orange-bg)', text: 'var(--color-orange-text)', border: 'var(--color-orange)' },
  STOPPING: { bg: 'var(--color-orange-bg)', text: 'var(--color-orange-text)', border: 'var(--color-orange)' },
  PENDING: { bg: 'var(--color-warning-bg)', text: 'var(--color-warning-text)', border: 'var(--color-warning)' },
  QUEUED: { bg: 'var(--color-warning-bg)', text: 'var(--color-warning-text)', border: 'var(--color-warning)' },
  ABANDONED: { bg: 'var(--color-purple-bg)', text: 'var(--color-purple-text)', border: 'var(--color-purple)' },
};

const DEFAULT_STYLE = { bg: 'var(--color-surface-sunken)', text: 'var(--color-ink-muted)', border: 'var(--color-ink-faint)' };

export default function StatusBadge({ status, size = 'md' }) {
  const normalized = (status || '').toUpperCase();
  const style = STYLES[normalized] || DEFAULT_STYLE;
  const label = normalized === 'STARTED' ? 'RUNNING' : normalized;

  return (
    <span
      className={`status-badge status-badge--${size}`}
      style={{ background: style.bg, color: style.text }}
    >
      <span className="status-badge-dot" style={{ background: style.border }} />
      {label || '—'}
    </span>
  );
}

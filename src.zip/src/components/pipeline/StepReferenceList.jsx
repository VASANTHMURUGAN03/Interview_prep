import { useState } from 'react';
import { ChevronDown, ChevronRight, ArrowUp, ArrowDown, Trash2, Plus } from 'lucide-react';
import RuleBuilder from './RuleBuilder';
import './StepReferenceList.css';

export default function StepReferenceList({ steps, onChange, catalog }) {
  const [expanded, setExpanded] = useState(null);
  const [picked, setPicked] = useState('');

  const typeOf = (name) => catalog.find((s) => s.name === name)?.type;

  const move = (index, dir) => {
    const next = [...steps];
    const target = index + dir;
    if (target < 0 || target >= next.length) return;
    [next[index], next[target]] = [next[target], next[index]];
    onChange(next);
  };

  const remove = (index) => onChange(steps.filter((_, i) => i !== index));

  const updateStep = (index, patch) => {
    onChange(steps.map((s, i) => (i === index ? { ...s, ...patch } : s)));
  };

  const addStep = () => {
    if (!picked) return;
    onChange([...steps, { name: picked }]);
    setPicked('');
  };

  const availableToAdd = catalog.filter((s) => !steps.some((ref) => ref.name === s.name));

  return (
    <div className="step-ref-list">
      {steps.length === 0 && <p className="step-ref-empty">No steps yet — add one from the catalog below.</p>}

      {steps.map((ref, i) => {
        const isOpen = expanded === i;
        return (
          <div className="step-ref-item" key={`${ref.name}-${i}`}>
            <div className="step-ref-row">
              <button className="step-ref-expand" onClick={() => setExpanded(isOpen ? null : i)}>
                {isOpen ? <ChevronDown size={15} /> : <ChevronRight size={15} />}
              </button>
              <span className="mono step-ref-name">{ref.name}</span>
              {typeOf(ref.name) && <span className="step-ref-type">{typeOf(ref.name)}</span>}
              {(ref.preExecution?.length > 0 || ref.postExecution?.length > 0) && (
                <span className="step-ref-rule-count">
                  {(ref.preExecution?.length || 0) + (ref.postExecution?.length || 0)} rule(s)
                </span>
              )}
              <div className="step-ref-actions">
                <button className="kv-remove-btn" onClick={() => move(i, -1)} disabled={i === 0} aria-label="Move up">
                  <ArrowUp size={14} />
                </button>
                <button className="kv-remove-btn" onClick={() => move(i, 1)} disabled={i === steps.length - 1} aria-label="Move down">
                  <ArrowDown size={14} />
                </button>
                <button className="kv-remove-btn" onClick={() => remove(i)} aria-label="Remove step">
                  <Trash2 size={14} />
                </button>
              </div>
            </div>

            {isOpen && (
              <div className="step-ref-detail fade-in-up">
                <div className="step-ref-rules-block">
                  <h4>Pre-execution rules</h4>
                  <RuleBuilder phase="pre" rules={ref.preExecution} onChange={(preExecution) => updateStep(i, { preExecution })} />
                </div>
                <div className="step-ref-rules-block">
                  <h4>Post-execution rules</h4>
                  <RuleBuilder phase="post" rules={ref.postExecution} onChange={(postExecution) => updateStep(i, { postExecution })} />
                </div>
              </div>
            )}
          </div>
        );
      })}

      <div className="step-ref-add-row">
        <div className="select-wrapper">
          <select className="select-control" value={picked} onChange={(e) => setPicked(e.target.value)}>
            <option value="">Select a step from the catalog…</option>
            {availableToAdd.map((s) => <option key={s.name} value={s.name}>{s.name} ({s.type})</option>)}
          </select>
        </div>
        <button className="btn-secondary" onClick={addStep} disabled={!picked}>
          <Plus size={15} />
          Add Step
        </button>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { Pencil, Database } from 'lucide-react';
import Modal from '../common/Modal';
import './SqlQueryPanel.css';

export default function SqlQueryPanel({ request, onChange }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(request || {});

  const openEditor = () => {
    setDraft(request || {});
    setEditing(true);
  };

  const save = () => {
    onChange(draft);
    setEditing(false);
  };

  const baseQuery = request?.baseQuery || '';
  const whereQuery = request?.whereQuery || '';
  const orderBy = request?.orderBy || '';
  const nextCursor = request?.nextCursor?.query || '';

  const isEmpty = !baseQuery && !whereQuery && !orderBy;

  return (
    <>
      <div className="sql-panel">
        <div className="sql-panel-header">
          <span className="sql-panel-label"><Database size={13} /> SQL Query</span>
          <button className="btn-ghost row-action-btn" onClick={openEditor}>
            <Pencil size={13} />
            Edit Query
          </button>
        </div>

        {isEmpty ? (
          <p className="sql-panel-empty">No query configured yet — click "Edit Query" to add one.</p>
        ) : (
          <pre className="sql-panel-code">
            {baseQuery}
            {whereQuery && <>{'\n'}<span className="sql-tok-keyword">WHERE</span> {whereQuery}</>}
            {orderBy && <>{'\n'}<span className="sql-tok-keyword">ORDER BY</span> {orderBy}</>}
            {nextCursor && <>{'\n\n'}<span className="sql-tok-comment">-- next cursor: {nextCursor}</span></>}
          </pre>
        )}
      </div>

      {editing && (
        <Modal
          title="Edit SQL Query"
          onClose={() => setEditing(false)}
          width={640}
          footer={
            <>
              <button className="btn-secondary" onClick={() => setEditing(false)}>Cancel</button>
              <button className="btn-primary" onClick={save}>Save Query</button>
            </>
          }
        >
          <label className="field-label" style={{ marginBottom: '0.85rem' }}>
            Base query
            <textarea
              className="text-input mono builder-textarea"
              placeholder="SELECT id, name FROM customer_lead"
              value={draft.baseQuery || ''}
              onChange={(e) => setDraft({ ...draft, baseQuery: e.target.value })}
              autoFocus
            />
          </label>
          <label className="field-label" style={{ marginBottom: '0.85rem' }}>
            Where clause
            <textarea
              className="text-input mono builder-textarea-sm"
              placeholder="id > 236100 and is_pushed = 0"
              value={draft.whereQuery || ''}
              onChange={(e) => setDraft({ ...draft, whereQuery: e.target.value })}
            />
          </label>
          <div className="field-grid">
            <label className="field-label">
              Order by
              <input
                className="text-input mono"
                placeholder="id"
                value={draft.orderBy || ''}
                onChange={(e) => setDraft({ ...draft, orderBy: e.target.value })}
              />
            </label>
            <label className="field-label">
              Next-cursor query
              <input
                className="text-input mono"
                placeholder="id > ${CURSOR}"
                value={draft.nextCursor?.query || ''}
                onChange={(e) => setDraft({ ...draft, nextCursor: { ...draft.nextCursor, query: e.target.value } })}
              />
            </label>
          </div>
        </Modal>
      )}
    </>
  );
}

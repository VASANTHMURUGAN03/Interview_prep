import { Plus, Trash2 } from 'lucide-react';
import './KeyValueTable.css';

/**
 * columns: [{ key, label, placeholder?, type?: 'text'|'select', options?: string[] }]
 * rows: array of plain objects with one property per column key
 */
export default function KeyValueTable({ columns, rows, onChange, addLabel = 'Add row' }) {
  const updateRow = (index, colKey, value) => {
    onChange(rows.map((r, i) => (i === index ? { ...r, [colKey]: value } : r)));
  };

  const addRow = () => {
    const blank = Object.fromEntries(columns.map((c) => [c.key, '']));
    onChange([...rows, blank]);
  };

  const removeRow = (index) => onChange(rows.filter((_, i) => i !== index));

  return (
    <div className="kv-table">
      {rows.length > 0 && (
        <div className="kv-table-head" style={{ gridTemplateColumns: `repeat(${columns.length}, 1fr) 32px` }}>
          {columns.map((c) => <span key={c.key}>{c.label}</span>)}
          <span />
        </div>
      )}
      {rows.map((row, i) => (
        <div className="kv-table-row" key={i} style={{ gridTemplateColumns: `repeat(${columns.length}, 1fr) 32px` }}>
          {columns.map((c) =>
            c.type === 'select' ? (
              <select
                key={c.key}
                className="select-control kv-input"
                value={row[c.key] ?? ''}
                onChange={(e) => updateRow(i, c.key, e.target.value)}
              >
                <option value="">—</option>
                {c.options.map((o) => <option key={o} value={o}>{o}</option>)}
              </select>
            ) : (
              <input
                key={c.key}
                className="text-input kv-input mono"
                placeholder={c.placeholder}
                value={row[c.key] ?? ''}
                onChange={(e) => updateRow(i, c.key, e.target.value)}
              />
            )
          )}
          <button className="kv-remove-btn" onClick={() => removeRow(i)} aria-label="Remove row">
            <Trash2 size={14} />
          </button>
        </div>
      ))}
      <button className="btn-ghost kv-add-btn" onClick={addRow}>
        <Plus size={14} />
        {addLabel}
      </button>
    </div>
  );
}

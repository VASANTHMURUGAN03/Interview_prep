import { Plus, Trash2 } from 'lucide-react';
import KeyValueTable from './KeyValueTable';
import { OPERATORS, PRE_EXECUTION_EFFECTS, POST_EXECUTION_EFFECTS } from '../../constants/pipeline';
import './RuleBuilder.css';

const CONDITION_COLUMNS = [
  { key: 'key', label: 'Key (dot notation)', placeholder: 'stepName.field' },
  { key: 'operator', label: 'Operator', type: 'select', options: OPERATORS },
  { key: 'value', label: 'Value', placeholder: 'Expected value' },
];

export default function RuleBuilder({ phase, rules, onChange }) {
  const effectOptions = phase === 'pre' ? PRE_EXECUTION_EFFECTS : POST_EXECUTION_EFFECTS;
  const safeRules = rules || [];

  const updateRule = (index, patch) => {
    onChange(safeRules.map((r, i) => (i === index ? { ...r, ...patch } : r)));
  };

  const addRule = () => {
    onChange([...safeRules, { conditions: [{ key: '', operator: 'equals', value: '' }], effect: { step: effectOptions[0] } }]);
  };

  const removeRule = (index) => onChange(safeRules.filter((_, i) => i !== index));

  return (
    <div className="rule-builder">
      {safeRules.map((rule, i) => (
        <div className="rule-card" key={i}>
          <div className="rule-card-header">
            <span className="rule-card-title">Rule {i + 1}</span>
            <button className="kv-remove-btn" onClick={() => removeRule(i)} aria-label="Remove rule">
              <Trash2 size={14} />
            </button>
          </div>

          <KeyValueTable
            columns={CONDITION_COLUMNS}
            rows={rule.conditions || []}
            onChange={(conditions) => updateRule(i, { conditions })}
            addLabel="Add condition"
          />

          <div className="rule-effect-row">
            <span className="rule-effect-label">Then</span>
            <select
              className="select-control"
              value={rule.effect?.step || ''}
              onChange={(e) => updateRule(i, { effect: { step: e.target.value } })}
            >
              {effectOptions.map((o) => <option key={o} value={o}>{o}</option>)}
            </select>
          </div>
        </div>
      ))}

      <button className="btn-ghost kv-add-btn" onClick={addRule}>
        <Plus size={14} />
        Add Rule
      </button>
    </div>
  );
}

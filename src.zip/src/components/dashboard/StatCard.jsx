import './StatCard.css';

export default function StatCard({ icon: Icon, label, value, variant = 'primary', loading }) {
  return (
    <div className={`stat-card stat-card--${variant} stagger-in`}>
      <div className="stat-card-icon">
        <Icon size={26} />
      </div>
      <div className="stat-card-content">
        <div className="stat-card-value">{loading ? '—' : value}</div>
        <div className="stat-card-label">{label}</div>
      </div>
    </div>
  );
}

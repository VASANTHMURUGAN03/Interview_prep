import { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';

import Logo from '../common/Logo';
import { NAV_ITEMS } from '../../constants/navigation';
import './Sidebar.css';

function groupItems(items) {
  const groups = [];
  for (const item of items) {
    let group = groups.find((g) => g.name === item.group);
    if (!group) {
      group = { name: item.group, items: [] };
      groups.push(group);
    }
    group.items.push(item);
  }
  return groups;
}

export default function Sidebar({ collapsed, onToggleCollapse, mobileOpen, onCloseMobile, isDesktop }) {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    document.documentElement.style.setProperty(
      '--sidebar-width',
      collapsed && isDesktop ? '84px' : '276px'
    );
  }, [collapsed, isDesktop]);

  const isActive = (path) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  const showLabels = !(collapsed && isDesktop);
  const groups = groupItems(NAV_ITEMS);

  return (
    <>
      {!isDesktop && mobileOpen && <div className="sidebar-scrim" onClick={onCloseMobile} />}

      <aside className={`sidebar ${collapsed && isDesktop ? 'collapsed' : ''} ${!isDesktop ? 'mobile' : ''} ${mobileOpen ? 'mobile-open' : ''}`}>
        <div className="sidebar-header">
          <div className="sidebar-logo">
            <Logo size={showLabels ? 22 : 20} />
          </div>
          {showLabels && (
            <div className="sidebar-title">
              <h2>Data Bridge</h2>
              <p>· Sync Console</p>
            </div>
          )}
          {!isDesktop && (
            <button className="sidebar-close" onClick={onCloseMobile} aria-label="Close menu">
              <X size={20} />
            </button>
          )}
        </div>

        {isDesktop && (
          <button className="sidebar-toggle press-on-click" onClick={onToggleCollapse} aria-label="Toggle sidebar">
            {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
          </button>
        )}

        <nav className="sidebar-nav">
          {groups.map((group) => (
            <div className="sidebar-group" key={group.name}>
              {showLabels && <div className="sidebar-group-label">{group.name}</div>}
              {group.items.map((item) => {
                const Icon = item.icon;
                const active = isActive(item.path);
                return (
                  <button
                    key={item.id}
                    className={`nav-item ${active ? 'active' : ''}`}
                    onClick={() => {
                      navigate(item.path);
                      onCloseMobile?.();
                    }}
                    title={showLabels ? '' : item.label}
                  >
                    <Icon size={19} strokeWidth={active ? 2.25 : 1.9} />
                    {showLabels && <span>{item.label}</span>}
                  </button>
                );
              })}
            </div>
          ))}
        </nav>

        <div className="sidebar-footer">
          {showLabels && <span className="version-info">Data Bridge · v1.0.0</span>}
        </div>
      </aside>
    </>
  );
}

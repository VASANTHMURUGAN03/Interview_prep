import { useState, useRef, useEffect } from 'react';
import { Menu, Bell, ChevronDown, LogOut, UserCircle } from 'lucide-react';
import './Header.css';

export default function Header({ isDesktop, onMenuClick }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    if (!menuOpen) return;
    const onClick = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false);
    };
    const onKey = (e) => { if (e.key === 'Escape') setMenuOpen(false); };
    document.addEventListener('mousedown', onClick);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onClick);
      document.removeEventListener('keydown', onKey);
    };
  }, [menuOpen]);

  return (
    <header className="app-header glass-surface">
      {!isDesktop && (
        <button className="header-menu-btn" onClick={onMenuClick} aria-label="Open menu">
          <Menu size={22} />
        </button>
      )}

      <span className="header-env-badge">SIT</span>

      <div className="header-spacer" />

      <div className="header-pulse">
        <span className="header-pulse-dot signal-ping" />
        All schedulers nominal
      </div>

      <button className="header-icon-btn" aria-label="Notifications">
        <Bell size={19} />
      </button>

      <div className="header-user" ref={menuRef}>
        <button
          className="header-user-trigger press-on-click"
          onClick={() => setMenuOpen((v) => !v)}
          aria-haspopup="menu"
          aria-expanded={menuOpen}
        >
          <div className="header-avatar">VM</div>
          {isDesktop && <ChevronDown size={14} className={`header-user-chevron ${menuOpen ? 'open' : ''}`} />}
        </button>

        {menuOpen && (
          <div className="header-user-menu fade-in-up" role="menu">
            <div className="header-user-menu-info">
              <div className="header-avatar header-avatar--lg">VM</div>
              <div>
                <p className="header-user-name">Vasanth M</p>
                <p className="header-user-role">SDE I · Data Engineering</p>
              </div>
            </div>
            <div className="header-user-menu-divider" />
            <button className="header-user-menu-item" role="menuitem">
              <UserCircle size={16} /> Profile
            </button>
            <button className="header-user-menu-item" role="menuitem">
              <LogOut size={16} /> Sign out
            </button>
          </div>
        )}
      </div>
    </header>
  );
}

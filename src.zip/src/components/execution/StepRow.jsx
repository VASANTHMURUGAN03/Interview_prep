import { useState } from 'react';
import { ChevronDown, ChevronRight as ChevronRightIcon } from 'lucide-react';
import dayjs from 'dayjs';

import StatusBadge from '../common/StatusBadge';
import './StepRow.css';

export default function StepRow({ step, maxDurationMs }) {
  const [open, setOpen] = useState(false);
  const totalMs = step.readDurationMs + step.processDurationMs + step.writeDurationMs;
  const barWidthPct = Math.max(6, Math.round((totalMs / maxDurationMs) * 100));

  const seg = (ms) => `${Math.max(2, Math.round((ms / totalMs) * 100))}%`;

  return (
    <div className="step-row">
      <button className="step-row-header" onClick={() => setOpen((v) => !v)}>
        {open ? <ChevronDown size={16} /> : <ChevronRightIcon size={16} />}
        <span className="step-row-name mono">{step.name}</span>
        <StatusBadge status={step.status} size="sm" />
        <span className="step-row-duration mono">{(totalMs / 1000).toFixed(1)}s</span>
      </button>

      <div className="step-bar-track">
        <div className="step-bar" style={{ width: `${barWidthPct}%` }}>
          <span className="step-bar-seg step-bar-seg--read" style={{ width: seg(step.readDurationMs) }} title="Read" />
          <span className="step-bar-seg step-bar-seg--process" style={{ width: seg(step.processDurationMs) }} title="Process" />
          <span className="step-bar-seg step-bar-seg--write" style={{ width: seg(step.writeDurationMs) }} title="Write" />
        </div>
      </div>

      {open && (
        <div className="step-detail fade-in-up">
          <div className="step-detail-grid">
            <div><span className="step-detail-label">Read count</span><span className="mono">{step.readCount.toLocaleString()}</span></div>
            <div><span className="step-detail-label">Write count</span><span className="mono">{step.writeCount.toLocaleString()}</span></div>
            <div><span className="step-detail-label">Start</span><span className="mono">{dayjs(step.startTime).format('HH:mm:ss')}</span></div>
            <div><span className="step-detail-label">End</span><span className="mono">{dayjs(step.endTime).format('HH:mm:ss')}</span></div>
          </div>
          <div className="step-detail-legend">
            <span><i className="legend-dot legend-dot--read" /> Read {(step.readDurationMs / 1000).toFixed(1)}s</span>
            <span><i className="legend-dot legend-dot--process" /> Process {(step.processDurationMs / 1000).toFixed(1)}s</span>
            <span><i className="legend-dot legend-dot--write" /> Write {(step.writeDurationMs / 1000).toFixed(1)}s</span>
          </div>
          {step.status === 'FAILED' && (
            <p className="step-error">This step failed — the downstream writer rejected the batch. Retry from Related Retries.</p>
          )}
        </div>
      )}
    </div>
  );
}

import { useState } from 'react';
import { AlertTriangle, Wand2 } from 'lucide-react';
import './JoltEditor.css';

export default function JoltEditor({ value, onChange }) {
  const [text, setText] = useState(() => JSON.stringify(value?.config ?? [], null, 2));
  const [error, setError] = useState(null);

  const handleChange = (newText) => {
    setText(newText);
    try {
      const parsed = JSON.parse(newText);
      setError(null);
      onChange({ config: parsed });
    } catch (e) {
      setError('Invalid JSON — changes not applied until this is fixed.');
    }
  };

  const format = () => {
    try {
      const parsed = JSON.parse(text);
      const pretty = JSON.stringify(parsed, null, 2);
      setText(pretty);
      setError(null);
    } catch (e) {
      // leave as-is; error already shown
    }
  };

  return (
    <div className="jolt-editor">
      <div className="jolt-editor-header">
        <p className="req-hint">
          JOLT transform spec — a list of <code>{'{ operation, spec }'}</code> objects. Edited as JSON since the
          wildcard-based spec structure doesn't map well to a form.
        </p>
        <button className="btn-ghost jolt-format-btn" onClick={format}>
          <Wand2 size={14} />
          Format
        </button>
      </div>
      <textarea
        className={`text-input mono jolt-textarea ${error ? 'jolt-textarea--error' : ''}`}
        value={text}
        onChange={(e) => handleChange(e.target.value)}
        spellCheck={false}
      />
      {error && (
        <p className="jolt-error">
          <AlertTriangle size={13} /> {error}
        </p>
      )}
    </div>
  );
}

const FIELDS = [
  { key: 'privateKeyPath', label: 'Private key path', placeholder: 'salesforce.privateKeyPath' },
  { key: 'publicKeyPath', label: 'Public key path', placeholder: '(optional)' },
  { key: 'algorithm', label: 'Algorithm', placeholder: 'RSA256' },
  { key: 'expiryInSec', label: 'Expiry (seconds)', placeholder: '86400' },
  { key: 'issuer', label: 'Issuer', placeholder: 'salesforce.issuer' },
  { key: 'subject', label: 'Subject', placeholder: 'salesforce.subject' },
  { key: 'audience', label: 'Audience', placeholder: 'salesforce.audience' },
];

export default function JwtForm({ value, onChange }) {
  return (
    <div className="field-grid">
      {FIELDS.map((f) => (
        <label key={f.key} className="field-label">
          {f.label}
          <input
            className="text-input mono"
            placeholder={f.placeholder}
            value={value?.[f.key] ?? ''}
            onChange={(e) => onChange({ ...value, [f.key]: e.target.value })}
          />
        </label>
      ))}
    </div>
  );
}

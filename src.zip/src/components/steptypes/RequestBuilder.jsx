import KeyValueTable from '../pipeline/KeyValueTable';
import { VARIABLE_TYPES, BODY_PARAM_TYPES } from '../../constants/pipeline';
import './RequestBuilder.css';

const HTTP_METHODS = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'];

function mapToRows(map) {
  return Object.entries(map || {}).map(([key, value]) => ({ key, value }));
}
function rowsToMap(rows) {
  return Object.fromEntries(rows.filter((r) => r.key).map((r) => [r.key, r.value]));
}

export default function RequestBuilder({ value, onChange }) {
  const request = value?.request || {};
  const endpoint = request.endpoint || {};
  const useRawBody = request.rawBody !== undefined && request.rawBody !== null;

  const update = (patch) => onChange({ ...value, request: { ...request, ...patch } });
  const updateEndpoint = (patch) => update({ endpoint: { ...endpoint, ...patch } });

  const responseRows = (value?.response?.params) || [];

  return (
    <div className="request-builder">
      <div className="req-section">
        <h4>Endpoint</h4>
        <div className="req-endpoint-row">
          <input className="text-input mono" placeholder="basePath (e.g. salesforce.basePath)" value={endpoint.basePath || ''} onChange={(e) => updateEndpoint({ basePath: e.target.value })} />
          <select className="select-control" value={endpoint.method || 'GET'} onChange={(e) => updateEndpoint({ method: e.target.value })}>
            {HTTP_METHODS.map((m) => <option key={m} value={m}>{m}</option>)}
          </select>
        </div>
        <input className="text-input mono req-url-input" placeholder="/services/data/v64.0/..." value={endpoint.url || ''} onChange={(e) => updateEndpoint({ url: e.target.value })} />
      </div>

      <div className="req-section">
        <h4>Headers</h4>
        <KeyValueTable
          columns={[{ key: 'key', label: 'Header', placeholder: 'authorization' }, { key: 'value', label: 'Value', placeholder: 'Bearer ${TOKEN}' }]}
          rows={mapToRows(request.headers)}
          onChange={(rows) => update({ headers: rowsToMap(rows) })}
          addLabel="Add header"
        />
      </div>

      <div className="req-section">
        <div className="req-section-header">
          <h4>Body</h4>
          <label className="req-toggle">
            <input
              type="checkbox"
              checked={useRawBody}
              onChange={(e) => {
                if (e.target.checked) update({ rawBody: '${CSV_DATA}', body: undefined });
                else update({ rawBody: undefined, body: [] });
              }}
            />
            Raw body (e.g. CSV upload)
          </label>
        </div>
        {useRawBody ? (
          <input className="text-input mono" placeholder="${CSV_DATA}" value={request.rawBody || ''} onChange={(e) => update({ rawBody: e.target.value })} />
        ) : (
          <KeyValueTable
            columns={[
              { key: 'name', label: 'Name', placeholder: 'grant_type' },
              { key: 'value', label: 'Value', placeholder: '${TOKEN} or a static value' },
              { key: 'type', label: 'Type', type: 'select', options: BODY_PARAM_TYPES },
            ]}
            rows={request.body || []}
            onChange={(rows) => update({ body: rows })}
            addLabel="Add body field"
          />
        )}
      </div>

      <div className="req-section">
        <h4>Variables</h4>
        <p className="req-hint">Referenced in headers/body/URL as <code>${'{NAME}'}</code>. "context" pulls another step's output; "implementation" calls a named helper; "env" reads a config property.</p>
        <KeyValueTable
          columns={[
            { key: 'name', label: 'Name', placeholder: 'TOKEN' },
            { key: 'type', label: 'Type', type: 'select', options: VARIABLE_TYPES },
            { key: 'value', label: 'Value', placeholder: 'salesForceAccessToken.accessToken' },
          ]}
          rows={request.variables || []}
          onChange={(rows) => update({ variables: rows })}
          addLabel="Add variable"
        />
      </div>

      <div className="req-section">
        <h4>Response mapping</h4>
        <p className="req-hint">Extract named values from the JSON response by dot-path.</p>
        <KeyValueTable
          columns={[
            { key: 'key', label: 'Output name', placeholder: 'accessToken' },
            { key: 'value', label: 'JSON path', placeholder: 'access_token' },
          ]}
          rows={responseRows}
          onChange={(rows) => onChange({ ...value, response: rows.length ? { params: rows } : null })}
          addLabel="Add mapping"
        />
      </div>
    </div>
  );
}

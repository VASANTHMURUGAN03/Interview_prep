import JwtForm from './JwtForm';
import RequestBuilder from './RequestBuilder';
import JoltEditor from './JoltEditor';
import KeyMapForm from './KeyMapForm';
import { REQUEST_DSL_TYPES, KEY_MAP_TYPES } from '../../constants/pipeline';

export default function StepTypeForm({ type, params, onChange }) {
  if (!type) {
    return <p className="req-hint">Pick a step type above to configure it.</p>;
  }

  if (type === 'JWT') {
    return <JwtForm value={params} onChange={onChange} />;
  }

  if (REQUEST_DSL_TYPES.includes(type)) {
    return <RequestBuilder value={params} onChange={onChange} />;
  }

  if (type === 'JOLT_TRANSFORM') {
    return <JoltEditor value={params} onChange={onChange} />;
  }

  if (KEY_MAP_TYPES.includes(type)) {
    return <KeyMapForm type={type} value={params} onChange={onChange} />;
  }

  return null;
}

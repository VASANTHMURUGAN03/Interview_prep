import KeyValueTable from '../pipeline/KeyValueTable';

function mapToRows(map) {
  return Object.entries(map || {}).map(([key, value]) => ({ key, value }));
}
function rowsToMap(rows) {
  return Object.fromEntries(rows.filter((r) => r.key).map((r) => [r.key, r.value]));
}

export default function KeyMapForm({ type, value, onChange }) {
  const v = value || {};

  if (type === 'FIELD_TRANSFORM') {
    return (
      <div>
        <label className="field-label" style={{ marginBottom: '0.85rem' }}>
          Data source (step name)
          <input className="text-input mono" value={v.dataSource || ''} onChange={(e) => onChange({ ...v, dataSource: e.target.value })} />
        </label>
        <KeyValueTable
          columns={[
            { key: 'source', label: 'Source field' },
            { key: 'target', label: 'Target field' },
            { key: 'implementation', label: 'Implementation fn', placeholder: 'safeConvertToYYYYMMDD' },
          ]}
          rows={v.config || []}
          onChange={(config) => onChange({ ...v, config })}
          addLabel="Add field mapping"
        />
      </div>
    );
  }

  if (type === 'DECRYPT') {
    return (
      <div>
        <div className="field-grid" style={{ marginBottom: '0.85rem' }}>
          <label className="field-label">
            Data source (step name)
            <input className="text-input mono" value={v.dataSource || ''} onChange={(e) => onChange({ ...v, dataSource: e.target.value })} />
          </label>
          <label className="req-toggle" style={{ alignSelf: 'end', paddingBottom: '0.5rem' }}>
            <input type="checkbox" checked={!!v.updateDataFlow} onChange={(e) => onChange({ ...v, updateDataFlow: e.target.checked })} />
            Update data flow in place
          </label>
        </div>
        <KeyValueTable
          columns={[{ key: 'source', label: 'Encrypted field' }, { key: 'target', label: 'Decrypted into' }]}
          rows={v.fields || []}
          onChange={(fields) => onChange({ ...v, fields })}
          addLabel="Add field"
        />
      </div>
    );
  }

  if (type === 'CSV_TO_JSON') {
    return (
      <div>
        <label className="field-label" style={{ marginBottom: '0.85rem' }}>
          Source (step output path)
          <input className="text-input mono" value={v.source || ''} onChange={(e) => onChange({ ...v, source: e.target.value })} />
        </label>
        <KeyValueTable
          columns={[{ key: 'key', label: 'CSV column' }, { key: 'value', label: 'JSON field' }]}
          rows={mapToRows(v.columns)}
          onChange={(rows) => onChange({ ...v, columns: rowsToMap(rows) })}
          addLabel="Add column mapping"
        />
      </div>
    );
  }

  if (type === 'JSON_TO_CSV') {
    return (
      <div>
        <label className="req-toggle" style={{ marginBottom: '0.85rem' }}>
          <input type="checkbox" checked={!!v.writeToFile} onChange={(e) => onChange({ ...v, writeToFile: e.target.checked })} />
          Write to file (instead of keeping in memory)
        </label>
        <KeyValueTable
          columns={[{ key: 'key', label: 'JSON field' }, { key: 'value', label: 'CSV column' }]}
          rows={mapToRows(v.columns)}
          onChange={(rows) => onChange({ ...v, columns: rows.length ? rowsToMap(rows) : null })}
          addLabel="Add column mapping"
        />
      </div>
    );
  }

  return null;
}

import { useNavigate } from 'react-router-dom';
import './NotFound.css';

export default function NotFound() {
  const navigate = useNavigate();
  return (
    <div className="not-found">
      <p className="not-found-code mono">404 · route-not-found</p>
      <h1 className="gradient-text">This bridge leads nowhere.</h1>
      <p className="not-found-desc">The page you're looking for doesn't exist or has moved.</p>
      <button className="btn-primary" onClick={() => navigate('/')}>Back to Dashboard</button>
    </div>
  );
}

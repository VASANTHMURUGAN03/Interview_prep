import { useEffect, useState, useCallback } from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import { GitPullRequest, ChevronRight } from 'lucide-react';
import dayjs from 'dayjs';

import PageHeader from '../../components/common/PageHeader';
import Loader from '../../components/common/Loader';
import ErrorState from '../../components/common/ErrorState';
import EmptyState from '../../components/common/EmptyState';
import StatusBadge from '../../components/common/StatusBadge';
import relatedRetriesService from '../../services/relatedRetriesService';

export default function RelatedRetries() {
  const { executionId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const job = location.state?.job;

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const result = await relatedRetriesService.getRelatedRetries(executionId);
      setData(result);
    } catch (e) {
      setError('Failed to load related retries.');
    } finally {
      setLoading(false);
    }
  }, [executionId]);

  useEffect(() => { load(); }, [load]);

  const trail = [
    { label: 'Jobs', onClick: () => navigate('/jobs') },
    ...(job ? [{ label: job.name, onClick: () => navigate(`/jobs/${job.id}/instances`, { state: { job } }) }] : []),
    { label: `Execution #${executionId}` },
  ];

  if (error) {
    return (
      <div>
        <PageHeader title="Related Retries" trail={trail} />
        <ErrorState description={error} onRetry={load} />
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="Related Retries" trail={trail} />

      {loading ? (
        <Loader label="Loading retry attempts…" />
      ) : !data || data.content.length === 0 ? (
        <EmptyState icon={GitPullRequest} title="No retries linked to this execution" />
      ) : (
        <div className="panel-card">
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Attempt</th>
                  <th>Instance ID</th>
                  <th>Status</th>
                  <th>Triggered By</th>
                  <th>Start Time</th>
                  <th>Duration</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {data.content.map((row) => (
                  <tr key={row.id}>
                    <td className="mono">#{row.attempt}</td>
                    <td className="mono">#{row.instanceId}</td>
                    <td><StatusBadge status={row.status} size="sm" /></td>
                    <td>{row.triggeredBy}</td>
                    <td className="mono">{dayjs(row.startTime).format('MMM D, HH:mm')}</td>
                    <td className="mono">{row.durationSec}s</td>
                    <td>
                      <button
                        className="btn-ghost row-action-btn"
                        onClick={() => job && navigate(`/jobs/${job.id}/instances/${row.instanceId}/execution`, { state: { job } })}
                        disabled={!job}
                      >
                        View <ChevronRight size={13} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

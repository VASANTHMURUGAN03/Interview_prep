import { useEffect, useState, useCallback } from 'react';
import { useParams, useLocation, useNavigate } from 'react-router-dom';
import { GitPullRequest } from 'lucide-react';
import dayjs from 'dayjs';

import PageHeader from '../../components/common/PageHeader';
import Loader from '../../components/common/Loader';
import ErrorState from '../../components/common/ErrorState';
import StatusBadge from '../../components/common/StatusBadge';
import StepRow from '../../components/execution/StepRow';
import executionService from '../../services/executionService';
import './ExecutionDetail.css';

export default function ExecutionDetail() {
  const { jobId, instanceId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const job = location.state?.job;

  const [execution, setExecution] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await executionService.getExecutionDetail(instanceId, job?.name || `Job #${jobId}`);
      setExecution(data);
    } catch (e) {
      setError('Failed to load execution detail.');
    } finally {
      setLoading(false);
    }
  }, [instanceId, job, jobId]);

  useEffect(() => { load(); }, [load]);

  const trail = [
    { label: 'Jobs', onClick: () => navigate('/jobs') },
    { label: job?.name || `Job #${jobId}`, onClick: () => navigate(`/jobs/${jobId}/instances`, { state: { job } }) },
    { label: `Instance #${instanceId}` },
  ];

  if (error) {
    return (
      <div>
        <PageHeader title="Execution Detail" trail={trail} />
        <ErrorState description={error} onRetry={load} />
      </div>
    );
  }

  const maxDurationMs = execution
    ? Math.max(...execution.steps.map((s) => s.readDurationMs + s.processDurationMs + s.writeDurationMs))
    : 1;
  const totalDurationSec = execution
    ? dayjs(execution.endTime).diff(dayjs(execution.startTime), 'second')
    : 0;

  return (
    <div>
      <PageHeader
        title="Execution Detail"
        trail={trail}
        actions={
          execution?.status === 'FAILED' && (
            <button
              className="btn-secondary"
              onClick={() => navigate(`/executions/${execution.id}/related-retries`, { state: { job } })}
            >
              <GitPullRequest size={15} />
              View Related Retries
            </button>
          )
        }
      />

      {loading ? (
        <Loader label="Loading execution…" />
      ) : (
        <>
          <div className="panel-card exec-summary">
            <div className="exec-summary-item">
              <span className="exec-summary-label">Status</span>
              <StatusBadge status={execution.status} />
            </div>
            <div className="exec-summary-item">
              <span className="exec-summary-label">Started</span>
              <span className="mono">{dayjs(execution.startTime).format('MMM D, HH:mm:ss')}</span>
            </div>
            <div className="exec-summary-item">
              <span className="exec-summary-label">Ended</span>
              <span className="mono">{dayjs(execution.endTime).format('MMM D, HH:mm:ss')}</span>
            </div>
            <div className="exec-summary-item">
              <span className="exec-summary-label">Duration</span>
              <span className="mono">{totalDurationSec}s</span>
            </div>
          </div>

          <div className="panel-card exec-steps">
            <h2 className="card-heading">Steps</h2>
            <p className="exec-steps-hint">Bar width shows relative duration across steps; segments show read/process/write split. Click a step for detail.</p>
            {execution.steps.map((step) => (
              <StepRow key={step.id} step={step} maxDurationMs={maxDurationMs} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

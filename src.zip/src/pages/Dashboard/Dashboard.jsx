import { useEffect, useState, useCallback } from 'react';
import {
  Database, CheckCircle2, Activity, XCircle, TrendingUp, RefreshCw, ChevronDown,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';
import dayjs from 'dayjs';

import PageHeader from '../../components/common/PageHeader';
import StatCard from '../../components/dashboard/StatCard';
import StatusBadge from '../../components/common/StatusBadge';
import Loader from '../../components/common/Loader';
import ErrorState from '../../components/common/ErrorState';
import EmptyState from '../../components/common/EmptyState';
import dashboardService from '../../services/dashboardService';
import jobsService from '../../services/jobsService';
import { colors } from '../../constants/tokens';
import './Dashboard.css';

const TIME_FILTERS = [
  { value: 'LAST_1_HOUR', label: 'Last 1 hour' },
  { value: 'LAST_6_HOURS', label: 'Last 6 hours' },
  { value: 'LAST_24_HOURS', label: 'Last 24 hours' },
  { value: 'TODAY', label: 'Today' },
  { value: 'THIS_WEEK', label: 'This week' },
  { value: 'LAST_MONTH', label: 'Last month' },
];

export default function Dashboard() {
  const [jobs, setJobs] = useState([]);
  const [selectedJob, setSelectedJob] = useState('ALL_JOBS');
  const [timeFilter, setTimeFilter] = useState('LAST_24_HOURS');

  const [stats, setStats] = useState(null);
  const [series, setSeries] = useState([]);
  const [recent, setRecent] = useState([]);
  const [topFailed, setTopFailed] = useState([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    jobsService.getAllJobs().then(setJobs).catch(() => {});
  }, []);

  const loadDashboard = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const jobName = selectedJob === 'ALL_JOBS' ? undefined : selectedJob;
      const [statsData, seriesData, recentData, topFailedData] = await Promise.all([
        dashboardService.getStats(timeFilter, jobName),
        dashboardService.getExecutionSeries(timeFilter),
        dashboardService.getRecentExecutions(),
        dashboardService.getTopFailedJobs(),
      ]);
      setStats(statsData);
      setSeries(seriesData);
      setRecent(recentData);
      setTopFailed(topFailedData);
    } catch (e) {
      setError('Failed to load dashboard data. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [timeFilter, selectedJob]);

  useEffect(() => {
    loadDashboard();
  }, [loadDashboard]);

  if (error) {
    return (
      <div>
        <PageHeader title="Dashboard" />
        <ErrorState description={error} onRetry={loadDashboard} />
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title="Dashboard"
        actions={
          <>
            <div className="select-wrapper">
              <select
                className="select-control"
                value={selectedJob}
                onChange={(e) => setSelectedJob(e.target.value)}
                disabled={loading}
              >
                <option value="ALL_JOBS">All Jobs</option>
                {jobs.map((job) => (
                  <option key={job.id} value={job.name}>{job.name}</option>
                ))}
              </select>
              <ChevronDown size={15} className="select-chevron" />
            </div>

            <div className="select-wrapper">
              <select
                className="select-control"
                value={timeFilter}
                onChange={(e) => setTimeFilter(e.target.value)}
                disabled={loading}
              >
                {TIME_FILTERS.map((f) => (
                  <option key={f.value} value={f.value}>{f.label}</option>
                ))}
              </select>
              <ChevronDown size={15} className="select-chevron" />
            </div>

            <button className="btn-primary" onClick={loadDashboard} disabled={loading}>
              <RefreshCw size={16} className={loading ? 'spin' : ''} />
              Refresh
            </button>
          </>
        }
      />

      <div className="stats-grid">
        <StatCard icon={Database} label="Total Jobs Triggered" value={stats?.totalJobs} variant="primary" loading={loading} />
        <StatCard icon={Activity} label="Active Jobs" value={stats?.activeJobs} variant="info" loading={loading} />
        <StatCard icon={CheckCircle2} label="Successful Jobs" value={stats?.totalSuccess?.toLocaleString()} variant="success" loading={loading} />
        <StatCard icon={XCircle} label="Failed Jobs" value={stats?.totalFailed} variant="danger" loading={loading} />
        <StatCard icon={TrendingUp} label="Success Rate" value={stats ? `${stats.successRate}%` : undefined} variant="warning" loading={loading} />
      </div>

      <div className="dashboard-grid">
        <div className="dashboard-card fade-in-up">
          <h2 className="card-heading">Success vs Failure</h2>
          {loading ? (
            <Loader label="Loading chart…" />
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={series}>
                <CartesianGrid strokeDasharray="3 3" stroke={colors.line} vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 12, fill: colors.inkMuted }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: colors.inkMuted }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{ borderRadius: 10, border: `1px solid ${colors.line}`, fontSize: 13 }}
                />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="success" name="Success" fill={colors.success} radius={[6, 6, 0, 0]} />
                <Bar dataKey="failed" name="Failed" fill={colors.danger} radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="dashboard-card fade-in-up">
          <h2 className="card-heading">Top Failed Jobs</h2>
          {loading ? (
            <Loader label="Loading…" />
          ) : topFailed.length === 0 ? (
            <EmptyState title="No failures" description="Nothing failed in this window." />
          ) : (
            <ul className="top-failed-list">
              {topFailed.map((job) => (
                <li key={job.name}>
                  <span className="top-failed-name">{job.name}</span>
                  <span className="top-failed-count">{job.failures}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <div className="dashboard-card fade-in-up">
        <h2 className="card-heading">Recent Executions</h2>
        {loading ? (
          <Loader label="Loading executions…" />
        ) : recent.length === 0 ? (
          <EmptyState title="No recent executions" description="Runs will show up here once a job executes." />
        ) : (
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Job Name</th>
                  <th>Status</th>
                  <th>Trigger</th>
                  <th>Start Time</th>
                  <th>Duration</th>
                </tr>
              </thead>
              <tbody>
                {recent.map((row) => (
                  <tr key={row.id}>
                    <td className="mono">{row.jobName}</td>
                    <td><StatusBadge status={row.status} size="sm" /></td>
                    <td>{row.triggeredBy}</td>
                    <td className="mono">{dayjs(row.startTime).format('MMM D, HH:mm')}</td>
                    <td className="mono">{row.durationSec}s</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

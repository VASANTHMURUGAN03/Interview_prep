import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { SlidersHorizontal, Plus, Edit3, Clock } from 'lucide-react';

import PageHeader from '../../components/common/PageHeader';
import Loader from '../../components/common/Loader';
import ErrorState from '../../components/common/ErrorState';
import EmptyState from '../../components/common/EmptyState';
import StatusBadge from '../../components/common/StatusBadge';
import ConfirmationDialog from '../../components/common/ConfirmationDialog';
import { useToast } from '../../context/ToastContext';
import jobConfigService from '../../services/jobConfigService';
import { describeCron } from '../../utils/cron';
import './JobConfiguration.css';

export default function JobConfiguration() {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [configs, setConfigs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [pendingToggle, setPendingToggle] = useState(null);
  const [toggling, setToggling] = useState(false);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const page = await jobConfigService.getConfigs(50, 0);
      setConfigs(page.content);
    } catch (e) {
      setError('Failed to load job configurations.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const confirmToggle = async () => {
    setToggling(true);
    try {
      if (pendingToggle.active) {
        await jobConfigService.deleteConfigByName(pendingToggle.name);
      } else {
        await jobConfigService.activateConfig(pendingToggle.name);
      }
      showToast(`${pendingToggle.name} ${pendingToggle.active ? 'disabled' : 'enabled'}.`, 'success');
      await load();
    } catch (err) {
      showToast(err.message || 'Failed to update job.', 'error');
    } finally {
      setToggling(false);
      setPendingToggle(null);
    }
  };

  if (error) {
    return (
      <div>
        <PageHeader title="Job Configuration" />
        <ErrorState description={error} onRetry={load} />
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title="Job Configuration"
        actions={
          <button className="btn-primary" onClick={() => navigate('/job-configuration/new')}>
            <Plus size={16} />
            New Job
          </button>
        }
      />

      {loading ? (
        <Loader label="Loading job configurations…" />
      ) : configs.length === 0 ? (
        <EmptyState icon={SlidersHorizontal} title="No job configurations yet" />
      ) : (
        <div className="panel-card">
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Entity</th>
                  <th>Strategy</th>
                  <th>Trigger</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {configs.map((job) => (
                  <tr key={job.id} className={!job.active ? 'row-disabled' : ''}>
                    <td className="mono">{job.name}</td>
                    <td>{job.entity}</td>
                    <td><span className="step-ref-type">{job.strategy}</span></td>
                    <td>
                      {job.trigger?.cron ? (
                        <span className="config-cron-desc"><Clock size={12} style={{ verticalAlign: 'text-bottom' }} /> {describeCron(job.trigger.cron)}</span>
                      ) : (
                        <span className="config-cron-desc">Manual / chained</span>
                      )}
                    </td>
                    <td>{job.lastStatus ? <StatusBadge status={job.lastStatus} size="sm" /> : '—'}</td>
                    <td>
                      <div className="row-actions">
                        <button className="btn-ghost row-action-btn" onClick={() => navigate(`/job-configuration/${job.name}/edit`)}>
                          <Edit3 size={14} /> Edit
                        </button>
                        <label className="row-action-btn config-toggle-label">
                          <input
                            type="checkbox"
                            checked={job.active}
                            onChange={() => setPendingToggle(job)}
                          />
                          {job.active ? 'Active' : 'Inactive'}
                        </label>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {pendingToggle && (
        <ConfirmationDialog
          title={pendingToggle.active ? 'Disable job configuration?' : 'Enable job configuration?'}
          message={
            pendingToggle.active
              ? `${pendingToggle.name} will be disabled (soft-deleted). It can be re-enabled any time.`
              : `${pendingToggle.name} will be re-enabled.`
          }
          confirmLabel={pendingToggle.active ? 'Disable' : 'Enable'}
          danger={pendingToggle.active}
          loading={toggling}
          onConfirm={confirmToggle}
          onCancel={() => setPendingToggle(null)}
        />
      )}
    </div>
  );
}

import { useEffect, useState, useCallback, useMemo } from 'react';
import { Layers, Plus, Edit3 } from 'lucide-react';
import dayjs from 'dayjs';

import PageHeader from '../../components/common/PageHeader';
import SearchBar from '../../components/common/SearchBar';
import Loader from '../../components/common/Loader';
import ErrorState from '../../components/common/ErrorState';
import EmptyState from '../../components/common/EmptyState';
import Modal from '../../components/common/Modal';
import StepTypeForm from '../../components/steptypes/StepTypeForm';
import { useToast } from '../../context/ToastContext';
import processStepService from '../../services/processStepService';
import { STEP_TYPES } from '../../constants/pipeline';
import './ProcessStepLibrary.css';

function emptyDraft() {
  return { name: '', type: 'JWT', params: {} };
}

export default function ProcessStepLibrary() {
  const { showToast } = useToast();
  const [steps, setSteps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');

  const [editing, setEditing] = useState(null); // step being edited, or emptyDraft() for new
  const [isNew, setIsNew] = useState(false);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await processStepService.getSteps();
      setSteps(data);
    } catch (e) {
      setError('Failed to load the process step library.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = useMemo(() => {
    if (!search.trim()) return steps;
    const q = search.toLowerCase();
    return steps.filter((s) => s.name.toLowerCase().includes(q) || s.type.toLowerCase().includes(q));
  }, [steps, search]);

  const openNew = () => { setEditing(emptyDraft()); setIsNew(true); };
  const openEdit = (step) => { setEditing(step); setIsNew(false); };

  const handleSave = async () => {
    if (!editing.name.trim()) {
      showToast('Step name is required.', 'error');
      return;
    }
    setSaving(true);
    try {
      await processStepService.upsertStep(editing);
      showToast(`${editing.name} saved.`, 'success');
      setEditing(null);
      load();
    } catch (e) {
      showToast(e.message || 'Failed to save step.', 'error');
    } finally {
      setSaving(false);
    }
  };

  if (error) {
    return (
      <div>
        <PageHeader title="Process Step Library" />
        <ErrorState description={error} onRetry={load} />
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title="Process Step Library"
        actions={
          <button className="btn-primary" onClick={openNew}>
            <Plus size={16} />
            New Step
          </button>
        }
      />

      <SearchBar
        value={search}
        onChange={setSearch}
        placeholder="Search by name or type…"
        resultLabel={loading ? undefined : `${filtered.length} step(s)`}
      />

      {loading ? (
        <Loader label="Loading step library…" />
      ) : filtered.length === 0 ? (
        <EmptyState icon={Layers} title="No steps found" />
      ) : (
        <div className="panel-card">
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Type</th>
                  <th>Status</th>
                  <th>Updated</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((step) => (
                  <tr key={step.id} className={!step.active ? 'row-disabled' : ''}>
                    <td className="mono">{step.name}</td>
                    <td><span className="step-ref-type">{step.type}</span></td>
                    <td>{step.active ? 'Active' : 'Inactive'}</td>
                    <td className="mono">{step.updatedAt ? dayjs(step.updatedAt).format('MMM D, HH:mm') : '—'}</td>
                    <td>
                      <button className="btn-ghost row-action-btn" onClick={() => openEdit(step)}>
                        <Edit3 size={14} /> Edit
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {editing && (
        <Modal
          title={isNew ? 'New Process Step' : `Edit — ${editing.name}`}
          onClose={() => setEditing(null)}
          width={640}
          footer={
            <>
              <button className="btn-secondary" onClick={() => setEditing(null)} disabled={saving}>Cancel</button>
              <button className="btn-primary" onClick={handleSave} disabled={saving}>
                {saving ? 'Saving…' : 'Save Step'}
              </button>
            </>
          }
        >
          <div className="field-grid step-editor-basics">
            <label className="field-label">
              Name
              <input
                className="text-input mono"
                value={editing.name}
                disabled={!isNew}
                onChange={(e) => setEditing({ ...editing, name: e.target.value })}
              />
            </label>
            <label className="field-label">
              Type
              <select
                className="select-control"
                value={editing.type}
                onChange={(e) => setEditing({ ...editing, type: e.target.value, params: {} })}
              >
                {STEP_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
              </select>
            </label>
          </div>

          <StepTypeForm
            type={editing.type}
            params={editing.params}
            onChange={(params) => setEditing({ ...editing, params })}
          />
        </Modal>
      )}
    </div>
  );
}

import { useEffect, useState, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Briefcase, Play, ChevronRight } from 'lucide-react';
import dayjs from 'dayjs';

import PageHeader from '../../components/common/PageHeader';
import SearchBar from '../../components/common/SearchBar';
import Loader from '../../components/common/Loader';
import ErrorState from '../../components/common/ErrorState';
import EmptyState from '../../components/common/EmptyState';
import StatusBadge from '../../components/common/StatusBadge';
import TriggerJobModal from '../../components/jobs/TriggerJobModal';
import jobsService from '../../services/jobsService';
import './JobsList.css';

export default function JobsList() {
  const navigate = useNavigate();
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [triggerJob, setTriggerJob] = useState(null);

  const loadJobs = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await jobsService.getAllJobs();
      setJobs(data);
    } catch (e) {
      setError('Failed to load jobs. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadJobs();
  }, [loadJobs]);

  const filteredJobs = useMemo(() => {
    if (!search.trim()) return jobs;
    return jobs.filter((j) => j.name.toLowerCase().includes(search.toLowerCase()));
  }, [jobs, search]);

  const openInstances = (job) => navigate(`/jobs/${job.id}/instances`, { state: { job } });

  if (error) {
    return (
      <div>
        <PageHeader title="Jobs" />
        <ErrorState description={error} onRetry={loadJobs} />
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="Jobs" />

      <SearchBar
        value={search}
        onChange={setSearch}
        placeholder="Search jobs by name…"
        resultLabel={loading ? undefined : `${filteredJobs.length} ${filteredJobs.length === 1 ? 'job' : 'jobs'} found`}
      />

      {loading ? (
        <Loader label="Loading jobs…" />
      ) : filteredJobs.length === 0 ? (
        <EmptyState
          icon={Briefcase}
          title="No jobs found"
          description={search ? 'Try adjusting your search query.' : 'No scheduler jobs are registered yet.'}
        />
      ) : (
        <div className="panel-card fade-in-up">
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Job Name</th>
                  <th>Instances</th>
                  <th>Last Run</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredJobs.map((job) => (
                  <tr key={job.id} className="jobs-table-row" onClick={() => openInstances(job)}>
                    <td>
                      <div className="jobs-table-name">
                        <span className="jobs-table-icon">{job.name?.[0]?.toUpperCase() || '?'}</span>
                        <span className="mono">{job.name}</span>
                      </div>
                    </td>
                    <td>{job.totalInstances}</td>
                    <td className="mono">{dayjs(job.lastRun).format('MMM D, HH:mm')}</td>
                    <td><StatusBadge status={job.status} size="sm" /></td>
                    <td>
                      <div className="row-actions" onClick={(e) => e.stopPropagation()}>
                        <button className="btn-secondary btn-sm" onClick={() => setTriggerJob(job)}>
                          <Play size={13} />
                          Trigger
                        </button>
                        <button className="btn-ghost row-action-btn" onClick={() => openInstances(job)}>
                          View
                          <ChevronRight size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {triggerJob && (
        <TriggerJobModal job={triggerJob} onClose={() => setTriggerJob(null)} />
      )}
    </div>
  );
}

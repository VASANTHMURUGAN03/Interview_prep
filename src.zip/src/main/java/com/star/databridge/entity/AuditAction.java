package com.star.databridge.entity;

/** NEW FILE. */
public enum AuditAction {
    CONFIG_CREATED,
    CONFIG_UPDATED,
    JOB_ENABLED,
    JOB_DISABLED,
    CRON_CHANGED,
    MANUAL_EXECUTION
}

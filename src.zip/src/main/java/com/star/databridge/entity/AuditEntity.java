package com.star.databridge.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

/**
 * NEW FILE — new collection "job_audit_logs". Separate from job_configs
 * deliberately (per the request): an audit trail should be append-only and
 * never touched by the same upsert path that manages live config state.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "job_audit_logs")
public class AuditEntity {

    @Id
    private String id;

    @Indexed
    private String jobId;

    @Indexed
    private String jobName;

    @Indexed
    private AuditAction action;

    /** JSON string snapshot — serialized via ObjectMapperUtil, not a typed field,
     *  since "previous/new value" can be a whole JobConfigEntity, a cron string,
     *  or an active flag depending on the action. */
    private String previousValue;
    private String newValue;

    @Indexed
    private String userId;
    private String username;

    private String remarks;

    @CreatedDate
    @Builder.Default
    private LocalDateTime timestamp = LocalDateTime.now();
}

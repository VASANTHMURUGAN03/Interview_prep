package com.star.databridge.service;

import com.star.databridge.entity.AuditAction;
import com.star.databridge.entity.AuditEntity;
import com.star.databridge.repository.AuditRepository;
import com.star.databridge.util.ObjectMapperUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * NEW FILE. recordAudit() is the single write path — called from
 * JobConfigService (create/update/enable/disable/cron-change) and
 * JobExecutionService (manual trigger). It deliberately never throws: a
 * failure to write an audit row should never block the actual business
 * operation it's describing (logged instead — see the catch below).
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuditService {

    private final AuditRepository auditRepository;
    private final MongoTemplate mongoTemplate;

    public void recordAudit(String jobId, String jobName, AuditAction action,
                             Object previousValue, Object newValue,
                             String userId, String username, String remarks) {
        try {
            AuditEntity audit = AuditEntity.builder()
                    .jobId(jobId)
                    .jobName(jobName)
                    .action(action)
                    .previousValue(previousValue != null ? ObjectMapperUtil.convertObjectToString(previousValue) : null)
                    .newValue(newValue != null ? ObjectMapperUtil.convertObjectToString(newValue) : null)
                    .userId(userId != null ? userId : "system")
                    .username(username != null ? username : "system")
                    .remarks(remarks)
                    .timestamp(LocalDateTime.now())
                    .build();

            auditRepository.save(audit);
        } catch (Exception e) {
            // Audit failures must never break the operation being audited.
            log.error("[Audit] Failed to record {} for job '{}'", action, jobName, e);
        }
    }

    public Page<AuditEntity> getHistoryByJob(String jobName, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "timestamp"));
        return auditRepository.findByJobName(jobName, pageable);
    }

    /**
     * General audit search — all filters optional. sortBy defaults to
     * "timestamp" if not a recognized field.
     */
    public Page<AuditEntity> search(String jobName, String userId, AuditAction action,
                                     LocalDateTime from, LocalDateTime to,
                                     int page, int size, String sortBy, Sort.Direction direction) {
        List<Criteria> filters = new ArrayList<>();
        if (jobName != null && !jobName.isBlank()) {
            filters.add(Criteria.where("jobName").regex(jobName, "i"));
        }
        if (userId != null && !userId.isBlank()) {
            filters.add(Criteria.where("userId").is(userId));
        }
        if (action != null) {
            filters.add(Criteria.where("action").is(action));
        }
        if (from != null) {
            filters.add(Criteria.where("timestamp").gte(from));
        }
        if (to != null) {
            filters.add(Criteria.where("timestamp").lte(to));
        }

        Criteria criteria = filters.isEmpty() ? new Criteria() : new Criteria().andOperator(filters.toArray(new Criteria[0]));

        List<String> sortableFields = List.of("timestamp", "jobName", "action", "username");
        String effectiveSortBy = sortableFields.contains(sortBy) ? sortBy : "timestamp";
        Sort.Direction effectiveDirection = direction != null ? direction : Sort.Direction.DESC;

        Query query = new Query(criteria).with(Sort.by(effectiveDirection, effectiveSortBy));
        long total = mongoTemplate.count(query, AuditEntity.class);

        query.skip((long) page * size).limit(size);
        List<AuditEntity> content = mongoTemplate.find(query, AuditEntity.class);

        return new org.springframework.data.domain.PageImpl<>(content, PageRequest.of(page, size), total);
    }
}

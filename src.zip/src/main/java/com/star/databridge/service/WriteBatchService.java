package com.star.databridge.service;

import com.star.databridge.dto.mongo.StatusCount;
import com.star.databridge.dto.mongo.WriteRecordDetail;
import com.star.databridge.entity.WriteBatchExecutionEntity;
import com.star.databridge.repository.WriteBatchExecutionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class WriteBatchService {

    private final WriteBatchExecutionRepository writeBatchExecutionRepository;
    private final MongoTemplate mongoTemplate;

    public WriteBatchExecutionEntity createBatch(String jobExecutionId, String entity, List<String> recordIds) {
        WriteBatchExecutionEntity writeBatch = WriteBatchExecutionEntity.builder()
                .jobExecutionId(jobExecutionId)
                .entity(entity)
                .recordIds(recordIds)
                .build();

        return writeBatchExecutionRepository.save(writeBatch);
    }

    public void updateBatchStatus(WriteBatchExecutionEntity writeBatch, String status, String referenceId, String errorMessage, WriteRecordDetail details) {
        writeBatch.setStatus(status);
        if (referenceId != null) {
            writeBatch.setReferenceId(referenceId);
        }
        if (errorMessage != null) {
            writeBatch.setErrorMessage(errorMessage);
        }
        if (details != null) {
            writeBatch.setDetails(details);
        }
        writeBatchExecutionRepository.save(writeBatch);
    }

    public void updateRecords(WriteBatchExecutionEntity writeBatch, List<String> recordIds) {
        writeBatch.setRecordIds(recordIds);
        writeBatch.setStatus("RUNNING");
        writeBatchExecutionRepository.save(writeBatch);
    }

    /**
     * Marks every non-terminal write batch for the given job execution as FAILED.
     * Used by the abort flow to drain any batches still sitting in the queue.
     */
    public void terminalizeNonTerminal(String jobExecutionId) {
        Criteria criteria = Criteria
                .where("jobExecutionId").is(jobExecutionId)
                .and("status").nin(List.of("SUCCESS", "FAILED"));

        Query query = new Query(criteria);
        Update update = new Update().set("status", "FAILED");

        mongoTemplate.updateMulti(query, update, WriteBatchExecutionEntity.class);
    }

    public List<StatusCount> getStatusWiseCount(String jobExecutionId) {
        Aggregation agg = Aggregation.newAggregation(
                Aggregation.match(Criteria.where("jobExecutionId").is(jobExecutionId)),
                Aggregation.group("status").count().as("totalCount"),
                Aggregation.project("totalCount").and("_id").as("status") // Rename _id to status
        );

        AggregationResults<StatusCount> results = mongoTemplate.aggregate(
                agg,
                "write_batch_executions",
                StatusCount.class
        );

        return results.getMappedResults();
    }

    /** Powers the Execution Detail write-batches panel. */
    public List<WriteBatchExecutionEntity> listByJobExecutionId(String jobExecutionId) {
        return writeBatchExecutionRepository.findByJobExecutionIdOrderByCreatedAtAsc(jobExecutionId);
    }

    /** Used by manual retry and the retry-chain endpoint below. */
    public WriteBatchExecutionEntity getById(String id) {
        return writeBatchExecutionRepository.findById(id).orElse(null);
    }

    /** Called by publishWriteRetry() (both the automatic and manual retry
     *  paths funnel through it) to link a new retry batch back to the one
     *  it retried — this is what makes Related Retries possible. */
    public void linkRetry(String newBatchId, String originalBatchId) {
        Query query = new Query(Criteria.where("_id").is(newBatchId));
        Update update = new Update().set("retriedFromBatchId", originalBatchId);
        mongoTemplate.updateFirst(query, update, WriteBatchExecutionEntity.class);
    }

    /**
     * Walks the retry chain forward from the given batch (which may itself
     * be a retry, or the original) and returns every batch in the chain,
     * oldest first. Used by the Related Retries UI.
     */
    public List<WriteBatchExecutionEntity> getRetryChain(String batchId) {
        WriteBatchExecutionEntity current = getById(batchId);
        if (current == null) {
            return List.of();
        }

        WriteBatchExecutionEntity original = current;
        while (original.getRetriedFromBatchId() != null) {
            WriteBatchExecutionEntity parent = getById(original.getRetriedFromBatchId());
            if (parent == null) break;
            original = parent;
        }

        List<WriteBatchExecutionEntity> chain = new java.util.ArrayList<>();
        chain.add(original);
        String cursor = original.getId();
        List<WriteBatchExecutionEntity> next = writeBatchExecutionRepository.findByRetriedFromBatchId(cursor);
        while (!next.isEmpty()) {
            chain.addAll(next);
            cursor = next.get(next.size() - 1).getId();
            next = writeBatchExecutionRepository.findByRetriedFromBatchId(cursor);
        }
        return chain;
    }
}

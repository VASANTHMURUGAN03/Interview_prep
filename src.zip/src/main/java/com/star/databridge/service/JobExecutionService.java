package com.star.databridge.service;

import com.star.databridge.dto.mongo.StatusCount;
import com.star.databridge.dto.response.ReadBatchRetryStateDto;
import com.star.databridge.dto.response.TriggerJobResponse;
import com.star.databridge.entity.AuditAction;
import com.star.databridge.entity.JobConfigEntity;
import com.star.databridge.entity.JobExecutionEntity;
import com.star.databridge.entity.ReadBatchExecutionEntity;
import com.star.databridge.entity.StepExecutionEntity;
import com.star.databridge.entity.WriteBatchExecutionEntity;
import com.star.databridge.repository.JobConfigRepository;
import com.star.databridge.repository.JobExecutionRepository;
import com.star.databridge.repository.StepExecutionRepository;
import com.star.databridge.util.KafkaUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@RequiredArgsConstructor
@Service
@Slf4j
public class JobExecutionService {

    private static final Set<String> TERMINAL_STATUSES = Set.of("COMPLETED", "FAILED", "ABORTED");

    private final JobConfigRepository jobConfigRepository;
    private final ReadBatchService readBatchService;
    private final WriteBatchService writeBatchService;
    private final SyncRecordService syncRecordService;
    private final JobExecutionRepository jobExecutionRepository;
    private final KafkaUtil kafkaUtil;

    // --- added across the missing-APIs / JobRunr+audit / gap-analysis batches ---
    private final MongoTemplate mongoTemplate;
    private final StepExecutionRepository stepExecutionRepository;
    private final WriteBatchProcessor writeBatchProcessor;
    private final AuditService auditService;

    public TriggerJobResponse triggerJob(String jobName) {
        Optional<JobConfigEntity> optionalJobConfig = jobConfigRepository.findByNameAndActive(jobName, true);

        if (optionalJobConfig.isEmpty()) {
            throw new RuntimeException("Job configuration not found: " + jobName);
        }

        JobConfigEntity jobConfig = optionalJobConfig.get();

        log.info("Triggering Job: {}", jobConfig.getName());
        JobExecutionEntity jobExecution = createJobExecution(jobConfig);

        // Create first read batch execution
        ReadBatchExecutionEntity firstReadBatch = readBatchService.createBatch(
                jobConfig, jobExecution.getId(), 1);

        // Publish first read batch message
        kafkaUtil.pushReadBatchMsg(firstReadBatch, null);

        // Publish completion check message
        kafkaUtil.pushCompletionCheckMsg(jobConfig.getId(), jobExecution.getId());

        return TriggerJobResponse.builder()
                .jobId(jobExecution.getJobUuid())
                .jobName(jobName)
                .jobExecutionId(jobExecution.getId())
                .build();
    }

    public JobExecutionEntity createJobExecution(JobConfigEntity config) {
        String jobUuid = UUID.randomUUID().toString();
        JobExecutionEntity entity = new JobExecutionEntity();
        entity.setJobId(config.getId());
        entity.setJobName(config.getName());
        entity.setJobConfig(config);
        entity.setJobUuid(jobUuid);
        entity.setCreatedAt(LocalDateTime.now());
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setContext(new HashMap<>());

        return jobExecutionRepository.save(entity);
    }

    public void updateStatus(String jobExecutionId, Map<String, List<StatusCount>> stats, String status) {
        jobExecutionRepository.findById(jobExecutionId).ifPresent(entity -> {
            entity.setStatus(status);
            entity.setStats(stats);
            jobExecutionRepository.save(entity);
        });
    }

    /**
     * Manually aborts a running job identified by its public {@code jobUuid}.
     * Marks the job as ABORTED and terminates all non-terminal read batches,
     * write batches, and sync records so the completion check stops waiting.
     *
     * @throws IllegalArgumentException if no job is found for the given uuid
     * @throws IllegalStateException    if the job is already in a terminal state
     */
    public JobExecutionEntity abortJobByUuid(String jobUuid) {
        JobExecutionEntity jobExecution = jobExecutionRepository.findByJobUuid(jobUuid)
                .orElseThrow(() -> new IllegalArgumentException("Job not found: " + jobUuid));

        if (TERMINAL_STATUSES.contains(jobExecution.getStatus())) {
            throw new IllegalStateException(
                    "Job " + jobUuid + " is already in terminal state: " + jobExecution.getStatus());
        }

        log.info("[JobExecution] Manually aborting job uuid={} id={}", jobUuid, jobExecution.getId());

        jobExecution.setStatus("ABORTED");
        jobExecutionRepository.save(jobExecution);

        String jobExecutionId = jobExecution.getId();
        readBatchService.terminalizeNonTerminal(jobExecutionId);
        writeBatchService.terminalizeNonTerminal(jobExecutionId);
        syncRecordService.terminalizeNonTerminal(jobExecutionId, "Job aborted by user");

        return jobExecution;
    }

    /**
     * Aborts a running job due to an internal failure: marks the job as FAILED
     * and terminates all non-terminal read batches and sync records so the
     * completion check stops waiting on them.
     */
    public void abortJob(String jobExecutionId, String reason) {
        log.error("[JobExecution] Aborting job {} — reason: {}", jobExecutionId, reason);

        jobExecutionRepository.findById(jobExecutionId).ifPresent(entity -> {
            entity.setStatus("FAILED");
            entity.setErrorMessage(reason);
            jobExecutionRepository.save(entity);
        });

        readBatchService.terminalizeNonTerminal(jobExecutionId);
        syncRecordService.terminalizeNonTerminal(jobExecutionId, reason);
    }

    // =========================================================================
    // Read APIs — list/detail, batches, step executions (missing-APIs batch)
    // =========================================================================

    public List<JobExecutionEntity> getExecutions(String jobName, String status, Integer limit, Integer pageNumber) {
        int intLimit = limit != null ? Math.min(limit, 50) : 20;
        int offset = pageNumber != null ? pageNumber : 0;

        List<Criteria> filters = new ArrayList<>();
        if (jobName != null && !jobName.isBlank()) {
            filters.add(Criteria.where("jobName").is(jobName));
        }
        if (status != null && !status.isBlank()) {
            filters.add(Criteria.where("status").is(status));
        }

        Criteria criteria = filters.isEmpty() ? new Criteria() : new Criteria().andOperator(filters.toArray(new Criteria[0]));

        Query query = new Query(criteria)
                .with(Sort.by(Sort.Direction.DESC, "updatedAt"))
                .skip((long) offset * intLimit)
                .limit(intLimit);

        return mongoTemplate.find(query, JobExecutionEntity.class);
    }

    public JobExecutionEntity getExecutionById(String jobExecutionId) {
        return jobExecutionRepository.findById(jobExecutionId).orElse(null);
    }

    public List<ReadBatchExecutionEntity> getReadBatches(String jobExecutionId) {
        return readBatchService.listByJobExecutionId(jobExecutionId);
    }

    public List<WriteBatchExecutionEntity> getWriteBatches(String jobExecutionId) {
        return writeBatchService.listByJobExecutionId(jobExecutionId);
    }

    /**
     * @param batchId   optional — narrows to one batch's steps
     * @param batchType optional — "READ" or "WRITE"/"ACK"; ignored if batchId is set
     */
    public List<StepExecutionEntity> getStepExecutions(String jobExecutionId, String batchId, String batchType) {
        if (batchId != null && !batchId.isBlank()) {
            return stepExecutionRepository.findByJobExecutionIdAndBatchIdOrderByStartedAtAsc(jobExecutionId, batchId);
        }
        if (batchType != null && !batchType.isBlank()) {
            return stepExecutionRepository.findByJobExecutionIdAndBatchTypeOrderByStartedAtAsc(jobExecutionId, batchType);
        }
        return stepExecutionRepository.findByJobExecutionIdOrderByStartedAtAsc(jobExecutionId);
    }

    // =========================================================================
    // Manual retry (retry-feasibility report's "minimal impact" option) —
    // forces a re-run of a FAILED batch without touching maxRetryCount.
    // =========================================================================

    public void retryBatch(String jobExecutionId, String batchId, String batchType, String fromStep) {
        if ("READ".equalsIgnoreCase(batchType)) {
            retryReadBatch(jobExecutionId, batchId);
        } else if ("WRITE".equalsIgnoreCase(batchType)) {
            retryWriteBatch(batchId);
        } else {
            throw new IllegalArgumentException("batchType must be READ or WRITE");
        }
        log.info("[ManualRetry] jobExecutionId={} batchId={} batchType={} fromStep={} — retry published",
                jobExecutionId, batchId, batchType, fromStep);
    }

    private void retryReadBatch(String jobExecutionId, String batchId) {
        ReadBatchExecutionEntity failedBatch = readBatchService.getById(batchId);
        if (failedBatch == null) {
            throw new IllegalArgumentException("Read batch not found: " + batchId);
        }
        if (!"FAILED".equals(failedBatch.getStatus())) {
            throw new IllegalStateException(
                    "Only a FAILED read batch can be manually retried — current status=" + failedBatch.getStatus());
        }

        // The cursor this batch should resume from isn't stored on the batch
        // itself (only the NEXT batch's cursor is, on success) — derive it
        // from the preceding batch, same as a fresh sequential read would use.
        String cursor = null;
        if (failedBatch.getBatchNo() > 1) {
            cursor = readBatchService.listByJobExecutionId(jobExecutionId).stream()
                    .filter(b -> b.getBatchNo() == failedBatch.getBatchNo() - 1)
                    .map(ReadBatchExecutionEntity::getNextCursor)
                    .findFirst()
                    .orElse(null);
        }

        JobExecutionEntity jobExecution = jobExecutionRepository.findById(jobExecutionId)
                .orElseThrow(() -> new IllegalArgumentException("Job execution not found: " + jobExecutionId));

        ReadBatchExecutionEntity retryBatch = readBatchService.createBatch(
                jobExecution.getJobConfig(), jobExecutionId, failedBatch.getBatchNo());

        kafkaUtil.pushReadBatchMsg(retryBatch, cursor);
    }

    private void retryWriteBatch(String batchId) {
        WriteBatchExecutionEntity failedBatch = writeBatchService.getById(batchId);
        if (failedBatch == null) {
            throw new IllegalArgumentException("Write batch not found: " + batchId);
        }
        if (!"FAILED".equals(failedBatch.getStatus())) {
            throw new IllegalStateException(
                    "Only a FAILED write batch can be manually retried — current status=" + failedBatch.getStatus());
        }

        List<String> failedRecordIds = syncRecordService.findByWriteBatchExecutionId(batchId).stream()
                .filter(r -> "FAILED".equals(r.getStatus()))
                .map(com.star.databridge.entity.SyncRecordEntity::getId)
                .toList();

        if (failedRecordIds.isEmpty()) {
            throw new IllegalStateException("No FAILED records found on write batch " + batchId + " to retry");
        }

        // Reset to RETRY WITHOUT touching retryCount — a manual retry
        // shouldn't silently eat into the automatic-retry budget.
        syncRecordService.setRecordStatus(failedRecordIds, "RETRY");

        writeBatchProcessor.publishWriteRetry(failedBatch);
    }

    /** Related Retries — write side chains linked batches (see WriteBatchService.getRetryChain). */
    public List<WriteBatchExecutionEntity> getWriteBatchRetryChain(String batchId) {
        return writeBatchService.getRetryChain(batchId);
    }

    /**
     * Related Retries — read side. Unlike write batches, a read batch's
     * retries mutate the SAME document in place, so there's no chain to
     * walk, only current state (see GAP_ANALYSIS for why).
     */
    public ReadBatchRetryStateDto getReadBatchRetryState(String batchId) {
        ReadBatchExecutionEntity batch = readBatchService.getById(batchId);
        if (batch == null) {
            throw new IllegalArgumentException("Read batch not found: " + batchId);
        }
        return ReadBatchRetryStateDto.builder()
                .batchId(batch.getId())
                .batchNo(batch.getBatchNo())
                .status(batch.getStatus())
                .retryCount(batch.getRetryCount() != null ? batch.getRetryCount() : 0)
                .remarks(batch.getRemarks())
                .build();
    }

    // =========================================================================
    // Manual trigger with params + audit (supersedes the plain audit-only
    // version — this is the one actually wired to the controller)
    // =========================================================================

    /**
     * HONEST LIMITATION: params are stored on JobExecutionEntity.context
     * (visible via the execution-detail API) but nothing in the pipeline
     * (VariableResolver, Process/Sink/AckExecutorService) reads FROM that
     * field today — "context" in VariableResolver means "another step's
     * output," a different meaning of the same word. Making these params
     * actually override reader/step behavior needs a new variable type
     * added to VariableResolver, which is a real change to existing
     * business logic and wasn't done here. What IS done: safe, durable
     * storage of the params against the execution, ready for that
     * follow-up.
     */
    public TriggerJobResponse triggerJobManually(String name, Map<String, Object> params, String userId, String username) {
        TriggerJobResponse response = triggerJobWithContext(name, "MANUAL", params);

        auditService.recordAudit(
                response.getJobExecutionId(), name, AuditAction.MANUAL_EXECUTION,
                null, params, userId, username, "Triggered manually via API");

        return response;
    }

    /**
     * Parallel path to triggerJob(String), which stays UNCHANGED so the
     * JobRunr recurring callback and the postComplete chain-trigger call
     * site (JobCompletionCheckConsumer) keep working exactly as before.
     */
    private TriggerJobResponse triggerJobWithContext(String jobName, String triggeredBy, Map<String, Object> params) {
        Optional<JobConfigEntity> optionalJobConfig = jobConfigRepository.findByNameAndActive(jobName, true);
        if (optionalJobConfig.isEmpty()) {
            throw new RuntimeException("Job configuration not found: " + jobName);
        }
        JobConfigEntity jobConfig = optionalJobConfig.get();

        log.info("Triggering Job: {} (triggeredBy={})", jobConfig.getName(), triggeredBy);

        JobExecutionEntity jobExecution = createJobExecution(jobConfig);
        jobExecution.setTriggeredBy(triggeredBy);
        if (params != null && !params.isEmpty()) {
            jobExecution.getContext().putAll(params);
        }
        jobExecutionRepository.save(jobExecution);

        ReadBatchExecutionEntity firstReadBatch = readBatchService.createBatch(jobConfig, jobExecution.getId(), 1);
        kafkaUtil.pushReadBatchMsg(firstReadBatch, null);
        kafkaUtil.pushCompletionCheckMsg(jobConfig.getId(), jobExecution.getId());

        return TriggerJobResponse.builder()
                .jobId(jobExecution.getJobUuid())
                .jobName(jobName)
                .jobExecutionId(jobExecution.getId())
                .build();
    }
}

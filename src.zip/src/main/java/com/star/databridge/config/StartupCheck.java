package com.star.databridge.config;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.bson.UuidRepresentation;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.nosql.mongo.MongoDBStorageProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class StartupCheck {

    private final Environment environment;

    @PostConstruct
    public void check() {
        System.out.println(
                "UUID REP = " +
                        environment.getProperty(
                                "spring.data.mongodb.uuid-representation"
                        )
        );
    }

//    @Bean
//    public StorageProvider storageProvider(
//            MongoDatabaseFactory mongoDatabaseFactory,
//            @Value("${spring.data.mongodb.uri}") String uri) {
//
//        MongoClientSettings settings = MongoClientSettings.builder()
//                .applyConnectionString(new ConnectionString(uri))
//                .uuidRepresentation(UuidRepresentation.STANDARD)
//                .build();
//
//        MongoClient client = MongoClients.create(settings);
//
//        String databaseName =
//                mongoDatabaseFactory.getMongoDatabase().getName();
//
//        return new MongoDBStorageProvider(client, databaseName);
//    }
}

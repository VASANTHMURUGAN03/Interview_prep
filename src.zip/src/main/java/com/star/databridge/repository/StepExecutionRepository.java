package com.star.databridge.repository;

import com.star.databridge.entity.StepExecutionEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * NEW FILE — step_executions currently has no read-side repository at all;
 * it's only ever written to (via StepExecutionLogService.upsertStepExecutionLog,
 * triggered by StepService.runStep's Kafka log publish). This is what the
 * Execution Detail UI needs to show real step-by-step data instead of a
 * fabricated timeline.
 */
@Repository
public interface StepExecutionRepository extends MongoRepository<StepExecutionEntity, String> {

    List<StepExecutionEntity> findByJobExecutionIdOrderByStartedAtAsc(String jobExecutionId);

    List<StepExecutionEntity> findByJobExecutionIdAndBatchIdOrderByStartedAtAsc(String jobExecutionId, String batchId);

    List<StepExecutionEntity> findByJobExecutionIdAndBatchTypeOrderByStartedAtAsc(String jobExecutionId, String batchType);
}

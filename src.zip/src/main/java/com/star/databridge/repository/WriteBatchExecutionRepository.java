package com.star.databridge.repository;

import com.star.databridge.entity.WriteBatchExecutionEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface WriteBatchExecutionRepository extends MongoRepository<WriteBatchExecutionEntity, String> {
    Optional<WriteBatchExecutionEntity> findByIdAndStatus(String id, String status);

    List<WriteBatchExecutionEntity> findByJobExecutionIdOrderByCreatedAtAsc(String jobExecutionId);

    List<WriteBatchExecutionEntity> findByRetriedFromBatchId(String retriedFromBatchId);
}

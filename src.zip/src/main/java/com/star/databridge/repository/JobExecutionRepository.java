package com.star.databridge.repository;

import com.star.databridge.entity.JobExecutionEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface JobExecutionRepository extends MongoRepository<JobExecutionEntity, String> {
    Optional<JobExecutionEntity> findByIdAndStatus(String id, String status);
    Optional<JobExecutionEntity> findByJobUuid(String jobUuid);
    Optional<JobExecutionEntity> findTopByJobNameOrderByCreatedAtDesc(String jobName);
}

package com.star.databridge.repository;

import com.star.databridge.entity.AuditEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/**
 * NEW FILE. Simple derived-query methods only — the multi-filter search
 * (job/user/action/date-range combined) lives in AuditService via
 * MongoTemplate + Criteria, same pattern as JobExecutionService.getExecutions()
 * and SyncRecordService.search() added earlier, since Spring Data can't
 * express "any combination of these optional filters" as one derived method.
 */
@Repository
public interface AuditRepository extends MongoRepository<AuditEntity, String> {
    Page<AuditEntity> findByJobName(String jobName, Pageable pageable);
}

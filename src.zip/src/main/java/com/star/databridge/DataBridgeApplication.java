package com.star.databridge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.jdbc.autoconfigure.DataSourceAutoConfiguration;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.kafka.annotation.EnableKafka;

@SpringBootApplication(
		scanBasePackages = { "com.star.databridge", "com.starhealth.encryption" },
		exclude = { DataSourceAutoConfiguration.class }
)
@EnableKafka
@EnableMongoAuditing
public class DataBridgeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataBridgeApplication.class, args);
	}

}

package com.star.databridge.controller;

import com.star.databridge.dto.request.TriggerJobRequest;
import com.star.databridge.dto.response.ApiResponse;
import com.star.databridge.dto.response.TriggerJobResponse;
import com.star.databridge.entity.JobExecutionEntity;
import com.star.databridge.service.JobExecutionService;
import com.star.databridge.service.StepExecutionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/jobs")
@Slf4j
public class JobExecutionController {

    private final JobExecutionService jobExecutionService;
    private final StepExecutionService stepExecutionService;

    /**
     * Now accepts an optional request body of trigger params (stored on the
     * execution's context — see JobExecutionService.triggerJobWithContext's
     * javadoc for the honest limitation on how far these currently reach
     * into the pipeline) and two optional identity headers, used to audit
     * the manual trigger. Same URL/method as before this change.
     */
    @PostMapping("/trigger/{name}")
    public ResponseEntity<ApiResponse<?>> triggerJobByName(
            @PathVariable String name,
            @RequestBody(required = false) TriggerJobRequest request,
            @RequestHeader(value = "X-User-Id", required = false) String userId,
            @RequestHeader(value = "X-User-Name", required = false) String username) {

        Map<String, Object> params = request != null ? request.getParams() : null;
        TriggerJobResponse response = jobExecutionService.triggerJobManually(name, params, userId, username);

        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(response)
                .build());
    }

    @PostMapping("/abort/{jobUuid}")
    public ResponseEntity<ApiResponse<?>> abortJob(@PathVariable String jobUuid) {
        try {
            JobExecutionEntity jobExecution = jobExecutionService.abortJobByUuid(jobUuid);
            return ResponseEntity.ok().body(ApiResponse
                    .builder()
                    .statusCode(HttpStatus.OK.value())
                    .message("Job aborted successfully")
                    .data(jobExecution.getJobUuid())
                    .build());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse
                    .builder()
                    .statusCode(HttpStatus.NOT_FOUND.value())
                    .message(e.getMessage())
                    .build());
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ApiResponse
                    .builder()
                    .statusCode(HttpStatus.CONFLICT.value())
                    .message(e.getMessage())
                    .build());
        }
    }

    // =========================================================================
    // Read APIs — execution list/detail, batches, step executions
    // =========================================================================

    @GetMapping("/executions")
    public ResponseEntity<ApiResponse<?>> getExecutions(
            @RequestParam(value = "jobName", required = false) String jobName,
            @RequestParam(value = "status", required = false) String status,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "pageNumber", required = false) Integer pageNumber) {
        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(jobExecutionService.getExecutions(jobName, status, limit, pageNumber))
                .build());
    }

    @GetMapping("/executions/{jobExecutionId}")
    public ResponseEntity<ApiResponse<?>> getExecutionById(@PathVariable String jobExecutionId) {
        var execution = jobExecutionService.getExecutionById(jobExecutionId);

        if (execution == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse
                    .builder()
                    .statusCode(HttpStatus.NOT_FOUND.value())
                    .message("Job execution not found: " + jobExecutionId)
                    .build());
        }

        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(execution)
                .build());
    }

    @GetMapping("/executions/{jobExecutionId}/read-batches")
    public ResponseEntity<ApiResponse<?>> getReadBatches(@PathVariable String jobExecutionId) {
        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(jobExecutionService.getReadBatches(jobExecutionId))
                .build());
    }

    @GetMapping("/executions/{jobExecutionId}/write-batches")
    public ResponseEntity<ApiResponse<?>> getWriteBatches(@PathVariable String jobExecutionId) {
        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(jobExecutionService.getWriteBatches(jobExecutionId))
                .build());
    }

    @GetMapping("/executions/{jobExecutionId}/step-executions")
    public ResponseEntity<ApiResponse<?>> getStepExecutions(
            @PathVariable String jobExecutionId,
            @RequestParam(value = "batchId", required = false) String batchId,
            @RequestParam(value = "batchType", required = false) String batchType) {
        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(jobExecutionService.getStepExecutions(jobExecutionId, batchId, batchType))
                .build());
    }

    /** Aggregated per-step success/failure counts across the whole execution. */
    @GetMapping("/executions/{jobExecutionId}/step-executions/summary")
    public ResponseEntity<ApiResponse<?>> getStepExecutionSummary(@PathVariable String jobExecutionId) {
        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(stepExecutionService.getSummary(jobExecutionId))
                .build());
    }

    // =========================================================================
    // Manual retry + Related Retries
    // =========================================================================

    @PostMapping("/executions/{jobExecutionId}/batches/{batchId}/retry")
    public ResponseEntity<ApiResponse<?>> retryBatch(
            @PathVariable String jobExecutionId,
            @PathVariable String batchId,
            @RequestParam("batchType") String batchType,
            @RequestParam(value = "fromStep", required = false) String fromStep) {
        try {
            jobExecutionService.retryBatch(jobExecutionId, batchId, batchType, fromStep);
            return ResponseEntity.ok().body(ApiResponse
                    .builder()
                    .statusCode(HttpStatus.OK.value())
                    .message("Retry published for batch " + batchId)
                    .build());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse
                    .builder()
                    .statusCode(HttpStatus.NOT_FOUND.value())
                    .message(e.getMessage())
                    .build());
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ApiResponse
                    .builder()
                    .statusCode(HttpStatus.CONFLICT.value())
                    .message(e.getMessage())
                    .build());
        }
    }

    /** batchType defaults to WRITE, preserving the original contract for any caller not passing it. */
    @GetMapping("/executions/{jobExecutionId}/batches/{batchId}/retries")
    public ResponseEntity<ApiResponse<?>> getRetryInfo(
            @PathVariable String jobExecutionId,
            @PathVariable String batchId,
            @RequestParam(value = "batchType", defaultValue = "WRITE") String batchType) {

        Object data = "READ".equalsIgnoreCase(batchType)
                ? jobExecutionService.getReadBatchRetryState(batchId)
                : jobExecutionService.getWriteBatchRetryChain(batchId);

        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(data)
                .build());
    }
}

package com.star.databridge.controller;

import com.star.databridge.dto.response.ApiResponse;
import com.star.databridge.entity.SyncRecordEntity;
import com.star.databridge.service.SyncRecordService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * NEW FILE — no controller previously existed for sync_records, even though
 * SyncRecordRepository already has most of the query methods needed. This
 * is what backs the Data Migration Search UI page.
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/jobs/executions/{jobExecutionId}/sync-records")
public class SyncRecordController {

    private final SyncRecordService syncRecordService;

    @GetMapping
    public ResponseEntity<ApiResponse<?>> search(
            @PathVariable String jobExecutionId,
            @RequestParam(value = "recordId", required = false) String recordId,
            @RequestParam(value = "referenceId", required = false) String referenceId,
            @RequestParam(value = "status", required = false) String status,
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "pageNumber", required = false) Integer pageNumber) {

        List<SyncRecordEntity> records = syncRecordService.search(
                jobExecutionId, recordId, referenceId, status, limit, pageNumber);

        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(records)
                .build());
    }
}

package com.star.databridge.controller;

import com.star.databridge.dto.response.ApiResponse;
import com.star.databridge.dto.response.ScheduledJobDto;
import com.star.databridge.service.SchedulingService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

/**
 * NEW FILE. Exposes JobRunr's own recurring-job registry — distinct from
 * /v1/job-configs, which is our business config. This answers "what does
 * the scheduler actually think is registered right now," useful for
 * confirming an enable/disable/cron-update took effect.
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/scheduler/jobs")
public class SchedulerController {

    private final SchedulingService schedulingService;

    @GetMapping
    public ResponseEntity<ApiResponse<?>> getAllJobs() {
        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(schedulingService.getAllJobs())
                .build());
    }

    @GetMapping("/{jobName}")
    public ResponseEntity<ApiResponse<?>> getJob(@PathVariable String jobName) {

        Optional<ScheduledJobDto> job = schedulingService.getJob(jobName);

        if (job.isPresent()) {
            return ResponseEntity.ok(
                    ApiResponse.builder()
                            .statusCode(HttpStatus.OK.value())
                            .message("success")
                            .data(job.get())
                            .build()
            );
        }

        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(
                        ApiResponse.builder()
                                .statusCode(HttpStatus.NOT_FOUND.value())
                                .message("No scheduled job found for: " + jobName)
                                .build()
                );
    }

    /** "Run Job Immediately" — one-off enqueue via JobRunr, independent of any recurring schedule. */
    @PostMapping("/{jobName}/run-now")
    public ResponseEntity<ApiResponse<?>> runNow(@PathVariable String jobName) {
        schedulingService.runNow(jobName);
        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("Job enqueued for immediate execution: " + jobName)
                .build());
    }
}

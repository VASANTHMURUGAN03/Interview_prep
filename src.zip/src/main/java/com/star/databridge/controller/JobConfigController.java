package com.star.databridge.controller;

import com.star.databridge.dto.request.UpdateCronRequest;
import com.star.databridge.dto.request.UpsertJobConfigDto;
import com.star.databridge.dto.response.ApiResponse;
import com.star.databridge.entity.JobConfigEntity;
import com.star.databridge.service.JobConfigService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * User identity for audit purposes comes from two optional request headers
 * (X-User-Id / X-User-Name) rather than a real auth/session mechanism,
 * which doesn't exist yet in this project. Swap for @AuthenticationPrincipal
 * or similar once that's decided — nothing else here needs to change.
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/job-configs")
public class JobConfigController {

    private final JobConfigService jobConfigService;

    @PostMapping()
    public ResponseEntity<ApiResponse<?>> upsertJobConfig(
            @RequestBody UpsertJobConfigDto jobConfigDto,
            @RequestHeader(value = "X-User-Id", required = false) String userId,
            @RequestHeader(value = "X-User-Name", required = false) String username) {
        JobConfigEntity jobConfig = jobConfigService.upsertConfig(jobConfigDto, userId, username);

        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(jobConfig)
                .build());
    }

    @GetMapping()
    public ResponseEntity<ApiResponse<?>> getConfigs(
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "pageNumber", required = false) Integer pageNumber) {
        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(jobConfigService.getConfigs(limit, pageNumber))
                .build());
    }

    /** Configs joined with their latest execution + JobRunr scheduler state — powers Jobs List / Job Configuration tables. */
    @GetMapping("/summary")
    public ResponseEntity<ApiResponse<?>> getConfigSummaries(
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "pageNumber", required = false) Integer pageNumber) {
        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(jobConfigService.getConfigSummaries(limit, pageNumber))
                .build());
    }

    @GetMapping("/{name}")
    public ResponseEntity<ApiResponse<?>> getConfigByName(@PathVariable String name) {
        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(jobConfigService.getConfigByName(name))
                .build());
    }

    @DeleteMapping("/{name}")
    public ResponseEntity<ApiResponse<?>> deleteConfigByName(
            @PathVariable String name,
            @RequestHeader(value = "X-User-Id", required = false) String userId,
            @RequestHeader(value = "X-User-Name", required = false) String username) {
        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(jobConfigService.deleteConfigByName(name, userId, username))
                .build());
    }

    @PostMapping("/{name}/activate")
    public ResponseEntity<ApiResponse<?>> activateConfig(
            @PathVariable String name,
            @RequestHeader(value = "X-User-Id", required = false) String userId,
            @RequestHeader(value = "X-User-Name", required = false) String username) {
        JobConfigEntity jobConfig = jobConfigService.activateConfig(name, userId, username);

        if (jobConfig == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse
                    .builder()
                    .statusCode(HttpStatus.NOT_FOUND.value())
                    .message("Job configuration not found: " + name)
                    .build());
        }

        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(jobConfig)
                .build());
    }

    @PatchMapping("/{name}/cron")
    public ResponseEntity<ApiResponse<?>> updateCron(
            @PathVariable String name,
            @RequestBody UpdateCronRequest request,
            @RequestHeader(value = "X-User-Id", required = false) String userId,
            @RequestHeader(value = "X-User-Name", required = false) String username) {
        try {
            JobConfigEntity jobConfig = jobConfigService.updateCron(name, request.getCron(), userId, username);
            return ResponseEntity.ok().body(ApiResponse
                    .builder()
                    .statusCode(HttpStatus.OK.value())
                    .message("success")
                    .data(jobConfig)
                    .build());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse
                    .builder()
                    .statusCode(HttpStatus.NOT_FOUND.value())
                    .message(e.getMessage())
                    .build());
        }
    }
}

package com.star.databridge.controller;

import com.star.databridge.dto.response.ApiResponse;
import com.star.databridge.entity.AuditAction;
import com.star.databridge.service.AuditService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

/** NEW FILE. */
@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/audit")
public class AuditController {

    private final AuditService auditService;

    @GetMapping
    public ResponseEntity<ApiResponse<?>> search(
            @RequestParam(value = "jobName", required = false) String jobName,
            @RequestParam(value = "userId", required = false) String userId,
            @RequestParam(value = "action", required = false) AuditAction action,
            @RequestParam(value = "from", required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
            @RequestParam(value = "to", required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime to,
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "size", defaultValue = "20") int size,
            @RequestParam(value = "sortBy", defaultValue = "timestamp") String sortBy,
            @RequestParam(value = "sortDirection", defaultValue = "DESC") Sort.Direction sortDirection) {

        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(auditService.search(jobName, userId, action, from, to, page, size, sortBy, sortDirection))
                .build());
    }

    @GetMapping("/job/{jobName}")
    public ResponseEntity<ApiResponse<?>> getHistoryByJob(
            @PathVariable String jobName,
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "size", defaultValue = "20") int size) {

        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(auditService.getHistoryByJob(jobName, page, size))
                .build());
    }
}

package com.star.databridge.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * NEW FILE — no aggregation of this kind exists anywhere in the codebase
 * today; this is genuinely new logic, not just a missing controller over
 * existing data.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DashboardStatsResponse {
    private long totalExecutions;
    private long activeJobConfigs;
    private long completedCount;
    private long failedCount;
    private long inProgressCount;
    private long abortedCount;
    private double successRate; // completedCount / (completedCount + failedCount), 0 if none
}

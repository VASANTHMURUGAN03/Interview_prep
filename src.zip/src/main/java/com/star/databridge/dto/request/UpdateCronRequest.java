package com.star.databridge.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/** NEW FILE. */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UpdateCronRequest {
    private String cron;
}

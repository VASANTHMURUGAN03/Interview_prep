import { delay, randomInt } from './mockUtils';
import { JOBS } from './mockData';

const jobsService = {
  async getAllJobs() {
    await delay(350);
    return JOBS;
  },

  async triggerJob({ jobId, jobName, parameters }) {
    await delay(900);
    // Simulate an occasional failure so the error path is visible too.
    if (randomInt(1, 10) === 1) {
      throw new Error(`Failed to trigger ${jobName}. The scheduler service rejected the request.`);
    }
    return {
      executionId: randomInt(10000, 99999),
      jobId,
      jobName,
      parameters,
      status: 'STARTED',
    };
  },
};

export default jobsService;

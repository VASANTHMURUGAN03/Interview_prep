import { delay } from './mockUtils';
import { generateRelatedRetries } from './mockData';

const relatedRetriesService = {
  async getRelatedRetries(executionId, { page = 0, size = 10 } = {}) {
    await delay(450);
    const rows = generateRelatedRetries(executionId);
    const totalElements = rows.length;
    const totalPages = Math.max(1, Math.ceil(totalElements / size));
    return {
      content: rows.slice(page * size, page * size + size),
      currentPage: page,
      pageSize: size,
      totalElements,
      totalPages,
      first: page === 0,
      last: page >= totalPages - 1,
    };
  },
};

export default relatedRetriesService;

import { delay } from './mockUtils';
import {
  generateDashboardStats,
  generateExecutionSeries,
  generateRecentExecutions,
  generateTopFailedJobs,
} from './mockData';

const dashboardService = {
  async getStats(timeFilter, jobName) {
    await delay(450);
    return generateDashboardStats(jobName);
  },

  async getExecutionSeries(timeFilter) {
    await delay(400);
    return generateExecutionSeries();
  },

  async getRecentExecutions() {
    await delay(500);
    return generateRecentExecutions();
  },

  async getTopFailedJobs() {
    await delay(350);
    return generateTopFailedJobs();
  },
};

export default dashboardService;

import { delay } from './mockUtils';
import { generateExecutionDetail } from './mockData';

const executionCache = new Map();

const executionService = {
  async getExecutionDetail(instanceId, jobName) {
    await delay(500);
    const key = `${jobName}-${instanceId}`;
    if (!executionCache.has(key)) {
      executionCache.set(key, generateExecutionDetail(instanceId, jobName));
    }
    return executionCache.get(key);
  },
};

export default executionService;

import { randomInt, pick, isoMinutesAgo } from './mockUtils';

export const JOB_NAMES = [
  'PolicyDataSyncJob',
  'ClaimsSettlementBatchJob',
  'CustomerKycRefreshJob',
  'PremiumReconciliationJob',
  'AgentCommissionPayoutJob',
  'DocumentArchivalJob',
  'FraudFlagRescanJob',
  'RenewalReminderJob',
];

const JOB_DESCRIPTIONS = [
  'Syncs policy master data from the core system into the reporting store.',
  'Settles approved claims and posts payout batches to finance.',
  'Refreshes customer KYC documents flagged for periodic re-verification.',
  'Reconciles collected premiums against the billing ledger.',
  'Calculates and pays out agent commissions for the period.',
  'Archives closed-policy documents to cold storage.',
  'Re-scans recent claims against the latest fraud rule set.',
  'Sends renewal reminders for policies expiring in the next 30 days.',
];

const SAMPLE_CRONS = [
  '0 2 * * *',
  '*/15 * * * *',
  '0 9 * * 1-5',
  '30 3 1 * *',
  '0 */4 * * *',
  '0 6 * * 0',
  '45 23 * * *',
  '0 8 1,15 * *',
];

export const STATUSES = ['COMPLETED', 'FAILED', 'RUNNING', 'STOPPED', 'PENDING', 'ABANDONED'];

export const TRIGGER_TYPES = ['SCHEDULED', 'MANUAL', 'RETRY'];

export const JOBS = JOB_NAMES.map((name, idx) => ({
  id: idx + 1,
  name,
  description: JOB_DESCRIPTIONS[idx],
  totalInstances: randomInt(40, 620),
  lastRun: isoMinutesAgo(randomInt(2, 900)),
  status: idx % 5 === 0 ? 'FAILED' : idx % 3 === 0 ? 'RUNNING' : 'COMPLETED',
  cronExpression: SAMPLE_CRONS[idx],
  enabled: idx !== 4,
  defaultParams: [
    { key: 'asOfDate', value: new Date().toISOString().slice(0, 10) },
    { key: 'batchSize', value: '500' },
  ],
}));

export function generateDashboardStats(jobName) {
  const relevant = jobName ? JOBS.filter((j) => j.name === jobName) : JOBS;
  const totalJobs = relevant.length || JOBS.length;
  const totalFailed = randomInt(2, 18);
  const totalSuccess = randomInt(320, 4200);
  const runningNow = randomInt(0, 4);
  const activeJobs = randomInt(totalJobs - 2 > 0 ? totalJobs - 2 : 1, totalJobs);
  const successRate = Math.round((totalSuccess / (totalSuccess + totalFailed)) * 1000) / 10;

  return {
    totalJobs,
    activeJobs,
    successRate,
    totalFailed,
    runningNow,
    totalSuccess,
  };
}

export function generateExecutionSeries() {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  return days.map((day) => ({
    day,
    success: randomInt(40, 160),
    failed: randomInt(1, 22),
  }));
}

export function generateRecentExecutions(count = 8) {
  return Array.from({ length: count }, (_, i) => ({
    id: 9000 - i,
    jobName: pick(JOB_NAMES),
    status: pick(STATUSES),
    triggeredBy: pick(TRIGGER_TYPES),
    startTime: isoMinutesAgo(randomInt(1, 480)),
    durationSec: randomInt(4, 640),
  }));
}

export function generateTopFailedJobs() {
  return [...JOB_NAMES]
    .sort(() => Math.random() - 0.5)
    .slice(0, 4)
    .map((name) => ({ name, failures: randomInt(2, 24) }));
}

// ---- Job Instances ----------------------------------------------------

export function generateInstances(jobName, count = 34) {
  return Array.from({ length: count }, (_, i) => {
    const id = 5000 + count - i;
    const status = i === 0 ? 'RUNNING' : pick(STATUSES.filter((s) => s !== 'RUNNING' || i < 2));
    const startMinsAgo = randomInt(5, 60) + i * randomInt(60, 240);
    const durationSec = randomInt(20, 900);
    return {
      id,
      jobName,
      lastStatus: status,
      executionCount: status === 'FAILED' ? randomInt(1, 3) : 1,
      duration: `${Math.floor(durationSec / 60)}m ${durationSec % 60}s`,
      triggeredBy: pick(TRIGGER_TYPES),
      lastUpdated: isoMinutesAgo(startMinsAgo),
    };
  });
}

// ---- Execution Detail ---------------------------------------------------

const STEP_NAMES = ['transformSFHospitals','sfDecryptHospitalFields' ,'salesForceJWT', 'salesforceBatchId', 'generateSFHospitalCSV', 'salesforceUploadData',"salesforceCloseBatch"];

export function generateExecutionDetail(instanceId, jobName) {
  const startBase = Date.now() - randomInt(5, 90) * 60_000;
  let cursor = startBase;
  const steps = STEP_NAMES.slice(0, randomInt(3, 5)).map((name, idx) => {
    const readDur = randomInt(2, 40) * 1000;
    const processDur = randomInt(2, 60) * 1000;
    const writeDur = randomInt(1, 30) * 1000;
    const startTime = new Date(cursor).toISOString();
    cursor += readDur + processDur + writeDur;
    const endTime = new Date(cursor).toISOString();
    const failed = idx === STEP_NAMES.length - 1 ? false : randomInt(1, 12) === 1;
    return {
      id: `step-${idx + 1}`,
      name,
      status: failed ? 'FAILED' : 'COMPLETED',
      readCount: randomInt(100, 5000),
      writeCount: randomInt(90, 4900),
      startTime,
      endTime,
      readDurationMs: readDur,
      processDurationMs: processDur,
      writeDurationMs: writeDur,
    };
  });

  const overallFailed = steps.some((s) => s.status === 'FAILED');

  return {
    id: Number(instanceId) + 40000,
    instanceId: Number(instanceId),
    jobName,
    status: overallFailed ? 'FAILED' : 'COMPLETED',
    startTime: new Date(startBase).toISOString(),
    endTime: new Date(cursor).toISOString(),
    steps,
  };
}

// ---- Related Retries -----------------------------------------------------

export function generateRelatedRetries(executionId, count = 5) {
  return Array.from({ length: count }, (_, i) => ({
    id: Number(executionId) + i + 1,
    instanceId: 6000 + i,
    attempt: i + 1,
    status: i === count - 1 ? 'COMPLETED' : 'FAILED',
    triggeredBy: i === 0 ? 'SCHEDULED' : 'RETRY',
    startTime: isoMinutesAgo(randomInt(10, 600) - i * 20),
    durationSec: randomInt(20, 500),
  }));
}

// ---- Data Migration Search -------------------------------------------------

export function generateMigrationRecords(jobName, searchValue, count = 12) {
  const targetJob = jobName || pick(JOB_NAMES);
  return Array.from({ length: count }, (_, i) => {
    const failed = randomInt(1, 6) === 1;
    const key = searchValue ? `${searchValue}-${randomInt(100, 999)}` : `POL-${randomInt(100000, 999999)}`;
    return {
      id: `mig-${i}`,
      jobName: targetJob,
      jobExecutionId: 40000 + i,
      batchId: `batch-${randomInt(1000, 9999)}`,
      itemStatus: failed ? 'FAILED' : 'SUCCESS',
      searchKey: key,
      readTime: isoMinutesAgo(randomInt(5, 2000)),
      processTime: failed ? null : isoMinutesAgo(randomInt(1, 1999)),
      errorStage: failed ? pick(['READ', 'PROCESS', 'WRITE']) : null,
      errorMessage: failed ? 'Downstream API returned HTTP 502 while writing the record.' : null,
      readerDetails: {
        rawData: { policyNumber: key, source: 'CORE_DB' },
      },
      processorDetails: failed ? null : {
        transformedData: { policyNumber: key, normalizedStatus: 'ACTIVE' },
        transformationsApplied: ['normalizeStatus', 'enrichCustomerRef'],
      },
      writerDetails: failed ? null : {
        apiEndpoint: '/internal/policy/upsert',
        httpStatusCode: 200,
      },
    };
  });
}

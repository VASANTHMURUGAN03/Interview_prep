import { delay } from './mockUtils';
import { generateMigrationRecords } from './mockData';

const migrationSearchService = {
  async search(jobName, searchValue) {
    await delay(600);
    if (!searchValue || !searchValue.trim()) return [];
    return generateMigrationRecords(jobName, searchValue.trim());
  },
};

export default migrationSearchService;

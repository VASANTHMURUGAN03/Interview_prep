import { delay } from './mockUtils';
import { PROCESS_STEPS } from './processStepsData';

// In-memory store so creates/edits persist across navigation within a session.
const store = [...PROCESS_STEPS];

const processStepService = {
  async getSteps(limit, pageNumber) {
    await delay(400);
    return [...store].sort((a, b) => a.name.localeCompare(b.name));
  },

  async getStepByName(name) {
    await delay(300);
    const step = store.find((s) => s.name === name);
    if (!step) throw new Error(`Process step not found: ${name}`);
    return step;
  },

  async upsertStep(dto) {
    await delay(500);
    const idx = store.findIndex((s) => s.name === dto.name);
    if (idx >= 0) {
      store[idx] = { ...store[idx], ...dto, active: true };
      return store[idx];
    }
    const created = { id: `step-${Date.now()}`, active: true, ...dto };
    store.push(created);
    return created;
  },
};

export default processStepService;

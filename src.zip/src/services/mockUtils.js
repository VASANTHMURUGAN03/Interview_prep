/**
 * Every service in this app currently talks to an in-memory mock dataset
 * instead of a real backend (see README). `delay` simulates realistic
 * network latency so loading states are actually visible, and every
 * service function returns a Promise — so swapping the mock body for a
 * real `axios` call later is a one-line change per function, and no
 * component code needs to change.
 */
export function delay(ms = 500) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

export function pick(arr) {
  return arr[randomInt(0, arr.length - 1)];
}

export function isoMinutesAgo(mins) {
  return new Date(Date.now() - mins * 60_000).toISOString();
}

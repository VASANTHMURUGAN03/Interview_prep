import { delay, randomInt } from './mockUtils';
import { JOB_CONFIGS } from './jobConfigsData';

const store = [...JOB_CONFIGS];

const jobConfigService = {
  async getConfigs(limit, pageNumber) {
    await delay(400);
    const size = limit ? Math.min(limit, 10) : 10;
    const page = pageNumber || 0;
    const sorted = [...store].sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    return {
      content: sorted.slice(page * size, page * size + size),
      totalElements: sorted.length,
      totalPages: Math.max(1, Math.ceil(sorted.length / size)),
      currentPage: page,
    };
  },

  async getConfigByName(name) {
    await delay(350);
    const config = store.find((c) => c.name === name);
    if (!config) throw new Error(`Job config not found: ${name}`);
    return config;
  },

  async upsertConfig(dto) {
    await delay(600);
    const idx = store.findIndex((c) => c.name === dto.name);
    const now = new Date().toISOString();
    if (idx >= 0) {
      store[idx] = { ...store[idx], ...dto, active: true, updatedAt: now };
      return store[idx];
    }
    const created = {
      id: `job-${Date.now()}`,
      active: true,
      createdAt: now,
      updatedAt: now,
      lastRun: null,
      lastStatus: null,
      ...dto,
    };
    store.push(created);
    return created;
  },

  // DELETE /v1/job-configs/{name} — soft delete, sets active=false.
  async deleteConfigByName(name) {
    await delay(450);
    const config = store.find((c) => c.name === name);
    if (config) config.active = false;
    return config;
  },

  // Proposed new endpoint — re-enable a disabled config without resubmitting it.
  async activateConfig(name) {
    await delay(450);
    const config = store.find((c) => c.name === name);
    if (config) config.active = true;
    return config;
  },

  async triggerJob(name) {
    await delay(700);
    const config = store.find((c) => c.name === name);
    if (!config || !config.active) {
      throw new Error(`Job configuration not found or inactive: ${name}`);
    }
    config.lastRun = new Date().toISOString();
    config.lastStatus = 'IN_PROGRESS';
    return {
      jobId: crypto.randomUUID?.() || `${Date.now()}`,
      jobName: name,
      jobExecutionId: `exec-${randomInt(10000, 99999)}`,
    };
  },

  async abortJob(jobUuid) {
    await delay(500);
    return { jobUuid, status: 'ABORTED' };
  },
};

export default jobConfigService;

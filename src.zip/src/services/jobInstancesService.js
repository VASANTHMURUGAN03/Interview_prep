import { delay } from './mockUtils';
import { generateInstances } from './mockData';

// Cache generated instances per job so status changes (stop/resume) persist
// across navigation within a session, same as a real backend would.
const instanceCache = new Map();

function getOrCreate(jobName) {
  if (!instanceCache.has(jobName)) {
    instanceCache.set(jobName, generateInstances(jobName));
  }
  return instanceCache.get(jobName);
}

const jobInstancesService = {
  async getInstances(jobName, { status, triggeredBy, page = 0, size = 10 } = {}) {
    await delay(450);
    let rows = getOrCreate(jobName);
    if (status) rows = rows.filter((r) => r.lastStatus === status);
    if (triggeredBy) rows = rows.filter((r) => r.triggeredBy === triggeredBy);

    const totalElements = rows.length;
    const totalPages = Math.max(1, Math.ceil(totalElements / size));
    const content = rows.slice(page * size, page * size + size);

    return {
      content,
      currentPage: page,
      pageSize: size,
      totalElements,
      totalPages,
      first: page === 0,
      last: page >= totalPages - 1,
    };
  },

  async stopInstance(jobName, instanceId) {
    await delay(500);
    const rows = getOrCreate(jobName);
    const row = rows.find((r) => r.id === instanceId);
    if (row) row.lastStatus = 'STOPPED';
    return { message: `Instance #${instanceId} stopped.` };
  },

  async resumeInstance(jobName, instanceId) {
    await delay(500);
    const rows = getOrCreate(jobName);
    const row = rows.find((r) => r.id === instanceId);
    if (row) row.lastStatus = 'RUNNING';
    return { message: `Instance #${instanceId} resumed.` };
  },
};

export default jobInstancesService;

import { isoMinutesAgo, randomInt } from './mockUtils';

export const PROCESS_STEPS = [
  {
    id: 'step-1',
    name: 'salesForceJWT',
    type: 'JWT',
    active: true,
    params: {
      privateKeyPath: 'salesforce.privateKeyPath',
      publicKeyPath: null,
      algorithm: 'RSA256',
      expiryInSec: 86400,
      issuer: 'salesforce.issuer',
      subject: 'salesforce.subject',
      audience: 'salesforce.audience',
    },
  },
  {
    id: 'step-2',
    name: 'salesForceAccessToken',
    type: 'API',
    active: true,
    params: {
      request: {
        endpoint: { basePath: 'salesforce.basePath', url: '/services/oauth2/token', method: 'POST' },
        headers: { 'content-type': 'application/x-www-form-urlencoded' },
        body: [
          { name: 'grant_type', value: 'urn:ietf:params:oauth:grant-type:jwt-bearer', type: 'static' },
          { name: 'assertion', value: '${TOKEN}', type: 'dynamic' },
        ],
        variables: [{ name: 'TOKEN', type: 'context', value: 'salesForceJWT' }],
      },
      response: { params: [{ key: 'accessToken', value: 'access_token' }] },
    },
  },
  {
    id: 'step-3',
    name: 'salesforceBatchId',
    type: 'API',
    active: true,
    params: {
      request: {
        endpoint: { basePath: 'salesforce.basePath', url: '/services/data/v64.0/jobs/ingest', method: 'POST' },
        headers: { authorization: 'Bearer ${TOKEN}' },
        body: [
          { name: 'object', value: 'Account', type: 'static' },
          { name: 'operation', value: 'upsert', type: 'static' },
        ],
        variables: [{ name: 'TOKEN', type: 'context', value: 'salesForceAccessToken.accessToken' }],
      },
      response: { params: [{ key: 'referenceId', value: 'id' }] },
    },
  },
  {
    id: 'step-4',
    name: 'salesforceUploadCustomers',
    type: 'BANCS_API',
    active: true,
    params: {
      request: {
        endpoint: { basePath: 'salesforce.basePath', url: '/services/data/v64.0/jobs/ingest/${BATCH_JOB_ID}/batches', method: 'PUT' },
        headers: { 'content-type': 'text/csv; charset=UTF-8', authorization: 'Bearer ${TOKEN}' },
        rawBody: '${CSV_DATA}',
        variables: [
          { name: 'BATCH_JOB_ID', type: 'context', value: 'salesforceBatchId.referenceId' },
          { name: 'TOKEN', type: 'context', value: 'salesForceAccessToken.accessToken' },
          { name: 'CSV_DATA', type: 'context', value: 'generateSFCustomerCSV' },
        ],
      },
      response: null,
    },
  },
  {
    id: 'step-5',
    name: 'transformSFCustomers',
    type: 'JOLT_TRANSFORM',
    active: true,
    params: {
      config: [
        {
          operation: 'shift',
          spec: {
            '*': {
              DL_UNIQUE_ID: ['[&1].record.DLUniqueId__c', '[&1].recordId'],
              EMAIL_ID: '[&1].record.PersonEmail',
              MOBILE_NO: '[&1].record.PersonMobilePhone',
            },
          },
        },
      ],
    },
  },
  {
    id: 'step-6',
    name: 'sfCustomerFieldTransformations',
    type: 'FIELD_TRANSFORM',
    active: true,
    params: {
      dataSource: 'sfDecryptCustomerFields',
      config: [
        { source: 'PersonBirthdate', target: 'PersonBirthdate', implementation: 'safeConvertToYYYYMMDD' },
        { source: 'CreatedDate', target: 'CreatedDate', implementation: 'safeConvertToYYYYMMDD' },
      ],
    },
  },
  {
    id: 'step-7',
    name: 'sfDecryptCustomerFields',
    type: 'DECRYPT',
    active: true,
    params: {
      updateDataFlow: true,
      dataSource: 'sinkRecords',
      fields: [
        { source: 'AadharNumber__c', target: 'AadharNumber__c' },
        { source: 'PersonEmail', target: 'PersonEmail' },
        { source: 'PersonMobilePhone', target: 'PersonMobilePhone' },
        { source: 'PANNumber__c', target: 'PANNumber__c' },
      ],
    },
  },
  {
    id: 'step-8',
    name: 'generateSFCustomerCSV',
    type: 'JSON_TO_CSV',
    active: true,
    params: { columns: null, writeToFile: false },
  },
  {
    id: 'step-9',
    name: 'sfCustomerSuccessRecordsJson',
    type: 'CSV_TO_JSON',
    active: true,
    params: {
      source: 'salesforceSuccessEntries.response',
      columns: { DLUniqueId__c: 'recordId' },
    },
  },
  {
    id: 'step-10',
    name: 'salesforceJobInfo',
    type: 'API',
    active: true,
    params: {
      request: {
        endpoint: { basePath: 'salesforce.basePath', url: '/services/data/v64.0/jobs/ingest/${BATCH_JOB_ID}', method: 'GET' },
        headers: { authorization: 'Bearer ${TOKEN}' },
        variables: [
          { name: 'BATCH_JOB_ID', type: 'context', value: 'salesforceBatchId.referenceId' },
          { name: 'TOKEN', type: 'context', value: 'salesForceAccessToken.accessToken' },
        ],
      },
      response: { params: [{ key: 'jobStatus', value: 'state' }] },
    },
  },
  {
    id: 'step-11',
    name: 'salesforceSuccessEntries',
    type: 'API',
    active: true,
    params: {
      request: {
        endpoint: { basePath: 'salesforce.basePath', url: '/services/data/v64.0/jobs/ingest/${BATCH_JOB_ID}/successfulResults', method: 'GET' },
        headers: { authorization: 'Bearer ${TOKEN}' },
        variables: [
          { name: 'BATCH_JOB_ID', type: 'context', value: 'salesforceBatchId.referenceId' },
          { name: 'TOKEN', type: 'context', value: 'salesForceAccessToken.accessToken' },
        ],
      },
      response: null,
    },
  },
  {
    id: 'step-12',
    name: 'salesforceFailedEntries',
    type: 'API',
    active: false,
    params: {
      request: {
        endpoint: { basePath: 'salesforce.basePath', url: '/services/data/v64.0/jobs/ingest/${BATCH_JOB_ID}/failedResults', method: 'GET' },
        headers: { authorization: 'Bearer ${TOKEN}' },
        variables: [
          { name: 'BATCH_JOB_ID', type: 'context', value: 'salesforceBatchId.referenceId' },
          { name: 'TOKEN', type: 'context', value: 'salesForceAccessToken.accessToken' },
        ],
      },
      response: null,
    },
  },
];

export function generateStepUsage(stepName) {
  // How many job configs currently reference this step — shown in the library list.
  return randomInt(0, 6);
}

export const STEP_META = PROCESS_STEPS.reduce((acc, s) => {
  acc[s.id] = { updatedAt: isoMinutesAgo(randomInt(60, 60000)) };
  return acc;
}, {});

const FIELD_RANGES = {
  second: { min: 0, max: 59 },
  minute: { min: 0, max: 59 },
  hour: { min: 0, max: 23 },
  dayOfMonth: { min: 1, max: 31 },
  month: { min: 1, max: 12 },
  dayOfWeek: { min: 0, max: 7 }, // 0 and 7 both mean Sunday
};

const WEEKDAY_NAMES = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const MONTH_NAMES = ['', 'JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

function expandField(raw, { min, max }) {
  const values = new Set();
  const named = raw.toUpperCase();
  const withNames = (s) => {
    WEEKDAY_NAMES.forEach((n, i) => { s = s.replaceAll(n, String(i)); });
    MONTH_NAMES.forEach((n, i) => { if (n) s = s.replaceAll(n, String(i)); });
    return s;
  };

  for (const part of withNames(named).split(',')) {
    let step = 1;
    let range = part;
    if (part.includes('/')) {
      const [r, s] = part.split('/');
      range = r;
      step = parseInt(s, 10);
      if (Number.isNaN(step) || step <= 0) throw new Error(`Invalid step "${part}"`);
    }

    let start = min;
    let end = max;
    if (range !== '*') {
      if (range.includes('-')) {
        const [a, b] = range.split('-').map((n) => parseInt(n, 10));
        if (Number.isNaN(a) || Number.isNaN(b)) throw new Error(`Invalid range "${part}"`);
        start = a;
        end = b;
      } else {
        const n = parseInt(range, 10);
        if (Number.isNaN(n)) throw new Error(`Invalid value "${part}"`);
        start = n;
        end = n;
      }
    }

    if (start < min || end > max) throw new Error(`Value out of range in "${part}"`);

    for (let v = start; v <= end; v += step) values.add(v === 7 && max === 7 ? 0 : v);
  }
  return values;
}

/**
 * Parses a cron string into a Set per field. Accepts both the standard
 * 5-field Unix format (minute hour day-of-month month day-of-week) and
 * Spring's `CronTrigger` 6-field format (second minute hour day-of-month
 * month day-of-week) — this backend uses Spring's `TaskScheduler` +
 * `CronTrigger`, so its cron strings include a leading seconds field
 * (e.g. `0 0 6 * * *` = 6:00:00 daily).
 */
export function parseCron(expression) {
  const fields = (expression || '').trim().split(/\s+/);
  if (fields.length !== 5 && fields.length !== 6) {
    throw new Error('Expected 5 fields (minute hour day month weekday) or 6 fields (second minute hour day month weekday)');
  }

  const hasSeconds = fields.length === 6;
  const [second, minute, hour, dayOfMonth, month, dayOfWeek] = hasSeconds
    ? fields
    : ['0', ...fields];

  return {
    second: expandField(second, FIELD_RANGES.second),
    minute: expandField(minute, FIELD_RANGES.minute),
    hour: expandField(hour, FIELD_RANGES.hour),
    dayOfMonth: expandField(dayOfMonth, FIELD_RANGES.dayOfMonth),
    month: expandField(month, FIELD_RANGES.month),
    dayOfWeek: expandField(dayOfWeek, FIELD_RANGES.dayOfWeek),
    // Standard cron rule: if BOTH day-of-month and day-of-week are restricted
    // (neither is the literal "*"), a day matches if EITHER matches (OR).
    // If either field is "*", only the other field's restriction applies.
    dayOfMonthIsWildcard: dayOfMonth === '*',
    dayOfWeekIsWildcard: dayOfWeek === '*',
    hasSeconds,
    raw: fields,
    rawHasSeconds: hasSeconds,
  };
}

export function isValidCron(expression) {
  try {
    parseCron(expression);
    return { valid: true };
  } catch (e) {
    return { valid: false, message: e.message };
  }
}

/** Human-readable description for common patterns; falls back to a generic phrase for anything complex. */
export function describeCron(expression) {
  let parsed;
  try {
    parsed = parseCron(expression);
  } catch (e) {
    return null;
  }
  const fields = parsed.hasSeconds ? parsed.raw : ['0', ...parsed.raw];
  const [, min, hour, dom, month, dow] = fields;
  const pad = (n) => String(n).padStart(2, '0');

  const isEvery = (f) => f === '*';
  const isStep = (f) => /^\*\/\d+$/.test(f);
  const stepOf = (f) => f.split('/')[1];

  const domWild = isEvery(dom);
  const monthWild = isEvery(month);
  const dowWild = isEvery(dow);

  if (isEvery(min) && isEvery(hour) && domWild && monthWild && dowWild) {
    return 'Runs every minute';
  }
  if (isStep(min) && isEvery(hour) && domWild && monthWild && dowWild) {
    return `Runs every ${stepOf(min)} minutes`;
  }
  if (isStep(hour) && !isEvery(min) && domWild && monthWild && dowWild) {
    return `Runs every ${stepOf(hour)} hours (at minute ${pad(min)})`;
  }
  if (!isEvery(min) && !isStep(min) && !isEvery(hour) && !isStep(hour) && domWild && monthWild && dowWild) {
    return `Runs daily at ${pad(hour)}:${pad(min)}`;
  }
  if (!isEvery(min) && !isEvery(hour) && domWild && monthWild && !dowWild) {
    return `Runs at ${pad(hour)}:${pad(min)} on selected weekdays`;
  }
  if (!isEvery(min) && !isEvery(hour) && !domWild && monthWild && dowWild) {
    return `Runs monthly on day ${dom} at ${pad(hour)}:${pad(min)}`;
  }
  return 'Runs on a custom schedule';
}

/**
 * Walks forward minute-by-minute from `from` to find the next `count` run
 * times (the matching second within the minute, if a seconds field is
 * present, is attached from the smallest value in that field's set — fine
 * for a preview; a real backend would use Spring's own CronExpression).
 * Capped at ~2 years of minutes so a bad expression can't hang.
 */
export function nextRunTimes(expression, count = 5, from = new Date()) {
  const parsed = parseCron(expression);
  const results = [];
  const cursor = new Date(from);
  cursor.setSeconds(0, 0);
  cursor.setMinutes(cursor.getMinutes() + 1);
  const firstSecond = Math.min(...parsed.second);

  const MAX_ITERATIONS = 60 * 24 * 366 * 2;
  let i = 0;
  while (results.length < count && i < MAX_ITERATIONS) {
    const min = cursor.getMinutes();
    const hour = cursor.getHours();
    const dom = cursor.getDate();
    const month = cursor.getMonth() + 1;
    const dow = cursor.getDay();

    const domMatch = parsed.dayOfMonth.has(dom);
    const dowMatch = parsed.dayOfWeek.has(dow);
    let dayMatches;
    if (parsed.dayOfMonthIsWildcard && parsed.dayOfWeekIsWildcard) {
      dayMatches = true;
    } else if (parsed.dayOfMonthIsWildcard) {
      dayMatches = dowMatch;
    } else if (parsed.dayOfWeekIsWildcard) {
      dayMatches = domMatch;
    } else {
      dayMatches = domMatch || dowMatch;
    }

    if (
      parsed.minute.has(min) &&
      parsed.hour.has(hour) &&
      parsed.month.has(month) &&
      dayMatches
    ) {
      const hit = new Date(cursor);
      hit.setSeconds(firstSecond);
      results.push(hit);
    }
    cursor.setMinutes(cursor.getMinutes() + 1);
    i += 1;
  }
  return results;
}

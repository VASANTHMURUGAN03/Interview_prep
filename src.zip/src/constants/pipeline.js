export const STEP_TYPES = [
  'JWT',
  'API',
  'BANCS_API',
  'JOLT_TRANSFORM',
  'FIELD_TRANSFORM',
  'DECRYPT',
  'CSV_TO_JSON',
  'JSON_TO_CSV',
];

export const READ_TYPES = ['API', 'SQL'];

export const STRATEGIES = [
  'READ_FIRST',
  'SIMULTANEOUS_READ_WRITE',
  'SIMULTANEOUS_SINGLE_TRIGGER',
];

export const ACK_TYPES = ['POLL', 'IMMEDIATE'];

export const FAILURE_STRATEGIES = ['ABORT', 'IGNORE'];

export const PAGINATION_TYPES = ['offset', 'cursor'];

export const REFERENCE_ID_TYPES = ['context', 'static'];

export const VARIABLE_TYPES = ['static', 'dynamic', 'context', 'implementation', 'env'];

export const BODY_PARAM_TYPES = ['static', 'dynamic'];

export const OPERATORS = [
  'equals',
  'notEquals',
  'greaterThan',
  'lessThan',
  'greaterThanOrEqualsTo',
  'lessThanOrEqualsTo',
  'in',
  'notIn',
];

export const PRE_EXECUTION_EFFECTS = ['execute', 'skip', 'restartSteps'];
export const POST_EXECUTION_EFFECTS = ['next', 'skip', 'restartSteps'];

// Step types that can be rendered as a structured form. JOLT_TRANSFORM's spec
// is too free-form/nested for a form and gets a JSON code editor instead.
export const REQUEST_DSL_TYPES = ['API', 'BANCS_API'];
export const KEY_MAP_TYPES = ['FIELD_TRANSFORM', 'DECRYPT', 'CSV_TO_JSON', 'JSON_TO_CSV'];

/**
 * JS-readable mirror of src/styles/tokens.css. Palette anchored on Star
 * Health's brand navy, brightened from the original #173172 sample for
 * more contrast/vibrancy across the UI.
 */

export const gradient = {
  start: '#2249A6',
  end: '#4C7CDE',
  css: 'linear-gradient(135deg, #2249A6 0%, #4C7CDE 100%)',
};

export const colors = {
  canvas: '#F8FAFF',
  surface: '#FFFFFF',
  surfaceHover: '#FAFBFF',
  surfaceSunken: '#EFF3FC',
  ink: '#10182C',
  inkMuted: '#576079',
  inkFaint: '#9AA4C2',
  line: '#E4E9F5',

  panel: '#101D40',
  panelElevated: '#1D2E5C',
  panelLine: '#2C3E6E',
  panelText: '#D9E0F7',
  panelTextMuted: '#8D99C4',

  primary: '#2249A6',
  primaryHover: '#1B3A87',
  accent: '#D9A63B',

  success: '#17AD68',
  successBg: '#DFFBEA',
  successText: '#0D6B3E',

  danger: '#E2413F',
  dangerBg: '#FDE8E7',
  dangerText: '#9A2222',

  info: '#3D6BEF',
  infoBg: '#E6EDFF',
  infoText: '#1E42B8',

  warning: '#D9A63B',
  warningBg: '#FFF6E0',
  warningText: '#7A5A16',

  orange: '#E2822F',
  orangeBg: '#FDEAD9',
  orangeText: '#813F0F',

  purple: '#8259DB',
  purpleBg: '#EFE7FC',
  purpleText: '#472A82',

  neutralBg: '#EFF3FC',
  neutralText: '#576079',
};

export const statusColorMap = {
  COMPLETED: colors.success,
  SUCCESS: colors.success,
  FAILED: colors.danger,
  FAILURE: colors.danger,
  PARTIAL_FAILURE: '#DD6A5C',
  RUNNING: colors.info,
  STARTED: colors.info,
  IN_PROGRESS: colors.info,
  STOPPED: colors.orange,
  STOPPING: colors.orange,
  PENDING: colors.warning,
  QUEUED: colors.warning,
  ABANDONED: colors.purple,
};

export const layout = {
  sidebarWidth: 280,
  sidebarWidthCollapsed: 84,
  headerHeight: 68,
};

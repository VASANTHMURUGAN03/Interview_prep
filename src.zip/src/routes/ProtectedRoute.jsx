import { Navigate } from 'react-router-dom';

/**
 * Route guard scaffold.
 *
 * sync-relay reads a `employee_accessToken` cookie and redirects to
 * `/sso/login` on a 401. This app has no real backend yet (everything is
 * mocked), so there's nothing to authenticate against. Wire this up to
 * the same cookie/SSO check — or whatever auth contract this product
 * ends up using — once that's decided.
 */
export default function ProtectedRoute({ children }) {
  const isAuthenticated = true;

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return children;
}

package com.star.databridge.controller;

import com.star.databridge.dto.request.UpsertProcessStepConfigDto;
import com.star.databridge.dto.response.ApiResponse;
import com.star.databridge.entity.ProcessStepEntity;
import com.star.databridge.service.ProcessStepConfigService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/process-steps/configs")
public class ProcessStepConfigController {

    private final ProcessStepConfigService processStepConfigService;

    @PostMapping()
    public ResponseEntity<ApiResponse<?>> upsertJobConfig(@RequestBody UpsertProcessStepConfigDto processStepConfigDto) {
        ProcessStepEntity config = processStepConfigService.upsertConfig(processStepConfigDto);

        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(config)
                .build());
    }

    @GetMapping()
    public ResponseEntity<ApiResponse<?>> getConfigs(
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "pageNumber", required = false) Integer pageNumber) {
        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(processStepConfigService.getConfigs(limit, pageNumber))
                .build());
    }

    @GetMapping("/{name}")
    public ResponseEntity<ApiResponse<?>> getConfigByName(@PathVariable String name) {
        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(processStepConfigService.getConfigByName(name))
                .build());
    }
}


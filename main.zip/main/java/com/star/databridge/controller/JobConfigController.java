package com.star.databridge.controller;

import com.star.databridge.dto.request.UpsertJobConfigDto;
import com.star.databridge.dto.response.ApiResponse;
import com.star.databridge.entity.JobConfigEntity;
import com.star.databridge.service.JobConfigService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/job-configs")
public class JobConfigController {

    private final JobConfigService jobConfigService;

    @PostMapping()
    public ResponseEntity<ApiResponse<?>> upsertJobConfig(@RequestBody UpsertJobConfigDto jobConfigDto) {
        JobConfigEntity jobConfig = jobConfigService.upsertConfig(jobConfigDto);

        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(jobConfig)
                .build());
    }

    @GetMapping()
    public ResponseEntity<ApiResponse<?>> getConfigs(
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "pageNumber", required = false) Integer pageNumber) {
        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(jobConfigService.getConfigs(limit, pageNumber))
                .build());
    }

    @GetMapping("/{name}")
    public ResponseEntity<ApiResponse<?>> getConfigByName(@PathVariable String name) {
        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(jobConfigService.getConfigByName(name))
                .build());
    }

    @DeleteMapping("/{name}")
    public ResponseEntity<ApiResponse<?>> deleteConfigByName(@PathVariable String name) {
        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(jobConfigService.deleteConfigByName(name))
                .build());
    }
}

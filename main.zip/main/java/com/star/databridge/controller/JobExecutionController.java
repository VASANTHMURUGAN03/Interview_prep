package com.star.databridge.controller;

import com.star.databridge.dto.response.ApiResponse;
import com.star.databridge.dto.response.TriggerJobResponse;
import com.star.databridge.entity.JobExecutionEntity;
import com.star.databridge.service.JobExecutionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/jobs")
@Slf4j
public class JobExecutionController {

    private final JobExecutionService jobExecutionService;

    @PostMapping("/trigger/{name}")
    public ResponseEntity<ApiResponse<?>> triggerJobByName(@PathVariable String name) {
        TriggerJobResponse response = jobExecutionService.triggerJob(name);

        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(response)
                .build());
    }

    @PostMapping("/abort/{jobUuid}")
    public ResponseEntity<ApiResponse<?>> abortJob(@PathVariable String jobUuid) {
        try {
            JobExecutionEntity jobExecution = jobExecutionService.abortJobByUuid(jobUuid);
            return ResponseEntity.ok().body(ApiResponse
                    .builder()
                    .statusCode(HttpStatus.OK.value())
                    .message("Job aborted successfully")
                    .data(jobExecution.getJobUuid())
                    .build());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse
                    .builder()
                    .statusCode(HttpStatus.NOT_FOUND.value())
                    .message(e.getMessage())
                    .build());
        } catch (IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(ApiResponse
                    .builder()
                    .statusCode(HttpStatus.CONFLICT.value())
                    .message(e.getMessage())
                    .build());
        }
    }
}
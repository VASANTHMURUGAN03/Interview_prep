package com.star.databridge.repository;

import com.star.databridge.dto.mongo.SyncRecordSummary;
import com.star.databridge.entity.SyncRecordEntity;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SyncRecordRepository extends MongoRepository<SyncRecordEntity, String> {

    List<SyncRecordEntity> findByJobExecutionIdAndStatus(String jobExecutionId, String status, Pageable pageable);

    long countByJobExecutionIdAndStatus(String jobExecutionId, String status);

    long countByJobExecutionIdAndStatusNotIn(String jobExecutionId, List<String> statuses);

    List<SyncRecordEntity> findAllByRecordIdInAndJobExecutionId(List<String> recordIds, String jobExecutionId);

    List<SyncRecordSummary> findAllByJobExecutionId(String jobExecutionId);

    List<SyncRecordSummary> findByJobExecutionIdAndStatusAndWriteBatchExecutionIdIsNull(String jobExecutionId, String status, Pageable pageable);

    long countByJobExecutionIdAndStatusAndWriteBatchExecutionIdIsNull(String jobExecutionId, String status);

    List<SyncRecordEntity> findByWriteBatchExecutionId(String writeBatchExecutionId);
}

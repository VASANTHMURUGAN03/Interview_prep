package com.star.databridge.repository;

import com.star.databridge.entity.ReadBatchExecutionEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReadBatchExecutionRepository extends MongoRepository<ReadBatchExecutionEntity, String> {
    long countByJobExecutionIdAndStatusNotIn(String jobExecutionId, List<String> statuses);
}


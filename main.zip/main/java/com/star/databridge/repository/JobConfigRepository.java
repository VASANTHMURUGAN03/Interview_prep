package com.star.databridge.repository;

import com.star.databridge.entity.JobConfigEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface JobConfigRepository extends MongoRepository<JobConfigEntity, String> {
    Optional<JobConfigEntity> findByNameAndActive(String name, boolean active);

    List<JobConfigEntity> findByTriggerTypeAndActive(String triggerType, boolean active);

    Optional<JobConfigEntity> findByName(String name);
}

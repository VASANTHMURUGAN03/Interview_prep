package com.star.databridge.repository;

import com.star.databridge.entity.ProcessStepEntity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProcessStepRepository extends MongoRepository<ProcessStepEntity, String> {
    Optional<ProcessStepEntity> findByNameAndActive(String name, boolean status);
    Optional<ProcessStepEntity> findByName(String name);
    List<ProcessStepEntity> findByNameIn(List<String> name);
}

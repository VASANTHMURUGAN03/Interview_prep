package com.star.databridge.config;

import org.springframework.context.annotation.Configuration;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@Configuration
public class ExecutorPool {

    private static final ExecutorService WRITE_BATCH_CONSUMER_EXECUTOR;

    static {
        WRITE_BATCH_CONSUMER_EXECUTOR = new ThreadPoolExecutor(
                Runtime.getRuntime().availableProcessors(),
                Runtime.getRuntime().availableProcessors() * 2,
                0L,
                TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<>(500),
                new ThreadPoolExecutor.CallerRunsPolicy()
        );
    }

    public static ExecutorService getWriteBatchConsumerExecutor() {
        // Return the shared, stable global instance
        return WRITE_BATCH_CONSUMER_EXECUTOR;
    }
}

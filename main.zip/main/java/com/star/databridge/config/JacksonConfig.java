package com.star.databridge.config;

import tools.jackson.core.StreamReadConstraints;
import tools.jackson.core.json.JsonFactory;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JacksonConfig {

    @Bean
    public ObjectMapper objectMapper() {
        StreamReadConstraints constraints = StreamReadConstraints.builder().maxStringLength(Integer.MAX_VALUE).build();
        JsonFactory jsonFactory = JsonFactory.builder().streamReadConstraints(constraints).build();
        // Jackson 3 auto-registers Java time (JSR-310) support, so no module needs to be added explicitly.
        return JsonMapper.builder(jsonFactory).build();
    }
}

package com.star.databridge.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

/**
 * Holds one {@link JdbcTemplate} per configured SQL source.
 * Sources are declared under {@code app.sqlSources.<name>} in the profile yaml.
 */
@Slf4j
@Component
public class SqlDataSourceRegistry {

    private final Map<String, JdbcTemplate> templates = new HashMap<>();

    public SqlDataSourceRegistry(SqlProperties props) {
        props.getSqlSources().forEach((name, config) -> {
            DataSource ds = DataSourceBuilder.create()
                    .url(config.getUrl())
                    .username(config.getUsername())
                    .password(config.getPassword())
                    .driverClassName(driverFor(config.getType()))
                    .build();
            templates.put(name, new JdbcTemplate(ds));
            log.info("[SqlDataSourceRegistry] Registered SQL source name={} type={}", name, config.getType());
        });
    }

    public JdbcTemplate getTemplate(String source) {
        JdbcTemplate template = templates.get(source);
        if (template == null) {
            throw new IllegalArgumentException("Unknown SQL source: " + source);
        }
        return template;
    }

    private String driverFor(String type) {
        if (type == null) {
            throw new IllegalArgumentException("SQL source type is required");
        }
        return switch (type.toLowerCase()) {
            case "postgres", "postgresql" -> "org.postgresql.Driver";
            case "mysql" -> "com.mysql.cj.jdbc.Driver";
            default -> throw new IllegalArgumentException("Unsupported SQL source type: " + type);
        };
    }
}

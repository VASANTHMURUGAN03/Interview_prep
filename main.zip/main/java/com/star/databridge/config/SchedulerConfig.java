package com.star.databridge.config;

import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.provider.mongo.MongoLockProvider;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

/**
 * Enables Spring scheduling and configures ShedLock with a MongoDB-backed
 * lock provider so that cron-triggered jobs run on exactly one pod.
 *
 * <p>The lock collection ({@code shedlock}) is auto-created in the same
 * database used by the application's MongoDB connection.
 */
@Configuration
@EnableScheduling
@EnableSchedulerLock(defaultLockAtMostFor = "30m")
public class SchedulerConfig {

    @Bean
    public LockProvider lockProvider(MongoDatabaseFactory mongoDatabaseFactory) {
        return new MongoLockProvider(mongoDatabaseFactory.getMongoDatabase());
    }

    @Bean
    public TaskScheduler taskScheduler() {
        ThreadPoolTaskScheduler scheduler = new ThreadPoolTaskScheduler();
        scheduler.setPoolSize(2);
        scheduler.setThreadNamePrefix("job-scheduler-");
        scheduler.initialize();
        return scheduler;
    }
}

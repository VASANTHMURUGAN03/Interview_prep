package com.star.databridge.config;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import io.micrometer.tracing.Tracer;

@Component
public class TracingDebugConfig {

    @Autowired(required = false)
    private Tracer tracer;

    @PostConstruct
    public void checkTracer() {
        System.out.println("Tracer bean = " + tracer);
    }
}

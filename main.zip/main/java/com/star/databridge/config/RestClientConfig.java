package com.star.databridge.config;

import com.star.databridge.properties.RestTemplateProperties;
import com.star.databridge.util.PropertyConstant;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.core5.util.Timeout;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

import java.time.Duration;

@Slf4j
@Configuration
@EnableConfigurationProperties(RestTemplateProperties.class)
@RequiredArgsConstructor
public class RestClientConfig {

    private final PropertyConstant propertyConstant;


    @Bean
    public RestClient.Builder restClientBuilder() {
        return RestClient.builder();
    }


    /**
     * Helper method to create a modern, pooling HTTP factory for Spring Boot 4.0
     */
    private HttpComponentsClientHttpRequestFactory createApacheFactory(int maxTotal, int maxPerRoute, int connectMs, int readMs) {
        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
        connectionManager.setMaxTotal(maxTotal);
        connectionManager.setDefaultMaxPerRoute(maxPerRoute);

        CloseableHttpClient httpClient = HttpClients.custom()
                .setConnectionManager(connectionManager)
                .build();

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);

        // Spring Boot 4 requires java.time.Duration instead of legacy integer milliseconds
        requestFactory.setConnectionRequestTimeout(Duration.ofMillis(connectMs));
        requestFactory.setReadTimeout(Duration.ofMillis(readMs));

        return requestFactory;
    }

    @Bean(name = "datalakeRestClient")
    public RestClient datalakeRestClient(RestClient.Builder builder) {
        RestClient client = builder
                .requestFactory(createApacheFactory(20, 20, 3000, 5000))
                .build();

        log.info("Initialized datalakeRestClient hashcode: {}", client.hashCode());
        return client;
    }

    @Bean(name = "salesforceRestClient")
    public RestClient salesforceRestClient(RestClient.Builder builder) {
        RestClient client = builder
                .requestFactory(createApacheFactory(20, 20, 3000, 5000))
                .build();

        log.info("Initialized salesforceRestClient hashcode: {}", client.hashCode());
        return client;
    }

    @Primary
    @Bean(name = "restClient")
    public RestClient defaultRestClient(RestClient.Builder builder) {
        RestClient client = builder
                .requestFactory(createApacheFactory(
                        100,
                        50,
                        3000,
                        propertyConstant.getGenericRestTemplateReadTimeOut()
                ))
                .build();

        log.info("Initialized defaultRestClient hashcode: {}", client.hashCode());
        return client;
    }
}
package com.star.databridge.config;

import com.star.databridge.properties.KafkaConfigurationProperties;
import com.star.databridge.util.KafkaConstant;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.util.backoff.FixedBackOff;

import java.util.Map;

@Configuration
@EnableKafka
@Slf4j
@RequiredArgsConstructor
@ConditionalOnProperty(value = "kafka.consumer.enabled", havingValue = "true")
public class KafkaConsumerConfig {

    private final KafkaConfigurationProperties kafkaConfigurationProperties;

    @Bean
    public Map<String, Object> consumerServerConfig() {
        return Map.of(
                ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaConfigurationProperties.getBootstrapServers(),
                ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, KafkaConstant.AUTO_OFFSET_RESET_CONFIG,
                ConsumerConfig.REQUEST_TIMEOUT_MS_CONFIG, kafkaConfigurationProperties.getRequestTimeout(),
                ConsumerConfig.RETRY_BACKOFF_MS_CONFIG, kafkaConfigurationProperties.getRetryBackOffMS(),
                ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, KafkaConstant.HEARTBEAT_INTERVAL_MS_CONFIG,
                ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, Boolean.FALSE,
                ConsumerConfig.ISOLATION_LEVEL_CONFIG, KafkaConstant.ISOLATION_LEVEL_CONFIG,
                ConsumerConfig.MAX_POLL_RECORDS_CONFIG, kafkaConfigurationProperties.getMaxPollRecord(),
                ConsumerConfig.GROUP_ID_CONFIG, kafkaConfigurationProperties.getGroupId()
        );
    }

    @Bean
    public ConsumerFactory<String, String> consumerFactory() {
        return new DefaultKafkaConsumerFactory<>(consumerServerConfig(), new StringDeserializer(),
                new StringDeserializer());
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<?, ?> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConcurrency(kafkaConfigurationProperties.getConcurrencyThreads());
        factory.getContainerProperties().setPollTimeout(kafkaConfigurationProperties.getPollTimeout());
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL_IMMEDIATE);
        factory.getContainerProperties().setObservationEnabled(true);
        factory.setConsumerFactory(consumerFactory());
        return factory;
    }

//    TODO undo this
//    @Bean
//    public DefaultErrorHandler kafkaErrorHandler() {
//        // After 3 total attempts (1 initial + 2 retries), the recoverer logs the failure
//        // and the offset is committed so remaining messages continue processing unblocked.
//        return new DefaultErrorHandler(
//                (record, ex) -> log.error(
//                        "Message failed after 3 attempts, skipping. topic={}, partition={}, offset={}, error={}",
//                        record.topic(), record.partition(), record.offset(), ex.getMessage()),
//                new FixedBackOff(0L, 2L)
//        );
//    }

}

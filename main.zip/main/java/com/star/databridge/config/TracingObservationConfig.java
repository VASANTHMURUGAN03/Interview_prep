package com.star.databridge.config;

import io.micrometer.observation.ObservationRegistry;
import io.micrometer.tracing.Tracer;
import io.micrometer.tracing.handler.DefaultTracingObservationHandler;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TracingObservationConfig {

    @Bean
    public CommandLineRunner registerMdcHandler(
            ObservationRegistry observationRegistry,
            ObjectProvider<Tracer> tracerProvider) { // ObjectProvider handles lazy initialization safely

        return args -> {
            // Retrieve the tracer bean safely at runtime execution
            Tracer tracer = tracerProvider.getIfAvailable();

            if (tracer != null) {
                observationRegistry.observationConfig().observationHandler(
                        new DefaultTracingObservationHandler(tracer)
                );
            }
        };
    }
}
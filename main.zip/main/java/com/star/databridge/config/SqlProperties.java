package com.star.databridge.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Data
@Component
@ConfigurationProperties(prefix = "app")
public class SqlProperties {

    /**
     * Named SQL connections used by {@code SqlReader}. The map key is the
     * source name referenced from {@code params.source} in the job config.
     */
    private Map<String, SqlSourceProperties> sqlSources = new HashMap<>();

    @Data
    public static class SqlSourceProperties {
        /** {@code postgres} or {@code mysql}. */
        private String type;
        private String url;
        private String username;
        private String password;
    }
}

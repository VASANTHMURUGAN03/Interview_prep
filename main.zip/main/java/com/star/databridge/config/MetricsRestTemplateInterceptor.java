package com.star.databridge.config;

import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class MetricsRestTemplateInterceptor implements ClientHttpRequestInterceptor {

    private final MeterRegistry meterRegistry;
    private final String metricName;

    public MetricsRestTemplateInterceptor(MeterRegistry meterRegistry, String metricName) {
        this.meterRegistry = meterRegistry;
        this.metricName = metricName;
    }

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
            throws IOException {
        long startTime = System.nanoTime();
        try {
            ClientHttpResponse response = execution.execute(request, body);
            recordMetrics(request, response, System.nanoTime() - startTime);
            return response;
        } catch (IOException ex) {
            recordMetrics(request, null, System.nanoTime() - startTime);
            throw ex;
        }
    }

    private void recordMetrics(HttpRequest request, ClientHttpResponse response, long durationInNs) throws IOException {
        String uri = request.getURI().getPath();
        String method = request.getMethod().toString();
        String status = (response != null) ? String.valueOf(response.getStatusCode().value()) : "error";

        meterRegistry.timer(metricName, "method", method, "uri", uri, "status", status)
                .record(durationInNs, TimeUnit.NANOSECONDS);
    }
}
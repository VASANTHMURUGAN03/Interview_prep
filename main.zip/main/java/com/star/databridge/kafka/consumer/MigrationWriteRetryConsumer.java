package com.star.databridge.kafka.consumer;

import com.star.databridge.dto.kafka.WriteBatchMessage;
import com.star.databridge.service.WriteBatchProcessor;
import com.star.databridge.util.ObjectMapperUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class MigrationWriteRetryConsumer extends BaseConsumer {

    private final WriteBatchProcessor writeBatchProcessor;

    @Value("${app.kafka.topics.migration-write-retry}")
    private String writeRetryTopic;

    @Override
    protected String getTopic() {
        return writeRetryTopic;
    }

    @KafkaListener(topics = "${app.kafka.topics.migration-write-retry}", concurrency = "3")
    public void consume(ConsumerRecord<String, String> record, Acknowledgment ack) {
        super.handleMessage(record, ack);
    }

    @Override
    protected void execute(ConsumerRecord<String, String> record) {
        WriteBatchMessage msg = ObjectMapperUtil.readValue(record.value(), WriteBatchMessage.class);
        log.info("[WriteRetry] Received message writeBatchExecutionId={}", msg.getWriteBatchExecutionId());

        writeBatchProcessor.process(msg, "RETRY");
    }
}

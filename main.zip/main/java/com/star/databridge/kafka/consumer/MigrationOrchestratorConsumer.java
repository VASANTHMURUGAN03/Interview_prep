package com.star.databridge.kafka.consumer;

import com.star.databridge.dto.kafka.OrchestrationMessage;
import com.star.databridge.dto.kafka.WriteBatchMessage;
import com.star.databridge.dto.mongo.SyncRecordSummary;
import com.star.databridge.entity.JobConfigEntity;
import com.star.databridge.entity.JobExecutionEntity;
import com.star.databridge.entity.SyncRecordEntity;
import com.star.databridge.entity.WriteBatchExecutionEntity;
import com.star.databridge.kafka.producer.KafkaEventPublisherUtil;
import com.star.databridge.repository.JobExecutionRepository;
import com.star.databridge.repository.SyncRecordRepository;
import com.star.databridge.service.WriteBatchService;
import com.star.databridge.config.ExecutorPool;
import com.star.databridge.util.ObjectMapperUtil;
import com.star.databridge.util.TracingUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

/**
 * Orchestrates the creation of write batches from READY sync records.
 *
 * <p>All messages for a given job are routed to the same consumer instance via
 * Kafka key = jobExecutionId (concurrency = 1 so ordering is guaranteed per job).
 *
 * <p>Strategy rules:
 * <ul>
 *   <li>SIMULTANEOUS_READ_WRITE – orchestrate on every message</li>
 *   <li>READ_FIRST – orchestrate only when lastBatch = true</li>
 * </ul>
 *
 * <p>Orchestration loop:
 * <ol>
 *   <li>While unassigned-READY count ≥ batchSize: take a page, assign writeBatchExecutionId,
 *       create WriteBatchExecutionEntity, publish write-batch message (no key → concurrent).</li>
 *   <li>If lastBatch and remaining unassigned-READY records exist (< batchSize):
 *       create one final partial write batch for them.</li>
 * </ol>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class MigrationOrchestratorConsumer extends BaseConsumer {

    private final JobExecutionRepository jobExecutionRepository;
    private final SyncRecordRepository syncRecordRepository;
    private final WriteBatchService writeBatchService;
    private final KafkaEventPublisherUtil kafkaEventPublisherUtil;
    private final MongoTemplate mongoTemplate;
    private final TracingUtils tracingUtils;

    @Value("${app.kafka.topics.migration-orchestrator}")
    private String orchestratorTopic;

    @Value("${app.kafka.topics.migration-write-batch}")
    private String writeBatchTopic;

    @Override
    protected String getTopic() {
        return orchestratorTopic;
    }

    @KafkaListener(topics = "${app.kafka.topics.migration-orchestrator}", concurrency = "1")
    public void consume(ConsumerRecord<String, String> record, Acknowledgment ack) {
        super.handleMessage(record, ack);
    }

    @Override
    protected void execute(ConsumerRecord<String, String> record) {
        OrchestrationMessage msg = ObjectMapperUtil.readValue(record.value(), OrchestrationMessage.class);
        log.info("[Orchestrator] Received message jobExecutionId={} lastBatch={}", msg.getJobExecutionId(), msg.isLastBatch());

        JobExecutionEntity jobExecution = jobExecutionRepository
                .findByIdAndStatus(msg.getJobExecutionId(), "IN_PROGRESS")
                .orElse(null);

        if (jobExecution == null) {
            log.warn("[Orchestrator] No in-progress job execution found for id={}", msg.getJobExecutionId());
            return;
        }

        JobConfigEntity jobConfig = jobExecution.getJobConfig();
        String strategy = jobConfig.getStrategy() != null ? jobConfig.getStrategy() : "READ_FIRST";

        // READ_FIRST: only act when all reads are done
        if ("READ_FIRST".equals(strategy) && !msg.isLastBatch()) {
            log.info("[Orchestrator] READ_FIRST strategy — skipping until last batch for job={}", msg.getJobExecutionId());
            return;
        }

        orchestrate(msg.getJobExecutionId(), jobConfig, msg.isLastBatch());
    }

    private void orchestrate(String jobExecutionId, JobConfigEntity jobConfig, boolean lastBatch) {
        int batchSize = jobConfig.getSink().getBatchSize();
        String entity = jobConfig.getEntity();

        long unassigned = syncRecordRepository
                .countByJobExecutionIdAndStatusAndWriteBatchExecutionIdIsNull(jobExecutionId, "READY");

        if (unassigned == 0 || (unassigned < batchSize && !lastBatch)) {
            log.info("[Orchestrator] No eligible records to batch for job={} (unassigned={}, lastBatch={})",
                    jobExecutionId, unassigned, lastBatch);
            return;
        }

        // When not lastBatch, only fetch complete batches worth of records
        int numBatches = lastBatch
                ? (int) Math.ceil((double) unassigned / batchSize)
                : (int) (unassigned / batchSize);
        int recordsToFetch = numBatches * batchSize;

        List<SyncRecordSummary> allRecords = syncRecordRepository
                .findByJobExecutionIdAndStatusAndWriteBatchExecutionIdIsNull(
                        jobExecutionId, "READY", PageRequest.of(0, recordsToFetch));
        log.info("[Orchestrator] Dispatching {} write batches for job={} (totalRecords={})",
                numBatches, jobExecutionId, allRecords.size());

        ExecutorService executor = ExecutorPool.getWriteBatchConsumerExecutor();
        List<Future<?>> futures = new ArrayList<>(numBatches);

        for (int i = 0; i < numBatches; i++) {
            int from = i * batchSize;
            int to = Math.min(from + batchSize, allRecords.size());
            List<SyncRecordSummary> chunk = allRecords.subList(from, to);

            futures.add(executor.submit(
                    tracingUtils.wrapCallableWithSpan("orchestrator-write-batch",
                            () -> {
                                publishWriteBatch(jobExecutionId, entity, chunk);
                                return null;
                            })
            ));
        }

        for (Future<?> future : futures) {
            try {
                future.get();
            } catch (Exception e) {
                throw new RuntimeException("[Orchestrator] Error creating write batch for job=" + jobExecutionId, e);
            }
        }
    }

    private void publishWriteBatch(String jobExecutionId, String entity, List<SyncRecordSummary> records) {
        WriteBatchExecutionEntity writeBatch = writeBatchService.createBatch(jobExecutionId, entity, null);

        List<String> ids = records.stream().map(SyncRecordSummary::getId).toList();
        Query query = new Query(Criteria.where("_id").in(ids));
        Update update = new Update().set("writeBatchExecutionId", writeBatch.getId());
        mongoTemplate.updateMulti(query, update, SyncRecordEntity.class);

        WriteBatchMessage writeBatchMsg = WriteBatchMessage.builder()
                .writeBatchExecutionId(writeBatch.getId())
                .build();

        kafkaEventPublisherUtil.publishEventToKafkaTopic(writeBatchTopic, writeBatch.getId(),
                ObjectMapperUtil.convertObjectToString(writeBatchMsg));

        log.info("[Orchestrator] Created write batch={} with {} records for job={}", writeBatch.getId(), ids.size(), jobExecutionId);
    }
}

package com.star.databridge.kafka.consumer;

import com.star.databridge.dto.kafka.JobCompletionMessage;
import com.star.databridge.dto.mongo.StatusCount;
import com.star.databridge.entity.JobConfigEntity;
import com.star.databridge.entity.JobExecutionEntity;
import com.star.databridge.repository.JobConfigRepository;
import com.star.databridge.repository.JobExecutionRepository;
import com.star.databridge.repository.ReadBatchExecutionRepository;
import com.star.databridge.repository.SyncRecordRepository;
import com.star.databridge.service.*;
import com.star.databridge.util.KafkaUtil;
import com.star.databridge.util.ObjectMapperUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.protocol.types.Field;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Slf4j
@Component
@RequiredArgsConstructor
public class JobCompletionCheckConsumer extends BaseConsumer {

    private final SyncRecordRepository syncRecordRepository;
    private final JobExecutionService jobExecutionService;
    private final JobConfigRepository jobConfigRepository;
    private final JobExecutionRepository jobExecutionRepository;
    private final ReadBatchExecutionRepository readBatchExecutionRepository;
    private final ReadBatchService readBatchService;
    private final WriteBatchService writeBatchService;
    private final SyncRecordService syncRecordService;
    private final KafkaUtil kafkaUtil;
    private final ReportService reportService;

    @Value("${app.kafka.topics.migration-job-completion-check}")
    private String completionCheckTopic;

    @Value("${app.kafka.topics.migration-job-completion-check-delay-ms:30000}")
    private long delayMs;

    @Override
    protected String getTopic() {
        return completionCheckTopic;
    }

    @KafkaListener(topics = "${app.kafka.topics.migration-job-completion-check}", concurrency = "3")
    public void consume(ConsumerRecord<String, String> record, Acknowledgment ack) {
        super.handleMessage(record, ack);
    }

    @Override
    protected void execute(ConsumerRecord<String, String> record) {
        JobCompletionMessage msg = ObjectMapperUtil.readValue(record.value(), JobCompletionMessage.class);
        String jobExecutionId = msg.getJobExecutionId();

        log.info("[CompletionCheck] Checking job completion for jobExecutionId={}", jobExecutionId);

        // If the job is already in a terminal failure state, don't overwrite it and don't trigger postComplete.
        Optional<JobExecutionEntity> optionalJobExecution = jobExecutionRepository.findById(jobExecutionId);
        if (optionalJobExecution.isPresent()) {
            String currentStatus = optionalJobExecution.get().getStatus();
            if ("FAILED".equals(currentStatus) || "ABORTED".equals(currentStatus)) {
                log.info("[CompletionCheck] Job {} already {} — stopping completion check", jobExecutionId, currentStatus);
                return;
            }
        }

        // Count records that are NOT in terminal state (SUCCESS, FAILED)
        long pendingRecordCount = syncRecordRepository.countByJobExecutionIdAndStatusNotIn(
                jobExecutionId,
                List.of("SUCCESS", "FAILED")
        );

        long pendingReadBatchCount = readBatchExecutionRepository.countByJobExecutionIdAndStatusNotIn(
                jobExecutionId,
                List.of("SUCCESS", "FAILED")
        );

        if (pendingRecordCount > 0 || pendingReadBatchCount > 0) {
            log.info("[CompletionCheck] Job {} has pending {} records, {} read batches — republishing with delay",
                    jobExecutionId, pendingRecordCount, pendingReadBatchCount);
            republishWithDelay(msg);
            return;
        }

        List<StatusCount> writeBatchStats = writeBatchService.getStatusWiseCount(jobExecutionId);
        List<StatusCount> readBatchStats = readBatchService.getStatusWiseCount(jobExecutionId);
        List<StatusCount> recordStats = syncRecordService.getStatusWiseCount(jobExecutionId);

        Map<String, List<StatusCount>> stats = Map.of(
                "readBatches", readBatchStats,
                "writeBatches", writeBatchStats,
                "records", recordStats
        );

        // All records are terminal — job is complete
        log.info("[CompletionCheck] Job {} is complete — all records are in terminal state", msg.getJobExecutionId());
        jobExecutionService.updateStatus(jobExecutionId, stats, "COMPLETED");

        sendJobReport(optionalJobExecution, jobExecutionId, recordStats);

        // Run postComplete: trigger next jobs
        triggerPostCompleteJobs(msg.getJobId());
    }

    private void republishWithDelay(JobCompletionMessage msg) {
        try {
            Thread.sleep(delayMs);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        kafkaUtil.pushCompletionCheckMsg(msg.getJobId(), msg.getJobExecutionId());
    }

    public void sendJobReport(Optional<JobExecutionEntity> optionalJobExecution, String jobExecutionId, List<StatusCount> recordStats){
        JobConfigEntity cfg = optionalJobExecution.get().getJobConfig();
        Optional.ofNullable(cfg.getReport()).ifPresent(report -> {
            try {
                reportService.sendReport(jobExecutionId, report, recordStats);
            } catch (Exception e) {
                log.error("[CompletionCheck] report failed for jobExecutionId={}", jobExecutionId, e);
            }
        });
    }

    private void triggerPostCompleteJobs(String jobId) {
        Optional<JobConfigEntity> optionalConfig = jobConfigRepository.findById(jobId);
        if (optionalConfig.isEmpty()) return;

        JobConfigEntity config = optionalConfig.get();
        if (config.getPostComplete() == null || config.getPostComplete().getTriggerJobs() == null) {
            return;
        }

        for (String nextJobName : config.getPostComplete().getTriggerJobs()) {
            log.info("[CompletionCheck] Triggering postComplete job: {}", nextJobName);
            try {
                jobExecutionService.triggerJob(nextJobName);
            } catch (Exception e) {
                log.error("[CompletionCheck] Failed to trigger postComplete job: {}", nextJobName, e);
            }
        }
    }
}
package com.star.databridge.kafka.consumer;

import com.star.databridge.constant.CommonConstant;
import com.star.databridge.util.CommonUtil;
import com.star.databridge.util.KafkaUtil;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.support.Acknowledgment;
import tools.jackson.core.JacksonException;

/**
 * Template base for all Kafka consumers.
 *
 * Flow per message:
 * consume() [defined in subclass, annotated with @KafkaListener]
 * └─► handleMessage() [logs receipt, delegates to execute()]
 *     ├─► execute() [business logic — implemented by each consumer]
 *     └─► on any uncaught exception → publishes to DLQ, then acknowledges
 *
 * Every message is always acknowledged exactly once — no Spring Kafka retries.
 * Consumers that need richer DLQ context should call getDlqPublisher() directly
 * inside their execute() and handle the exception themselves (without rethrowing).
 */
@Slf4j
@Getter
public abstract class BaseConsumer {

    @Autowired
    private KafkaUtil dlqPublisher;

    /**
     * Returns the topic this consumer is bound to — used for structured logging.
     */
    protected abstract String getTopic();

    /**
     * All business logic for this consumer.
     * Must NOT rethrow exceptions — handle them and call getDlqPublisher() explicitly,
     * or let the BaseConsumer safety-net catch route to the DLQ automatically.
     */
    protected abstract void execute(ConsumerRecord<String, String> record) throws JacksonException;
    /**
     * Called by the concrete consumer's @KafkaListener method.
     * Logs the inbound record, delegates to execute(), and always acknowledges.
     * Any exception that escapes execute() is sent to the DLQ before acking.
     */
    protected void handleMessage(ConsumerRecord<String, String> record, Acknowledgment ack) {
        MDC.put(CommonConstant.REQUEST_UUID, CommonUtil.generateUniqueId());
        log.info("[{}] Message received | partition={} offset={} key={}",
                getTopic(), record.partition(), record.offset(), record.key());
        log.debug("[{}] Payload: {}", getTopic(), record.value());
        long currTime = System.currentTimeMillis();
        try {

            // execute the consumer function
            execute(record);
        } catch (Exception e) {
            log.error("[{}] Unhandled exception — routing to DLQ | key={} | error={}",
                    getTopic(), record.key(), e.getMessage(), e);
            dlqPublisher.publishToDlq("PROCESSING_ERROR", e.getMessage().substring(0, Math.min(400, e.getMessage().length())), getTopic(), record.value(), null);
        } finally {
            log.info("[{}] message executed: {}", getTopic(), System.currentTimeMillis() - currTime);
            ack.acknowledge();
            MDC.remove(CommonConstant.REQUEST_UUID);
        }
    }
}

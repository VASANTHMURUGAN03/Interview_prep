package com.star.databridge.kafka.consumer;

import com.star.databridge.dto.common.JobContext;
import com.star.databridge.dto.kafka.ReadBatchMessage;
import com.star.databridge.dto.mongo.PaginationConfig;
import com.star.databridge.dto.reader.*;
import com.star.databridge.entity.*;
import com.star.databridge.reader.DataReader;
import com.star.databridge.reader.ReaderFactory;
import com.star.databridge.repository.JobExecutionRepository;
import com.star.databridge.repository.ReadBatchExecutionRepository;
import com.star.databridge.dto.mongo.ReadConfig;
import com.star.databridge.service.*;
import com.star.databridge.util.KafkaUtil;
import com.star.databridge.util.ObjectMapperUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;
import tools.jackson.databind.ObjectMapper;

import java.util.List;
import java.util.Optional;

@Slf4j
@Component
@RequiredArgsConstructor
public class MigrationReadBatchConsumer extends BaseConsumer {

    private final ReaderFactory readerFactory;
    private final ProcessExecutorService processExecutorService;
    private final ReadBatchService readBatchService;
    private final JobExecutionService jobExecutionService;
    private final JobExecutionRepository jobExecutionRepository;
    private final ReadBatchExecutionRepository readBatchExecutionRepository;
    private final KafkaUtil kafkaUtil;
    private final ObjectMapper objectMapper;

    @Value("${app.kafka.topics.migration-read-batch}")
    private String readBatchTopic;

    @Override
    protected String getTopic() {
        return readBatchTopic;
    }

    @KafkaListener(topics = "${app.kafka.topics.migration-read-batch}", concurrency = "3")
    public void consume(ConsumerRecord<String, String> record, Acknowledgment ack) {
        super.handleMessage(record, ack);
    }

    @Override
    protected void execute(ConsumerRecord<String, String> record) {
        log.info("[MigrationReadBatch] Received message: {}", record.value());

        ReadBatchMessage msg = ObjectMapperUtil.readValue(record.value(), ReadBatchMessage.class);

        // Load read batch execution
        Optional<ReadBatchExecutionEntity> optionalReadBatch =
                readBatchExecutionRepository.findById(msg.getReadBatchExecutionId());
        if (optionalReadBatch.isEmpty()) {
            throw new RuntimeException("Read batch execution not found: " + msg.getReadBatchExecutionId());
        }

        ReadBatchExecutionEntity readBatch = optionalReadBatch.get();

        // Load job execution → job config
        Optional<JobExecutionEntity> optionalJobExecution =
                jobExecutionRepository.findById(readBatch.getJobExecutionId());
        if (optionalJobExecution.isEmpty()) {
            throw new RuntimeException("Job execution not found: " + readBatch.getJobExecutionId());
        }

        JobExecutionEntity jobExecution = optionalJobExecution.get();

        // Bail out if the job was externally aborted while this message was queued.
        if (!"IN_PROGRESS".equals(jobExecution.getStatus())) {
            log.info("[MigrationReadBatch] Job {} is {} — skipping read batch {}",
                    readBatch.getJobExecutionId(), jobExecution.getStatus(), readBatch.getId());
            return;
        }

        JobConfigEntity jobConfig = jobExecution.getJobConfig();

        PaginationConfig paginationConfig = objectMapper.convertValue(
                jobConfig.getRead().getParams().get("pagination"), PaginationConfig.class);

        JobContext jobContext = JobContext.builder()
                .jobId(jobConfig.getId())
                .jobExecutionId(readBatch.getJobExecutionId())
                .entity(jobConfig.getEntity())
                .batchId(readBatch.getId())
                .batchNo(readBatch.getBatchNo())
                .build();

        try {
            // 1. Read
            ReadContext readContext = ReadContext.builder()
                    .jobContext(jobContext)
                    .cursor("CURSOR".equalsIgnoreCase(paginationConfig.getType()) && msg.getNextCursor() != null ? msg.getNextCursor() : "0")
                    .offset("OFFSET".equalsIgnoreCase(paginationConfig.getType()) && msg.getNextCursor() != null
                            ? Long.parseLong(msg.getNextCursor()) : 0)
                    .stepConfig(jobConfig.getRead())
                    .build();

            DataReader reader = readerFactory.getReader(jobConfig.getRead().getType());
            ReadResult readResult = reader.read(readContext);

            log.info("[MigrationReadBatch] Read complete batchNo={} hasMore={}", readBatch.getBatchNo(), readResult.isHasMore());

            // 2. Process + persist sync_records (status=READY)
            List<SyncRecordEntity> syncRecords = processExecutorService.execute(
                    jobConfig.getProcess(), readResult.getData(), jobContext);

            // 3. Update read batch execution: records + status
            List<String> recordIds = syncRecords.stream().map(SyncRecordEntity::getRecordId).toList();
            String nextCursor = null;

            // 4. If hasMore, create next read batch execution and publish message
            if (readResult.isHasMore()) {
                nextCursor = readResult.getNextCursor() != null
                        ? readResult.getNextCursor()
                        : String.valueOf(readResult.getNextOffset());

                ReadBatchExecutionEntity nextReadBatch = readBatchService.createBatch(
                        jobConfig, readBatch.getJobExecutionId(), readBatch.getBatchNo() + 1);

                kafkaUtil.pushReadBatchMsg(nextReadBatch, nextCursor);
            }

            readBatchService.setSuccessful(readBatch, recordIds, nextCursor);

            // 5. Notify orchestrator — lastBatch = !hasMore
            kafkaUtil.pushOrchestrationMsg(readBatch.getJobExecutionId(), !readResult.isHasMore());

        } catch (Exception e) {
            log.error("[MigrationReadBatch] Error processing batchNo={}", readBatch.getBatchNo(), e);
            handleReadBatchError(readBatch, jobConfig, paginationConfig, msg.getNextCursor(), e);
        }
    }

    private void handleReadBatchError(ReadBatchExecutionEntity readBatch, JobConfigEntity jobConfig,
                                      PaginationConfig paginationConfig, String currentCursor, Exception cause) {
        ReadConfig readConfig = jobConfig.getRead();
        int maxRetryCount = readConfig.getMaxRetryCount() != null ? readConfig.getMaxRetryCount() : 3;

        // Retries remaining — republish the same batch
        if (readBatch.getRetryCount() < maxRetryCount) {
            readBatch.setRetryCount(readBatch.getRetryCount() + 1);
            readBatch.setStatus("RETRY");
            readBatch.setRemarks(cause.getMessage());
            readBatchExecutionRepository.save(readBatch);
            kafkaUtil.pushReadBatchMsg(readBatch, currentCursor);
            log.info("[MigrationReadBatch] Retrying batchNo={} retryCount={}",
                    readBatch.getBatchNo(), readBatch.getRetryCount());
            return;
        }

        // Retries exhausted — terminal failure for this batch
        readBatch.setStatus("FAILED");
        readBatch.setRemarks(cause.getMessage());
        readBatchExecutionRepository.save(readBatch);
        log.error("[MigrationReadBatch] Max retries exceeded for batchNo={}", readBatch.getBatchNo());

        String paginationType = paginationConfig != null ? paginationConfig.getType() : null;
        String failureStrategy = readConfig.getFailureStrategy();
        String reason = "Read batch " + readBatch.getBatchNo() + " failed: " + cause.getMessage();

        // Cursor pagination cannot skip a failed batch — the next cursor comes from
        // the response we failed to receive. Always abort regardless of failureStrategy.
        if ("CURSOR".equalsIgnoreCase(paginationType)) {
            log.error("[MigrationReadBatch] Cursor pagination cannot recover from batch failure — aborting job {}",
                    readBatch.getJobExecutionId());
            jobExecutionService.abortJob(readBatch.getJobExecutionId(), reason);
            return;
        }

        // Offset pagination — honor failureStrategy (default ABORT)
        if ("IGNORE".equalsIgnoreCase(failureStrategy)) {
            log.warn("[MigrationReadBatch] Ignoring failed batchNo={} and continuing at next offset",
                    readBatch.getBatchNo());
            continueAtNextOffset(jobConfig, readBatch, paginationConfig, currentCursor);
            return;
        }

        // ABORT (default)
        jobExecutionService.abortJob(readBatch.getJobExecutionId(), reason);
    }

    /**
     * For IGNORE strategy with OFFSET pagination: skip the failed batch by creating
     * the next read batch at {@code currentOffset + batchSize} and publish it.
     * Also triggers write batch publishing so the sink side isn't left stranded
     * when the failed batch was batch #1 under {@code SIMULTANEOUS_READ_WRITE}.
     */
    private void continueAtNextOffset(JobConfigEntity jobConfig, ReadBatchExecutionEntity failedBatch,
                                      PaginationConfig paginationConfig, String currentCursor) {
        long currentOffset = currentCursor != null ? Long.parseLong(currentCursor) : 0;
        int batchSize = paginationConfig.getBatchSize() != null ? paginationConfig.getBatchSize() : 0;
        String nextCursor = String.valueOf(currentOffset + batchSize);

        ReadBatchExecutionEntity nextReadBatch = readBatchService.createBatch(
                jobConfig, failedBatch.getJobExecutionId(), failedBatch.getBatchNo() + 1);

        kafkaUtil.pushReadBatchMsg(nextReadBatch, nextCursor);

        // Notify orchestrator that a read batch completed (even though it failed/was skipped)
        // lastBatch=false since we're continuing to the next offset
        kafkaUtil.pushOrchestrationMsg(failedBatch.getJobExecutionId(), false);
    }
}

package com.star.databridge.kafka.consumer;

import com.star.databridge.dto.kafka.StepExecutionLogMessage;
import com.star.databridge.service.StepExecutionLogService;
import com.star.databridge.util.ObjectMapperUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class StepExecutionLogConsumer extends BaseConsumer {

    private final StepExecutionLogService stepExecutionLogService;

    @Value("${app.kafka.topics.migration-step-execution-logs}")
    private String stepExecutionLogTopic;

    @Override
    protected String getTopic() {
        return stepExecutionLogTopic;
    }

    @KafkaListener(topics = "${app.kafka.topics.migration-step-execution-logs}", concurrency = "3")
    public void consume(ConsumerRecord<String, String> record, Acknowledgment ack) {
        super.handleMessage(record, ack);
    }

    @Override
    protected void execute(ConsumerRecord<String, String> record) {
        try {
            StepExecutionLogMessage msg = ObjectMapperUtil.readValue(record.value(), StepExecutionLogMessage.class);
            stepExecutionLogService.upsertStepExecutionLog(msg);

            log.debug("[StepExecutionLog] Persisted step execution: step={} status={}", msg.getStepName(), msg.getStatus());
        } catch (Exception e) {
            log.error("[StepExecutionLogConsumer] Step execution log consumer failed {}, error {}",
                    record.value(), e.getMessage());
        }
    }
}

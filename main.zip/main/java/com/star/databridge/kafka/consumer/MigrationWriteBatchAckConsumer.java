package com.star.databridge.kafka.consumer;

import com.star.databridge.dto.ack.AckResult;
import com.star.databridge.dto.common.JobContext;
import com.star.databridge.dto.kafka.AckMessage;
import com.star.databridge.dto.mongo.WriteRecordDetail;
import com.star.databridge.entity.JobConfigEntity;
import com.star.databridge.entity.JobExecutionEntity;
import com.star.databridge.entity.SyncRecordEntity;
import com.star.databridge.entity.WriteBatchExecutionEntity;
import com.star.databridge.kafka.producer.KafkaEventPublisherUtil;
import com.star.databridge.repository.JobExecutionRepository;
import com.star.databridge.repository.SyncRecordRepository;
import com.star.databridge.repository.WriteBatchExecutionRepository;
import com.star.databridge.service.AckExecutorService;
import com.star.databridge.service.WriteBatchProcessor;
import com.star.databridge.service.WriteBatchService;

import com.star.databridge.util.ObjectMapperUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class MigrationWriteBatchAckConsumer extends BaseConsumer {

    private final WriteBatchProcessor writeBatchProcessor;
    private final WriteBatchExecutionRepository writeBatchExecutionRepository;
    private final JobExecutionRepository jobExecutionRepository;
    private final SyncRecordRepository syncRecordRepository;
    private final WriteBatchService writeBatchService;
    private final AckExecutorService ackExecutorService;
    private final KafkaEventPublisherUtil kafkaEventPublisherUtil;

    @Value("${app.kafka.topics.migration-write-batch-ack}")
    private String writeBatchAckTopic;

    @Override
    protected String getTopic() {
        return writeBatchAckTopic;
    }

    @KafkaListener(topics = "${app.kafka.topics.migration-write-batch-ack}", concurrency = "3")
    public void consume(ConsumerRecord<String, String> record, Acknowledgment ack) {
        super.handleMessage(record, ack);
    }

    @Override
    protected void execute(ConsumerRecord<String, String> record) {
        AckMessage msg = ObjectMapperUtil.readValue(record.value(), AckMessage.class);
        log.info("[WriteBatchAck] Received message writeBatchExecutionId={}", msg.getWriteBatchExecutionId());

        String writeBatchExecutionId = msg.getWriteBatchExecutionId();

        WriteBatchExecutionEntity writeBatch = writeBatchExecutionRepository.findByIdAndStatus(writeBatchExecutionId, "ACK_PENDING")
                .orElse(null);

        if (writeBatch == null) {
            log.error("[WriteBatchAck] No writeBatchExecution found for id={}", writeBatchExecutionId);
            return;
        }

        JobExecutionEntity jobExecution = jobExecutionRepository.findByIdAndStatus(writeBatch.getJobExecutionId(), "IN_PROGRESS")
                .orElse(null);

        if (jobExecution == null) {
            log.error("[WriteBatchAck] No jobExecution found for id={}", writeBatch.getJobExecutionId());
            return;
        }

        JobConfigEntity jobConfig = jobExecution.getJobConfig();
        int maxRetryCount = jobConfig.getSink().getMaxRetryCount();

        List<SyncRecordEntity> records = writeBatch.getRecordIds() == null
                ? List.of()
                : syncRecordRepository.findAllByRecordIdInAndJobExecutionId(writeBatch.getRecordIds(), writeBatch.getJobExecutionId());

        if (records.isEmpty()) {
            log.warn("[WriteBatchAck] No records found for ack batch={}", writeBatch.getId());
            writeBatchService.updateBatchStatus(writeBatch, "SUCCESS", null, "No records found", null);
            return;
        }

        JobContext jobContext = JobContext.builder()
                .jobId(jobConfig.getId())
                .jobExecutionId(writeBatch.getJobExecutionId())
                .entity(writeBatch.getEntity())
                .batchRefId(writeBatch.getReferenceId())
                .batchId(writeBatch.getId())
                .build();

        try {
            AckResult ackResult = ackExecutorService.executeAck(
                    jobConfig.getAck(), records, jobContext, null, maxRetryCount);

            if (ackResult.isRestart()) {
//                TODO commented to reduce pressure
//                Thread.sleep(5000);
                log.info("[WriteBatchAck] Slept for 5000 batchId = {}, jobId = {}",
                        writeBatch.getId(), writeBatch.getJobExecutionId());
                kafkaEventPublisherUtil.publishEventToKafkaTopic(writeBatchAckTopic, writeBatch.getJobExecutionId(), ObjectMapperUtil.convertObjectToString(msg));
                return;
            }

            WriteRecordDetail recordDetail = WriteRecordDetail.builder()
                .successRecordIds(ackResult.getSuccessRecords())
                .failRecordIds(ackResult.getFailedRecords())
                .build();

            writeBatchService.updateBatchStatus(writeBatch, "SUCCESS", writeBatch.getReferenceId(), 
                null, recordDetail);

            if (!ackResult.getFailedRecords().isEmpty()) {
                writeBatchProcessor.publishWriteRetry(writeBatch);
            }
        } catch (Exception e) {
            log.error("[WriteBatchAck] Ack failed for batch={}", writeBatch.getId(), e);
            writeBatchProcessor.handleFailure(writeBatch, records, maxRetryCount, writeBatch.getReferenceId(), e.getMessage());
        }
    }
}

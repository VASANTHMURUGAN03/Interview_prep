package com.star.databridge.kafka.consumer;

import com.star.databridge.dto.kafka.WriteBatchMessage;
import com.star.databridge.service.WriteBatchProcessor;
import com.star.databridge.util.ObjectMapperUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;


@Slf4j
@Component
@RequiredArgsConstructor
public class MigrationWriteBatchConsumer extends BaseConsumer {

    private final WriteBatchProcessor writeBatchProcessor;
    @Value("${app.kafka.topics.migration-write-batch}")
    private String writeBatchTopic;

    @Override
    protected String getTopic() {
        return writeBatchTopic;
    }

    @KafkaListener(topics = "${app.kafka.topics.migration-write-batch}", concurrency = "3")
    public void consume(ConsumerRecord<String, String> record, Acknowledgment ack) {
        try {
            super.handleMessage(record, ack);
        } catch (Exception e) {
            log.error("Error processing record", e);
        } finally {
            ack.acknowledge();
        }
    }

    @Override
    protected void execute(ConsumerRecord<String, String> record) {
        WriteBatchMessage msg = ObjectMapperUtil.readValue(record.value(), WriteBatchMessage.class);
        log.info("[WriteBatch] Received message writeBatchExecutionId={}", msg.getWriteBatchExecutionId());

        writeBatchProcessor.process(msg, "READY");
    }
}

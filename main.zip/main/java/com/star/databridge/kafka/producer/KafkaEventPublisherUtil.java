package com.star.databridge.kafka.producer;

import com.star.databridge.exception.SyncErrorCode;
import com.star.databridge.exception.DataBridgeException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class KafkaEventPublisherUtil {

    private final KafkaTemplate<String, String> kafkaTemplate;

    public void publishEventToKafkaTopic(String topicName, String id, String payload) throws DataBridgeException {
        try {
            SendResult<String, String> sentKafkaDetails = kafkaTemplate.send(topicName, id, payload).get();
            log.info("KAFKA_LOGGING: Kafka sent message value: {}, key: {} on topic: {}",
                    sentKafkaDetails.getProducerRecord().value(),
                    sentKafkaDetails.getProducerRecord().key(),
                    sentKafkaDetails.getProducerRecord().topic());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt(); // Restore the interrupt status
            log.warn("Thread was interrupted in logEventToDBAndPublish");
        } catch (Exception e) {
            log.error("Exception occurred in logEventToDBAndPublish", e);
            throw new DataBridgeException(SyncErrorCode.KAFKA_PRODUCE_FAILED, e);
        }
    }

    public void publishEventToKafkaTopic(String topicName, String payload) throws DataBridgeException {
        try {
            SendResult<String, String> sentKafkaDetails = kafkaTemplate.send(topicName, payload).get();
            log.info("KAFKA_LOGGING: Kafka sent message value: {}, headers: {}, key: {} on topic: {}",
                    sentKafkaDetails.getProducerRecord().value(),
                    sentKafkaDetails.getProducerRecord().headers(),
                    sentKafkaDetails.getProducerRecord().key(),
                    sentKafkaDetails.getProducerRecord().topic());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt(); // Restore the interrupt status
            log.warn("Thread was interrupted in logEventToDBAndPublish");
        } catch (Exception e) {
            log.error("Exception occurred in logEventToDBAndPublish", e);
            throw new DataBridgeException(SyncErrorCode.KAFKA_PRODUCE_FAILED, e);
        }
    }
}

package com.star.databridge.enums;

/**
 * Control-flow decision returned by {@code StepService} after running a step.
 *
 * <p>Drives how the caller (process / sink / ack executor) advances through
 * its configured step list.
 */
public enum FlowDecision {
    /** Proceed to the next step. Default when no post-execution rule matches. */
    NEXT,

    /** Skip the next step (advance by two). */
    SKIP_NEXT,

    /**
     * Abandon the remaining steps and restart from the beginning.
     * Only valid in the ACK flow — enforced by {@code StepService}.
     */
    RESTART
}

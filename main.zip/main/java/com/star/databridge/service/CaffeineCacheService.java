package com.star.databridge.service;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.Expiry;
import lombok.extern.slf4j.Slf4j;
import org.checkerframework.checker.index.qual.NonNegative;
import org.springframework.stereotype.Service;
import tools.jackson.databind.JsonNode;

import java.util.concurrent.TimeUnit;

/**
 * In-process Caffeine cache for step outputs, scoped to a specific job execution.
 *
 * <p>Cache key format: {@code {jobExecutionId}:{stepName}}
 * <br>TTL is supplied per entry at write time from {@code StepConfig.cacheExpiryTime}.
 * If zero or negative, a default of 300 s is applied.
 *
 * <p>Cache writes never throw — failures are swallowed so the main execution flow is unaffected.
 */
@Slf4j
@Service
public class CaffeineCacheService {

    private static final long DEFAULT_TTL_SECONDS = 300L;

    /**
     * Wraps a {@link JsonNode} together with its expiry time so that Caffeine's
     * per-entry {@link Expiry} implementation can read the TTL at write time.
     */
    private record Entry(JsonNode value, long ttlNanos) {}

    private final Cache<String, Entry> cache = Caffeine.newBuilder()
            .expireAfter(new Expiry<String, Entry>() {
                @Override
                public long expireAfterCreate(String key, Entry entry, long currentTime) {
                    return entry.ttlNanos();
                }

                @Override
                public long expireAfterUpdate(String key, Entry entry, long currentTime,
                                              @NonNegative long currentDuration) {
                    return entry.ttlNanos();
                }

                @Override
                public long expireAfterRead(String key, Entry entry, long currentTime,
                                            @NonNegative long currentDuration) {
                    return currentDuration; // do not reset TTL on read
                }
            })
            .build();

    /**
     * Returns the cached step output for the given job execution and step, or {@code null} on miss.
     */
    public JsonNode get(String key) {
        Entry entry = cache.getIfPresent(key);
        if (entry != null) {
            log.info("[CaffeineStepCacheService] Cache hit  key={}, value={}", key, entry.value().toString());
            return entry.value();
        }
        log.info("[CaffeineStepCacheService] Cache miss key={}", key);
        return null;
    }

    /**
     * Stores {@code result} under {@code {jobExecutionId}:{stepName}} with the given TTL.
     *
     * @param ttlSeconds TTL in seconds; values ≤ 0 fall back to {@value DEFAULT_TTL_SECONDS} s.
     */
    public void put(String key, JsonNode result, long ttlSeconds) {
        if (result == null) {
            return;
        }
        try {
            long effectiveTtl = ttlSeconds > 0 ? ttlSeconds : DEFAULT_TTL_SECONDS;
            cache.put(key, new Entry(result, TimeUnit.SECONDS.toNanos(effectiveTtl)));
            log.info("[CaffeineStepCacheService] Cached  key={} ttl={}s , value={}", key, effectiveTtl,result);
        } catch (Exception e) {
            log.info("[CaffeineStepCacheService] Failed to cache for key '{}': {}", key, e.getMessage());
        }
    }

    public String buildStepKey(String jobExecutionId, String stepName) {
        return "step:" + jobExecutionId + ":" + stepName;
    }
}

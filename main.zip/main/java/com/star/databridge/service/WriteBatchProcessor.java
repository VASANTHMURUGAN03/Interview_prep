package com.star.databridge.service;

import com.star.databridge.config.ExecutorPool;
import com.star.databridge.dto.ack.AckResult;
import com.star.databridge.dto.common.JobContext;
import com.star.databridge.dto.kafka.AckMessage;
import com.star.databridge.dto.kafka.WriteBatchMessage;
import com.star.databridge.dto.mongo.AckConfig;
import com.star.databridge.dto.mongo.WriteRecordDetail;
import com.star.databridge.dto.sink.SinkResult;
import com.star.databridge.entity.JobConfigEntity;
import com.star.databridge.entity.JobExecutionEntity;
import com.star.databridge.entity.SyncRecordEntity;
import com.star.databridge.entity.WriteBatchExecutionEntity;
import com.star.databridge.kafka.producer.KafkaEventPublisherUtil;
import com.star.databridge.repository.JobExecutionRepository;
import com.star.databridge.repository.SyncRecordRepository;
import com.star.databridge.repository.WriteBatchExecutionRepository;

import com.star.databridge.util.ObjectMapperUtil;
import com.star.databridge.util.TracingUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Unified processor for both write-batch and write-retry flows.
 *
 * <p>Handles: load batch + config → query records → mark records PICKED →
 * run sink steps → handle ack (NONE / IMMEDIATE / POLL) → publish next batch.
 *
 * <p>Both consumers delegate here with different source statuses (READY vs RETRY)
 * and different self-publish topics; the retry topic is always the same.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class WriteBatchProcessor {

    private final SyncRecordRepository syncRecordRepository;
    private final SinkExecutorService sinkExecutorService;
    private final AckExecutorService ackExecutorService;
    private final WriteBatchService writeBatchService;
    private final JobExecutionRepository jobExecutionRepository;
    private final WriteBatchExecutionRepository writeBatchExecutionRepository;
    private final KafkaEventPublisherUtil kafkaEventPublisherUtil;
    private final SyncRecordService syncRecordService;
    private final TracingUtils tracingUtils;

    @Value("${app.kafka.topics.migration-write-retry}")
    private String writeRetryTopic;

    @Value("${app.kafka.topics.migration-write-batch-ack}")
    private String writeBatchAckTopic;

    /**
     * @param writeBatchMessage id of the write batch execution to process
     * @param sourceStatus          status to query records by ("READY" or "RETRY")
     */
    public void process(WriteBatchMessage writeBatchMessage, String sourceStatus) {
        WriteBatchExecutionEntity writeBatch = writeBatchExecutionRepository
                .findByIdAndStatus(writeBatchMessage.getWriteBatchExecutionId(), "PENDING").orElse(null);

        if (writeBatch == null) {
            log.error("[WriteBatchProcessor] no write batch found: {}", writeBatchMessage);
            return;
        }

        JobExecutionEntity jobExecution = jobExecutionRepository
                .findByIdAndStatus(writeBatch.getJobExecutionId(), "IN_PROGRESS")
                .orElse(null);

        if (jobExecution == null) {
            log.error("[WriteBatchProcessor] no job execution found: {}", writeBatch.getJobExecutionId());
            return;
        }

        JobConfigEntity jobConfig = jobExecution.getJobConfig();
        int batchSize = jobConfig.getSink().getBatchSize();
        int maxRetryCount = jobConfig.getSink().getMaxRetryCount();

        // Load the records pre-assigned to this write batch by the orchestrator.
        // For the retry flow (sourceStatus=RETRY) we fall back to a status-based query.
        List<SyncRecordEntity> records;
        if ("RETRY".equals(sourceStatus)) {
            records = syncRecordRepository.findByJobExecutionIdAndStatus(
                    writeBatch.getJobExecutionId(), sourceStatus, PageRequest.of(0, batchSize));
        } else {
            records = syncRecordRepository.findByWriteBatchExecutionId(writeBatch.getId());
        }

        if (records.isEmpty()) {
            log.warn("[WriteBatchProcessor] No records found for batch={}", writeBatch.getId());
            writeBatchService.updateBatchStatus(writeBatch, "SUCCESS", null, "No records", null);
            return;
        }

        List<String> recordIds = new ArrayList<>();
        List<String> syncIds = new ArrayList<>();

        for (SyncRecordEntity record : records) {
            recordIds.add(record.getRecordId());
            syncIds.add(record.getId());
        }

        syncRecordService.setRecordStatus(syncIds, "PICKED");
        writeBatchService.updateRecords(writeBatch, recordIds);

        JobContext jobContext = JobContext.builder()
                .jobId(jobConfig.getId())
                .jobExecutionId(writeBatch.getJobExecutionId())
                .entity(writeBatch.getEntity())
                .batchId(writeBatch.getId())
                .build();

        try {
            SinkResult sinkResult = sinkExecutorService.execute(jobConfig.getSink(), records, jobContext);
            handleAck(jobConfig, writeBatch, records, jobContext, sinkResult, maxRetryCount);
        } catch (Exception e) {
            log.error("[WriteBatchProcessor] Sink failed for batch={}", writeBatch.getId(), e);
            handleFailure(writeBatch, records, maxRetryCount, null, e.getMessage());
        }
    }

    // -------------------------------------------------------------------------
    // Ack handling
    // -------------------------------------------------------------------------

    private void handleAck(JobConfigEntity jobConfig, WriteBatchExecutionEntity writeBatch,
                           List<SyncRecordEntity> records, JobContext jobContext,
                           SinkResult sinkResult, int maxRetryCount) {
        AckConfig ackConfig = jobConfig.getAck();
        String referenceId = sinkResult != null ? sinkResult.getReferenceId() : null;

        List<String> recordIds = new ArrayList<>();
        List<String> syncIds = new ArrayList<>();

        for (SyncRecordEntity record : records) {
            recordIds.add(record.getRecordId());
            syncIds.add(record.getId());
        }

        if (ackConfig == null || ackConfig.getType() == null) {
            // No ack → all records succeed
            WriteRecordDetail recordDetail = new WriteRecordDetail(recordIds, null);
            writeBatchService.updateBatchStatus(writeBatch, "SUCCESS", referenceId, null, recordDetail);
            syncRecordService.setRecordStatus(syncIds, "SUCCESS");
            return;
        }

        switch (ackConfig.getType().toUpperCase()) {
            case "POLL" -> {
                writeBatchService.updateBatchStatus(writeBatch, "ACK_PENDING", referenceId, null, null);
                syncRecordService.setRecordStatus(syncIds, "ACK_PENDING");
                publishAckMessage(writeBatch);
            }
            case "IMMEDIATE" -> {
                AckResult ackResult = ackExecutorService.executeAck(
                        ackConfig, records, jobContext,
                        sinkResult != null ? sinkResult.getStepOutputs() : null,
                        maxRetryCount);
                
                WriteRecordDetail recordDetail = new WriteRecordDetail(ackResult.getSuccessRecords(), ackResult.getFailedRecords());
                writeBatchService.updateBatchStatus(writeBatch, "SUCCESS", referenceId, null, recordDetail);

                if (!ackResult.getFailedRecords().isEmpty()) {
                    publishWriteRetry(writeBatch);
                }
            }
            default -> {
                log.warn("[WriteBatchProcessor] Unknown ack type '{}' — treating as no-ack", ackConfig.getType());
                WriteRecordDetail recordDetail = new WriteRecordDetail(recordIds, null);
                writeBatchService.updateBatchStatus(writeBatch, "SUCCESS", referenceId, null, recordDetail);
                syncRecordService.setRecordStatus(syncIds, "SUCCESS");
            }
        }
    }

    // -------------------------------------------------------------------------
    // Failure handling
    // -------------------------------------------------------------------------

    public void handleFailure(WriteBatchExecutionEntity writeBatch, List<SyncRecordEntity> records,
                              int maxRetryCount, String referenceId, String errorMessage) {

        List<String> recordIds = records.stream().map(SyncRecordEntity::getRecordId).toList();
        WriteRecordDetail recordDetail = new WriteRecordDetail(null, recordIds);
        writeBatchService.updateBatchStatus(writeBatch, "FAILED", referenceId, errorMessage, recordDetail);
        syncRecordService.handleFailedRecords(records, maxRetryCount, errorMessage);

        boolean hasRetryRecords = records.stream().anyMatch(r -> "RETRY".equals(r.getStatus()));
        if (hasRetryRecords) {
            publishWriteRetry(writeBatch);
        }
    }

    // -------------------------------------------------------------------------
    // Publishing helpers
    // -------------------------------------------------------------------------

    public void publishWriteRetry(WriteBatchExecutionEntity writeBatch) {
        WriteBatchExecutionEntity retryBatch = writeBatchService.createBatch(
                writeBatch.getJobExecutionId(), writeBatch.getEntity(), null);

        WriteBatchMessage retryMsg = WriteBatchMessage.builder()
                .writeBatchExecutionId(retryBatch.getId())
                .build();

        kafkaEventPublisherUtil.publishEventToKafkaTopic(writeRetryTopic, writeBatch.getJobExecutionId(),
                ObjectMapperUtil.convertObjectToString(retryMsg));
        log.info("[WriteBatchProcessor] Published write-retry for entity={}", writeBatch.getEntity());
    }

    private void publishAckMessage(WriteBatchExecutionEntity writeBatch) {
        AckMessage ackMsg = AckMessage.builder()
                .writeBatchExecutionId(writeBatch.getId())
                .build();

        kafkaEventPublisherUtil.publishEventToKafkaTopic(writeBatchAckTopic, writeBatch.getJobExecutionId(),
                ObjectMapperUtil.convertObjectToString(ackMsg));
        log.info("[WriteBatchProcessor] Published ack message for batch={}", writeBatch.getId());
    }
}

package com.star.databridge.service;

import com.star.databridge.dto.mongo.StatusCount;
import com.star.databridge.dto.mongo.WriteRecordDetail;
import com.star.databridge.entity.WriteBatchExecutionEntity;
import com.star.databridge.repository.WriteBatchExecutionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class WriteBatchService {

    private final WriteBatchExecutionRepository writeBatchExecutionRepository;
    private final MongoTemplate mongoTemplate;

    public WriteBatchExecutionEntity createBatch(String jobExecutionId, String entity, List<String> recordIds) {
        WriteBatchExecutionEntity writeBatch = WriteBatchExecutionEntity.builder()
                .jobExecutionId(jobExecutionId)
                .entity(entity)
                .recordIds(recordIds)
                .build();

        return writeBatchExecutionRepository.save(writeBatch);
    }

    public void updateBatchStatus(WriteBatchExecutionEntity writeBatch, String status, String referenceId, String errorMessage, WriteRecordDetail details) {
        writeBatch.setStatus(status);
        if (referenceId != null) {
            writeBatch.setReferenceId(referenceId);
        }
        if (errorMessage != null) {
            writeBatch.setErrorMessage(errorMessage);
        }
        if (details != null) {
            writeBatch.setDetails(details);
        }
        writeBatchExecutionRepository.save(writeBatch);
    }

    public void updateRecords(WriteBatchExecutionEntity writeBatch, List<String> recordIds) {
        writeBatch.setRecordIds(recordIds);
        writeBatch.setStatus("RUNNING");
        writeBatchExecutionRepository.save(writeBatch);
    }

    /**
     * Marks every non-terminal write batch for the given job execution as FAILED.
     * Used by the abort flow to drain any batches still sitting in the queue.
     */
    public void terminalizeNonTerminal(String jobExecutionId) {
        Criteria criteria = Criteria
                .where("jobExecutionId").is(jobExecutionId)
                .and("status").nin(List.of("SUCCESS", "FAILED"));

        Query query = new Query(criteria);
        Update update = new Update().set("status", "FAILED");

        mongoTemplate.updateMulti(query, update, WriteBatchExecutionEntity.class);
    }

    public List<StatusCount> getStatusWiseCount(String jobExecutionId) {
        Aggregation agg = Aggregation.newAggregation(
                Aggregation.match(Criteria.where("jobExecutionId").is(jobExecutionId)),
                Aggregation.group("status").count().as("totalCount"),
                Aggregation.project("totalCount").and("_id").as("status") // Rename _id to status
        );

        AggregationResults<StatusCount> results = mongoTemplate.aggregate(
                agg,
                "write_batch_executions",
                StatusCount.class
        );

        return results.getMappedResults();
    }
}

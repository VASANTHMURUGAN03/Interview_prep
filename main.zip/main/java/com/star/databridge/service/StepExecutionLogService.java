package com.star.databridge.service;

import com.star.databridge.dto.kafka.StepExecutionLogMessage;
import com.star.databridge.entity.StepExecutionEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;


@Service
@RequiredArgsConstructor
public class StepExecutionLogService {
    private final MongoTemplate mongoTemplate;

    public void upsertStepExecutionLog(StepExecutionLogMessage entity) throws IllegalAccessException {
        Criteria criteria = Criteria.where("stepExecutionId").is(entity.getStepExecutionId());
        Query query = new Query(criteria);

        Update update = new Update();

        // Using reflection to iterate through fields
        for (Field field : entity.getClass().getDeclaredFields()) {
            field.setAccessible(true);
            Object value = field.get(entity);
            // Skip the ID field (used in query) and all null values
            if (value != null && !field.getName().equals("stepExecutionId")) {
                update.set(field.getName(), value);
            }
        }

        // 3. Perform Upsert
        mongoTemplate.upsert(query, update, StepExecutionEntity.class);
    }
}

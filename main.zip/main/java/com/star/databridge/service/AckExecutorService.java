package com.star.databridge.service;

import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.star.databridge.dto.ack.AckResult;
import com.star.databridge.dto.common.JobContext;
import com.star.databridge.dto.mongo.AckConfig;
import com.star.databridge.dto.mongo.StepConfig;
import com.star.databridge.enums.FlowDecision;
import com.star.databridge.dto.processor.StepExecutionContext;
import com.star.databridge.dto.processor.StepOutcome;
import com.star.databridge.entity.SyncRecordEntity;
import com.star.databridge.util.JsonUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Runs ack steps for a write batch and resolves success/failed record IDs from
 * the resulting step outputs based on the configured paths.
 *
 * <p>Step execution (rule evaluation, processor dispatch, log publishing) is
 * delegated to {@link StepService}; this service only orchestrates the loop
 * and converts the resulting step outputs into an {@link AckResult}.
 *
 * <p>Used in two flows:
 * <ul>
 *   <li><b>IMMEDIATE</b>: invoked inline after the sink completes — receives the
 *       sink step outputs as {@code initialStepOutputs}, so ack steps can reuse
 *       access tokens and other sink artifacts.</li>
 *   <li><b>POLL</b>: invoked from the ack consumer — starts with empty
 *       {@code initialStepOutputs}; the user must include any required auth steps
 *       in the ack config.</li>
 * </ul>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AckExecutorService {

    private static final String BATCH_TYPE = "ACK";

    private final StepService stepService;
    private final SyncRecordService syncRecordService;
    private final ObjectMapper objectMapper;

    /**
     * Executes ack steps and applies success/failed outcomes to records.
     *
     * @param ackConfig          ack config from job
     * @param records            records picked for this write batch
     * @param jobContext         shared execution IDs (writeBatchId in batchId)
     * @param initialStepOutputs sink step outputs (IMMEDIATE) or {@code null} (POLL)
     * @param maxRetryCount      max retries per record from sink config
     * @return {@link AckResult} with success/failed record IDs, or {@code restart=true}
     * when a rule triggers a restart (caller should republish with a delay)
     */
    public AckResult executeAck(AckConfig ackConfig, List<SyncRecordEntity> records,
                                JobContext jobContext, Map<String, JsonNode> initialStepOutputs,
                                int maxRetryCount) {

        StepExecutionContext context = StepExecutionContext.builder()
                .batchType(BATCH_TYPE)
                .jobContext(jobContext)
                .stepOutputs(new HashMap<>(
                        initialStepOutputs != null ? initialStepOutputs : Map.of()))
                .builtinVars(buildBuiltinVars(jobContext))
                .sinkRecords(records)
                .files(new ArrayList<>())
                .build();

        boolean restart = runSteps(ackConfig.getSteps(), context);

        if (restart) {
            log.info("[AckExecutor] Restart requested for batch={}", jobContext.getBatchId());
            return AckResult.builder()
                    .restart(true)
                    .successRecords(List.of())
                    .failedRecords(List.of())
                    .build();
        }

        List<String> successIds = extractSuccessRecordIds(context.getStepOutputs(), ackConfig.getSuccessRecords());
        Map<String, String> failedRecordIdMap = extractFailedRecordIds(context.getStepOutputs(), ackConfig.getFailedRecords());

        log.info("[AckExecutor] Ack resolved: success={} failed={} batch={}",
                successIds.size(), failedRecordIdMap.size(), jobContext.getBatchId());

        applyAckOutcome(jobContext.getJobExecutionId(), successIds, failedRecordIdMap, maxRetryCount);

        return AckResult.builder()
                .restart(false)
                .successRecords(successIds)
                .failedRecords(new ArrayList<>(failedRecordIdMap.keySet()))
                .build();
    }

    // -------------------------------------------------------------------------
    // Step loop — delegates per-step work to StepService
    // -------------------------------------------------------------------------

    /**
     * Runs steps in order, honoring {@link FlowDecision} values returned by
     * {@link StepService}. Returns {@code true} if a restart was requested.
     */
    private boolean runSteps(List<StepConfig> steps, StepExecutionContext stepContext) {
        if (steps == null) return false;

        int stepNo = 0;
        while (stepNo < steps.size()) {
            StepOutcome outcome = stepService.executeStep(steps.get(stepNo), stepContext);
            switch (outcome.getDecision()) {
                case NEXT -> stepNo++;
                case SKIP_NEXT -> stepNo += 2;
                case RESTART -> {
                    return true;
                }
            }
        }
        return false;
    }

    // -------------------------------------------------------------------------
    // Built-in variables passed into every ack step's ProcessContext
    // -------------------------------------------------------------------------

    private Map<String, String> buildBuiltinVars(JobContext jobContext) {
        return Map.of(
                "ENTITY_TYPE", safe(jobContext.getEntity()),
                "REFERENCE_ID", safe(jobContext.getBatchRefId()),
                "BATCH_ID", safe(jobContext.getBatchId()),
                "JOB_EXECUTION_ID", safe(jobContext.getJobExecutionId())
        );
    }

    private String safe(String value) {
        return value != null ? value : "";
    }

    // -------------------------------------------------------------------------
    // ID extraction
    // -------------------------------------------------------------------------

    /**
     * Extracts a list of successful record IDs from step outputs using a path like
     * {@code "fetchSuccessfulRecords.recordIds"}.
     */
    private List<String> extractSuccessRecordIds(Map<String, JsonNode> stepOutputs, String path) {
        if (path == null) {
            return List.of();
        }

        String[] parts = path.split("\\.", 2);
        JsonNode stepOutput = stepOutputs.get(parts[0]);
        if (stepOutput == null) {
            return List.of();
        }

        JsonNode idsNode = parts.length == 1 ? stepOutput : JsonUtil.safelyExtractData(stepOutput, parts[1]);
        if (idsNode == null || !idsNode.isArray()) {
            return List.of();
        }

        return objectMapper.convertValue(idsNode, new TypeReference<>() {
        });
    }

    /**
     * Extracts a map of failed record IDs → error messages from step outputs
     * using a path like {@code "fetchFailedRecords.recordIds"}.
     */
    private Map<String, String> extractFailedRecordIds(Map<String, JsonNode> stepOutputs, String path) {
        if (path == null) {
            return Map.of();
        }

        String[] parts = path.split("\\.", 2);
        JsonNode stepOutput = stepOutputs.get(parts[0]);
        if (stepOutput == null) {
            return Map.of();
        }

        JsonNode idsNode = parts.length == 1 ? stepOutput : JsonUtil.safelyExtractData(stepOutput, parts[1]);
        if (idsNode == null || !idsNode.isObject()) {
            return Map.of();
        }

        return objectMapper.convertValue(idsNode, new TypeReference<>() {
        });
    }

    /**
     * Marks records whose IDs are in {@code successIds} as COMPLETED, and the rest
     * (treated as failed) via {@link SyncRecordService#handleFailedRecords(List, int, Map)}.
     */
    public void applyAckOutcome(String jobExecutionId, List<String> successIds,
                                Map<String, String> failedIds, int maxRetryCount) {
        // mark successful
        if (!successIds.isEmpty()) {
            syncRecordService.updateRecordStatus(jobExecutionId, successIds, "SUCCESS");
        }

        // failed records
        if (!failedIds.isEmpty()) {
            List<String> failedRecordIds = new ArrayList<>(failedIds.keySet());
            List<SyncRecordEntity> failedRecords = syncRecordService.findByRecordIdAndJobId(jobExecutionId, failedRecordIds);
            syncRecordService.handleFailedRecords(failedRecords, maxRetryCount, failedIds);
        }

    }
}

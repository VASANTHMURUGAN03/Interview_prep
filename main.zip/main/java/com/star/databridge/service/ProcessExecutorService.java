package com.star.databridge.service;

import com.star.databridge.dto.common.JobContext;
import com.star.databridge.dto.mongo.StepConfig;
import com.star.databridge.dto.processor.StepExecutionContext;
import com.star.databridge.dto.processor.StepOutcome;
import com.star.databridge.entity.SyncRecordEntity;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import tools.jackson.databind.JsonNode;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProcessExecutorService {

    private static final String BATCH_TYPE = "READ";

    private final StepService stepService;
    private final SyncRecordService syncRecordService;

    public List<SyncRecordEntity> execute(List<StepConfig> steps, JsonNode readData, JobContext jobContext) {
        Map<String, JsonNode> stepOutputs = new HashMap<>();
        stepOutputs.put("read", readData);

        StepExecutionContext context = StepExecutionContext.builder()
                .batchType(BATCH_TYPE)
                .jobContext(jobContext)
                .stepOutputs(stepOutputs)
                .builtinVars(Map.of())
                .build();

        JsonNode currentData = readData;

        int stepNo = 0;
        while (stepNo < steps.size()) {
            StepOutcome outcome = stepService.executeStep(steps.get(stepNo), context);

            // If the resolved step asked to promote its result to the data flow, honor it.
            if (outcome.getResult() != null && isUpdateDataFlow(outcome.getStepParams())) {
                currentData = outcome.getResult();
            }

            switch (outcome.getDecision()) {
                case NEXT -> stepNo++;
                case SKIP_NEXT -> stepNo += 2;
                case RESTART -> throw new IllegalStateException(
                        "restartSteps effect is not supported in process flow");
            }
        }

        return syncRecordService.insertBatchedSyncRecords(currentData,
                jobContext.getJobExecutionId(), jobContext.getEntity(), jobContext.getBatchId());
    }

    private boolean isUpdateDataFlow(Map<String, Object> params) {
        if (params == null) return false;
        Object flag = params.get("updateDataFlow");
        return flag instanceof Boolean b && b;
    }
}

package com.star.databridge.service;

import tools.jackson.databind.JsonNode;
import com.star.databridge.dto.mongo.Condition;
import com.star.databridge.dto.mongo.Effect;
import com.star.databridge.dto.mongo.Rule;
import com.star.databridge.util.DataUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Evaluates rule conditions against a {@link JsonNode} source.
 *
 * <p>A rule fires when ALL of its conditions hold (AND semantics). The first matching
 * rule's {@link Effect} wins; if no rules match, returns {@code null} so the caller
 * applies its default behavior.
 *
 * <p>Supported operators (case-insensitive): {@code equals}, {@code notEquals},
 * {@code greaterThan}, {@code lessThan}, {@code greaterThanOrEqualsTo},
 * {@code lessThanOrEqualsTo}, {@code in}, {@code notIn}.
 */
@Slf4j
@Service
public class RuleService {

    public Effect evaluate(List<Rule> rules, Map<String, JsonNode> context) {
        if (rules == null || rules.isEmpty() || context == null) {
            return null;
        }

        for (Rule rule : rules) {
            if (matches(rule.getConditions(), context)) {
                return rule.getEffect();
            }
        }

        return null;
    }

    private boolean matches(List<Condition> conditions, Map<String, JsonNode> context) {
        if (conditions == null || conditions.isEmpty()) return true;
        return conditions.stream().allMatch(c -> evaluateCondition(c, context));
    }

    private boolean evaluateCondition(Condition condition, Map<String, JsonNode> context) {
        JsonNode actual = DataUtil.resolveFromContext(condition.getKey(), context);
        Object expected = condition.getValue();

        return switch (condition.getOperator()) {
            case "equals" -> equals(actual, expected);
            case "notEquals" -> !equals(actual, expected);
            case "greaterThan" -> compare(actual, expected) > 0;
            case "lessThan" -> compare(actual, expected) < 0;
            case "greaterThanOrEqualsTo" -> compare(actual, expected) >= 0;
            case "lessThanOrEqualsTo" -> compare(actual, expected) <= 0;
            case "in" -> isIn(actual, expected);
            case "notIn" -> !isIn(actual, expected);
            default -> throw new IllegalArgumentException(
                    "Unknown rule operator: " + condition.getOperator());
        };
    }

    // -------------------------------------------------------------------------
    // Operator helpers
    // -------------------------------------------------------------------------

    private boolean equals(JsonNode actual, Object expected) {
        if (actual == null || actual.isMissingNode() || actual.isNull()) {
            return expected == null;
        }
        return Objects.equals(actual.asString(), String.valueOf(expected));
    }

    private int compare(JsonNode actual, Object expected) {
        if (actual == null || actual.isMissingNode() || actual.isNull() || expected == null) {
            throw new IllegalArgumentException("Cannot compare null values");
        }
        BigDecimal a = new BigDecimal(actual.asString());
        BigDecimal b = new BigDecimal(String.valueOf(expected));
        return a.compareTo(b);
    }

    private boolean isIn(JsonNode actual, Object expected) {
        if (actual == null || actual.isMissingNode() || actual.isNull()) return false;
        if (!(expected instanceof Collection<?> values)) {
            throw new IllegalArgumentException("'in' / 'notIn' requires array value");
        }
        String actualStr = actual.asString();
        return values.stream()
                .map(String::valueOf)
                .anyMatch(actualStr::equals);
    }
}

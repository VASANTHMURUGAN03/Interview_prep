package com.star.databridge.service;

import com.star.databridge.common.apiHelper.DmsApiHelper;
import com.star.databridge.common.apiHelper.NotificationApiHelper;
import com.star.databridge.dto.mongo.ReportConfig;
import com.star.databridge.dto.mongo.StatusCount;
import com.star.databridge.dto.mongo.SyncRecordSummary;
import com.star.databridge.repository.JobExecutionRepository;
import com.star.databridge.repository.SyncRecordRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import com.star.databridge.dto.response.DmsUploadApiResponse;
import com.star.databridge.dto.response.NotificationSendEmailApiResponse;
import com.star.databridge.processor.impl.JsonToCsvProcessor;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReportService {

    private static final String[] DEFAULT_COLUMNS = {
            "Record ID",  "Status",  "Error Message"
    };
    private final SyncRecordRepository syncRecordRepository;
    private final DmsApiHelper dmsApiHelper;
    private final NotificationApiHelper notificationApiHelper;
    private final JobExecutionRepository jobExecutionRepository;
    private final JsonToCsvProcessor jsonToCsvProcessor;

    public void sendReport(String jobExecutionId, ReportConfig config, List<StatusCount> recordStats) {
        log.info("[Report] Sending report for jobExecutionId={}", jobExecutionId);

        List<SyncRecordSummary> records = syncRecordRepository.findAllByJobExecutionId(jobExecutionId);
        String base64Csv = encodeCsv(records, DEFAULT_COLUMNS);
        log.info("[Report] CSV built ({} rows), encoded to Base64", records.size());

        // 1. Upload to DMS
        DmsUploadApiResponse dmsUploadResponse = dmsApiHelper.uploadReport(base64Csv);
        log.info("[Report] DMS upload response: {}", dmsUploadResponse);

        String documentId = Optional.ofNullable(dmsUploadResponse)
                .map(DmsUploadApiResponse::getData)
                .map(DmsUploadApiResponse.Data::getDocumentId)
                .orElse(null);

        jobExecutionRepository.findById(jobExecutionId).ifPresent(entity -> {
            entity.setJobReportDocId(documentId);
            jobExecutionRepository.save(entity);
            log.info("[Report] Saved docId={} to jobExecution={}", documentId, jobExecutionId);
        });

        // 2. Notify by email
        NotificationSendEmailApiResponse notificationResponse = notificationApiHelper.sendNotificationMail(documentId, config, recordStats);
        log.info("[Report] Notification response: {}", notificationResponse);
    }

    private String encodeCsv(List<SyncRecordSummary> records, String[] columns) {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             OutputStream base64Os = Base64.getEncoder().wrap(baos);
             Writer writer = new OutputStreamWriter(base64Os, StandardCharsets.UTF_8);
             BufferedWriter bw = new BufferedWriter(writer)) {

            // header
            bw.write(String.join(",", columns));
            bw.newLine();

            // rows
            for (SyncRecordSummary r : records) {
                bw.write(jsonToCsvProcessor.escapeCsv(r.getRecordId()));
                bw.write(",");
                bw.write(jsonToCsvProcessor.escapeCsv(r.getStatus()));
                bw.write(",");
                bw.write(jsonToCsvProcessor.escapeCsv(r.getErrorMessage() != null ? r.getErrorMessage() : ""));
                bw.newLine();
            }
            bw.flush();
            return baos.toString(StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("Failed to encode CSV", e);
        }
    }

}
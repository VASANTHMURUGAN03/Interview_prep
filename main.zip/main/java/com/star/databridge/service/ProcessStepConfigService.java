package com.star.databridge.service;

import com.star.databridge.dto.request.UpsertProcessStepConfigDto;
import com.star.databridge.entity.ProcessStepEntity;
import com.star.databridge.repository.ProcessStepRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.time.Instant;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProcessStepConfigService {
    private final MongoTemplate mongoTemplate;
    private final ProcessStepRepository processStepRepository;

    public ProcessStepEntity upsertConfig(UpsertProcessStepConfigDto upsertProcessStepConfig) {
        ProcessStepEntity processStepEntity = createProcessStepEntity(upsertProcessStepConfig);
        return upsertConfig(upsertProcessStepConfig.getName(), processStepEntity);
    }

    private ProcessStepEntity createProcessStepEntity(UpsertProcessStepConfigDto upsertJobConfigDto) {
        ProcessStepEntity configEntity = new ProcessStepEntity();
        configEntity.setName(upsertJobConfigDto.getName());
        configEntity.setType(upsertJobConfigDto.getType());
        configEntity.setParams(upsertJobConfigDto.getParams());
        configEntity.setActive(true);

        return configEntity;
    }

    private ProcessStepEntity upsertConfig(String configName, ProcessStepEntity processStepEntity) {
        Query query = new Query(Criteria.where("name").is(configName));

        Update update = new Update();

        for (Field field : processStepEntity.getClass().getDeclaredFields()) {
            field.setAccessible(true);
            String fieldName = field.getName();
            try {
                Object value = field.get(processStepEntity);
                if (value != null &&
                    !fieldName.equals("name") &&
                    !fieldName.equals("createdAt") &&
                    !fieldName.equals("updatedAt")) {

                    update.set(field.getName(), value);
                }
            } catch (IllegalAccessException e) {
                log.error("Error in upsert job config name = {}, field = {}, message = {}",
                        configName, field, e.getMessage());
            }
        }

        update.set("updatedAt", Instant.now());
        update.setOnInsert("createdAt", Instant.now());

        FindAndModifyOptions options = new FindAndModifyOptions().upsert(true).returnNew(true);

        return mongoTemplate.findAndModify(query, update, options, ProcessStepEntity.class);
    }

    public List<ProcessStepEntity> getConfigs(Integer limit, Integer pageNumber) {
        int intLimit = limit != null ? Math.min(limit, 10) : 10;
        int offset = pageNumber != null ? pageNumber : 0;

        Pageable pageable = PageRequest.of(offset, intLimit, Sort.by("updatedAt").descending());

        return processStepRepository.findAll(pageable).getContent();
    }

    public ProcessStepEntity getConfigByName(String name) {
        return processStepRepository.findByName(name).orElse(null);
    }

    public List<ProcessStepEntity> getConfigsByNames(List<String> names) {
        return processStepRepository.findByNameIn(names);
    }
}

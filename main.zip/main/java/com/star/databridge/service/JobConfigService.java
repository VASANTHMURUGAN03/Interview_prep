package com.star.databridge.service;

import tools.jackson.databind.ObjectMapper;
import com.star.databridge.dto.mongo.AckConfig;
import com.star.databridge.dto.mongo.SinkConfig;
import com.star.databridge.dto.mongo.StepConfig;
import com.star.databridge.dto.request.UpsertJobConfigDto;
import com.star.databridge.entity.JobConfigEntity;
import com.star.databridge.entity.ProcessStepEntity;
import com.star.databridge.repository.JobConfigRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class JobConfigService {
    private final MongoTemplate mongoTemplate;
    private final JobConfigRepository jobConfigRepository;
    private final ProcessStepConfigService processStepConfigService;
    private final ObjectMapper objectMapper;

    public JobConfigEntity upsertConfig(UpsertJobConfigDto upsertJobConfigDto) {
        JobConfigEntity jobConfigEntity = createJobConfigEntity(upsertJobConfigDto);
        return upsertConfig(upsertJobConfigDto.getName(), jobConfigEntity);
    }

    private JobConfigEntity createJobConfigEntity(UpsertJobConfigDto upsertJobConfigDto) {
        JobConfigEntity jobConfigEntity = new JobConfigEntity();
        jobConfigEntity.setName(upsertJobConfigDto.getName());
        jobConfigEntity.setEntity(upsertJobConfigDto.getEntity());
        jobConfigEntity.setStrategy(upsertJobConfigDto.getStrategy());
        jobConfigEntity.setTrigger(upsertJobConfigDto.getTrigger());
        jobConfigEntity.setRead(upsertJobConfigDto.getRead());
        jobConfigEntity.setProcess(upsertJobConfigDto.getProcess());
        jobConfigEntity.setSink(upsertJobConfigDto.getSink());
        jobConfigEntity.setAck(upsertJobConfigDto.getAck());
        jobConfigEntity.setPostComplete(upsertJobConfigDto.getPostComplete());
        jobConfigEntity.setActive(true);

        return jobConfigEntity;
    }

    private JobConfigEntity upsertConfig(String configName, JobConfigEntity jobConfigEntity) {
        Query query = new Query(Criteria.where("name").is(configName));

        Update update = new Update();

        for (Field field : jobConfigEntity.getClass().getDeclaredFields()) {
            field.setAccessible(true);
            String fieldName = field.getName();
            try {
                Object value = field.get(jobConfigEntity);
                if ((fieldName.equals("ack") || fieldName.equals("postComplete")) && value == null) {
                    update.set(field.getName(), value);
                    continue;
                }

                if (value != null &&
                    !fieldName.equals("name") &&
                    !fieldName.equals("createdAt") &&
                    !fieldName.equals("updatedAt")) {
                    update.set(field.getName(), value);
                }
            } catch (IllegalAccessException e) {
                log.error("Error in upsert job config name = {}, field = {}, message = {}",
                        configName, field, e.getMessage());
            }
        }

        update.set("updatedAt", Instant.now());
        update.setOnInsert("createdAt", Instant.now());

        FindAndModifyOptions options = new FindAndModifyOptions().upsert(true).returnNew(true);

        return mongoTemplate.findAndModify(query, update, options, JobConfigEntity.class);
    }

    public List<JobConfigEntity> getConfigs(Integer limit, Integer pageNumber) {
        int intLimit = limit != null ? Math.min(limit, 10) : 10;
        int offset = pageNumber != null ? pageNumber : 0;

        Pageable pageable = PageRequest.of(offset, intLimit, Sort.by("updatedAt").descending());

        return jobConfigRepository.findAll(pageable).getContent();
    }

    public JobConfigEntity getConfigByName(String name) {
        JobConfigEntity jobConfig = jobConfigRepository.findByName(name).orElse(null);
        if (jobConfig == null) {
            return null;
        }

        List<String> stepNames = extractStepNames(jobConfig);
        List<ProcessStepEntity> processSteps = processStepConfigService.getConfigsByNames(stepNames);
        return addStepDetails(jobConfig, processSteps);
    }

    public JobConfigEntity deleteConfigByName(String name) {
        JobConfigEntity config = new JobConfigEntity();
        config.setName(name);
        config.setActive(false);
        return upsertConfig(config.getName(), config);
    }

    private List<String> extractStepNames(JobConfigEntity config) {
        List<String> stepNames = new ArrayList<>();

        if (config.getProcess() != null) {
            config.getProcess().stream().map(StepConfig::getName).forEach(stepNames::add);
        }

        Optional<List<StepConfig>> sinkSteps = Optional.ofNullable(config.getSink()).map(SinkConfig::getSteps);
        sinkSteps.ifPresent(stepConfigs ->
                stepConfigs.stream().map(StepConfig::getName).forEach(stepNames::add)
        );

        Optional<List<StepConfig>> ackSteps = Optional.ofNullable(config.getAck()).map(AckConfig::getSteps);
        ackSteps.ifPresent(stepConfigs ->
                stepConfigs.stream().map(StepConfig::getName).forEach(stepNames::add)
        );

        return stepNames;
    }

    private JobConfigEntity addStepDetails(JobConfigEntity config, List<ProcessStepEntity> steps) {
        if (steps == null || steps.isEmpty()) {
            return null;
        }

        JobConfigEntity clonedConfig = objectMapper.convertValue(config, JobConfigEntity.class);

        Map<String, ProcessStepEntity> stepLookup = steps.stream()
                .collect(Collectors.toMap(
                        ProcessStepEntity::getName,
                        step -> step,
                        (existing, replacement) -> existing
                ));


        if (clonedConfig.getProcess() != null) {
            clonedConfig.setProcess(getStepConfigs(clonedConfig.getProcess(), stepLookup));
        }

        Optional<List<StepConfig>> sinkSteps = Optional.ofNullable(clonedConfig.getSink()).map(SinkConfig::getSteps);
        sinkSteps.ifPresent(stepConfigs ->
                clonedConfig.getSink().setSteps(getStepConfigs(stepConfigs, stepLookup))
        );

        Optional<List<StepConfig>> ackSteps = Optional.ofNullable(clonedConfig.getAck()).map(AckConfig::getSteps);
        ackSteps.ifPresent(stepConfigs ->
                clonedConfig.getAck().setSteps(getStepConfigs(stepConfigs, stepLookup))
        );

        return clonedConfig;
    }

    private List<StepConfig> getStepConfigs(List<StepConfig> steps, Map<String, ProcessStepEntity> stepLookup) {
        return steps.stream()
                .map(stepConfig -> {
                    ProcessStepEntity matchingStep = stepLookup.get(stepConfig.getName());
                    if (matchingStep == null) {
                        return stepConfig;
                    }

                    return StepConfig.builder()
                            .name(stepConfig.getName())
                            .type(matchingStep.getType())
                            .params(matchingStep.getParams())
                            .preExecution(stepConfig.getPreExecution())
                            .postExecution(stepConfig.getPostExecution())
                            .build();
                }).toList();
    }
}

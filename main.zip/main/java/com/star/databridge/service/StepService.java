package com.star.databridge.service;

import tools.jackson.databind.JsonNode;
import com.star.databridge.dto.mongo.Effect;
import com.star.databridge.dto.mongo.Rule;
import com.star.databridge.dto.mongo.StepConfig;
import com.star.databridge.enums.FlowDecision;
import com.star.databridge.dto.processor.ProcessContext;
import com.star.databridge.dto.processor.ProcessStepConfig;
import com.star.databridge.dto.processor.StepExecutionContext;
import com.star.databridge.dto.processor.StepOutcome;
import com.star.databridge.entity.ProcessStepEntity;
import com.star.databridge.processor.DataProcessor;
import com.star.databridge.processor.ProcessorFactory;
import com.star.databridge.repository.ProcessStepRepository;
import com.star.databridge.util.CommonUtil;
import com.star.databridge.util.KafkaUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

/**
 * Shared step-execution engine used by process, sink, and ack executors.
 *
 * <p>Each call to {@link #executeStep} performs the full per-step pipeline:
 * <ol>
 *   <li>Resolve the {@link ProcessStepEntity} by name — return a no-op outcome if missing.</li>
 *   <li>Evaluate {@code preExecution} rules against the accumulated step outputs.</li>
 *   <li>If pre-rule decides {@code skip}, return without running the step.</li>
 *   <li>Otherwise, publish RUNNING log, invoke the processor, store the result in
 *       {@code stepOutputs} under the step name, publish SUCCESS/FAILED log.</li>
 *   <li>Evaluate {@code postExecution} rules against the updated step outputs and
 *       return the resulting {@link FlowDecision}.</li>
 * </ol>
 *
 * <p>{@code restartSteps} is only valid in the ACK flow — any other {@code batchType}
 * triggering a restart will throw an {@link IllegalStateException}.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class StepService {

    private final ProcessStepRepository processStepRepository;
    private final ProcessorFactory processorFactory;
    private final KafkaUtil kafkaUtil;
    private final RuleService ruleService;
    private final CaffeineCacheService caffeineCacheService;

    private static final String BATCH_TYPE_ACK = "ACK";

    public StepOutcome executeStep(StepConfig stepRef, StepExecutionContext stepContext) {
        ProcessStepEntity stepEntity = processStepRepository
                .findByNameAndActive(stepRef.getName(), true)
                .orElse(null);

        if (stepEntity == null) {
            log.warn("[StepService] Skipping step '{}': not found", stepRef.getName());
            return StepOutcome.builder().decision(FlowDecision.NEXT).build();
        }

        // Pre-execution rule evaluation
        PreDecision preDecision = evaluatePre(stepRef.getPreExecution(), stepContext);
        if (preDecision == PreDecision.SKIP_CURRENT) {
            log.info("[StepService] Skipping step '{}' due to preExecution rule", stepEntity.getName());
            return StepOutcome.builder()
                    .decision(FlowDecision.NEXT)
                    .stepParams(stepEntity.getParams())
                    .build();
        }
        if (preDecision == PreDecision.RESTART) {
            validateRestartAllowed(stepContext);
            return StepOutcome.builder()
                    .decision(FlowDecision.RESTART)
                    .stepParams(stepEntity.getParams())
                    .build();
        }

        log.info("[StepService] Executing step '{}' (type={})", stepEntity.getName(), stepEntity.getType());
        JsonNode result = runStep(stepEntity, stepContext);

        // Post-execution rule evaluation
        FlowDecision postDecision = evaluatePost(stepRef.getPostExecution(), stepContext);
        if (postDecision == FlowDecision.RESTART) {
            validateRestartAllowed(stepContext);
        }

        return StepOutcome.builder()
                .result(result)
                .decision(postDecision)
                .stepParams(stepEntity.getParams())
                .build();
    }

    // -------------------------------------------------------------------------
    // Step invocation
    // -------------------------------------------------------------------------

    private JsonNode runStep(ProcessStepEntity stepEntity, StepExecutionContext stepContext) {
        String jobExecutionId = stepContext.getJobContext().getJobExecutionId();
        String batchId = stepContext.getJobContext().getBatchId();
        String stepId = CommonUtil.generateUniqueId();
        String cacheKey = caffeineCacheService.buildStepKey(jobExecutionId,stepEntity.getName());
        // Caffeine cache check
        if (stepEntity.getCache() != null) {
            JsonNode cached = caffeineCacheService.get(cacheKey);
            if (cached != null) {
                stepContext.getStepOutputs().put(stepEntity.getName(), cached);
                return cached;
            }
        }

        kafkaUtil.publishStepExecutionLog(jobExecutionId, batchId, stepContext.getBatchType(),
                stepEntity.getName(), stepEntity.getType(), "RUNNING", stepId, null);

        try {
            ProcessContext processContext = buildProcessContext(stepEntity, stepContext);
            DataProcessor processor = processorFactory.getProcessor(stepEntity.getType());
            JsonNode result = processor.process(processContext);

            if (result != null) {
                stepContext.getStepOutputs().put(stepEntity.getName(), result);
                if (stepEntity.getCache() != null) {
                    caffeineCacheService.put(cacheKey, result, stepEntity.getCache().getExpiryTime());
                }
            }

            kafkaUtil.publishStepExecutionLog(jobExecutionId, batchId, stepContext.getBatchType(),
                    stepEntity.getName(), stepEntity.getType(), "SUCCESS", stepId, null);

            return result;
        } catch (Exception e) {
            log.error("StepService.runStep - exception: {}", e.getMessage(), e);
            kafkaUtil.publishStepExecutionLog(jobExecutionId, batchId, stepContext.getBatchType(),
                    stepEntity.getName(), stepEntity.getType(), "FAILED", stepId, e.getMessage());
            throw e;
        }
    }

    private ProcessContext buildProcessContext(ProcessStepEntity stepEntity, StepExecutionContext context) {
        return ProcessContext.builder()
                .stepConfig(toProcessStepConfig(stepEntity))
                .jobContext(context.getJobContext())
                .stepOutputs(context.getStepOutputs())
                .builtinVars(context.getBuiltinVars() != null ? context.getBuiltinVars() : Collections.emptyMap())
                .sinkRecords(context.getSinkRecords())
                .files(context.getFiles())
                .build();
    }

    private ProcessStepConfig toProcessStepConfig(ProcessStepEntity entity) {
        return ProcessStepConfig.builder()
                .id(entity.getId())
                .name(entity.getName())
                .type(entity.getType())
                .params(entity.getParams())
                .build();
    }

    // -------------------------------------------------------------------------
    // Rule evaluation
    // -------------------------------------------------------------------------

    private PreDecision evaluatePre(List<Rule> rules, StepExecutionContext stepContext) {
        Effect effect = ruleService.evaluate(rules, stepContext.getStepOutputs());
        if (effect == null || effect.getStep() == null) {
            return PreDecision.EXECUTE;
        }

        return switch (effect.getStep()) {
            case "execute" -> PreDecision.EXECUTE;
            case "skip" -> PreDecision.SKIP_CURRENT;
            case "restartSteps" -> PreDecision.RESTART;
            case "next" -> throw new IllegalArgumentException(
                    "Invalid preExecution effect 'next' — valid effects: execute, skip, restartSteps");
            default -> throw new IllegalArgumentException(
                    "Unknown preExecution effect '" + effect.getStep()
                            + "' — valid effects: execute, skip, restartSteps");
        };
    }

    private FlowDecision evaluatePost(List<Rule> rules, StepExecutionContext context) {
        Effect effect = ruleService.evaluate(rules, context.getStepOutputs());
        if (effect == null || effect.getStep() == null) {
            return FlowDecision.NEXT;
        }

        return switch (effect.getStep()) {
            case "next" -> FlowDecision.NEXT;
            case "skip" -> FlowDecision.SKIP_NEXT;
            case "restartSteps" -> FlowDecision.RESTART;
            case "execute" -> throw new IllegalArgumentException(
                    "Invalid postExecution effect 'execute' — valid effects: next, skip, restartSteps");
            default -> throw new IllegalArgumentException(
                    "Unknown postExecution effect '" + effect.getStep()
                            + "' — valid effects: next, skip, restartSteps");
        };
    }

    private void validateRestartAllowed(StepExecutionContext context) {
        if (!BATCH_TYPE_ACK.equalsIgnoreCase(context.getBatchType())) {
            throw new IllegalStateException(
                    "restartSteps effect is only supported in the ACK flow — batchType="
                            + context.getBatchType());
        }
    }

    /** Internal — pre-execution produces one of these three outcomes. */
    private enum PreDecision {
        EXECUTE, SKIP_CURRENT, RESTART
    }
}

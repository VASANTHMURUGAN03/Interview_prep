package com.star.databridge.service;

import com.star.databridge.entity.JobConfigEntity;
import com.star.databridge.repository.JobConfigRepository;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.core.LockConfiguration;
import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.core.SimpleLock;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.TimeZone;

/**
 * Dynamically registers cron-based scheduled tasks for all active job configs
 * with {@code trigger.type = "SCHEDULER"}.
 *
 * <p>Each cron trigger is wrapped with a ShedLock distributed lock so that in a
 * multi-pod deployment, only one instance executes the job at any given fire time.
 *
 * <p>Tasks are registered once on startup via {@link #registerScheduledJobs()}.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class JobSchedulerService {

    private final TaskScheduler taskScheduler;
    private final LockProvider lockProvider;
    private final JobConfigRepository jobConfigRepository;
    private final JobExecutionService jobExecutionService;

    @PostConstruct
    public void registerScheduledJobs() {
        List<JobConfigEntity> scheduledJobs = jobConfigRepository
                .findByTriggerTypeAndActive("SCHEDULER", true);

        log.info("[JobScheduler] Found {} active SCHEDULER jobs to register", scheduledJobs.size());

        for (JobConfigEntity job : scheduledJobs) {
            String cron = job.getTrigger().getCron();
            CronTrigger trigger = new CronTrigger(cron, TimeZone.getTimeZone("IST"));

            taskScheduler.schedule(() -> executeWithLock(job), trigger);

            log.info("[JobScheduler] Registered cron '{}' for job '{}'", cron, job.getName());
        }
    }

    /**
     * Acquires a distributed lock keyed by job name and, if acquired, triggers the job.
     * If another pod already holds the lock, the execution is silently skipped.
     */
    private void executeWithLock(JobConfigEntity job) {
        String lockName = "scheduler-job-" + job.getName();

        LockConfiguration lockConfig = new LockConfiguration(
                Instant.now(),
                lockName,
                Duration.ofMinutes(30),   // lockAtMostFor — safety upper bound
                Duration.ofMinutes(1)     // lockAtLeastFor — prevents rapid re-fire
        );

        Optional<SimpleLock> lock = lockProvider.lock(lockConfig);

        if (lock.isEmpty()) {
            log.debug("[JobScheduler] Lock not acquired for '{}' — another pod is handling it", job.getName());
            return;
        }

        try {
            log.info("[JobScheduler] Triggering scheduled job '{}'", job.getName());
            jobExecutionService.triggerJob(job.getName());
        } catch (Exception e) {
            log.error("[JobScheduler] Failed to trigger job '{}'", job.getName(), e);
        } finally {
            lock.get().unlock();
        }
    }
}

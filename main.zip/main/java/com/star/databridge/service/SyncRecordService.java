package com.star.databridge.service;

import com.mongodb.client.model.InsertManyOptions;
import tools.jackson.databind.JsonNode;
import com.mongodb.client.result.UpdateResult;
import com.star.databridge.dto.mongo.StatusCount;
import com.star.databridge.entity.SyncRecordEntity;
import com.star.databridge.repository.SyncRecordRepository;
import com.star.databridge.util.ObjectMapperUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class SyncRecordService {
    private final MongoTemplate mongoTemplate;
    private final SyncRecordRepository syncRecordRepository;

    public void updateRecordStatus(String jobExecutionId, List<String> recordIds, String status) {
        Criteria criteria = Criteria
                .where("jobExecutionId").is(jobExecutionId)
                .and("recordId").in(recordIds);

        Query query = new Query(criteria);
        Update update = new Update().set("status", status);

        mongoTemplate.updateMulti(query, update, SyncRecordEntity.class);
    }

    public void updateRecordStatus(String jobExecutionId, String status) {
        Criteria criteria = Criteria
                .where("jobExecutionId").is(jobExecutionId);

        Query query = new Query(criteria);
        Update update = new Update().set("status", status);

        mongoTemplate.updateMulti(query, update, SyncRecordEntity.class);
    }

    /**
     * Marks every non-terminal sync record for the given job execution as FAILED.
     * Used by the abort flow to stop the completion check from waiting on them.
     */
    public void terminalizeNonTerminal(String jobExecutionId, String errorMessage) {
        Criteria criteria = Criteria
                .where("jobExecutionId").is(jobExecutionId)
                .and("status").nin(List.of("SUCCESS", "FAILED"));

        Query query = new Query(criteria);
        Update update = new Update()
                .set("status", "FAILED")
                .set("errorMessage", errorMessage);

        mongoTemplate.updateMulti(query, update, SyncRecordEntity.class);
    }

    public List<SyncRecordEntity> findByRecordIdAndJobId(String jobExecutionId, List<String> recordIds) {
        Criteria criteria = Criteria
                .where("jobExecutionId").is(jobExecutionId)
                .and("recordId").in(recordIds);

        Query query = new Query(criteria);
        return mongoTemplate.find(query, SyncRecordEntity.class);
    }

    public void handleFailedRecords(List<SyncRecordEntity> records, int maxRetryCount, Map<String, String> failedRecordIdMap) {
        records.forEach(record -> {
            int retryCount = record.getRetryCount() != null ? record.getRetryCount() : 0;
            String errorMessage = failedRecordIdMap.get(record.getRecordId());
            record.setErrorMessage(errorMessage);
            if (retryCount < maxRetryCount) {
                record.setStatus("RETRY");
                record.setRetryCount(retryCount + 1);
            } else {
                record.setStatus("FAILED");
            }
        });
        syncRecordRepository.saveAll(records);
    }


    public void handleFailedRecords(List<SyncRecordEntity> records, int maxRetryCount, String errorMessage) {
        records.forEach(record -> {
            int retryCount = record.getRetryCount() != null ? record.getRetryCount() : 0;
            record.setErrorMessage(errorMessage);
            if (retryCount < maxRetryCount) {
                record.setStatus("RETRY");
                record.setRetryCount(retryCount + 1);
            } else {
                record.setStatus("FAILED");
            }
        });
        syncRecordRepository.saveAll(records);
    }

    public List<SyncRecordEntity> insertBatchedSyncRecords(JsonNode jsonNodeArray,
                                                           String jobExecutionId,
                                                           String entity,
                                                           String batchId) {
        if (!jsonNodeArray.isArray() || jsonNodeArray.isEmpty()) {
            log.warn("[JobExecution] No records to persist for batch={}", batchId);
            return List.of();
        }

        List<SyncRecordEntity> entities = new ArrayList<>();

        for (JsonNode node : jsonNodeArray) {
            String recordMap = ObjectMapperUtil.convertObjectToString(node.get("record"));

            SyncRecordEntity syncRecord = SyncRecordEntity.builder()
                    .jobExecutionId(jobExecutionId)
                    .entity(entity)
                    .recordId(node.get("recordId").asString())
                    .record(Document.parse(recordMap))
                    .build();

            if (node.get("referenceId") != null) {
                syncRecord.setReferenceId(node.get("referenceId").asString());
            }

            entities.add(syncRecord);
        }

        List<SyncRecordEntity> saved = syncRecordRepository.insert(entities);
        log.info("[JobExecution] Persisted {} sync records for batch={}", saved.size(), batchId);
        return saved;
    }

    public void setRecordStatus(List<String> ids, String status) {
        if (ids == null || ids.isEmpty()) {
            return;
        }

        // 2. Define the criteria to target these specific documents
        Query query = new Query(Criteria.where("_id").in(ids));

        // 3. Define the update operation
        Update update = new Update().set("status", status);

        // 4. Execute a single multi-update command across the cluster
        UpdateResult result = mongoTemplate.updateMulti(query, update, SyncRecordEntity.class);

        log.info("Successfully updated {} records to status {}", result.getModifiedCount(), status);
    }

    public List<StatusCount> getStatusWiseCount(String jobExecutionId) {
        Aggregation agg = Aggregation.newAggregation(
                Aggregation.match(Criteria.where("jobExecutionId").is(jobExecutionId)),
                Aggregation.group("status").count().as("totalCount"),
                Aggregation.project("totalCount").and("_id").as("status") // Rename _id to status
        );

        AggregationResults<StatusCount> results = mongoTemplate.aggregate(
                agg,
                "sync_records",
                StatusCount.class
        );

        return results.getMappedResults();
    }
}

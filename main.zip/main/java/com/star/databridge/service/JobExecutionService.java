package com.star.databridge.service;

import com.star.databridge.dto.mongo.StatusCount;
import com.star.databridge.dto.response.TriggerJobResponse;
import com.star.databridge.entity.JobConfigEntity;
import com.star.databridge.entity.JobExecutionEntity;
import com.star.databridge.entity.ReadBatchExecutionEntity;
import com.star.databridge.repository.JobConfigRepository;
import com.star.databridge.repository.JobExecutionRepository;
import com.star.databridge.util.KafkaUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@RequiredArgsConstructor
@Service
@Slf4j
public class JobExecutionService {

    private static final Set<String> TERMINAL_STATUSES = Set.of("COMPLETED", "FAILED", "ABORTED");

    private final JobConfigRepository jobConfigRepository;
    private final ReadBatchService readBatchService;
    private final WriteBatchService writeBatchService;
    private final SyncRecordService syncRecordService;
    private final JobExecutionRepository jobExecutionRepository;
    private final KafkaUtil kafkaUtil;

    public TriggerJobResponse triggerJob(String jobName) {
        Optional<JobConfigEntity> optionalJobConfig = jobConfigRepository.findByNameAndActive(jobName, true);

        if (optionalJobConfig.isEmpty()) {
            throw new RuntimeException("Job configuration not found: " + jobName);
        }

        JobConfigEntity jobConfig = optionalJobConfig.get();

        log.info("Triggering Job: {}", jobConfig.getName());
        JobExecutionEntity jobExecution = createJobExecution(jobConfig);

        // Create first read batch execution
        ReadBatchExecutionEntity firstReadBatch = readBatchService.createBatch(
                jobConfig, jobExecution.getId(), 1);

        // Publish first read batch message
        kafkaUtil.pushReadBatchMsg(firstReadBatch, null);

        // Publish completion check message
        kafkaUtil.pushCompletionCheckMsg(jobConfig.getId(), jobExecution.getId());

        return TriggerJobResponse.builder()
                .jobId(jobExecution.getJobUuid())
                .jobName(jobName)
                .jobExecutionId(jobExecution.getId())
                .build();
    }

    public JobExecutionEntity createJobExecution(JobConfigEntity config) {
        String jobUuid = UUID.randomUUID().toString();
        JobExecutionEntity entity = new JobExecutionEntity();
        entity.setJobId(config.getId());
        entity.setJobName(config.getName());
        entity.setJobConfig(config);
        entity.setJobUuid(jobUuid);
        entity.setCreatedAt(LocalDateTime.now());
        entity.setUpdatedAt(LocalDateTime.now());
        entity.setContext(new HashMap<>());

        return jobExecutionRepository.save(entity);
    }

    public void updateStatus(String jobExecutionId, Map<String, List<StatusCount>> stats, String status) {
        jobExecutionRepository.findById(jobExecutionId).ifPresent(entity -> {
            entity.setStatus(status);
            entity.setStats(stats);
            jobExecutionRepository.save(entity);
        });
    }

    /**
     * Manually aborts a running job identified by its public {@code jobUuid}.
     * Marks the job as ABORTED and terminates all non-terminal read batches,
     * write batches, and sync records so the completion check stops waiting.
     *
     * @throws IllegalArgumentException if no job is found for the given uuid
     * @throws IllegalStateException    if the job is already in a terminal state
     */
    public JobExecutionEntity abortJobByUuid(String jobUuid) {
        JobExecutionEntity jobExecution = jobExecutionRepository.findByJobUuid(jobUuid)
                .orElseThrow(() -> new IllegalArgumentException("Job not found: " + jobUuid));

        if (TERMINAL_STATUSES.contains(jobExecution.getStatus())) {
            throw new IllegalStateException(
                    "Job " + jobUuid + " is already in terminal state: " + jobExecution.getStatus());
        }

        log.info("[JobExecution] Manually aborting job uuid={} id={}", jobUuid, jobExecution.getId());

        jobExecution.setStatus("ABORTED");
        jobExecutionRepository.save(jobExecution);

        String jobExecutionId = jobExecution.getId();
        readBatchService.terminalizeNonTerminal(jobExecutionId);
        writeBatchService.terminalizeNonTerminal(jobExecutionId);
        syncRecordService.terminalizeNonTerminal(jobExecutionId, "Job aborted by user");

        return jobExecution;
    }

    /**
     * Aborts a running job due to an internal failure: marks the job as FAILED
     * and terminates all non-terminal read batches and sync records so the
     * completion check stops waiting on them.
     */
    public void abortJob(String jobExecutionId, String reason) {
        log.error("[JobExecution] Aborting job {} — reason: {}", jobExecutionId, reason);

        jobExecutionRepository.findById(jobExecutionId).ifPresent(entity -> {
            entity.setStatus("FAILED");
            entity.setErrorMessage(reason);
            jobExecutionRepository.save(entity);
        });

        readBatchService.terminalizeNonTerminal(jobExecutionId);
        syncRecordService.terminalizeNonTerminal(jobExecutionId, reason);
    }
}

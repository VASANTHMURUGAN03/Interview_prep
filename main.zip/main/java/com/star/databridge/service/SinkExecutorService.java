package com.star.databridge.service;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.star.databridge.dto.common.JobContext;
import com.star.databridge.dto.mongo.SinkConfig;
import com.star.databridge.dto.mongo.StepConfig;
import com.star.databridge.dto.processor.StepExecutionContext;
import com.star.databridge.dto.processor.StepOutcome;
import com.star.databridge.dto.sink.SinkResult;
import com.star.databridge.entity.SyncRecordEntity;
import com.star.databridge.util.JsonUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class SinkExecutorService {

    private static final String BATCH_TYPE = "WRITE";

    private final StepService stepService;
    private final ObjectMapper objectMapper;

    /**
     * Executes all sink steps for a write batch.
     *
     * <p>Per-step execution (rule evaluation, processor dispatch, logging) is
     * delegated to {@link StepService}. This service only orchestrates the loop,
     * resolves the referenceId from accumulated step outputs, and cleans up any
     * files created during execution.
     *
     * @param config     sink config carrying step references
     * @param records    sync records picked for this write batch
     * @param jobContext shared execution IDs (writeBatchId in batchId)
     * @return the final step output, the resolved referenceId, and the step outputs
     */
    public SinkResult execute(SinkConfig config, List<SyncRecordEntity> records, JobContext jobContext) {
        if (config == null || config.getSteps() == null || records.isEmpty()) {
            log.warn("[SinkExecutor] Nothing to sink — config or records are empty");
            return null;
        }

        Map<String, JsonNode> stepOutputs = new HashMap<>();
        stepOutputs.put("sinkRecords", objectMapper.valueToTree(getSyncRecords(records)));

        StepExecutionContext context = StepExecutionContext.builder()
                .batchType(BATCH_TYPE)
                .jobContext(jobContext)
                .stepOutputs(stepOutputs)
                .builtinVars(Map.of("ENTITY_TYPE", jobContext.getEntity() != null ? jobContext.getEntity() : ""))
                .sinkRecords(records)
                .files(new ArrayList<>())
                .build();

        log.info("[SinkExecutor] Starting sink for entity={} records={} steps={}",
                jobContext.getEntity(), records.size(), config.getSteps().size());

        try {
            JsonNode lastResult = runSteps(config.getSteps(), context);
            String referenceId = resolveReferenceId(config, context.getStepOutputs());

            log.info("[SinkExecutor] Sink complete for batch={}", jobContext.getBatchId());
            return SinkResult.builder()
                    .lastStepOutput(lastResult)
                    .referenceId(referenceId)
                    .stepOutputs(context.getStepOutputs())
                    .build();
        } finally {
            cleanupFiles(context.getFiles());
        }
    }

    /**
     * Runs sink steps in order, honoring {@code SKIP_NEXT} / {@code NEXT} flow
     * decisions. {@code RESTART} is rejected at the {@link StepService} layer
     * for the sink flow, so it cannot reach this loop.
     */
    private JsonNode runSteps(List<StepConfig> steps, StepExecutionContext ctx) {
        JsonNode lastResult = null;
        int i = 0;
        String stepName;
        while (i < steps.size()) {
            stepName = steps.get(i).getName();
            long currTimeStamp = System.currentTimeMillis();
            StepOutcome outcome = stepService.executeStep(steps.get(i), ctx);
            if (outcome.getResult() != null) {
                lastResult = outcome.getResult();
            }
            switch (outcome.getDecision()) {
                case NEXT -> i++;
                case SKIP_NEXT -> i += 2;
                case RESTART -> throw new IllegalStateException(
                        "restartSteps effect is not supported in sink flow");
            }
            log.info("step execution ended: {}, time taken: {} ms", stepName, System.currentTimeMillis() - currTimeStamp);
        }
        return lastResult;
    }

    private String resolveReferenceId(SinkConfig config, Map<String, JsonNode> stepOutputs) {
        if (config.getReferenceId() == null) {
            return null;
        }

        String type = config.getReferenceId().getType();
        String value = config.getReferenceId().getValue();

        if (!"context".equalsIgnoreCase(type) || value == null) {
            return null;
        }

        String[] parts = value.split("\\.", 2);
        JsonNode stepOutput = stepOutputs.get(parts[0]);

        if (stepOutput == null) {
            return null;
        }
        if (parts.length == 1) {
            return stepOutput.asString();
        }

        JsonNode field = JsonUtil.extractData(stepOutput, parts[1]);
        return field.asString();
    }

    private void cleanupFiles(List<String> files) {
        if (files == null || files.isEmpty()) return;

        for (String fileName : files) {
            try {
                Path filePath = Path.of("src/main/resources/files", fileName);
                Files.deleteIfExists(filePath);
                log.debug("[SinkExecutor] Deleted file: {}", fileName);
            } catch (IOException e) {
                log.warn("[SinkExecutor] Failed to delete file: {}", fileName, e);
            }
        }

        log.info("[SinkExecutor] Cleaned up {} files", files.size());
    }

    private List<org.bson.Document> getSyncRecords(List<SyncRecordEntity> records) {
        return records.stream().map(SyncRecordEntity::getRecord).toList();
    }
}

package com.star.databridge.service;

import com.star.databridge.dto.mongo.StatusCount;
import com.star.databridge.entity.JobConfigEntity;
import com.star.databridge.entity.ReadBatchExecutionEntity;
import com.star.databridge.repository.ReadBatchExecutionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReadBatchService {

    private final ReadBatchExecutionRepository readBatchExecutionRepository;
    private final MongoTemplate mongoTemplate;

    public ReadBatchExecutionEntity createBatch(JobConfigEntity config, String jobExecutionId,
                                                int batchNo) {
        ReadBatchExecutionEntity entity = ReadBatchExecutionEntity.builder()
                .jobExecutionId(jobExecutionId)
                .batchNo(batchNo)
                .jobName(config.getName())
                .nextCursor(null)
                .build();

        return readBatchExecutionRepository.save(entity);
    }

    public void setSuccessful(ReadBatchExecutionEntity readBatch, List<String> recordIds, String nextCursor) {
        readBatch.setRecordIds(recordIds);
        readBatch.setStatus("SUCCESS");
        readBatch.setNextCursor(nextCursor);
        readBatchExecutionRepository.save(readBatch);
    }

    /**
     * Marks every non-terminal read batch for the given job execution as FAILED.
     * Used by the abort flow to drain any batches still sitting in the queue.
     */
    public void terminalizeNonTerminal(String jobExecutionId) {
        Criteria criteria = Criteria
                .where("jobExecutionId").is(jobExecutionId)
                .and("status").nin(List.of("SUCCESS", "FAILED"));

        Query query = new Query(criteria);
        Update update = new Update().set("status", "FAILED");

        mongoTemplate.updateMulti(query, update, ReadBatchExecutionEntity.class);
    }

    public List<StatusCount> getStatusWiseCount(String jobExecutionId) {
        Aggregation agg = Aggregation.newAggregation(
                Aggregation.match(Criteria.where("jobExecutionId").is(jobExecutionId)),
                Aggregation.group("status").count().as("totalCount"),
                Aggregation.project("totalCount").and("_id").as("status") // Rename _id to status
        );

        AggregationResults<StatusCount> results = mongoTemplate.aggregate(
                agg,
                "read_batch_executions",
                StatusCount.class
        );

        return results.getMappedResults();
    }

}

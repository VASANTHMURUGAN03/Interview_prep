package com.star.databridge.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.http.HttpStatus;

import static org.springframework.http.HttpStatus.*;

/**
 * Error codes start with `802`
 */
@Getter
@AllArgsConstructor
public enum RestTemplateErrorCodes {
    FAILED_TO_UPLOAD_FILE_TO_DMS(ErrorCategory.TECHNICAL, "802", "failed to upload file to dms", INTERNAL_SERVER_ERROR),
    INVALID_REQUEST(ErrorCategory.BUSINESS, "803", "Invalid request", BAD_REQUEST),
    RESOURCE_NOT_FOUND(ErrorCategory.TECHNICAL, "805", "Resource not found", NOT_FOUND),
    WHITELIST_CHECK_FAILED(ErrorCategory.TECHNICAL, "805", "Unauthorized request. Whitelisting check failed", HttpStatus.UNAUTHORIZED),
    JSON_PARSE_FAILURE(ErrorCategory.TECHNICAL, "806", "failed to parse json", INTERNAL_SERVER_ERROR),
    FLOW_TYPE_NOT_FOUND_FOR_THIS_REQUEST(ErrorCategory.BUSINESS, "807", "flow type not found for this request", BAD_REQUEST),
    POLICY_DETAILS_MISSING(ErrorCategory.BUSINESS, "808", "policy details required", BAD_REQUEST),
    INVALID_DOCUMENT_PROCESSING_EVENT(ErrorCategory.BUSINESS, "809", "document processing event invalid", BAD_REQUEST),
    CASE_ID_IS_MISSING_IN_EVENT(ErrorCategory.BUSINESS, "810", "caseid is missing in event", BAD_REQUEST),
    INVALID_PAYLOAD(ErrorCategory.TECHNICAL, "811", "Invalid Payload and Failed to parse", BAD_REQUEST),
    DOWNSTREAM_SOCKET_TIMEOUT_ERROR(ErrorCategory.TECHNICAL, "812", "Downstream socket timeout", INTERNAL_SERVER_ERROR),
    DOWNSTREAM_HOST_CONNECT_ERROR(ErrorCategory.TECHNICAL, "813", "Downstream host connet timeout", INTERNAL_SERVER_ERROR),
    DOWNSTREAM_CONNECT_TIMEOUT_ERROR(ErrorCategory.TECHNICAL, "814", "Downstream connect timeout", INTERNAL_SERVER_ERROR),
    DOWNSTREAM_SERVICE_NOT_AVAILABLE(ErrorCategory.TECHNICAL, "815", "Downstream service not available", INTERNAL_SERVER_ERROR),
    FAILED_TO_GET_RESPONSE_FROM_DOWN_STREAM_SYSTEM(ErrorCategory.TECHNICAL, "816", "Failed to get response from down stream system", INTERNAL_SERVER_ERROR),
    RESPONSE_BODY_EMPTY(ErrorCategory.TECHNICAL, "817", "Response body is null", INTERNAL_SERVER_ERROR),
    SOMETHING_WENT_WRONG(ErrorCategory.TECHNICAL, "818", "%s", INTERNAL_SERVER_ERROR),
    DELAY_SERVICE_EXCEPTION(ErrorCategory.TECHNICAL,"819" ,"failed message: %s" ,INTERNAL_SERVER_ERROR );
    private final ErrorCategory category;
    private final String code;
    private String displayMessage;
    private final HttpStatus httpStatus;

    public enum ErrorCategory {
        TECHNICAL,
        BUSINESS
    }

    protected void setDisplayMessage(String message) {
        this.displayMessage = message;
    }
}

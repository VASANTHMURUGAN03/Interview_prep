package com.star.databridge.exception;

import lombok.Getter;

@Getter
public class RestTemplateException extends RuntimeException {
    protected final RestTemplateErrorCodes errorCodes;

    public RestTemplateException(RestTemplateErrorCodes errorCodes, Throwable cause) {
        super(String.format(errorCodes.getDisplayMessage()), cause);
        this.errorCodes = errorCodes;
    }

    public RestTemplateException(RestTemplateErrorCodes errorCodes) {
        super(String.format(errorCodes.getDisplayMessage()));
        this.errorCodes = errorCodes;
    }

    public RestTemplateException(RestTemplateErrorCodes errorCodes, Object... args) {
        super(String.format(errorCodes.getDisplayMessage(), args));
        this.errorCodes = errorCodes;
    }

    public RestTemplateException(RestTemplateErrorCodes errorCodes, Throwable cause, Object... args) {
        super(String.format(errorCodes.getDisplayMessage(), args), cause);
        this.errorCodes = errorCodes;
    }

    public RestTemplateException(RestTemplateErrorCodes errorCodes, String displayMessage) {
        super(displayMessage);
        this.errorCodes = errorCodes;
        this.errorCodes.setDisplayMessage(String.format(errorCodes.getDisplayMessage(), displayMessage));
    }
}

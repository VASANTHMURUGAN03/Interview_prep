package com.star.databridge.exception;

import lombok.Getter;

@Getter
public class DataBridgeException extends RuntimeException {

    private final SyncErrorCode syncErrorCode;

    public DataBridgeException(SyncErrorCode syncErrorCode) {
        super(syncErrorCode.getDisplayMessage());
        this.syncErrorCode = syncErrorCode;
    }

    public DataBridgeException(SyncErrorCode syncErrorCode, Object... args) {
        super(String.format(syncErrorCode.getDisplayMessage(), args));
        this.syncErrorCode = syncErrorCode;
    }

    public DataBridgeException(SyncErrorCode syncErrorCode, Throwable cause, Object... args) {
        super(String.format(syncErrorCode.getDisplayMessage(), args), cause);
        this.syncErrorCode = syncErrorCode;
    }

    public DataBridgeException(SyncErrorCode syncErrorCode, Throwable cause) {
        super(cause);
        this.syncErrorCode = syncErrorCode;
    }

    public DataBridgeException(SyncErrorCode syncErrorCode, String displayMessage) {
        super(displayMessage);
        this.syncErrorCode = syncErrorCode;
    }

}
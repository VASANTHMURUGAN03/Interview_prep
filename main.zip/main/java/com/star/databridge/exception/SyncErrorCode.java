package com.star.databridge.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.http.HttpStatus;

import static org.springframework.http.HttpStatus.*;

@Getter
@AllArgsConstructor
public enum SyncErrorCode {
    FAILED_TO_GENERATE_SALESFORCE_TOKEN(ErrorCategory.TECHNICAL, "4001", "Failed to generate salesforce auth token", INTERNAL_SERVER_ERROR),
    FAILURE_WHILE_CALLING_SALESFORCE(ErrorCategory.TECHNICAL, "4002", "Failure while calling salesforce", INTERNAL_SERVER_ERROR),
    SOMETHING_WENT_WRONG(ErrorCategory.TECHNICAL, "4003", "Something went wrong", INTERNAL_SERVER_ERROR),
    TECHNICAL_FAILURE(ErrorCategory.TECHNICAL, "4004", "Something went wrong technically. Please reach out to the team for assistance", INTERNAL_SERVER_ERROR),
    STOPPED_BATCH_PROCESSING(ErrorCategory.TECHNICAL, "4005", "Stopped batch processing", INTERNAL_SERVER_ERROR),
    JSON_PARSE_FAILURE(ErrorCategory.TECHNICAL, "4006", "failed to parse json", INTERNAL_SERVER_ERROR),
    FAILURE_WHILE_CALLING_DATABRICKS(ErrorCategory.TECHNICAL, "4007", "Failure while calling datalake", INTERNAL_SERVER_ERROR),
    FAILED_TO_GET_DATALAKE_REQUEST_DB(ErrorCategory.TECHNICAL,"4008","Failure to get the datalake query from db",INTERNAL_SERVER_ERROR),
    FAILED_TO_GET_DATALAKE_REQUEST(ErrorCategory.TECHNICAL,"4008","Failure to get the datalake query from db",INTERNAL_SERVER_ERROR),
    LOG_OUT_USER_ERROR(ErrorCategory.TECHNICAL,"611","Error While Log out User", UNAUTHORIZED),
    INVALID_TOKEN(ErrorCategory.TECHNICAL, "601", "Invalid token", UNAUTHORIZED),
    GENERIC_EXCEPTION(ErrorCategory.TECHNICAL, "600", "Something went wrong, Please retry", INTERNAL_SERVER_ERROR),
    AUTH_TOKEN_MISSING(ErrorCategory.TECHNICAL, "602", "Required Auth Token", UNAUTHORIZED  ),
    REFRESH_TOKEN_NOT_PRESENT(ErrorCategory.TECHNICAL,"614"  ,"No Data found from claim Routing", BAD_REQUEST ),
    DUPLICATE_BATCH_AND_JOBID_INSERTION(ErrorCategory.TECHNICAL, "615", "Duplicate batch and job getting inserted", INTERNAL_SERVER_ERROR),
    PRIVATE_KEY_ERROR(ErrorCategory.TECHNICAL,"616","Unable to load private key exception message %s",INTERNAL_SERVER_ERROR),
    FAILED_TO_CALL_SF_BANCS_API(ErrorCategory.TECHNICAL,"617","Failure to call the SF Bancs API",INTERNAL_SERVER_ERROR),
    INVALID_JOB_NAME(ErrorCategory.TECHNICAL,"618","Job Name should not contains special Character _ ",BAD_REQUEST),
    VERSION_MANDATORY(ErrorCategory.TECHNICAL,"619","version is mandatory to update Job details - version is more than 0",BAD_REQUEST),
    INVALID_DATA(ErrorCategory.TECHNICAL,"619","Job not found",BAD_REQUEST),
    MISSING_FIELDS(ErrorCategory.TECHNICAL,"620","%s",BAD_REQUEST),
    KAFKA_PRODUCE_FAILED(ErrorCategory.TECHNICAL, "1022", "Failed to produce event to Kafka", HttpStatus.SERVICE_UNAVAILABLE)
    ;

    private final ErrorCategory category;
    private final String code;
    private final String displayMessage;
    private final HttpStatus httpStatus;


    public enum ErrorCategory {
        TECHNICAL,
        BUSINESS
    }
}

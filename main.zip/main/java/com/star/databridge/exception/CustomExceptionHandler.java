package com.star.databridge.exception;

import com.star.databridge.dto.response.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

@RestControllerAdvice
@Slf4j
public class CustomExceptionHandler {

    public static final String SOMETHING_WENT_WRONG = "Something went wrong";

    @ExceptionHandler(DataBridgeException.class)
    public ResponseEntity<ApiResponse<Object>> handleRestCallException(DataBridgeException ex, WebRequest request) {
        log.error("Custom exception captured - ex: {}", ex.getMessage(), ex);
        ApiResponse<Object> ApiResponse = new ApiResponse<>(ex.getSyncErrorCode(),ex.getMessage(), ex.getSyncErrorCode().getHttpStatus().value());
        return new ResponseEntity<>(ApiResponse, ex.getSyncErrorCode().getHttpStatus());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<Object>> handleException(Exception ex) {
        log.error("exception occurred", ex);
        SyncErrorCode genericException = SyncErrorCode.GENERIC_EXCEPTION;
        ApiResponse<Object> ApiResponse = new ApiResponse<>(genericException, SOMETHING_WENT_WRONG,  500);
        return new ResponseEntity<>(ApiResponse, genericException.getHttpStatus());
    }


}

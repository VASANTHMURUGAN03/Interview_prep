package com.star.databridge.exception;

public class AuthenticationException extends DataBridgeException {
    public AuthenticationException(SyncErrorCode syncErrorCode) {
        super(syncErrorCode);
    }
}

package com.star.databridge.reader;

import com.star.databridge.dto.reader.ReadContext;
import com.star.databridge.dto.reader.ReadResult;

/**
 * Contract for all data source readers.
 * Implementations handle a specific source type (API, MONGO, SQL, KAFKA, etc.)
 * and return records as a flat list of key-value maps.
 */
public interface DataReader {

    /**
     * Read one batch of records using the supplied context.
     * The context carries pagination state (offset or cursor) so the same
     * reader instance can be called repeatedly for subsequent batches.
     */
    ReadResult read(ReadContext context);

    /**
     * Returns the source type this reader handles (e.g. "API", "MONGO").
     * Used by {@link ReaderFactory} to select the right implementation.
     */
    String getType();
}

package com.star.databridge.reader;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Selects the right {@link DataReader} for a given source type.
 * All {@code DataReader} beans are injected automatically; new readers
 * (Mongo, SQL, Kafka, …) are picked up without changing this class.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ReaderFactory {

    private final List<DataReader> readers;

    public DataReader getReader(String type) {
        return readers.stream()
                .filter(r -> r.getType().equalsIgnoreCase(type))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No DataReader registered for type: " + type));
    }
}

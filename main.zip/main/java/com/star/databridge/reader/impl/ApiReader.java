package com.star.databridge.reader.impl;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.star.databridge.dto.mongo.PaginationConfig;
import com.star.databridge.dto.mongo.ReadConfig;
import com.star.databridge.dto.reader.ReadContext;
import com.star.databridge.dto.reader.ReadResult;
import com.star.databridge.dto.reader.api.ApiParamConfig;
import com.star.databridge.reader.DataReader;
import com.star.databridge.util.processor.ApiCallExecutor;
import com.star.databridge.util.JsonUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.JsonPath;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Reads one page of data from an HTTP API endpoint.
 *
 * <p>Responsibilities (this class only):
 * <ul>
 *   <li>Inject pagination variables ({@code BATCH_SIZE}, {@code OFFSET} / {@code CURSOR})
 *       as built-in vars before delegating to {@link ApiCallExecutor}.</li>
 *   <li>Determine {@code hasMore} from the extracted response using
 *       {@link PaginationConfig#getHasNext()} as the key.</li>
 *   <li>Build and return {@link ReadResult}.</li>
 * </ul>
 * <p>
 * Variable resolution, header substitution, API call, and response extraction
 * are all handled by {@link ApiCallExecutor}.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ApiReader implements DataReader {

    private final ApiCallExecutor apiCallExecutor;
    private final ObjectMapper objectMapper;

    @Override
    public String getType() {
        return "API";
    }

    @Override
    public ReadResult read(ReadContext context) {
        ReadConfig stepConfig = context.getStepConfig();
        ApiParamConfig config = objectMapper.convertValue(stepConfig.getParams(), ApiParamConfig.class);

        PaginationConfig pagination = config.getPagination();
        int batchSize = pagination != null ? pagination.getBatchSize() : 1000;

        Map<String, String> builtinVars = buildPaginationVars(context, batchSize, pagination);

        log.info("[ApiReader] Reading batch offset={} cursor={}", context.getOffset(), context.getCursor());

        // No step outputs for the read layer — context variable type is not applicable here
        JsonNode extractedData = apiCallExecutor.execute(
                config.getRequest(), config.getResponse(), builtinVars, null);

        return buildResult(extractedData, context, batchSize, pagination);
    }

    // -------------------------------------------------------------------------
    // Pagination built-in variables
    // -------------------------------------------------------------------------

    private Map<String, String> buildPaginationVars(ReadContext context, int batchSize,
                                                    PaginationConfig pagination) {
        Map<String, String> vars = new LinkedHashMap<>();
        vars.put("BATCH_SIZE", String.valueOf(batchSize));

        if (pagination != null && "cursor".equalsIgnoreCase(pagination.getType())) {
            vars.put("CURSOR", context.getCursor() != null ? context.getCursor() : "");
        } else {
            vars.put("OFFSET", String.valueOf(context.getOffset()));
        }
        return vars;
    }

    // -------------------------------------------------------------------------
    // Result construction
    // -------------------------------------------------------------------------

    private ReadResult buildResult(JsonNode data, ReadContext context, int batchSize,
                                   PaginationConfig pagination) {
        if (pagination == null) {
            return ReadResult.builder().data(data).hasMore(false).build();
        }

        int rowCount = JsonUtil.extractData(data, pagination.getHasNext()).size();
        boolean hasMore = batchSize > 0 && rowCount == batchSize;
        return switch (pagination.getType().toLowerCase()) {
            case "offset" -> ReadResult.builder()
                    .data(data)
                    .nextOffset(context.getOffset() + batchSize)
                    .hasMore(hasMore)
                    .build();
            case "cursor" -> {
                    String nextCursor = null;
                    if (hasMore && pagination.getNextCursorPath() != null) {
                        try{
                            DocumentContext ctx = JsonPath.parse(data.toString());
                            nextCursor = ctx.read(pagination.getNextCursorPath());
                        } catch (Exception e) {
                            nextCursor = null;
                        }
                    }
                    yield ReadResult.builder()
                            .data(data)
                            .nextCursor(nextCursor)
                            .hasMore(hasMore && nextCursor != null)
                            .build();
                }
            default -> throw new IllegalArgumentException(
                    "Unsupported pagination type: " + pagination.getType());
        };
    }

}

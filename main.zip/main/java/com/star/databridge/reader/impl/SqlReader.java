package com.star.databridge.reader.impl;

import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;
import com.star.databridge.config.SqlDataSourceRegistry;
import com.star.databridge.dto.mongo.PaginationConfig;
import com.star.databridge.dto.mongo.ReadConfig;
import com.star.databridge.dto.reader.ReadContext;
import com.star.databridge.dto.reader.ReadResult;
import com.star.databridge.dto.reader.sql.NextCursorConfig;
import com.star.databridge.dto.reader.sql.SqlParamConfig;
import com.star.databridge.dto.reader.sql.SqlRequestConfig;
import com.star.databridge.reader.DataReader;
import com.star.databridge.util.DataUtil;
import com.star.databridge.util.VariableResolver;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reads one page of data from a configured SQL data source (Postgres or MySQL).
 *
 * <p>Query shape per pagination type:
 * <ul>
 *   <li><b>cursor</b>: {@code baseQuery WHERE nextCursor.query AND (whereQuery) LIMIT batchSize}.
 *       The {@code nextCursor.query} fragment is skipped on the first call unless
 *       {@link NextCursorConfig#isIncludeInFirstQuery()} is set.</li>
 *   <li><b>offset</b>: {@code baseQuery WHERE (whereQuery) LIMIT batchSize OFFSET offset}.</li>
 * </ul>
 *
 * <p>For cursor pagination the next cursor is extracted from the last row by
 * parsing the leading identifier of {@link NextCursorConfig#getQuery()}
 * (e.g. {@code "id > ${NEXT_CURSOR}"} → column {@code id}).
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class SqlReader implements DataReader {

    private static final Pattern CURSOR_COLUMN_PATTERN = Pattern.compile("^\\s*([A-Za-z_][A-Za-z0-9_]*)");

    private final SqlDataSourceRegistry dataSourceRegistry;
    private final VariableResolver variableResolver;
    private final ObjectMapper objectMapper;

    @Override
    public String getType() {
        return "SQL";
    }

    @Override
    public ReadResult read(ReadContext context) {
        ReadConfig stepConfig = context.getStepConfig();
        SqlParamConfig config = objectMapper.convertValue(stepConfig.getParams(), SqlParamConfig.class);

        SqlRequestConfig request = config.getRequest();
        PaginationConfig pagination = config.getPagination();
        boolean isCursorPagination = pagination != null && "cursor".equalsIgnoreCase(pagination.getType());
        int batchSize = pagination != null && pagination.getBatchSize() != null ? pagination.getBatchSize() : 1000;

        Map<String, String> builtinVars = buildPaginationVars(context, batchSize, pagination, isCursorPagination);
        Map<String, String> vars = variableResolver.resolve(request.getVariables(), builtinVars, null);

        String sql = buildQuery(request, pagination, context, isCursorPagination, batchSize);
        String resolved = String.valueOf(DataUtil.substitute(sql, vars));

        JdbcTemplate jdbcTemplate = dataSourceRegistry.getTemplate(config.getSource());
        log.info("[SqlReader] source={} batchNo={} sql={}", config.getSource(),
                context.getJobContext().getBatchNo(), resolved);

        List<Map<String, Object>> rows = jdbcTemplate.queryForList(resolved);

        return buildResult(rows, pagination, context, batchSize, request, isCursorPagination);
    }

    // -------------------------------------------------------------------------
    // Query construction
    // -------------------------------------------------------------------------

    private String buildQuery(SqlRequestConfig request, PaginationConfig pagination,
                              ReadContext context, boolean isCursor, int batchSize) {
        List<String> clauses = new ArrayList<>();

        if (isCursor && includeCursorClause(request.getNextCursor(), context)) {
            clauses.add(request.getNextCursor().getQuery());
        }
        if (request.getWhereQuery() != null && !request.getWhereQuery().isBlank()) {
            clauses.add(request.getWhereQuery());
        }

        StringBuilder sql = new StringBuilder(request.getBaseQuery());
        if (!clauses.isEmpty()) {
            sql.append(" WHERE ").append(String.join(" AND ", clauses));
        }
        if(request.getOrderBy()!=null && !request.getOrderBy().isBlank()){
            sql.append(" ORDER BY ").append(request.getOrderBy());
        }
        sql.append(" LIMIT ").append(batchSize);
        if (!isCursor && pagination != null && "offset".equalsIgnoreCase(pagination.getType())) {
            sql.append(" OFFSET ").append(context.getOffset());
        }
        return sql.toString();
    }

    private boolean includeCursorClause(NextCursorConfig nextCursor, ReadContext context) {
        if (nextCursor == null || nextCursor.getQuery() == null) {
            return false;
        }

        boolean firstCall = context.getCursor() == null;
        return !firstCall || nextCursor.isIncludeInFirstQuery();
    }

    // -------------------------------------------------------------------------
    // Pagination built-in variables
    // -------------------------------------------------------------------------

    private Map<String, String> buildPaginationVars(ReadContext context, int batchSize,
                                                    PaginationConfig pagination, boolean isCursor) {
        Map<String, String> vars = new LinkedHashMap<>();
        vars.put("BATCH_SIZE", String.valueOf(batchSize));

        if (pagination == null) return vars;
        String paginationVar = pagination.getOffsetVariable();
        if (paginationVar == null) return vars;

        if (isCursor) {
            if (context.getCursor() != null) {
                vars.put(paginationVar, context.getCursor());
            }
        } else {
            vars.put(paginationVar, String.valueOf(context.getOffset()));
        }
        return vars;
    }

    // -------------------------------------------------------------------------
    // Result construction
    // -------------------------------------------------------------------------

    private ReadResult buildResult(List<Map<String, Object>> rows, PaginationConfig pagination,
                                   ReadContext context, int batchSize, SqlRequestConfig request,
                                   boolean isCursor) {
        ArrayNode rowsNode = objectMapper.valueToTree(rows);
        String dataKey = pagination != null && pagination.getHasNext() != null ? pagination.getHasNext() : "data";
        ObjectNode root = objectMapper.createObjectNode();
        root.set(dataKey, rowsNode);

        boolean hasMore = batchSize > 0 && rows.size() == batchSize;

        if (pagination == null) {
            return ReadResult.builder().data(root).hasMore(false).build();
        }

        if (isCursor) {
            String nextCursor = hasMore ? extractNextCursor(rows, request.getNextCursor()) : null;
            return ReadResult.builder().data(root).nextCursor(nextCursor).hasMore(hasMore && nextCursor != null).build();
        }

        return ReadResult.builder()
                .data(root)
                .nextOffset(context.getOffset() + batchSize)
                .hasMore(hasMore)
                .build();
    }

    private String extractNextCursor(List<Map<String, Object>> rows, NextCursorConfig nextCursor) {
        if (rows.isEmpty() || nextCursor == null || nextCursor.getQuery() == null) return null;

        Matcher matcher = CURSOR_COLUMN_PATTERN.matcher(nextCursor.getQuery());
        if (!matcher.find()) {
            throw new IllegalStateException("Unable to parse cursor column from: " + nextCursor.getQuery());
        }
        String column = matcher.group(1);

        Map<String, Object> lastRow = rows.get(rows.size() - 1);
        Object value = lastRow.get(column);
        if (value == null) {
            throw new IllegalStateException("Cursor column '" + column + "' is null in last row");
        }
        return String.valueOf(value);
    }
}

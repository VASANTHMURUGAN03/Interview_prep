package com.star.databridge;


import com.star.databridge.processor.impl.PhoneValidationProcessor;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.jdbc.autoconfigure.DataSourceAutoConfiguration;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.kafka.annotation.EnableKafka;


import java.util.LinkedHashMap;
import java.util.Map;

@SpringBootApplication(
		scanBasePackages = { "com.star.databridge", "com.starhealth.encryption" },
		exclude = { DataSourceAutoConfiguration.class }
)
@EnableKafka
@EnableMongoAuditing
public class DataBridgeApplication {

	public static void main(String[] args) {

		Map<String, String> test = new LinkedHashMap<>();

		test.put("9876543212", "9876543212");
		test.put("+919876543212", "9876543212");
		test.put("9876543212A", "9876543212");
		test.put("099934AAAA", "099934");
		test.put("+91 74657 76789", "917465776789");
		test.put("87898 78987", "8789878987");
		test.put("+625 3434343A", "6253434343");
		test.put("AAAAAA", "AAAAAA");
		test.put("000000", "000000");
		test.put("+678743434534", "+678743434534");

		System.out.println("\n=== PHONE  VERIFICATION  ===");
		System.out.printf("%-20s | %-15s | %-15s | %-6s%n", "INPUT RAW TEXT", "TARGET EXPECTED", "ACTUAL CLEANED", "STATUS");
		System.out.println("--------------------------------------------------------------------------");

		int passed = 0;
		for (Map.Entry<String, String> scenario : test.entrySet()) {
			String input = scenario.getKey();
			String expected = scenario.getValue();

			String actual = PhoneValidationProcessor.validateAndClean(input);
			boolean check = expected.equals(actual);
			if (check) passed++;

			System.out.printf("%-20s | %-15s | %-15s | %-6s%n",
					input, expected, actual, check ? "PASSED" : "FAILED ");
		}

		System.out.println("--------------------------------------------------------------------------");
		System.out.printf("Total Assertions Passed: %d / %d %n", passed, test.size());
		System.out.println("==========================================================================\n");
		if (passed == test.size()) {
			System.out.println("Validation  checks passed cleanly. Starting DataBridge service.");
			SpringApplication.run(DataBridgeApplication.class, args);
		} else {
			System.err.println("CRITICAL ERROR: Phone validation  rules broken! Aborting boot phase.");
			System.exit(1);
		}
	}

}



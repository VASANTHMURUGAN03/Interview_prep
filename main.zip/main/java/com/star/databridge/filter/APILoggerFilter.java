package com.star.databridge.filter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

@Slf4j
@Component
@AllArgsConstructor
public class APILoggerFilter extends OncePerRequestFilter {
    private static final List<String> LOG_HEADERS = List.of(
            "token",
            "hash",
            "clientname",
            "app_info"
    );

    private static final List<String> SENSITIVE_HEADERS = List.of(
            "token"
    );

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        doFilterWrapped(wrapRequest(request), wrapResponse(response), filterChain);
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String requestUrl = request.getRequestURI();
        return requestUrl.contains("swagger");
    }

    protected void doFilterWrapped(ContentCachingRequestWrapper request, ContentCachingResponseWrapper response, FilterChain filterChain) throws ServletException, IOException {
        long requestStartTime = System.currentTimeMillis();
        try {
            filterChain.doFilter(request, response);
        } finally {
            Map<String, Object> logMap = getLogMap(request, response);
            logMap.put("api_time", System.currentTimeMillis() - requestStartTime);
            log.info("API_LOGGING: {}", logMap);
            response.copyBodyToResponse();
        }
    }

    private Map<String, Object> getLogMap(ContentCachingRequestWrapper request, ContentCachingResponseWrapper response) {
        Map<String, Object> logMap = new HashMap<>();
        String requestString = getRequestString(request);
        String responseString = getResponseString(response);
        Map<String, String> headers = getHeaders(request);

        logMap.put("response_code", response.getStatus());
        logMap.put("request_body", requestString.replaceAll("\\s", ""));
        logMap.put("response", responseString.replaceAll("\\s", ""));
        logMap.putAll(headers);

        return logMap;
    }

    private static Map<String, String> getHeaders(ContentCachingRequestWrapper request) {
        Map<String, String> headers = new HashMap<>();
        Collections.list(request.getHeaderNames())
                .forEach(headerName ->
                        Collections.list(request.getHeaders(headerName))
                                .forEach(headerValue -> {
                                    if (!isSensitiveHeader(headerName)) {
                                        headers.put(headerName, headerValue);
                                    }
                                }));

        headers.put("request_url", request.getRequestURI());
        headers.put("request_parameters", request.getQueryString());
        headers.put("api_method", request.getMethod());

        return headers;
    }

    private static String getRequestString(ContentCachingRequestWrapper request) {
        byte[] content = request.getContentAsByteArray();
        return byteDataToString(content, request.getCharacterEncoding());
    }

    private static String getResponseString(ContentCachingResponseWrapper response) {
        byte[] content = response.getContentAsByteArray();
        return byteDataToString(content, response.getCharacterEncoding());
    }

    private static String byteDataToString(byte[] content, String contentEncoding) {
        StringBuilder response = new StringBuilder();
        try {
            String contentString = new String(content, contentEncoding);
            Stream.of(contentString.split("\r\n|\r|\n")).forEach(line -> response.append(" ").append(line).append("\n"));
        } catch (UnsupportedEncodingException e) {
            log.error("Failed to parse response while logging with exception: {}", e.getMessage());
        }
        return response.toString();
    }

    private static boolean isHeaderAllowedInLog(String headerName) {
        return LOG_HEADERS.contains(headerName.toLowerCase());
    }

    private static boolean isSensitiveHeader(String headerName) {
        return SENSITIVE_HEADERS.contains(headerName.toLowerCase());
    }

    private static ContentCachingRequestWrapper wrapRequest(HttpServletRequest request) {
        if (request instanceof ContentCachingRequestWrapper) {
            return (ContentCachingRequestWrapper) request;
        } else {
            return new ContentCachingRequestWrapper(request, 0);
        }
    }

    private static ContentCachingResponseWrapper wrapResponse(HttpServletResponse response) {
        if (response instanceof ContentCachingResponseWrapper) {
            return (ContentCachingResponseWrapper) response;
        } else {
            return new ContentCachingResponseWrapper(response);
        }
    }
}


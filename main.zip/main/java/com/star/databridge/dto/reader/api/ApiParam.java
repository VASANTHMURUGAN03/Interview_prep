package com.star.databridge.dto.reader.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApiParam {
    private String name;
    /**
     * Raw value; may contain {@code ${VAR}} placeholders when {@code type=dynamic}.
     */
    private Object value;
    /**
     * {@code "static"} – use value as-is; {@code "dynamic"} – substitute {@code ${VAR}} placeholders.
     */
    private String type;
}
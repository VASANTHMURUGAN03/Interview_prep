package com.star.databridge.dto.reader.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApiResponseConfig {
    /**
     * Dot-notation paths into the raw response JSON.
     * Typical keys: "columns", "data".
     */
    private List<ApiResponseParamConfig> params;
    private String type;
}
package com.star.databridge.dto.reader.sql;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NextCursorConfig {

    /**
     * WHERE clause fragment used for cursor pagination, e.g. {@code id > ${NEXT_CURSOR}}.
     * The first identifier in the fragment is treated as the cursor column — its
     * value in the last returned row becomes the next cursor.
     */
    private String query;

    /**
     * If {@code true}, {@link #query} is also appended to the very first call
     * (paired with the initial cursor variable value from {@code variables}).
     */
    private boolean includeInFirstQuery;
}

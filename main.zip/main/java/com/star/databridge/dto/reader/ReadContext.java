package com.star.databridge.dto.reader;

import com.star.databridge.dto.common.JobContext;
import com.star.databridge.dto.mongo.ReadConfig;
import com.star.databridge.dto.mongo.PaginationConfig;
import com.star.databridge.reader.DataReader;
import lombok.Builder;
import lombok.Data;

/**
 * Carries the state needed by a {@link DataReader} for one batch invocation.
 * Offset and cursor are mutually exclusive depending on the pagination type
 * configured in {@link PaginationConfig}.
 */
@Data
@Builder
public class ReadContext {

    private ReadConfig stepConfig;

    /**
     * Current zero-based record offset (offset-based pagination).
     */
    private long offset;

    /**
     * Opaque cursor token (cursor-based pagination).
     */
    private String cursor;

    private JobContext jobContext;
}

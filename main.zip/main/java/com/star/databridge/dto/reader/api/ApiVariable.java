package com.star.databridge.dto.reader.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApiVariable {
    private String name;
    /** "static" → use value directly; "implementation" → invoke named method. */
    private String type;
    private Object value;
}

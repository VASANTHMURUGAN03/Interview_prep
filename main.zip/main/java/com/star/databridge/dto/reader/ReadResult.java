package com.star.databridge.dto.reader;

import tools.jackson.databind.JsonNode;
import com.star.databridge.reader.DataReader;
import lombok.Builder;
import lombok.Data;

/**
 * Result returned by a {@link DataReader} after one batch read.
 */
@Data
@Builder
public class ReadResult {

    /**
     * Raw extracted data from the API response, keyed by the response param names
     * defined in the job config. Ready to be handed to the process layer.
     */
    private JsonNode data;

    /**
     * Next offset to use for offset-based pagination.
     */
    private long nextOffset;

    /**
     * Next cursor token for cursor-based pagination.
     */
    private String nextCursor;

    /**
     * Whether more records are available beyond this batch.
     */
    private boolean hasMore;
}

package com.star.databridge.dto.reader.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EndpointConfig {
    private String basePath;
    private String url;
    private String method;
    /**
     * Header map where values may be credential-key references (e.g. "CLIENT_ID").
     */
    private Map<String, String> headers;
}

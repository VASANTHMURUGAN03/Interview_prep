package com.star.databridge.dto.reader.api;

import com.star.databridge.dto.mongo.PaginationConfig;
import com.star.databridge.dto.mongo.StepConfig;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Typed representation of the {@code params} map stored inside a
 * {@link StepConfig} when
 * {@code type = "API"}.
 *
 * <pre>
 * params:
 *   endpoint:
 *     url: /eps/matrix-data-sync/api/v1/testDatalake
 *     method: POST
 *     headers:
 *       client-id: CLIENT_ID      # credential key resolved from app.credentials
 *       x-api-key: API_KEY
 *   request:
 *     body:
 *       - name: statement
 *         value: "SELECT * FROM ... WHERE change_date >= ${DATE} LIMIT ${BATCH_SIZE} OFFSET ${OFFSET}"
 *         type: dynamic
 *         variables:
 *           - name: DATE
 *             type: implementation
 *             value: getToday
 *           - name: OFFSET
 *             type: static
 *             value: 0
 *       - name: warehouse_id
 *         value: 9383dfdb4b6d2adf
 *         type: static
 *   response:
 *     params:
 *       columns: manifest.schema.columns
 *       data: result.data_array
 *     transform:
 *       name: transformDLDataToKeyValue
 * </pre>
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApiParamConfig {

    private ApiRequestConfig request;
    private ApiResponseConfig response;
    private PaginationConfig pagination;
}

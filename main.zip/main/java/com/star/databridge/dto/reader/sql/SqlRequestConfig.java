package com.star.databridge.dto.reader.sql;

import com.star.databridge.dto.reader.api.ApiVariable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SqlRequestConfig {

    /** e.g. {@code select * from users}. */
    private String baseQuery;

    /**
     * Optional filter clause (without the {@code WHERE} keyword), e.g.
     * {@code createdAt >= '${DATE}'}. Wrapped in parentheses when combined
     * with a cursor clause.
     */
    private String whereQuery;

    /** Cursor pagination clause — only consulted when pagination type is {@code cursor}. */
    private NextCursorConfig nextCursor;

    /** Batch size template — typically {@code ${BATCH_SIZE}}. Used in {@code LIMIT}. */
    private String batchSize;

    private String orderBy;

    /** Variables resolved into a map before query substitution. Same shape as {@code ApiVariable}. */
    private List<ApiVariable> variables;
}

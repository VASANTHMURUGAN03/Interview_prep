package com.star.databridge.dto.reader.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApiRequestConfig {
    private EndpointConfig endpoint;

    /**
     * Header map whose values may contain {@code ${VAR}} placeholders.
     * Resolved using the variables map before the API call.
     */
    private Map<String, String> headers;

    private List<ApiParam> body;
    private String rawBody;
    private List<ApiParam> query;
    private List<ApiParam> path;

    /**
     * Top-level variables resolved first into a flat map.
     * Supported types: {@code static}, {@code env}, {@code implementation}, {@code context}.
     */
    private List<ApiVariable> variables;
}

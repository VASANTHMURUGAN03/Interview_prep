package com.star.databridge.dto.reader.sql;

import tools.jackson.databind.JsonNode;
import com.star.databridge.dto.mongo.PaginationConfig;
import com.star.databridge.dto.mongo.StepConfig;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Typed representation of the {@code params} map stored inside a
 * {@link StepConfig} when {@code type = "SQL"}.
 *
 * <pre>
 * params:
 *   source: SPSPostgresDB          # key into app.sqlSources
 *   request:
 *     baseQuery: "select * from users"
 *     whereQuery: "createdAt &gt;= '${DATE}'"
 *     nextCursor:
 *       query: "id &gt; ${NEXT_CURSOR}"
 *       includeInFirstQuery: true
 *     batchSize: "${BATCH_SIZE}"
 *     variables:
 *       - { name: DATE,        type: implementation, value: getToday }
 *       - { name: BATCH_SIZE,  type: static,         value: 1000 }
 *       - { name: NEXT_CURSOR, type: static,         value: 0 }
 *   pagination:
 *     type: cursor              # cursor | offset
 *     offsetVariable: NEXT_CURSOR
 *     batchSize: 1000
 *     hasNext: data
 * </pre>
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SqlParamConfig {

    private String source;
    private SqlRequestConfig request;
    private JsonNode response;
    private PaginationConfig pagination;
}

package com.star.databridge.dto.common;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class JobContext {
    private String jobId;
    private String jobExecutionId;
    private String entity;
    private String batchId;
    private String batchRefId;
    private int batchNo;
}

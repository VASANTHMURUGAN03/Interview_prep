package com.star.databridge.dto.processor;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CsvToJsonConfig {
    /**
     * Maps CSV header → JSON key. If absent, all CSV columns are kept as-is.
     * Only columns present in the map are extracted from the CSV.
     */
    private Map<String, String> columns;

    /**
     * Name of the step whose output contains the CSV string. Optional — if not
     * provided, the most recently added entry in {@code stepOutputs} is used.
     */
    private String source;
}

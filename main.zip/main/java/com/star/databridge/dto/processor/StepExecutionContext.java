package com.star.databridge.dto.processor;

import tools.jackson.databind.JsonNode;
import com.star.databridge.dto.common.JobContext;
import com.star.databridge.entity.SyncRecordEntity;
import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * Shared state for a batch's worth of step execution.
 *
 * <p>Built once per batch by the caller (process / sink / ack executor) and
 * passed into {@code StepService.executeStep} for each step. {@code stepOutputs}
 * is mutated in place as steps run, so later steps see prior outputs.
 */
@Data
@Builder
public class StepExecutionContext {

    /** Used for step-execution logging and restart validation. READ | WRITE | ACK. */
    private String batchType;

    private JobContext jobContext;

    /** Mutated per step — each step's result is stored under the step name. */
    private Map<String, JsonNode> stepOutputs;

    /** Batch-specific pre-resolved variables merged into {@code ProcessContext.builtinVars}. */
    private Map<String, String> builtinVars;

    /** Sync records for the current write batch. {@code null} for the read/process flow. */
    private List<SyncRecordEntity> sinkRecords;

    /** Generated file names to be cleaned up by the caller after execution. */
    private List<String> files;
}

package com.star.databridge.dto.processor;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JsonToCsvConfig {
    /** Step name in {@code stepOutputs} whose output (a JSON array) provides the rows. */
    private String dataSource;

    private Map<String, String> columns;

    @Builder.Default
    private String lineEnding = "\n";

    private boolean writeToFile;
}

package com.star.databridge.dto.processor;

import tools.jackson.databind.JsonNode;
import com.star.databridge.enums.FlowDecision;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * Result returned by {@code StepService.executeStep}.
 *
 * <p>{@code result} is {@code null} when the step was skipped (missing entity,
 * or pre-execution rule decided {@code skip}). {@code stepParams} exposes the
 * resolved {@code ProcessStepEntity.params} so callers can honor step-specific
 * params such as {@code updateDataFlow} without re-querying.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StepOutcome {
    private JsonNode result;
    private FlowDecision decision;

    /** Params from the resolved step entity — {@code null} when the step was skipped. */
    private Map<String, Object> stepParams;
}

package com.star.databridge.dto.processor;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProcessStepConfig {
    private String id;
    private String name;
    private String type;
    Map<String, Object> params;
}

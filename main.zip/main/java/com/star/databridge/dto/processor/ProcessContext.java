package com.star.databridge.dto.processor;

import tools.jackson.databind.JsonNode;
import com.star.databridge.dto.common.JobContext;
import com.star.databridge.entity.SyncRecordEntity;
import com.star.databridge.processor.DataProcessor;
import lombok.Builder;
import lombok.Data;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Carries the state and configuration needed by a {@link DataProcessor}
 * for one invocation.
 *
 * <p>{@code stepOutputs} accumulates each step's return value keyed by step name,
 * starting with {@code "read"} for the initial data from the read layer.
 * Every processor receives the full accumulated context so it can reference
 * any prior step's output.
 *
 * <p>{@code builtinVars} are pre-resolved key/value pairs injected by the executor
 * before variable resolution runs (e.g. {@code ENTITY_TYPE} from the sink layer,
 * pagination vars from the read layer).
 */
@Data
@Builder
public class ProcessContext {
    private ProcessStepConfig stepConfig;
    private JobContext jobContext;

    /**
     * Accumulated step outputs keyed by step name.
     * Initialised with {@code "read" → readData} before the first step runs.
     */
    private Map<String, JsonNode> stepOutputs;

    /**
     * Pre-resolved variables injected by the caller, merged into the variable
     * resolution map before the config {@code variables} list is processed.
     * Callers may pass {@code null} or omit — treated as empty.
     */
    @Builder.Default
    private Map<String, String> builtinVars = Collections.emptyMap();

    /**
     * Sync records for the current write batch.
     * Only populated in sink context — null in process (read) context.
     */
    private List<SyncRecordEntity> sinkRecords;

    /**
     * File names created during this batch (e.g. CSV files).
     * Shared reference from SinkContext — processors add to this list,
     * SinkExecutorService cleans up after execution.
     */
    private List<String> files;
}

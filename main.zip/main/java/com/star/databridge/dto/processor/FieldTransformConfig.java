package com.star.databridge.dto.processor;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FieldTransformConfig {

    /** Step name in {@code stepOutputs} whose output contains the records to transform. */
    private String dataSource;

    /** Field-by-field transform list. */
    private List<TransformMapping> config;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TransformMapping {
        private String source;
        private String target;
        private String implementation;
    }
}

package com.star.databridge.dto.processor;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class HashingConfig {
    private String dataSource;
    private List<FieldMapping> fields;

    @Data
    public static class FieldMapping {
        private String source;  // field to read (already decrypted)
        private String target;  // field to write hash into
        private String type;    // "date" or "string"
    }
}

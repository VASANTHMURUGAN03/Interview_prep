package com.star.databridge.dto.processor;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DecryptionConfig {

    /** Step name in {@code stepOutputs} whose output contains the records to decrypt. */
    private String dataSource;

    /** Field-by-field decryption mapping. */
    private List<FieldMapping> fields;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FieldMapping {
        private String source;
        private String target;
    }
}

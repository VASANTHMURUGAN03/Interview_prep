package com.star.databridge.dto.ack;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AckResult {
    private List<String> successRecords;
    private List<String> failedRecords;
    private boolean restart;
}

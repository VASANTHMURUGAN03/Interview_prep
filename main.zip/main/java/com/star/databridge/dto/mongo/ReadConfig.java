package com.star.databridge.dto.mongo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReadConfig {
    private String type; // API, MONGO, etc.
    private Integer parallelThreads;
    private Integer maxRetryCount;

    /**
     * What to do when a read batch exhausts its retries.
     * <ul>
     *   <li>{@code ABORT} — mark the entire job as FAILED and stop.</li>
     *   <li>{@code IGNORE} — mark the failed batch as FAILED and continue with the next batch.
     *       Only valid for {@code OFFSET} pagination; {@code CURSOR} pagination always aborts
     *       since the cursor for subsequent batches is unrecoverable without the failed response.</li>
     * </ul>
     * Defaults to {@code ABORT} if unset.
     */
    private String failureStrategy;
    private Map<String, Object> params; // Flexible for different type
}

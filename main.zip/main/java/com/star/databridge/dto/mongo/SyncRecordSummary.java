package com.star.databridge.dto.mongo;

public interface SyncRecordSummary {
    String getId();
    String getRecordId();
    String getStatus();
    String getErrorMessage();
}

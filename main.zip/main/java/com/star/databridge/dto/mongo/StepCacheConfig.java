package com.star.databridge.dto.mongo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Optional Caffeine cache config for a process step.
 * Presence of this object on a {@link StepConfig} enables caching for that step.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StepCacheConfig {

    /** TTL in seconds for the cache entry. Defaults to 300s if zero or not set. */
    @Builder.Default
    private long expiryTime = 300;
}

package com.star.databridge.dto.mongo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StepConfig {
    private String name;
    private String type; // API, MONGO, etc.
    private Map<String, Object> params; // Flexible for different type

    /**
     * Rules evaluated BEFORE the step runs, against the accumulated {@code stepOutputs}.
     * Condition keys use dot notation like {@code "stepName.field"}.
     */
    private List<Rule> preExecution;

    /**
     * Rules evaluated AFTER the step runs, against THIS step's output.
     * Condition keys use dot notation within the step output (e.g. {@code "state"}).
     */
    private List<Rule> postExecution;

    /** When present, step output is cached in-process (Caffeine) keyed by jobExecutionId + stepName.
     * Add as {@code "cache": { "expiryTime": 3600 } }
     * */
    private StepCacheConfig cache;
}

package com.star.databridge.dto.mongo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaginationConfig {
    private String type;
    private String offsetVariable;
    private Integer batchSize;
    private String hasNext;
    /** Dot-notation path into the API response where the next cursor token lives. */
    private String nextCursorPath;
}
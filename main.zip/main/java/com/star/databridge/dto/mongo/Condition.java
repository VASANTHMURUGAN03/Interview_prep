package com.star.databridge.dto.mongo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Condition {
    /**
     * Path to the value in the source JSON. Uses dot notation
     * (e.g. "state" for postExecution against current step output,
     * or "salesforceJobInfo.state" for preExecution against accumulated step outputs).
     */
    private String key;

    /**
     * Comparison operator. Supported (case-insensitive):
     * equals, notEquals, greaterThan, lessThan,
     * greaterThanOrEqualsTo, lessThanOrEqualsTo, in, notIn.
     */
    private String operator;

    /**
     * Expected value. Can be a String, Number, Boolean, or List (for in/notIn).
     */
    private Object value;
}

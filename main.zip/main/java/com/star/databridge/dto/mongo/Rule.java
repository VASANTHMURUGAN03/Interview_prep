package com.star.databridge.dto.mongo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Rule {
    /**
     * All conditions must hold (AND semantics) for the rule's effect to apply.
     */
    private List<Condition> conditions;

    private Effect effect;
}

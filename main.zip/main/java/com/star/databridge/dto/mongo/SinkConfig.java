package com.star.databridge.dto.mongo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SinkConfig {
    private Integer maxRetryCount;
    private Integer batchSize;
    private ReferenceIdConfig referenceId;
    private List<StepConfig> steps;
}

package com.star.databridge.dto.mongo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Effect {
    /**
     * What to do when the rule's conditions are met. Valid values depend on the
     * phase in which the rule fires:
     *
     * <p><b>preExecution</b> — evaluated before the step runs:
     * <ul>
     *   <li>{@code execute} — run the current step (default when no rule matches).</li>
     *   <li>{@code skip} — skip the current step and proceed to the next.</li>
     *   <li>{@code restartSteps} — abandon remaining steps; republish the message
     *       with a delay so all steps run again from the beginning (ACK flow only).</li>
     * </ul>
     *
     * <p><b>postExecution</b> — evaluated after the step runs:
     * <ul>
     *   <li>{@code next} — proceed to the next step (default when no rule matches).</li>
     *   <li>{@code skip} — skip the next step (advance by two).</li>
     *   <li>{@code restartSteps} — abandon remaining steps; republish the message
     *       with a delay (ACK flow only).</li>
     * </ul>
     *
     * <p>Supplying an effect that is invalid for the phase raises an
     * {@link IllegalArgumentException} at evaluation time.
     */
    private String step;
}

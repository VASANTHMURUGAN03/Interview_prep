package com.star.databridge.dto.mongo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AckConfig {
    private String type; // POLL, IMMEDIATE
    private String successRecords; // path to extract success record IDs (e.g. "fetchSuccessfulRecords.recordIds")
    private String failedRecords;  // path to extract failed record IDs
    private List<StepConfig> steps;
}

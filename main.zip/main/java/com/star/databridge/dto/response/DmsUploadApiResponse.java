package com.star.databridge.dto.response;

import lombok.Data;

@Data
public class DmsUploadApiResponse {
    private String responseCode;
    private String responseMessage;
    private String displayMessage;
    private String traceId;
    private Data data;

    @lombok.Data
    public static class Data {
        private String documentId;
    }
}

package com.star.databridge.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TriggerJobResponse {
    private String jobId;
    private String jobName;
    private String jobExecutionId;
}

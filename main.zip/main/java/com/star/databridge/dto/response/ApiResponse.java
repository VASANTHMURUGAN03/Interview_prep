package com.star.databridge.dto.response;

import com.star.databridge.exception.SyncErrorCode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.slf4j.MDC;

@Data
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
public class ApiResponse<T> {
    public int statusCode;
    private String errorCode;
    private String message;
    private String displayMessage;
    private T data;
    private String traceId;

    public static final String TRACE_ID = "traceId";

    //  Constructor for exceptions and display message
    public ApiResponse(SyncErrorCode errorCode, String displayMessage, int statusCode) {
        this(statusCode, errorCode.getCode(), errorCode.name(), displayMessage, null, MDC.get(TRACE_ID));
    }
}

package com.star.databridge.dto.response;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class NotificationSendEmailApiResponse {
    private String responseCode;
    private String responseMessage;
    private String requestUID;
    private List<Map<String, String>> displayMessage;
}

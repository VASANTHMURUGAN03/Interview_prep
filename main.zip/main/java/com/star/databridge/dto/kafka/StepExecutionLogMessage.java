package com.star.databridge.dto.kafka;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class StepExecutionLogMessage {
    private String jobExecutionId;
    private String stepExecutionId;
    private String batchId;
    private String batchType; // READ or WRITE
    private String stepName;
    private String stepType;
    private String status; // RUNNING, SUCCESS, FAILED
    private String errorMessage;
    private LocalDateTime startedAt;
    private LocalDateTime completedAt;
}

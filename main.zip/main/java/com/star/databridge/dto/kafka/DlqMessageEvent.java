package com.star.databridge.dto.kafka;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Kafka event published to the fulfiller migration DLQ when a duplicate
 * active record is detected before insert.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DlqMessageEvent {

    /** Short machine-readable code, e.g. "DUPLICATE_ACTIVE_USER". */
    private String errorCode;

    /** Human-readable error description. */
    private String errorMessage;

    /** Kafka topic that produced the original message. */
    private String sourceTopic;

    /** Raw JSON payload of the original Kafka record. */
    private String originalRecord;

    /** Code of the existing ACTIVE fulfiller found in the database. */
    private String foundCode;
}

package com.star.databridge.dto.kafka;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ReadBatchMessage {
    private String readBatchExecutionId;
    private int batchNo;
    private String nextCursor;
}

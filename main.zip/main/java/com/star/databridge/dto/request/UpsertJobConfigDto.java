package com.star.databridge.dto.request;

import com.star.databridge.dto.mongo.*;
import lombok.*;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UpsertJobConfigDto {
    @NonNull
    private String name;

    private String entity;

    @Builder.Default
    private String strategy = "READ_FIRST";
    private TriggerConfig trigger;
    private ReadConfig read;
    private List<StepConfig> process;
    private SinkConfig sink;
    private AckConfig ack;
    private PostCompleteConfig postComplete;
}

package com.star.databridge.dto.request;

import lombok.*;

import java.util.Map;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UpsertProcessStepConfigDto {
    @NonNull
    private String name;

    private String type;
    Map<String, Object> params;
}

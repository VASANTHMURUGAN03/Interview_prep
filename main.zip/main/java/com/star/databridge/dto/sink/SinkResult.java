package com.star.databridge.dto.sink;

import tools.jackson.databind.JsonNode;
import lombok.Builder;
import lombok.Data;

import java.util.Map;

@Data
@Builder
public class SinkResult {
    private JsonNode lastStepOutput;
    private String referenceId;
    private Map<String, JsonNode> stepOutputs;
}

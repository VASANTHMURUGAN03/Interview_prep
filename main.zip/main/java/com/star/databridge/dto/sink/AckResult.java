package com.star.databridge.dto.sink;

import com.star.databridge.entity.SyncRecordEntity;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * Outcome of running ack steps for a write batch.
 *
 * <p>{@code restartRequested} is set when a {@code restartSteps} effect fires —
 * the caller should republish the ack message with a delay and skip applying
 * record outcomes (since the ack didn't actually complete).
 *
 * <p>Otherwise, {@code retryRecords} contains records that moved to RETRY status
 * (caller decides whether to publish a write-retry batch).
 */
@Data
@Builder
public class AckResult {
    private boolean restartRequested;
    private List<SyncRecordEntity> retryRecords;
}

package com.star.databridge.dto.sink;

import tools.jackson.databind.JsonNode;
import com.star.databridge.dto.processor.ProcessContext;
import com.star.databridge.dto.common.JobContext;
import com.star.databridge.entity.SyncRecordEntity;
import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.Map;

/**
 * Carries the shared state for a single sink execution.
 *
 * <p>{@code stepOutputs} starts empty and accumulates each sink step's return value
 * under the step name, exactly like the process layer — so subsequent steps can
 * reference prior outputs via {@code context} variables (e.g. the JWT, access token,
 * or Salesforce batch job ID produced by earlier steps).
 *
 * <p>{@code entityType} is the internal table/entity name derived from the
 * {@code SyncRecordEntity.table} field of the first record in the batch.
 * It is injected as the builtin variable {@code ENTITY_TYPE} when building each
 * step's {@link ProcessContext}.
 */
@Data
@Builder
public class SinkContext {
    private JobContext jobContext;
    private Map<String, JsonNode> stepOutputs;
    private String entityType;
    private List<SyncRecordEntity> records;
    private List<String> files;
}

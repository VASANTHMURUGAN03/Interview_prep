package com.star.databridge.common.apiHelper;

import com.star.databridge.dto.response.DmsUploadApiResponse;
import com.star.databridge.util.RestTemplateUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.star.databridge.common.Constants;

import java.util.LinkedHashMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
@Slf4j
public class DmsApiHelper {
    private final RestTemplateUtils restTemplateUtils;

    @Value("${dmsService.uploadDoc}")
    private String dmsUploadDoc;

    @Value("${dmsService.getPreSignedUrl}")
    private String dmsPreSignedUrl;

    @Value("${dmsService.apiKey}")
    private String dmsApiKey;

    @Value("${spring.application.clientId}")
    private String clientId;

    public DmsUploadApiResponse uploadReport(String documentImageBase64) {
        Map<String, String> headers = Map.of("x-api-key", dmsApiKey, "client-id", clientId);
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("category", Constants.DMS_CATEGORY);
        body.put("subCategory", Constants.DMS_SUB_CATEGORY);
        body.put("fileType", Constants.DMS_DOC_TYPE);
        body.put("documentName", Constants.DMS_DOC_NAME);
        body.put("source", Constants.DMS_DOC_SOURCE);
        body.put("documentImage", documentImageBase64);
        return restTemplateUtils.postForObject(dmsUploadDoc, headers, body, DmsUploadApiResponse.class);
    }

//    public DmsApiResponse fetchReport(String documentId) {
//        if (documentId == null) {
//            log.warn("[DMS] No documentId provided");
//            return null;
//        }
//        String url = dmsPreSignedUrl + "?did=" + documentId;
//        Map<String, String> headers = Map.of("x-api-key", dmsApiKey, "client-id", clientId);
//        return restTemplateUtils.getForObject(url, headers, DmsApiResponse.class);
//    }
}

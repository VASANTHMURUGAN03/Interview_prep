package com.star.databridge.common.apiHelper;

import com.star.databridge.common.Constants;
import com.star.databridge.dto.mongo.ReportConfig;
import com.star.databridge.dto.mongo.StatusCount;
import com.star.databridge.dto.response.NotificationSendEmailApiResponse;
import com.star.databridge.util.RestTemplateUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class NotificationApiHelper {

    private final RestTemplateUtils restTemplateUtils;

    @Value("${notificationService.sendEmail}")
    private String notificationEmail;

    @Value("${notificationService.apiKey}")
    private String notificationApiKey;

    @Value("${spring.application.clientId}")
    private String clientId;

    public NotificationSendEmailApiResponse sendNotificationMail(String dmsDocId, ReportConfig config, List<StatusCount> stats) {
        Map<String, String> headers = Map.of("x-api-key", notificationApiKey, "client-id", clientId);

        String toEmailID = String.join(";", config.getEmails());

        long successCount = stats.stream()
                .filter(sc -> "SUCCESS".equalsIgnoreCase(sc.getStatus()))
                .findFirst()
                .map(StatusCount::getTotalCount)
                .orElse(0L);

        long failedCount = stats.stream()
                .filter(sc -> "FAILED".equalsIgnoreCase(sc.getStatus()))
                .findFirst()
                .map(StatusCount::getTotalCount)
                .orElse(0L);

        long totalCount = successCount + failedCount;

        Map<String, String> templateInfo = new LinkedHashMap<>();
        templateInfo.put("JOB_NAME", config.getJobName());
        templateInfo.put("RECORD_COUNT", String.valueOf(totalCount));
        templateInfo.put("SUCCESS_RECORD_COUNT", String.valueOf(successCount));
        templateInfo.put("FAILED_RECORD_COUNT", String.valueOf(failedCount));

        List<Map<String, String>> attachments = List.of(
                Map.of("dmsId", dmsDocId, "fileName", Constants.DMS_DOC_NAME + "." + Constants.DMS_DOC_TYPE)
        );

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("templateId", config.getNotificationTemplateId());
        body.put("templateInfo", templateInfo);
        body.put("toEmailID", toEmailID);
        body.put("subject", "Job Execution Report For " + config.getJobName());
        body.put("fromEmailID", Constants.DATA_BRIDGE_EMAIL);
        body.put("attachments", attachments);

        return restTemplateUtils.postForObject(notificationEmail, headers, body, NotificationSendEmailApiResponse.class);
    }

}


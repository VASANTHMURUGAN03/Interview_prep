package com.star.databridge.common;

public class Constants {
    public static final String DMS_CATEGORY = "REPORTS";
    public static final String DMS_SUB_CATEGORY = "DATA_MIGRATION_REPORT";
    public static final String DMS_DOC_TYPE = "csv";
    public static final String DMS_DOC_NAME = "migrationReport";
    public static final String DMS_DOC_SOURCE = "DATA_BRIDGE";
    public static final String DATA_BRIDGE_EMAIL = "databridge@starhealth.in";
}

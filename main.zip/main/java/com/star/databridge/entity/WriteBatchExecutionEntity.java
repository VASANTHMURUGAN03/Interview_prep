package com.star.databridge.entity;

import com.star.databridge.dto.mongo.WriteRecordDetail;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "write_batch_executions")
public class WriteBatchExecutionEntity {
    @Id
    private String id;

    private String jobExecutionId;
    private String entity;

    @Builder.Default
    private String status = "PENDING";

    private String referenceId;
    private List<String> recordIds;
    private String errorMessage;

    private WriteRecordDetail details;

    @CreatedDate
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();

    @LastModifiedDate
    @Builder.Default
    private LocalDateTime updatedAt = LocalDateTime.now();
}

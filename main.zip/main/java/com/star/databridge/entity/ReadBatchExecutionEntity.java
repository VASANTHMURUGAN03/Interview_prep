package com.star.databridge.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "read_batch_executions")
public class ReadBatchExecutionEntity {
    @Id
    private String id;

    private String jobName;
    private String jobExecutionId;
    private int batchNo;
    private String nextCursor;
    private String remarks;

    @Builder.Default
    private String status = "IN_PROGRESS";

    @Builder.Default
    private Integer retryCount = 0;

    private List<String> recordIds;

    @CreatedDate
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();

    @LastModifiedDate
    @Builder.Default
    private LocalDateTime updatedAt = LocalDateTime.now();
}

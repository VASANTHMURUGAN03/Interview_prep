package com.star.databridge.entity;

import com.star.databridge.dto.mongo.StatusCount;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "job_executions")
public class JobExecutionEntity {
    @Id
    private String id;

    private String jobId;
    private String jobUuid;
    private String jobName;
    private JobConfigEntity jobConfig;
    private String jobReportDocId;

    @Builder.Default
    private String status = "IN_PROGRESS";
    
    @Builder.Default
    private Integer retryCount = 0;

    private Map<String, List<StatusCount>> stats;

    private String errorMessage;

    private Map<String, Object> context;

    @CreatedDate
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();

    @LastModifiedDate
    @Builder.Default
    private LocalDateTime updatedAt = LocalDateTime.now();
}

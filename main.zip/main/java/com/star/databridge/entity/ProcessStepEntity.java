package com.star.databridge.entity;

import com.star.databridge.dto.mongo.StepCacheConfig;
import lombok.*;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "process_steps")
public class ProcessStepEntity {
    @Id
    private String id;
    private String name;
    private String type;
    Map<String, Object> params;
    private boolean active;
    private StepCacheConfig cache;

    @CreatedDate
    private LocalDateTime createdAt;

    @LastModifiedDate
    private LocalDateTime updatedAt;
}
package com.star.databridge.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "step_executions")
public class StepExecutionEntity {
    @Id
    private String id;

    private String stepExecutionId;
    private String jobExecutionId;
    private String batchId;
    private String batchType; // READ or WRITE
    private String stepName;
    private String stepType;
    private String status; // RUNNING, SUCCESS, FAILED
    private String errorMessage;

    private LocalDateTime startedAt;
    private LocalDateTime completedAt;

    @CreatedDate
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();
}

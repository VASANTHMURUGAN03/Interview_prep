package com.star.databridge.entity;

import com.star.databridge.dto.mongo.*;
import lombok.*;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "job_configs")
public class JobConfigEntity {
    @Id
    private String id;
    private String name;
    private String entity;
    private String strategy; // READ_FIRST, SIMULTANEOUS_READ_WRITE
    private TriggerConfig trigger;
    private ReadConfig read;
    private List<StepConfig> process;
    private SinkConfig sink;
    private AckConfig ack;
    private PostCompleteConfig postComplete;
    private ReportConfig report;
    private boolean active;

    @CreatedDate
    private LocalDateTime createdAt;

    @LastModifiedDate
    private LocalDateTime updatedAt;
}
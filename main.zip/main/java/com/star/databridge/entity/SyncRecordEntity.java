package com.star.databridge.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "sync_records")
public class SyncRecordEntity {

    @Id
    private String id;
    private String jobExecutionId;
    private String entity;
    private String recordId;
    private String referenceId;
    private org.bson.Document record;
    private String writeBatchExecutionId;

    @Builder.Default
    private Integer retryCount = 0;

    @Builder.Default
    private String status = "READY";

    private String errorMessage;

    @CreatedDate
    private LocalDateTime createdAt;

    @LastModifiedDate
    private LocalDateTime updatedAt;
}

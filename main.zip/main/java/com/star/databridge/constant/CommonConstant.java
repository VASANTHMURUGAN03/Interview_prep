package com.star.databridge.constant;

public class CommonConstant {
    public static String REQUEST_UUID = "requestUUID";
}

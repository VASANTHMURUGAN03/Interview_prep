package com.star.databridge.constant;


import tools.jackson.databind.JsonNode;

import java.util.Map;

public class ApiConstant {
    public static final Map<String, Class<?>> RESPONSE_TYPE = Map.of("CSV", String.class, "JSON", JsonNode.class);
}

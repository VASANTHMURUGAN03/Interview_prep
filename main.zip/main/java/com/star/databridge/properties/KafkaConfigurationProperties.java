package com.star.databridge.properties;

import lombok.Data;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "kafka.config")
@Data
@ConditionalOnProperty(value = "kafka.consumer.enabled", havingValue = "true")
public class KafkaConfigurationProperties {

    private String bootstrapServers;
    private int requestTimeout;
    private int deliveryTimeout;
    private long retryBackOffMS;
    private int concurrencyThreads;
    private long pollTimeout;
    private long initialInterval;
    private String maxPollRecord;
    private String groupId;
}

package com.star.databridge.properties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ConfigurationProperties(prefix = "rest.template")
public class RestTemplateProperties {
    private int connectTimeout=5000;
    private int readTimeout=1000;
    private int maxConnection=10;
}
package com.star.databridge.processor;

import tools.jackson.databind.JsonNode;
import com.star.databridge.dto.processor.ProcessContext;
import com.star.databridge.dto.mongo.StepConfig;
import com.star.databridge.processor.impl.JoltTransformProcessor;

/**
 * Contract for all record-level processing steps.
 *
 * <p>Implementations cover different cardinality patterns:
 * <ul>
 *   <li><b>1-to-1</b> – transform / enrich each record (e.g. {@link JoltTransformProcessor}).</li>
 *   <li><b>N-to-1</b> – aggregate N records into a single output record.</li>
 *   <li><b>1-to-N</b> – split one record into multiple output records.</li>
 * </ul>
 *
 * The process type string (e.g. "JOLT_TRANSFORM", "AGGREGATE", "SPLIT") must
 * match {@link #getType()} and is stored in
 * {@link StepConfig#getType()}.
 */
public interface DataProcessor {

    /**
     * Process a batch of input records and return the resulting output records.
     * The output list may be smaller (aggregation), larger (split), or the same
     * size (transform) as the input.
     */
    JsonNode process(ProcessContext context);

    /** Process-step type identifier used by {@link ProcessorFactory}. */
    String getType();
}

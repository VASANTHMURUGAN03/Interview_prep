package com.star.databridge.processor.impl;

import com.star.databridge.dto.processor.HashingConfig;
import com.star.databridge.dto.processor.ProcessContext;
import com.star.databridge.processor.DataProcessor;
import com.star.databridge.util.DataUtil;
import com.star.databridge.util.JsonUtil;
import com.star.databridge.util.ObjectMapperUtil;
import com.star.databridge.util.TracingUtils;
import com.starhealth.encryption.service.FieldEncryptionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Generates a signed JWT and returns it as a {@link tools.jackson.databind.node.StringNode}.
 * The executor stores the result in {@code ProcessContext.stepOutputs} under the step name;
 * input data is left unchanged (this step does not update the data flow).
 *
 * <p>Expected params:
 * <pre>
 * {
 *   "privateKeyPath": "salesforce.privateKeyPath",  // env property or literal file path
 *   "publicKeyPath":  null,                         // optional; env property or literal path
 *   "algorithm":      "RSA256",
 *   "expiryInSec":    300,
 *   "issuer":         "salesForce.issuer",          // env property; falls back to config value
 *   "subject":        "salesForce.subject",         // env property; falls back to config value
 *   "audience":       "salesForce.audience"         // env property; falls back to config value
 * }
 * </pre>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class HashingProcessor implements DataProcessor {

    private final ObjectMapper objectMapper;
    private final FieldEncryptionService fieldEncryptionService;
    private final TracingUtils tracingUtils;

    // Excel epoch starts at 1899-12-31
    private static final LocalDate EXCEL_EPOCH = LocalDate.of(1899, 12, 31);
    private static final String base64KeyValue = "RII8Bk2XwIrW8WF6k+NEISDyfnqwHEZ1oqJ0jztXYqA=";

    @Override
    public String getType() {
        return "HASHING";
    }

    @Override
    public JsonNode process(ProcessContext context) {
        long startTime = System.currentTimeMillis();

        HashingConfig config = ObjectMapperUtil.convertObject(
                context.getStepConfig().getParams(), HashingConfig.class);

        JsonNode input = DataUtil.resolveFromContext(
                config.getDataSource(), context.getStepOutputs());

        if (input == null || !input.isArray()) {
            return objectMapper.createArrayNode();
        }

        List<HashingConfig.FieldMapping> mappings = config.getFields();
        int totalRows = input.size();

        int cores = Runtime.getRuntime().availableProcessors();
        ExecutorService executor = Executors.newFixedThreadPool(cores + 1);
        int chunkSize = (totalRows + cores - 1) / cores;

        List<Future<List<ObjectNode>>> futures = new ArrayList<>();

        for (int i = 0; i < cores; i++) {
            int start = i * chunkSize;
            int end = Math.min(start + chunkSize, totalRows);
            if (start >= end) break;

            futures.add(
                    executor.submit(
                            tracingUtils.wrapCallableWithSpan(
                                    "hash-chunk",
                                    () -> processChunk(input, mappings, start, end)
                            )
                    )
            );
        }

        ArrayNode result = objectMapper.createArrayNode();
        for (Future<List<ObjectNode>> future : futures) {
            try {
                List<ObjectNode> chunkResult = future.get();
                result.addAll(chunkResult);
            } catch (Exception e) {
                throw new RuntimeException("Error processing chunk", e);
            }
        }

        executor.shutdown();
        log.info("Total execution time: {} ms", System.currentTimeMillis() - startTime);
        return result;
    }

    private List<ObjectNode> processChunk(JsonNode input,
                                          List<HashingConfig.FieldMapping> mappings,
                                          int start,
                                          int end) {
        List<ObjectNode> localResult = new ArrayList<>(end - start);

        for (int i = start; i < end; i++) {
            JsonNode row = input.get(i);
            ObjectNode out = (ObjectNode) row;

            for (HashingConfig.FieldMapping mapping : mappings) {
                JsonNode value = JsonUtil.safelyExtractData(row, mapping.getSource());
                if (value == null || value.isNull()) continue;

                try {
                    String hashed = hash(value, mapping.getType());
                    if (hashed != null) {
                        out.put(mapping.getTarget(), hashed); // ✅ write hashed value
                    }
                } catch (Exception e) {
                    log.error("[HashingProcessor] Error hashing field={} at row={}", mapping.getSource(), i, e);
                }
            }

            localResult.add(out);
        }

        return localResult;
    }

    private String hash(JsonNode value, String type) throws Exception {
        if ("date".equalsIgnoreCase(type) && value.isNumber()) {
            return hashDate(value.asLong());
        }
        return generateHash(value.asText());
    }

    private String hashDate(long excelSerial) throws Exception {
        String isoDate = excelSerialToIsoDate(excelSerial);
        return generateHash(isoDate);
    }

    private String excelSerialToIsoDate(long value) {
        LocalDate date = EXCEL_EPOCH.plusDays(value);
        return date.format(DateTimeFormatter.ISO_LOCAL_DATE);
    }

    private String generateHash(String message) throws Exception {
        byte[] keyData = Base64.getDecoder().decode(base64KeyValue);
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(keyData, "HmacSHA256"));
        byte[] signature = mac.doFinal(message.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encodeToString(signature);
    }
}
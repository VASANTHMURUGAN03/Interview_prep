package com.star.databridge.processor.impl;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.star.databridge.dto.processor.JsonToCsvConfig;
import com.star.databridge.dto.processor.ProcessContext;
import com.star.databridge.processor.DataProcessor;
import com.star.databridge.util.DataUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.StringJoiner;
import java.util.UUID;

@Slf4j
@Component
@RequiredArgsConstructor
public class JsonToCsvProcessor implements DataProcessor {

    private static final String FILES_DIR = "src/main/resources/files";

    private final ObjectMapper objectMapper;

    @Override
    public String getType() {
        return "JSON_TO_CSV";
    }

    @Override
    public JsonNode process(ProcessContext context) {
        JsonToCsvConfig config = objectMapper.convertValue(context.getStepConfig().getParams(), JsonToCsvConfig.class);

        Map<String, String> columns = config.getColumns() != null ? config.getColumns() : null;

        boolean writeToFile = config.isWriteToFile();

        JsonNode input = DataUtil.resolveFromContext(config.getDataSource(), context.getStepOutputs());
        if (input == null || !input.isArray() || input.isEmpty()) {
            log.warn("[JsonToCsvProcessor] No array data found at dataSource={}", config.getDataSource());
            return objectMapper.convertValue("", JsonNode.class);
        }

        String csv = buildCsv(input, columns, normalizeLineEnding(config.getLineEnding()));
        log.info("CSV created: {}", csv);

        if (writeToFile) {
            String fileName = writeToFile(csv);
            if (context.getFiles() != null) {
                context.getFiles().add(fileName);
            }
        }

        log.info("[JsonToCsvProcessor] Generated CSV with {} rows", input.size());
        return objectMapper.valueToTree(csv);
    }

    private String buildCsv(JsonNode records, Map<String, String> columns, String lineEnding) {
        StringBuilder sb = new StringBuilder();

        Map<String, String> columnMap;
        if (columns != null && !columns.isEmpty()) {
            columnMap = new LinkedHashMap<>(columns);
        } else {
            JsonNode firstRecord = records.get(0);
            columnMap = new LinkedHashMap<>();
            firstRecord.propertyNames().forEach(key -> columnMap.put(key, key));
        }

        // Header row
        StringJoiner headerJoiner = new StringJoiner(",");
        columnMap.values().forEach(headerJoiner::add);
        sb.append(headerJoiner).append(lineEnding);

        // Data rows
        for (JsonNode record : records) {
            StringJoiner rowJoiner = new StringJoiner(",");
            for (String sourceKey : columnMap.keySet()) {
                rowJoiner.add(escapeCsv(stringValue(record.get(sourceKey))));
            }
            sb.append(rowJoiner).append(lineEnding);
        }

        return sb.toString();
    }

    private String stringValue(JsonNode node) {
        if (node == null || node.isNull()) {
            return "";
        }
        if (node.isValueNode()) {
            return node.asString();
        }
        return node.toString();
    }

    public String escapeCsv(String value) {
        if (value.contains(",") || value.contains("\"") || value.contains("\n") || value.contains("\r")) {
            return "\"" + value.replace("\"", "\"\"") + "\"";
        }
        return value;
    }

    /**
     * Writes CSV to resources/files/ with a UUID filename.
     * @return the generated file name
     */
    private String writeToFile(String csv) {
        String fileName = UUID.randomUUID() + ".csv";
        Path dir = Path.of(FILES_DIR);
        try {
            Files.createDirectories(dir);
            Files.writeString(dir.resolve(fileName), csv);
            log.info("[JsonToCsvProcessor] Written CSV to file: {}/{}", FILES_DIR, fileName);
            return fileName;
        } catch (IOException e) {
            log.error("[JsonToCsvProcessor] Failed to write CSV file: {}", fileName, e);
            throw new RuntimeException("Failed to write CSV file", e);
        }
    }

    private String normalizeLineEnding(String lineEnding) {
        if (lineEnding == null || lineEnding.isEmpty()) {
            return "\r\n";
        }

        return lineEnding
                .replace("\\r", "\r")
                .replace("\\n", "\n");
    }
}

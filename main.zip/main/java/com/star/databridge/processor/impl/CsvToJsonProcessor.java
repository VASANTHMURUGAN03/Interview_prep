package com.star.databridge.processor.impl;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;
import com.star.databridge.dto.processor.CsvToJsonConfig;
import com.star.databridge.dto.processor.ProcessContext;
import com.star.databridge.processor.DataProcessor;
import com.star.databridge.util.DataUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Parses a CSV string into a JSON array. The input CSV is read from the
 * accumulated {@code stepOutputs} — either the step named by {@code source},
 * or the most recently added entry if {@code source} is omitted.
 *
 * <p>If {@code columns} is provided, only the mapped CSV headers are extracted
 * and renamed in the output. Otherwise, every column is kept with its CSV header
 * as the JSON key.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CsvToJsonProcessor implements DataProcessor {

    private final ObjectMapper objectMapper;

    @Override
    public String getType() {
        return "CSV_TO_JSON";
    }

    @Override
    public JsonNode process(ProcessContext context) {
        CsvToJsonConfig config = objectMapper.convertValue(
                context.getStepConfig().getParams(), CsvToJsonConfig.class);

        String csv = resolveCsvSource(context.getStepOutputs(), config.getSource());
        if (csv == null || csv.isBlank()) {
            log.warn("[CsvToJsonProcessor] No CSV content found in stepOutputs");
            return objectMapper.createArrayNode();
        }

        List<String[]> rows = parseCsv(csv);
        if (rows.isEmpty()) {
            return objectMapper.createArrayNode();
        }

        String[] headers = rows.getFirst();
        Map<String, String> columnMap = config.getColumns();

        ArrayNode result = objectMapper.createArrayNode();
        for (int r = 1; r < rows.size(); r++) {
            String[] values = rows.get(r);
            ObjectNode row = objectMapper.createObjectNode();
            for (int c = 0; c < headers.length && c < values.length; c++) {
                String header = headers[c];
                if (columnMap != null && !columnMap.isEmpty()) {
                    // Only extract columns listed in the mapping
                    String targetKey = columnMap.get(header);
                    if (targetKey != null) {
                        row.put(targetKey, values[c]);
                    }
                } else {
                    row.put(header, values[c]);
                }
            }
            result.add(row);
        }

        log.info("[CsvToJsonProcessor] Parsed {} rows from CSV", result.size());
        return result;
    }

    // -------------------------------------------------------------------------
    // CSV source resolution
    // -------------------------------------------------------------------------

    private String resolveCsvSource(Map<String, JsonNode> stepOutputs, String source) {
        JsonNode node = DataUtil.resolveFromContext(source, stepOutputs);
        return node != null ? node.asString() : null;
    }

    // -------------------------------------------------------------------------
    // CSV parsing (RFC 4180 subset: supports quoted fields with commas + escaped quotes)
    // -------------------------------------------------------------------------

    private List<String[]> parseCsv(String csv) {
        List<String[]> rows = new ArrayList<>();
        List<String> currentRow = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean inQuotes = false;

        for (int i = 0; i < csv.length(); i++) {
            char ch = csv.charAt(i);

            if (inQuotes) {
                if (ch == '"') {
                    if (i + 1 < csv.length() && csv.charAt(i + 1) == '"') {
                        field.append('"');
                        i++;
                    } else {
                        inQuotes = false;
                    }
                } else {
                    field.append(ch);
                }
            } else {
                switch (ch) {
                    case '"' -> inQuotes = true;
                    case ',' -> {
                        currentRow.add(field.toString());
                        field.setLength(0);
                    }
                    case '\n' -> {
                        currentRow.add(field.toString());
                        field.setLength(0);
                        rows.add(currentRow.toArray(new String[0]));
                        currentRow = new ArrayList<>();
                    }
                    case '\r' -> {
                        // ignore — LF will close the row
                    }
                    default -> field.append(ch);
                }
            }
        }

        if (!field.isEmpty() || !currentRow.isEmpty()) {
            currentRow.add(field.toString());
            rows.add(currentRow.toArray(new String[0]));
        }

        return rows;
    }
}

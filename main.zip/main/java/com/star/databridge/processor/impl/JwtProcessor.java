package com.star.databridge.processor.impl;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.star.databridge.dto.processor.ProcessContext;
import com.star.databridge.processor.DataProcessor;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.time.Instant;
import java.util.Base64;
import java.util.Map;

/**
 * Generates a signed JWT and returns it as a {@link tools.jackson.databind.node.StringNode}.
 * The executor stores the result in {@code ProcessContext.stepOutputs} under the step name;
 * input data is left unchanged (this step does not update the data flow).
 *
 * <p>Expected params:
 * <pre>
 * {
 *   "privateKeyPath": "salesforce.privateKeyPath",  // env property or literal file path
 *   "publicKeyPath":  null,                         // optional; env property or literal path
 *   "algorithm":      "RSA256",
 *   "expiryInSec":    300,
 *   "issuer":         "salesForce.issuer",          // env property; falls back to config value
 *   "subject":        "salesForce.subject",         // env property; falls back to config value
 *   "audience":       "salesForce.audience"         // env property; falls back to config value
 * }
 * </pre>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class JwtProcessor implements DataProcessor {

    private final Environment env;
    private final ObjectMapper objectMapper;

    @Override
    public String getType() {
        return "JWT";
    }

    @Override
    @SneakyThrows
    public JsonNode process(ProcessContext context) {
        Map<String, Object> params = context.getStepConfig().getParams();

        String privateKeyPath = resolveEnv(params, "privateKeyPath");
        String publicKeyPath = resolveEnvNullable(params, "publicKeyPath");
        String issuer = resolveEnv(params, "issuer");
        String subject = resolveEnv(params, "subject");
        String audience = resolveEnv(params, "audience");
        String algorithmType = String.valueOf(params.get("algorithm"));
        int expiryInSec = Integer.parseInt(String.valueOf(params.get("expiryInSec")));

        Algorithm algorithm = getAlgorithm(algorithmType, privateKeyPath, publicKeyPath);

        String token = JWT.create()
                .withIssuer(issuer)
                .withSubject(subject)
                .withAudience(audience)
                .withIssuedAt(Instant.now())
                .withExpiresAt(Instant.now().plusSeconds(expiryInSec))
                .sign(algorithm);

        log.info("[JwtProcessor] JWT generated for subject = {}, token = {}", subject, token);

        return objectMapper.convertValue(token, JsonNode.class);
    }

    // -------------------------------------------------------------------------
    // Param resolution — env lookup with fallback to config literal
    // -------------------------------------------------------------------------

    /**
     * Resolves a param value: first tries it as an env property key;
     * if the env doesn't have it, uses the config value as-is.
     */
    private String resolveEnv(Map<String, Object> params, String key) {
        String configValue = String.valueOf(params.get(key));
        return env.getProperty(configValue, configValue);
    }

    /**
     * Same as {@link #resolveEnv} but returns {@code null} when the param is missing or
     * explicitly {@code null} in the config.
     */
    private String resolveEnvNullable(Map<String, Object> params, String key) {
        Object raw = params.get(key);
        if (raw == null || "null".equalsIgnoreCase(String.valueOf(raw))) return null;
        String configValue = String.valueOf(raw);
        return env.getProperty(configValue, configValue);
    }

    // -------------------------------------------------------------------------
    // Key loading
    // -------------------------------------------------------------------------

    @SneakyThrows
    private RSAPrivateKey loadRSAPrivateKey(String filePath) {
        String pem = stripPemHeaders(getFileContent(filePath),
                "-----BEGIN PRIVATE KEY-----", "-----END PRIVATE KEY-----",
                "-----BEGIN RSA PRIVATE KEY-----", "-----END RSA PRIVATE KEY-----");

        byte[] keyBytes = Base64.getDecoder().decode(pem);
        return (RSAPrivateKey) KeyFactory.getInstance("RSA")
                .generatePrivate(new PKCS8EncodedKeySpec(keyBytes));
    }

    @SneakyThrows
    private RSAPublicKey loadRSAPublicKey(String filePath) {
        String pem = stripPemHeaders(getFileContent(filePath),
                "-----BEGIN PUBLIC KEY-----", "-----END PUBLIC KEY-----",
                "-----BEGIN RSA PUBLIC KEY-----", "-----END RSA PUBLIC KEY-----");

        byte[] keyBytes = Base64.getDecoder().decode(pem);
        return (RSAPublicKey) KeyFactory.getInstance("RSA")
                .generatePublic(new X509EncodedKeySpec(keyBytes));
    }

    private String getFileContent(String filePath) throws Exception {
        ClassPathResource resource = new ClassPathResource(filePath);
        return new String(resource.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
    }

    private String stripPemHeaders(String pem, String... headers) {
        String result = pem;
        for (String header : headers) {
            result = result.replace(header, "");
        }
        return result.replaceAll("\\s", "");
    }

    private Algorithm getAlgorithm(String algorithm, String privateKeyPath, String publicKeyPath) {
        switch (algorithm) {
            case "RSA256":
            case "RS256": // Handle both variants
                RSAPrivateKey privateKey = loadRSAPrivateKey(privateKeyPath);
                RSAPublicKey publicKey = (publicKeyPath != null) ? loadRSAPublicKey(publicKeyPath) : null;
                return Algorithm.RSA256(publicKey, privateKey);

            default:
                throw new IllegalArgumentException("Unsupported algorithm: " + algorithm);
        }
    }
}

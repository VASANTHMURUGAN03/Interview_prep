package com.star.databridge.processor.impl;

import com.bazaarvoice.jolt.Chainr;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.star.databridge.processor.DataProcessor;
import com.star.databridge.dto.processor.ProcessContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * A {@link DataProcessor} that applies a full
 * <a href="https://github.com/bazaarvoice/jolt">Jolt</a> chainr spec to every
 * record in the batch.
 *
 * <p>All standard Jolt operations are supported: shift, default, remove,
 * cardinality, sort, modify-overwrite-beta, etc.
 *
 * <p>The spec is stored in {@code StepConfig.params.spec} as a list of Jolt
 * operation objects (already a {@code List<Object>} after MongoDB deserialization),
 * e.g.:
 * <pre>
 * {
 *   "type": "JOLT_TRANSFORM",
 *   "params": {
 *     "spec": [
 *       {
 *         "operation": "shift",
 *         "spec": {
 *           "customer_id": "customerId",
 *           "full_name":   "name",
 *           "address": {
 *             "city": "address.city",
 *             "pin":  "address.pinCode"
 *           }
 *         }
 *       },
 *       {
 *         "operation": "default",
 *         "spec": {
 *           "status": "ACTIVE"
 *         }
 *       }
 *     ]
 *   }
 * }
 * </pre>
 *
 * <p>This is a <em>process-step</em> processor. For response-level transforms
 * applied inside a reader
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class JoltTransformProcessor implements DataProcessor {

    private final ObjectMapper objectMapper;

    @Override
    public String getType() {
        return "JOLT_TRANSFORM";
    }

    @Override
    public JsonNode process(ProcessContext processContext) {
        // 1. Load the Jolt specification

        long currTime = System.currentTimeMillis();
        log.info("Jolt transformation started - record:{}", processContext.getStepOutputs().size());
        @SuppressWarnings("unchecked")
        List<Object> specs = (List<Object>) processContext.getStepConfig().getParams().get("config");

        Chainr chainr = Chainr.fromSpec(specs);

        // 2. Convert JsonNode to a standard Java Object (Map/List)
        Object inputObject = objectMapper.convertValue(processContext.getStepOutputs(), Object.class);

        // 3. Execute the Jolt transformation
        Object outputObject = chainr.transform(inputObject);
        log.info("Jolt transformation ended - time: {}, record: {}", System.currentTimeMillis() - currTime, processContext.getStepOutputs().size());

        // 4. Convert the result back to a JsonNode
        return objectMapper.valueToTree(outputObject);
    }
}

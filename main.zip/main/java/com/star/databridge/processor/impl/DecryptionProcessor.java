package com.star.databridge.processor.impl;

import com.star.databridge.util.TracingUtils;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;
import com.star.databridge.dto.processor.DecryptionConfig;
import com.star.databridge.dto.processor.ProcessContext;
import com.star.databridge.processor.DataProcessor;
import com.star.databridge.util.DataUtil;
import com.star.databridge.util.ObjectMapperUtil;
import com.starhealth.encryption.service.FieldEncryptionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import com.star.databridge.util.JsonUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * A process-layer {@link DataProcessor} that reads records from a prior step output
 * and decrypts the configured fields per row, writing each decrypted value to the
 * configured target field.
 *
 * <p>Expected params:
 * <pre>
 * {
 *   "dataSource": "transformCustomerDataForCSV",
 *   "fields": [
 *     { "source": "AadharNumber__c", "target": "AadharNumber__c" },
 *     ...
 *   ]
 * }
 * </pre>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DecryptionProcessor implements DataProcessor {

    private final ObjectMapper objectMapper;
    private final FieldEncryptionService fieldEncryptionService;
    private final TracingUtils tracingUtils;

    @Override
    public String getType() {
        return "DECRYPT";
    }


    @Override
    public JsonNode process(ProcessContext context) {
        long startTime = System.currentTimeMillis();
        DecryptionConfig config = ObjectMapperUtil.convertObject(
                context.getStepConfig().getParams(), DecryptionConfig.class);
        JsonNode input = DataUtil.resolveFromContext(
                config.getDataSource(), context.getStepOutputs());
        if (input == null || !input.isArray()) {
            return objectMapper.createArrayNode();
        }

        List<DecryptionConfig.FieldMapping> mappings = config.getFields();
        int totalRows = input.size();

        // ✅ CPU-bound → number of cores only
        int cores = Runtime.getRuntime().availableProcessors();
        ExecutorService executor = Executors.newFixedThreadPool(cores+1);

        // ✅ Chunk size (important)
        int chunkSize = (totalRows + cores - 1) / cores;

        List<Future<List<ObjectNode>>> futures = new ArrayList<>();

        for (int i = 0; i < cores; i++) {
            int start = i * chunkSize;
            int end = Math.min(start + chunkSize, totalRows);

            if (start >= end) break;
            futures.add(
                    executor.submit(
                            tracingUtils.wrapCallableWithSpan(
                                    "decrypt-chunk",
                                    () -> processChunk(input, mappings, start, end)
                            )
                    )
            );
        }

        ArrayNode result = objectMapper.createArrayNode();

        for (Future<List<ObjectNode>> future : futures) {
            try {
                List<ObjectNode> chunkResult = future.get();
                for (ObjectNode node : chunkResult) {
                    result.add(node);
                }
            } catch (Exception e) {
                throw new RuntimeException("Error processing chunk", e);
            }
        }

        executor.shutdown();
        log.info("Total execution time: {} ms", System.currentTimeMillis() - startTime);

        return result;
    }



    private String decryptField(String encrypted) {
        String trimmed = encrypted.trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        try {
//            log.debug("[DecryptionProcessor] Calling decryptFieldString for value={}", trimmed);
            return fieldEncryptionService.decryptFieldString(trimmed);
            //            log.info("[DecryptionProcessor] Decryption success for value={}", decrypted);
        } catch (Exception e) {
            log.error("Decryption failed for value [{}]. Check encryption service/keys.", trimmed, e);
            return null;
        }
    }


    /**
     * ✅ Process a chunk of rows (key optimization)
     */
    private List<ObjectNode> processChunk(JsonNode input,
                                          List<DecryptionConfig.FieldMapping> mappings,
                                          int start,
                                          int end) {

        List<ObjectNode> localResult = new ArrayList<>(end - start);

        for (int i = start; i < end; i++) {
            JsonNode row = input.get(i);

            // Directly mutate the row
            ObjectNode out = (ObjectNode) row;

            for (DecryptionConfig.FieldMapping mapping : mappings) {
                // Extract source value using nested path
                JsonNode value = JsonUtil.safelyExtractData(row, mapping.getSource());
                if (value == null || value.isNull() || !value.isTextual()) {
                    log.debug("[DecryptionProcessor] Row={}, sourceField={} is NULL", i, mapping.getSource());
                    continue;
                }

                String text = value.asString();
                if (text.isEmpty()) continue;

                try {
                    String decrypted = decryptField(text);
                    if (decrypted != null) {
                        // Resolve parent node via dot notation for target
                        String target = mapping.getTarget();
                        int lastDot = target.lastIndexOf('.');
                        String fieldName = lastDot < 0 ? target : target.substring(lastDot + 1);
                        JsonNode parentNode = lastDot < 0 ? out : JsonUtil.safelyExtractData(out, target.substring(0, lastDot));

                        if (parentNode != null && parentNode.isObject()) {
                            ((ObjectNode) parentNode).put(fieldName, decrypted);
                        } else {
                            throw new IllegalStateException(
                                    String.format("Target path '%s' does not resolve to an ObjectNode. Row=%d", target, i));
                        }
                    }
                } catch (Exception e) {
                    log.error("[DecryptionProcessor] Error decrypting field={} at row={}",
                            mapping.getSource(), i, e);
                }
            }

            localResult.add(out);
        }

        return localResult;
    }


}

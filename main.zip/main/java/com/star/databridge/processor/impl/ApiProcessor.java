package com.star.databridge.processor.impl;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.star.databridge.dto.processor.ProcessContext;
import com.star.databridge.dto.reader.api.ApiParamConfig;
import com.star.databridge.processor.DataProcessor;
import com.star.databridge.util.processor.ApiCallExecutor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;


/**
 * A process-layer {@link DataProcessor} that calls an HTTP API, extracts the
 * configured response fields, and returns them as an {@code ObjectNode}.
 *
 * <p>The executor stores the return value in {@code ProcessContext.stepOutputs} under
 * the step name. Input data is left unchanged is {@code false}).
 *
 * <p>Variable resolution, header substitution, API call, and response extraction
 * are all handled by {@link ApiCallExecutor}.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ApiProcessor implements DataProcessor {

    private final ApiCallExecutor apiCallExecutor;
    private final ObjectMapper objectMapper;

    @Override
    public String getType() {
        return "API";
    }

    @Override
    public JsonNode process(ProcessContext context) {
        ApiParamConfig config = objectMapper.convertValue(
                context.getStepConfig().getParams(), ApiParamConfig.class);

        log.info("[ApiProcessor] step={}", context.getStepConfig().getName());
        log.info("[ApiProcessor] config: {} , context:{} ",config,context);
        return apiCallExecutor.execute(
                config.getRequest(), config.getResponse(),
                context.getBuiltinVars(), context.getStepOutputs());
    }
}

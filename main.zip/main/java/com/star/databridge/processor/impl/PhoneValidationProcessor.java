package com.star.databridge.processor.impl;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;

import com.star.databridge.dto.processor.HashingConfig;
import com.star.databridge.dto.processor.ProcessContext;
import com.star.databridge.processor.DataProcessor;
import com.star.databridge.util.DataUtil;
import com.star.databridge.util.JsonUtil;
import com.star.databridge.util.ObjectMapperUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.regex.Pattern;
@Slf4j
@Component
@RequiredArgsConstructor
public class PhoneValidationProcessor implements DataProcessor {

    private final ObjectMapper objectMapper;

    private static final Pattern ONLY_DIGITS = Pattern.compile("^\\d+$");
    private static final Pattern STRIP_NON_DIGITS = Pattern.compile("[^0-9]");

    @Override
    public String getType() {
        return "PHONE_VALIDATION";
    }

    @Override
    public JsonNode process(ProcessContext context) {
        long startTime = System.currentTimeMillis();

        HashingConfig config = ObjectMapperUtil.convertObject(
                context.getStepConfig().getParams(), HashingConfig.class);
        JsonNode input = DataUtil.resolveFromContext(
                config.getDataSource(), context.getStepOutputs());

        if (input == null || !input.isArray()) {
            return objectMapper.createArrayNode();
        }

        List<HashingConfig.FieldMapping> mappings = config.getFields();
        ArrayNode result = objectMapper.createArrayNode();
        for (int i = 0; i < input.size(); i++) {
            JsonNode row = input.get(i);
            ObjectNode out = (ObjectNode) row.deepCopy();

            for (HashingConfig.FieldMapping mapping : mappings) {
                JsonNode value = JsonUtil.safelyExtractData(out, mapping.getSource());
                if (value == null || value.isNull() || !value.isTextual()) {
                    continue;
                }

                try {
                    String rawValue = value.asText();
                    String cleanedValue = validateAndClean(rawValue);
                    String target = mapping.getTarget();
                    ensurePathExists(out, target);

                    int lastDot = target.lastIndexOf('.');
                    String fieldName = lastDot < 0 ? target : target.substring(lastDot + 1);
                    JsonNode parentNode = lastDot < 0 ? out : JsonUtil.safelyExtractData(out, target.substring(0, lastDot));

                    if (parentNode != null && parentNode.isObject()) {
                        ((ObjectNode) parentNode).put(fieldName, cleanedValue);
                    }
                } catch (Exception e) {
                    log.error("[PhoneValidationProcessor] Error processing column mapping source={} at row={}", mapping.getSource(), i, e);
                }
            }
            result.add(out);
        }

        log.info("[PhoneValidationProcessor] Step completed in {} ms for {} records.",
                System.currentTimeMillis() - startTime, input.size());
        return result;
    }

    public static String validateAndClean(String rawPhone) {
        if (rawPhone == null || rawPhone.isEmpty()) {
            return rawPhone;
        }

        // Rule 1: Clean spaces immediately to evaluate actual structure
        String normalized = rawPhone.replace(" ", "");

        // Rule 2: Valid 10-digit Indian Mobile Number
        if (normalized.length() == 10 && ONLY_DIGITS.matcher(normalized).matches()) {
            return normalized;
        }

        // Rule 3: Valid Indian Mobile Number with +91 Country Code
        if (normalized.length() == 13 && normalized.startsWith("+91")
                && ONLY_DIGITS.matcher(normalized.substring(3)).matches()) {
            return normalized.substring(3);
        }

        // Rule 4: Handle alphanumeric noise (e.g., '099934AAAA', '9876543212A')
        String contentWithoutPlus = normalized.replace("+", "");
        boolean hasNonNumeric = !ONLY_DIGITS.matcher(contentWithoutPlus).matches();

        if (hasNonNumeric) {
            String stripped = STRIP_NON_DIGITS.matcher(normalized).replaceAll("");

            // Fallback to raw if stripping leaves it entirely empty (e.g., 'AAAAAA')
            if (!stripped.isEmpty()) {
                return stripped;
            }
        }
        // Rule 5: International, pure-character, or generic fallback (e.g., 'AAAAAA', '000000')
        return normalized;
    }

    private void ensurePathExists(ObjectNode root, String targetPath) {
        if (!targetPath.contains(".")) return;
        String[] parts = targetPath.split("\\.");
        ObjectNode current = root;
        for (int i = 0; i < parts.length - 1; i++) {
            String part = parts[i];
            if (!current.has(part) || !current.get(part).isObject()) {
                current.set(part, objectMapper.createObjectNode());
            }
            current = (ObjectNode) current.get(part);
        }
    }
}

package com.star.databridge.processor.impl;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;
import com.star.databridge.dto.processor.FieldTransformConfig;
import com.star.databridge.dto.processor.ProcessContext;
import com.star.databridge.processor.DataProcessor;
import com.star.databridge.util.DataUtil;
import com.star.databridge.util.FieldTransformer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * A {@link DataProcessor} that applies named field-level transforms to every row
 * of an upstream step's output. Each entry in {@code config} reads {@code source}
 * from the row, runs {@code implementation} via {@link FieldTransformer}, and
 * writes the result to {@code target}.
 *
 * <p>Expected params:
 * <pre>
 * {
 *   "dataSource": "sfDecryptCustomerFields",
 *   "config": [
 *     { "source": "PersonBirthdate", "target": "PersonBirthdate", "implementation": "safeConvertToYYYYMMDD" }
 *   ]
 * }
 * </pre>
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class FieldTransformProcessor implements DataProcessor {

    private final ObjectMapper objectMapper;
    private final FieldTransformer fieldTransformer;

    @Override
    public String getType() {
        return "FIELD_TRANSFORM";
    }

    @Override
    public JsonNode process(ProcessContext context) {
        FieldTransformConfig config = objectMapper.convertValue(
                context.getStepConfig().getParams(), FieldTransformConfig.class);

        JsonNode input = DataUtil.resolveFromContext(config.getDataSource(), context.getStepOutputs());
        if (input == null || !input.isArray()) {
            log.warn("[FieldTransformProcessor] No array data found at dataSource={}", config.getDataSource());
            return objectMapper.createArrayNode();
        }

        List<FieldTransformConfig.TransformMapping> mappings = config.getConfig();
        ArrayNode result = objectMapper.createArrayNode();
        for (JsonNode row : input) {
            ObjectNode out = (row instanceof ObjectNode obj) ? obj.deepCopy() : objectMapper.createObjectNode();
            for (FieldTransformConfig.TransformMapping mapping : mappings) {
                JsonNode value = row.get(mapping.getSource());
                out.put(mapping.getTarget(), fieldTransformer.apply(mapping.getImplementation(), value));
            }
            result.add(out);
        }

        log.info("[FieldTransformProcessor] Transformed {} field(s) across {} row(s)",
                mappings.size(), result.size());
        return result;
    }
}

package com.star.databridge.processor;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Selects the right {@link DataProcessor} for a given process-step type.
 * All {@code DataProcessor} beans are injected automatically; new processors
 * (AGGREGATE, SPLIT, …) are picked up without changing this class.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ProcessorFactory {

    private final List<DataProcessor> processors;

    public DataProcessor getProcessor(String type) {
        return processors.stream()
                .filter(processor -> processor.getType().equalsIgnoreCase(type))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException(
                        "No DataProcessor registered for type: " + type));
    }
}

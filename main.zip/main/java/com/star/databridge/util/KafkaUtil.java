package com.star.databridge.util;

import com.star.databridge.dto.kafka.DlqMessageEvent;
import com.star.databridge.dto.kafka.JobCompletionMessage;
import com.star.databridge.dto.kafka.ReadBatchMessage;
import com.star.databridge.dto.kafka.OrchestrationMessage;
import com.star.databridge.dto.kafka.StepExecutionLogMessage;
import com.star.databridge.entity.ReadBatchExecutionEntity;
import com.star.databridge.kafka.producer.KafkaEventPublisherUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Slf4j
@Component
@RequiredArgsConstructor
public class KafkaUtil {

    @Value("${app.kafka.topics.migration-batch-dlq}")
    private String dlqTopic;

    @Value("${app.kafka.topics.migration-read-batch}")
    private String readBatchTopic;

    @Value("${app.kafka.topics.migration-orchestrator}")
    private String orchestratorTopic;

    @Value("${app.kafka.topics.migration-job-completion-check}")
    private String completionCheckTopic;

    @Value("${app.kafka.topics.migration-step-execution-logs}")
    private String stepExecutionLogTopic;

    private final KafkaEventPublisherUtil kafkaEventPublisherUtil;

    /**
     * Publishes a structured DLQ event to the configured DLQ topic.
     *
     * @param errorCode      short machine-readable code (e.g. "PROCESSING_ERROR")
     * @param errorMessage   human-readable description
     * @param sourceTopic    original topic the failed message came from
     * @param originalRecord raw JSON payload of the failed record
     * @param foundCode      code of an entity found in DB (null when not applicable)
     */
    public void publishToDlq(String errorCode, String errorMessage,
                             String sourceTopic, String originalRecord, String foundCode) {
        try {
            DlqMessageEvent event = DlqMessageEvent.builder()
                    .errorCode(errorCode)
                    .errorMessage(errorMessage)
                    .sourceTopic(sourceTopic)
                    .originalRecord(originalRecord)
                    .foundCode(foundCode)
                    .build();

            String payload = ObjectMapperUtil.convertObjectToString(event);
            kafkaEventPublisherUtil.publishEventToKafkaTopic(dlqTopic, payload);

            log.info("[{}] DLQ event published | errorCode={} foundCode={}",
                    sourceTopic, errorCode, foundCode);
        } catch (Exception e) {
            log.error("[{}] Failed to publish DLQ event | errorCode={} | error={}",
                    sourceTopic, errorCode, e.getMessage(), e);
        }
    }


    public void pushReadBatchMsg(ReadBatchExecutionEntity readBatch, String nextCursor) {
        ReadBatchMessage msg = ReadBatchMessage.builder()
                .readBatchExecutionId(readBatch.getId())
                .batchNo(readBatch.getBatchNo())
                .nextCursor(nextCursor)
                .build();

        kafkaEventPublisherUtil.publishEventToKafkaTopic(readBatchTopic, readBatch.getId(), ObjectMapperUtil.convertObjectToString(msg));
        log.info("[KafkaUtil] Published read batch message batchNo={}", readBatch.getBatchNo());
    }

    public void pushOrchestrationMsg(String jobExecutionId, boolean lastBatch) {
        OrchestrationMessage msg = OrchestrationMessage.builder()
                .jobExecutionId(jobExecutionId)
                .lastBatch(lastBatch)
                .build();

        kafkaEventPublisherUtil.publishEventToKafkaTopic(orchestratorTopic, jobExecutionId,
                ObjectMapperUtil.convertObjectToString(msg));
        log.info("[KafkaUtil] Published orchestration message jobExecutionId={} lastBatch={}", jobExecutionId, lastBatch);
    }

    public void pushCompletionCheckMsg(String jobId, String jobExecutionId) {
        JobCompletionMessage msg = JobCompletionMessage.builder()
                .jobId(jobId)
                .jobExecutionId(jobExecutionId)
                .build();

        kafkaEventPublisherUtil.publishEventToKafkaTopic(completionCheckTopic, jobExecutionId, ObjectMapperUtil.convertObjectToString(msg));
        log.info("[KafkaUtil] Published completion check message {}", msg);
    }

    public void publishStepExecutionLog(String jobExecutionId, String batchId, String batchType,
                                        String stepName, String stepType, String status, String stepId,
                                        String errorMessage) {
        try {
            StepExecutionLogMessage message = StepExecutionLogMessage.builder()
                    .jobExecutionId(jobExecutionId)
                    .stepExecutionId(stepId)
                    .batchId(batchId)
                    .batchType(batchType)
                    .stepName(stepName)
                    .stepType(stepType)
                    .status(status)
                    .startedAt(status.equals("RUNNING") ? LocalDateTime.now() : null)
                    .completedAt(!status.equals("RUNNING") ? LocalDateTime.now() : null)
                    .errorMessage(errorMessage)
                    .build();

            kafkaEventPublisherUtil.publishEventToKafkaTopic(stepExecutionLogTopic, stepId,
                    ObjectMapperUtil.convertObjectToString(message));
        } catch (Exception e) {
            log.error("[StepExecutionLog] Failed to publish log for step={} status={}", stepName, status, e);
        }
    }
}

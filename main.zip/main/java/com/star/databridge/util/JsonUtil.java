package com.star.databridge.util;


import tools.jackson.databind.JsonNode;

public class JsonUtil {
    public static JsonNode extractData(JsonNode rootNode, String dotNotationPath) {

        // Convert dot notation/bracket notation path to JSON Pointer syntax (e.g., /results/0/data)
        String jsonPointerPath = convertToCanonicalJsonPointer(dotNotationPath);

        // Use JsonNode.at() which safely navigates the tree
        JsonNode targetNode = rootNode.at(jsonPointerPath);

        if (targetNode.isMissingNode()) {
            throw new RuntimeException("Target path did not resolve to a valid JSON: " + jsonPointerPath);
        }

        // Convert the JsonNode array into a Java List<JsonNode>
        return targetNode;
    }

    public static JsonNode safelyExtractData(JsonNode rootNode, String dotNotationPath) {

        try {
            return JsonUtil.extractData(rootNode, dotNotationPath);
        } catch (Exception e) {
            return null;
        }
    }

    private static String convertToCanonicalJsonPointer(String dotNotationPath) {
        String path = dotNotationPath.replace('.', '/').replace("[", "/").replace("]", "");
        if (!path.startsWith("/")) {
            path = "/" + path;
        }
        return path;
    }

    public static Object safeParse(String value) {
        if (value.isEmpty()) {
            return "";
        }
        try {
            // Try parsing as JSON
            return ObjectMapperUtil.readTree(value);
        } catch (Exception e) {
            // Not valid JSON → return as plain string
            return value;
        }
    }
}

package com.star.databridge.util;

import tools.jackson.databind.JsonNode;
import com.star.databridge.dto.reader.api.ApiVariable;
import lombok.RequiredArgsConstructor;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Shared variable resolution for reader/processor/sink configs.
 *
 * <p>Resolution rules:
 * <ul>
 *   <li>Builtin vars (supplied by the caller — e.g. pagination {@code BATCH_SIZE},
 *       {@code OFFSET}, {@code CURSOR}) are seeded first and always win over any
 *       same-named entry in {@code variables}. This lets configs declare a
 *       default ({@code static 0}) that is overridden by the runtime builtin.</li>
 *   <li>Each {@link ApiVariable} is resolved by its {@code type}: {@code static},
 *       {@code env}, {@code implementation}, {@code context}.</li>
 * </ul>
 */
@Service
@RequiredArgsConstructor
public class VariableResolver {

    /** Internal entity name → Salesforce object API name. */
    private static final Map<String, String> SF_ENTITY_MAP = Map.ofEntries(
            Map.entry("customer", "Account"),
            Map.entry("policy", "Asset"),
            Map.entry("policyMember", "AssetRelationship"),
            Map.entry("hospital", "Account"),
            Map.entry("proposalUpdate", ""),
            Map.entry("agent", "Account"),
            Map.entry("office", "OfficeMaster__c"),
            Map.entry("salesManager", "Account"),
            Map.entry("emi","EMI__c")
    );
    /** Internal entity name → Salesforce external ID field used for upsert. */
    private static final Map<String, String> SF_FIELD_MAP = Map.ofEntries(
            Map.entry("customer", "DLUniqueId__c"),
            Map.entry("policy", "PolicyNumber__c"),
            Map.entry("policyMember", "DLUniqueId__c"),
            Map.entry("hospital", "HospitalId__c"),
            Map.entry("proposalUpdate", "proposal-default"),
            Map.entry("agent", "AgentCode__c"),
            Map.entry("office", "OfficeCode__c"),
            Map.entry("salesManager", "SMCode__c"),
            Map.entry("emi","UniqueEMIId__c")
    );

    private final Environment env;

    public Map<String, String> resolve(List<ApiVariable> variables,
                                       Map<String, String> builtinVars,
                                       Map<String, JsonNode> stepOutputs) {
        Map<String, String> resolved = new LinkedHashMap<>();
        if (builtinVars != null) {
            resolved.putAll(builtinVars);
        }
        if (variables == null) {
            return resolved;
        }

        for (ApiVariable var : variables) {
            // Builtin wins: if a pagination/caller-supplied value is already seeded
            // for this key, skip the config entry (which usually just declares a default).
            if (resolved.containsKey(var.getName())) continue;

            String value = switch (var.getType().toLowerCase()) {
                case "static" -> String.valueOf(var.getValue());
                case "env" -> env.getProperty(String.valueOf(var.getValue()));
                case "implementation" -> resolveImplementation(String.valueOf(var.getValue()), resolved);
                case "context" -> DataUtil.resolveFromContext(String.valueOf(var.getValue()), stepOutputs, resolved);
                default -> String.valueOf(var.getValue());
            };
            resolved.put(var.getName(), value);
        }
        return resolved;
    }

    /**
     * Resolves named implementation methods to runtime values.
     *
     * <p>{@code resolvedSoFar} contains all variables already resolved in this call
     * (builtins + earlier entries in the variables list). Entity-type methods read
     * {@code ENTITY_TYPE} from it — callers must inject it as a builtin var first.
     *
     * <p>Extend {@link #SF_ENTITY_MAP} / {@link #SF_FIELD_MAP} to add new entity
     * mappings without touching this method.
     */
    private String resolveImplementation(String methodName, Map<String, String> resolvedSoFar) {
        return switch (methodName) {
            case "getToday" -> LocalDate.now().toString();
            case "getYesterday" -> LocalDate.now().minusDays(1).toString();
            case "get30minBefore" -> LocalDateTime.now().minusMinutes(30).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"));
            case "getSalesForceEntity" -> SF_ENTITY_MAP.getOrDefault(
                    resolvedSoFar.get("ENTITY_TYPE"), "");
            case "getSalesForceFieldName" -> SF_FIELD_MAP.getOrDefault(
                    resolvedSoFar.get("ENTITY_TYPE"), "");
            default -> throw new IllegalArgumentException(
                    "Unknown implementation variable: " + methodName);
        };
    }
}

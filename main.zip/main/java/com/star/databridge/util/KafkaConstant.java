package com.star.databridge.util;

public class KafkaConstant {

    public static final String AUTO_OFFSET_RESET_CONFIG = "latest";
    public static final int HEARTBEAT_INTERVAL_MS_CONFIG = 5000;
    public static final String ISOLATION_LEVEL_CONFIG = "read_committed";
}

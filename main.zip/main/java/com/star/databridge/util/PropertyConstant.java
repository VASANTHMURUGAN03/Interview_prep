package com.star.databridge.util;

import io.micrometer.common.util.StringUtils;
import jakarta.annotation.PostConstruct;
import lombok.Data;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Data
@Component
public class PropertyConstant {
    private Environment environment;

    public PropertyConstant(Environment environment) {
        this.environment = environment;
    }

    private int genericRestTemplateReadTimeOut;

    @PostConstruct
    public void init() {
        this.setGenericRestTemplateReadTimeOut(Integer.parseInt(
                checkForMandatoryProperty("rest.generic.config.read-timeout")));
    }

    public String checkForMandatoryProperty(String property) {
        String propertyValue = environment.getProperty(property);
        if (StringUtils.isEmpty(propertyValue)) {
            throw new IllegalArgumentException("Property " + property + " is mandatory");
        }
        return propertyValue;
    }
}

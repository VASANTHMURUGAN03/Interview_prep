package com.star.databridge.util.processor;


import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ObjectNode;
import com.star.databridge.constant.ApiConstant;
import com.star.databridge.dto.reader.api.*;
import com.star.databridge.util.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Single point of truth for all HTTP API step execution — used by the read layer,
 * the process layer, and the sink layer.
 *
 * <p>Execution order for each call:
 * <ol>
 *   <li>Delegate variable resolution to {@link VariableResolver} — merges builtins
 *       with the {@code variables} list and resolves by type
 *       ({@code static}, {@code env}, {@code implementation}, {@code context}).</li>
 *   <li>Substitute {@code ${VAR}} placeholders in headers, body, query, path, and URL
 *       via {@link DataUtil#substitute}.</li>
 *   <li>Call the API.</li>
 *   <li>Extract the configured response fields and return them as an {@link ObjectNode}.</li>
 * </ol>
 *
 * <p>Pagination is intentionally excluded — that is owned by the read layer.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ApiCallExecutor {

    private final Environment env;
    private final ObjectMapper objectMapper;
    private final RestTemplateUtils restTemplateUtils;
    private final VariableResolver variableResolver;


    /**
     * @param request     request config (endpoint, headers, body, variables, …)
     * @param response    response extraction config
     * @param builtinVars pre-resolved variables injected by the caller (e.g. BATCH_SIZE, OFFSET)
     * @param stepOutputs accumulated step context for {@code context}-type variables;
     *                    pass {@code null} or empty when not in a process step
     * @return extracted response as an {@link ObjectNode} keyed by the response param names
     */
    public JsonNode execute(ApiRequestConfig request, ApiResponseConfig response,
                            Map<String, String> builtinVars, Map<String, JsonNode> stepOutputs) {

        // 1. Resolve all variables into a flat map
        Map<String, String> vars = variableResolver.resolve(request.getVariables(), builtinVars, stepOutputs);
        log.info("Variables picked from job config: request -{},vars-{},",request, vars);

        // 2. Resolve headers (substitute ${VAR} in values)
        Map<String, String> headers = substituteHeaders(request.getHeaders(), vars);

        // 3. Build body / query maps
        Map<String, Object> body = buildParamMap(request.getBody(), vars);
        Map<String, Object> query = buildParamMap(request.getQuery(), vars);

        // 3a. Resolve rawBody if present
        String resolvedRawBody = String.valueOf(DataUtil.substitute(request.getRawBody(), vars));

        // 4. Resolve URL (basePath is always an env property key; URL may have path vars)
        String baseUrl = env.getProperty(request.getEndpoint().getBasePath());
        String url = baseUrl + DataUtil.substitute(request.getEndpoint().getUrl(), vars);
        String responseType = Optional.ofNullable(response).map(ApiResponseConfig::getType).orElse("JSON");

        log.info("[ApiCallExecutor] {} {}", request.getEndpoint().getMethod().toUpperCase(), url);

        // 5. Call the API
        JsonNode rawResponse = callApi(request.getEndpoint().getMethod(), url, body, query, headers,
                resolvedRawBody, responseType);

        // 6. Extract and return response fields
        return extractResponse(rawResponse, response);
    }

    // -------------------------------------------------------------------------
    // Header / param substitution
    // -------------------------------------------------------------------------

    private Map<String, String> substituteHeaders(Map<String, String> configHeaders,
                                                  Map<String, String> vars) {
        if (configHeaders == null) return Collections.emptyMap();
        Map<String, String> resolved = new LinkedHashMap<>();
        configHeaders.forEach((k, v) -> resolved.put(k, String.valueOf(DataUtil.substitute(v, vars))));
        return resolved;
    }

    private Map<String, Object> buildParamMap(List<ApiParam> params, Map<String, String> vars) {
        Map<String, Object> map = new LinkedHashMap<>();
        if (params == null) return map;

        for (ApiParam param : params) {
            if ("static".equalsIgnoreCase(param.getType())) {
                map.put(param.getName(), param.getValue());
            } else {
                // dynamic — substitute ${VAR} placeholders in the template value
                map.put(param.getName(), DataUtil.substitute(String.valueOf(param.getValue()), vars));
            }
        }
        return map;
    }

    // -------------------------------------------------------------------------
    // API call dispatch
    // -------------------------------------------------------------------------

    private JsonNode callApi(String method, String url, Map<String, Object> body,
                             Map<String, Object> query, Map<String, String> headers,
                             String rawBody, String responseType) {
        boolean isFormEncoded = headers.values().stream()
                .anyMatch(v -> v != null && v.contains("application/x-www-form-urlencoded"));

        Class<?> responseClass = ApiConstant.RESPONSE_TYPE.get(responseType);

        Object response = switch (method.toUpperCase()) {
            case "POST" -> {
                Object reqBody = !rawBody.isEmpty() ? rawBody : body;
                if (isFormEncoded) {
                    yield restTemplateUtils.postFormUrlEncoded(url, headers, toStringMap(body), responseClass);
                } else {
                    yield restTemplateUtils.postForObject(url, headers, reqBody, responseClass);
                }
            }
            case "PUT" -> !rawBody.isEmpty() ?
                    restTemplateUtils.putForObject(url, headers, rawBody, responseClass)
            : restTemplateUtils.putForObject(url, headers, body, responseClass);
            case "GET" -> restTemplateUtils.getForObject(url, headers, body, responseClass);
            case "PATCH" -> restTemplateUtils.patchForObject(url, headers, body, responseClass);
            default -> throw new IllegalArgumentException("Unsupported HTTP method: " + method);
        };

        if (responseClass == String.class) {
            JsonNode textNode = objectMapper.valueToTree(response);
            ObjectNode jsonResponse = objectMapper.createObjectNode();
            jsonResponse.set("response", textNode);
            return jsonResponse;
        }

        return (JsonNode) response;
    }

    private Map<String, String> toStringMap(Map<String, Object> map) {
        Map<String, String> result = new LinkedHashMap<>();
        map.forEach((k, v) -> result.put(k, String.valueOf(v)));
        return result;
    }

    // -------------------------------------------------------------------------
    // Response extraction
    // -------------------------------------------------------------------------

    private JsonNode extractResponse(JsonNode rawResponse, ApiResponseConfig responseConfig) {
        if (responseConfig == null || responseConfig.getParams() == null) {
            return rawResponse;
        }

        ObjectNode result = objectMapper.createObjectNode();

        for (ApiResponseParamConfig param : responseConfig.getParams()) {
            result.set(param.getKey(), JsonUtil.safelyExtractData(rawResponse, param.getValue()));
        }
        return result;
    }
}

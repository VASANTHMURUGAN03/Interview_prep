package com.star.databridge.util;

import tools.jackson.databind.JsonNode;
import com.star.databridge.exception.RestTemplateErrorCodes;
import com.star.databridge.exception.RestTemplateException;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.*;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Map;
import java.util.Objects;

@Slf4j
@Data
@Component
@RequiredArgsConstructor
public class RestTemplateUtils {

    private final RestClient restClient;

    public <T> T getForObject(String url, Map<String, String> headers, Map<String, Object> queryParams, Class<T> clazz)
            throws RestTemplateException {
        UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromUriString(url);
        for (Map.Entry<String, Object> entry : queryParams.entrySet()) {
            uriComponentsBuilder.queryParam(entry.getKey(), entry.getValue());
        }
        return getForObject(uriComponentsBuilder.toUriString(), headers,clazz);
    }

    public <T> T getForObject(String url, Map<String, String> headers, Class<T> clazz) throws RestTemplateException {
        HttpEntity<?> request = getHeader(headers);
        UriComponents uriComponents = UriComponentsBuilder.fromUriString(url).build();

        try {
            log.info("Url : {}, Request : {}", url, ObjectMapperUtil.convertObjectToString(request));

            var response = restClient.get().uri(uriComponents.encode().toUri())
                    .headers(httpHeaders -> {
                        headers.forEach(httpHeaders::add);
                    }).retrieve()
                    .body(clazz);
            log.info("RestTemplateUtils.getForObject - response: {}", response);
            return response;

        } catch (ResourceAccessException e) {
            log.error(LogConstants.TIMEOUT_EXCEPTION, e.getMessage(), e);
            throw new RestTemplateException(RestTemplateErrorCodes.DOWNSTREAM_CONNECT_TIMEOUT_ERROR);
        } catch (HttpServerErrorException e) {
            log.error(LogConstants.RESPONSE_STATUS_CODE,
                    e.getStatusCode(), e.getResponseBodyAsString(), url, e);
            if(e.getStatusCode().value() == 503) throw new RestTemplateException(RestTemplateErrorCodes.DOWNSTREAM_SERVICE_NOT_AVAILABLE);
            throw new RestTemplateException(RestTemplateErrorCodes.FAILED_TO_GET_RESPONSE_FROM_DOWN_STREAM_SYSTEM);
        } catch (HttpClientErrorException e) {
            log.error(LogConstants.RESPONSE_STATUS_CODE,
                    e.getStatusCode(), e.getResponseBodyAsString(), url, e);
            throw new RestTemplateException(RestTemplateErrorCodes.INVALID_PAYLOAD,
                    e.getResponseBodyAsString(), uriComponents.encode().toUri().toString());
        } catch (Exception e) {
            log.error(LogConstants.ERROR, e.getMessage(), e);
            throw new RestTemplateException(RestTemplateErrorCodes.SOMETHING_WENT_WRONG, e.getMessage(), uriComponents.encode().toUri().toString());
        }

    }

    public <T> T putForObject(String url, Map<String, String> headers, Map<String, Object> payload, Class<T> clazz) {
        HttpEntity<?> request = getHeader(headers, payload);
        UriComponents uriComponents = UriComponentsBuilder.fromUriString(url).build();

        try {
            log.info("Request : {}", ObjectMapperUtil.convertObjectToString(request));
            var response = restClient.put().uri(uriComponents.encode().toUri())
                    .headers(httpHeaders -> {
                        headers.forEach(httpHeaders::add);
                    })
                    .body(payload)
                    .retrieve()
                    .body(clazz);
            log.info("RestTemplateUtils.putForObject - response: {}", response);
            return response;

        } catch (ResourceAccessException e) {
            log.error(LogConstants.TIMEOUT_EXCEPTION, e.getMessage(), e);
            throw new RestTemplateException(RestTemplateErrorCodes.DOWNSTREAM_CONNECT_TIMEOUT_ERROR);
        } catch (HttpServerErrorException e) {
            log.error(LogConstants.RESPONSE_STATUS_CODE,
                    e.getStatusCode(), e.getResponseBodyAsString(), url, e);
            if(e.getStatusCode().value() == 503) throw new RestTemplateException(RestTemplateErrorCodes.DOWNSTREAM_SERVICE_NOT_AVAILABLE);
            throw new RestTemplateException(RestTemplateErrorCodes.FAILED_TO_GET_RESPONSE_FROM_DOWN_STREAM_SYSTEM);
        } catch (HttpClientErrorException e) {
            log.error(LogConstants.RESPONSE_STATUS_CODE,
                    e.getStatusCode(), e.getResponseBodyAsString(), url, e);
            throw new RestTemplateException(RestTemplateErrorCodes.INVALID_PAYLOAD,
                    e.getResponseBodyAsString(), uriComponents.encode().toUri().toString());
        } catch (Exception e) {
            log.error(LogConstants.ERROR, e.getMessage(), e);
            throw new RestTemplateException(RestTemplateErrorCodes.SOMETHING_WENT_WRONG, e.getMessage(), uriComponents.encode().toUri().toString());
        }
    }

    // For CSV push
    public <T> T putForObject(String url, Map<String, String> headers, String payload, Class<T> clazz) {
        UriComponents uriComponents = UriComponentsBuilder.fromUriString(url).build();

        try {
            log.info("Header: {}, Request : {}", headers, payload);
            var response = restClient.put().uri(uriComponents.encode().toUri())
                    .headers(httpHeaders -> headers.forEach(httpHeaders::add))
                    .body(payload)
                    .retrieve()
                    .body(clazz);
            log.info("RestTemplateUtils.putForObject - response: {}", response);
            return response;

        } catch (ResourceAccessException e) {
            log.error(LogConstants.TIMEOUT_EXCEPTION, e.getMessage(), e);
            throw new RestTemplateException(RestTemplateErrorCodes.DOWNSTREAM_CONNECT_TIMEOUT_ERROR);
        } catch (HttpServerErrorException e) {
            log.error(LogConstants.RESPONSE_STATUS_CODE,
                    e.getStatusCode(), e.getResponseBodyAsString(), url, e);

            if(e.getStatusCode().value() == 503) {
                throw new RestTemplateException(RestTemplateErrorCodes.DOWNSTREAM_SERVICE_NOT_AVAILABLE);
            }
            throw new RestTemplateException(RestTemplateErrorCodes.FAILED_TO_GET_RESPONSE_FROM_DOWN_STREAM_SYSTEM);
        } catch (HttpClientErrorException e) {
            log.error(LogConstants.RESPONSE_STATUS_CODE,
                    e.getStatusCode(), e.getResponseBodyAsString(), url, e);
            throw new RestTemplateException(RestTemplateErrorCodes.INVALID_PAYLOAD,
                    e.getResponseBodyAsString(), uriComponents.encode().toUri().toString());
        } catch (Exception e) {
            log.error(LogConstants.ERROR, e.getMessage(), e);
            throw new RestTemplateException(RestTemplateErrorCodes.SOMETHING_WENT_WRONG, e.getMessage(), uriComponents.encode().toUri().toString());
        }
    }

    public <T> T postForObject(String url, Map<String, String> headers, Object payload, Class<T> clazz)
            throws RestTemplateException {
        HttpEntity<?> request = getHeader(headers, payload);
        UriComponents uriComponents = UriComponentsBuilder.fromUriString(url).build();
        try {
            log.info(LogConstants.REQUEST_LOG_MESSAGE, ObjectMapperUtil.convertObjectToString(request),
                    uriComponents.encode().toUri());

            var response = restClient.post().uri(uriComponents.encode().toUri())
                    .headers(httpHeaders -> headers.forEach(httpHeaders::add))
                    .body(payload)
                    .retrieve()
                    .body(clazz);

            log.info("RestTemplateUtils.postForObject - response: {}", response);
            return response;

        } catch (ResourceAccessException e) {
            log.error(LogConstants.TIMEOUT_EXCEPTION, e.getMessage(), e);
            throw new RestTemplateException(RestTemplateErrorCodes.DOWNSTREAM_CONNECT_TIMEOUT_ERROR);
        } catch (HttpServerErrorException e) {
            log.error(LogConstants.RESPONSE_STATUS_CODE,
                    e.getStatusCode(), e.getResponseBodyAsString(), url, e);
            if(e.getStatusCode().value() == 503) {
                throw new RestTemplateException(RestTemplateErrorCodes.DOWNSTREAM_SERVICE_NOT_AVAILABLE);
            }
            throw new RestTemplateException(RestTemplateErrorCodes.FAILED_TO_GET_RESPONSE_FROM_DOWN_STREAM_SYSTEM);
        } catch (HttpClientErrorException e) {
            log.error(LogConstants.RESPONSE_STATUS_CODE,
                    e.getStatusCode(), e.getResponseBodyAsString(), url, e);
            throw new RestTemplateException(RestTemplateErrorCodes.INVALID_PAYLOAD,
                    e.getResponseBodyAsString(), uriComponents.encode().toUri().toString());
        } catch (Exception e) {
            log.error(LogConstants.ERROR, e.getMessage(), e);
            throw new RestTemplateException(RestTemplateErrorCodes.SOMETHING_WENT_WRONG, e.getMessage(), uriComponents.encode().toUri().toString());
        }
    }

    public String postForRedirectUrl(String url, Map<String, String> headers, Map<String, Object> payload)
            throws RestTemplateException {
        HttpEntity<?> request = getHeader(headers, payload);
        UriComponents uriComponents = UriComponentsBuilder.fromUriString(url).build();

        try {
            log.info(LogConstants.REQUEST_LOG_MESSAGE, ObjectMapperUtil.convertObjectToString(request), uriComponents.encode().toUri());
            long startTime = System.currentTimeMillis();

            // Modern RestClient fluent post execution
            ResponseEntity<Void> response = restClient.post()
                    .uri(uriComponents.encode().toUri())
                    .headers(httpHeaders -> {
                        if (headers != null) {
                            headers.forEach(httpHeaders::add);
                        }
                    })
                    .body(payload)
                    .retrieve()// RestClient automatically uses Jackson to serialize the payload map
                    // CRITICAL: Prevent RestClient from throwing exceptions on 3xx redirections
                    .onStatus(HttpStatusCode::is3xxRedirection, (req, res) -> {
                        // Do nothing here: let the response bypass default error handlers
                        // so it passes down to the ResponseEntity below.
                    })
                    .toBodilessEntity();

            log.info(LogConstants.FETCHED, uriComponents.encode().toUri(), System.currentTimeMillis() - startTime);
            log.info("Response status: {}", response.getStatusCode());

            if (response.getStatusCode() == HttpStatus.FOUND || response.getStatusCode().is3xxRedirection()) {
                String redirectUrl = Objects.requireNonNull(response.getHeaders().getLocation()).toString();
                log.info("Redirected Location: {}", redirectUrl);
                return redirectUrl;
            }
            throw new RestTemplateException(
                    RestTemplateErrorCodes.FAILED_TO_GET_RESPONSE_FROM_DOWN_STREAM_SYSTEM,
                    "Expected redirect but got: " + response.getStatusCode()
            );
        } catch (ResourceAccessException e) {
            log.error(LogConstants.TIMEOUT_EXCEPTION, e.getMessage(), e);
            throw new RestTemplateException(RestTemplateErrorCodes.DOWNSTREAM_CONNECT_TIMEOUT_ERROR);
        } catch (HttpServerErrorException e) {
            log.error(LogConstants.RESPONSE_STATUS_CODE,
                    e.getStatusCode(), e.getResponseBodyAsString(), url, e);
            if(e.getStatusCode().value() == 503) throw new RestTemplateException(RestTemplateErrorCodes.DOWNSTREAM_SERVICE_NOT_AVAILABLE);
            throw new RestTemplateException(RestTemplateErrorCodes.FAILED_TO_GET_RESPONSE_FROM_DOWN_STREAM_SYSTEM);
        } catch (HttpClientErrorException e) {
            log.error(LogConstants.RESPONSE_STATUS_CODE,
                    e.getStatusCode(), e.getResponseBodyAsString(), url, e);
            throw new RestTemplateException(RestTemplateErrorCodes.INVALID_PAYLOAD,
                    e.getResponseBodyAsString(), uriComponents.encode().toUri().toString());
        } catch (Exception e) {
            log.error(LogConstants.ERROR, e.getMessage(), e);
            throw new RestTemplateException(RestTemplateErrorCodes.SOMETHING_WENT_WRONG, e.getMessage(), uriComponents.encode().toUri().toString());
        }
    }

    private HttpEntity<?> getHeader(Map<String, String> headers) {
        HttpHeaders header = new HttpHeaders();
        headers.entrySet().forEach(entry ->
            header.set(entry.getKey(), entry.getValue()));
        return new HttpEntity<>(header);
    }

    private HttpEntity<?> getHeader(Map<String, String> headers, Object payload) {
        HttpHeaders header = new HttpHeaders();
        headers.forEach(header::set);
        return new HttpEntity<>(payload, header);
    }

    public <T> T postForObjectWithCustomRestTemplate(String url, Map<String, String> headers, Map<String, Object>
            payload, Class<T> clazz)
            throws RestTemplateException {
        HttpEntity<?> request = getHeader(headers, payload);
        UriComponents uriComponents = UriComponentsBuilder.fromUriString(url).build();

        try {
            log.info(LogConstants.REQUEST_LOG_MESSAGE, ObjectMapperUtil.convertObjectToString(request),
                    uriComponents.encode().toUri());
            var response = restClient.post()
                    .uri(uriComponents.encode().toUri())
                    .headers(httpHeaders -> {
                        if (headers != null) headers.forEach(httpHeaders::add);
                    })
                    .body(payload)
                    .retrieve()
                    .body(clazz);
            log.info("RestTemplateUtils.postForObjectWithCustomRestTemplate - response: {}", response);
            return response;

        } catch (ResourceAccessException e) {
            log.error(LogConstants.TIMEOUT_EXCEPTION, e.getMessage(), e);
            throw new RestTemplateException(RestTemplateErrorCodes.DOWNSTREAM_CONNECT_TIMEOUT_ERROR);
        } catch (HttpServerErrorException e) {
            log.error(LogConstants.RESPONSE_STATUS_CODE,
                    e.getStatusCode(), e.getResponseBodyAsString(), url, e);
            if(e.getStatusCode().value() == 503) throw new RestTemplateException(RestTemplateErrorCodes.DOWNSTREAM_SERVICE_NOT_AVAILABLE);
            throw new RestTemplateException(RestTemplateErrorCodes.FAILED_TO_GET_RESPONSE_FROM_DOWN_STREAM_SYSTEM);
        } catch (HttpClientErrorException e) {
            log.error(LogConstants.RESPONSE_STATUS_CODE,
                    e.getStatusCode(), e.getResponseBodyAsString(), url, e);
            throw new RestTemplateException(RestTemplateErrorCodes.INVALID_PAYLOAD,
                    e.getResponseBodyAsString(), uriComponents.encode().toUri().toString());
        } catch (Exception e) {
            log.error(LogConstants.ERROR, e.getMessage(), e);
            throw new RestTemplateException(RestTemplateErrorCodes.SOMETHING_WENT_WRONG, e.getMessage(), uriComponents.encode().toUri().toString());
        }
    }
    public <T> T postFormUrlEncoded(String url, Map<String, String> headers, Map<String, String> formParams,
                                    Class<T> clazz) throws RestTemplateException {
        HttpHeaders httpHeadersVal = new HttpHeaders();
        headers.forEach(httpHeadersVal::set);
        httpHeadersVal.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        // Convert payload to MultiValueMap for form-urlencoded requests
        MultiValueMap<String, String> body = new LinkedMultiValueMap<>();
        body.setAll(formParams);  // Directly put all key-value pairs

        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(body, httpHeadersVal);
        UriComponents uriComponents = UriComponentsBuilder.fromUriString(url).build();

        try {
            log.info(LogConstants.REQUEST_LOG_MESSAGE,
                    ObjectMapperUtil.convertObjectToString(request), uriComponents.encode().toUri());

            var response = restClient.post()
                    .uri(uriComponents.encode().toUri())
                    .headers(httpHeaders -> {
                        headers.forEach(httpHeadersVal::add);
                        // Explicitly keeping your contentType override rule safely
                        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
                    })
                    .body(body) // RestClient auto-serializes MultiValueMap as form parameters
                    .retrieve()
                    .body(clazz);
            log.info("RestTemplateUtils.postFormUrlEncoded - response: {}", response);
            return response;
        } catch (ResourceAccessException e) {
            log.error(LogConstants.TIMEOUT_EXCEPTION, e.getMessage(), e);
            throw new RestTemplateException(RestTemplateErrorCodes.DOWNSTREAM_CONNECT_TIMEOUT_ERROR);
        } catch (HttpServerErrorException e) {
            log.error(LogConstants.RESPONSE_STATUS_CODE,
                    e.getStatusCode(), e.getResponseBodyAsString(), url, e);
            if(e.getStatusCode().value() == 503) throw new RestTemplateException(RestTemplateErrorCodes.DOWNSTREAM_SERVICE_NOT_AVAILABLE);
            throw new RestTemplateException(RestTemplateErrorCodes.FAILED_TO_GET_RESPONSE_FROM_DOWN_STREAM_SYSTEM);
        } catch (HttpClientErrorException e) {
            log.error(LogConstants.RESPONSE_STATUS_CODE,
                    e.getStatusCode(), e.getResponseBodyAsString(), url, e);
            throw new RestTemplateException(RestTemplateErrorCodes.INVALID_PAYLOAD,
                    e.getResponseBodyAsString(), uriComponents.encode().toUri().toString());
        } catch (Exception e) {
            log.error(LogConstants.ERROR, e.getMessage(), e);
            throw new RestTemplateException(RestTemplateErrorCodes.SOMETHING_WENT_WRONG, e.getMessage(), uriComponents.encode().toUri().toString());
        }
    }

    public JsonNode postForObjectToJsonNode(String url, Map<String, String> headers, Map<String, Object> payload)
            throws RestTemplateException {
        HttpEntity<?> request = getHeader(headers, payload);
        UriComponents uriComponents = UriComponentsBuilder.fromUriString(url).build();

        try {
            log.info(LogConstants.REQUEST_LOG_MESSAGE, ObjectMapperUtil.convertObjectToString(request),
                    uriComponents.encode().toUri());
            long startTime = System.currentTimeMillis();
            JsonNode response = restClient.post()
                    .uri(uriComponents.encode().toUri())
                    .headers(httpHeaders -> {
                        headers.forEach(httpHeaders::add);
                    })
                    .body(payload)
                    .retrieve()
                    .body(JsonNode.class);
            log.info("RestTemplateUtils.postForObjectToJsonNode - response: {}", response);
            return response;

        } catch (ResourceAccessException e) {
            log.error(LogConstants.TIMEOUT_EXCEPTION, e.getMessage(), e);
            throw new RestTemplateException(RestTemplateErrorCodes.DOWNSTREAM_CONNECT_TIMEOUT_ERROR);
        } catch (HttpServerErrorException e) {
            log.error(LogConstants.RESPONSE_STATUS_CODE,
                    e.getStatusCode(), e.getResponseBodyAsString(), url, e);
            if(e.getStatusCode().value() == 503) throw new RestTemplateException(RestTemplateErrorCodes.DOWNSTREAM_SERVICE_NOT_AVAILABLE);
            throw new RestTemplateException(RestTemplateErrorCodes.FAILED_TO_GET_RESPONSE_FROM_DOWN_STREAM_SYSTEM);
        } catch (HttpClientErrorException e) {
            log.error(LogConstants.RESPONSE_STATUS_CODE,
                    e.getStatusCode(), e.getResponseBodyAsString(), url, e);
            throw new RestTemplateException(RestTemplateErrorCodes.INVALID_PAYLOAD,
                    e.getResponseBodyAsString(), uriComponents.encode().toUri().toString());
        } catch (Exception e) {
            log.error(LogConstants.ERROR, e.getMessage(), e);
            throw new RestTemplateException(RestTemplateErrorCodes.SOMETHING_WENT_WRONG, e.getMessage(), uriComponents.encode().toUri().toString());
        }
    }

    public <T> T patchForObject(String url,
                                Map<String, String> headers,
                                Map<String, Object> payload,
                                Class<T> clazz) {

        HttpEntity<?> request = getHeader(headers, payload);
        UriComponents uriComponents = UriComponentsBuilder.fromUriString(url).build();

        try {
            log.info("Request : {}", ObjectMapperUtil.convertObjectToString(request));

            var response = restClient.patch()
                    .uri(uriComponents.encode().toUri())
                    .headers(httpHeaders -> {
                        headers.forEach(httpHeaders::add);
                    })
                    .body(payload)
                    .retrieve()
                    .body(clazz);
            log.info("RestTemplateUtils.patchForObject - response: {}", response);
            return response;

        } catch (ResourceAccessException e) {
            log.error(LogConstants.TIMEOUT_EXCEPTION, e.getMessage(), e);
            throw new RestTemplateException(
                    RestTemplateErrorCodes.DOWNSTREAM_CONNECT_TIMEOUT_ERROR);

        } catch (HttpServerErrorException e) {
            log.error(LogConstants.RESPONSE_STATUS_CODE,
                    e.getStatusCode(),
                    e.getResponseBodyAsString(),
                    url, e);

            if (e.getStatusCode().value() == 503) {
                throw new RestTemplateException(
                        RestTemplateErrorCodes.DOWNSTREAM_SERVICE_NOT_AVAILABLE);
            }

            throw new RestTemplateException(
                    RestTemplateErrorCodes.FAILED_TO_GET_RESPONSE_FROM_DOWN_STREAM_SYSTEM);

        } catch (HttpClientErrorException e) {
            log.error(LogConstants.RESPONSE_STATUS_CODE,
                    e.getStatusCode(),
                    e.getResponseBodyAsString(),
                    url, e);

            throw new RestTemplateException(
                    RestTemplateErrorCodes.INVALID_PAYLOAD,
                    e.getResponseBodyAsString(),
                    uriComponents.encode().toUri().toString());

        } catch (Exception e) {
            log.error(LogConstants.ERROR, e.getMessage(), e);
            throw new RestTemplateException(
                    RestTemplateErrorCodes.SOMETHING_WENT_WRONG,
                    e.getMessage(),
                    uriComponents.encode().toUri().toString());
        }
    }

}
package com.star.databridge.util;


import tools.jackson.databind.JsonNode;
import lombok.extern.slf4j.Slf4j;

import java.util.Map;

@Slf4j
public class DataUtil {
    /**
     * Resolves a {@code context}-type variable from accumulated step outputs.
     * Supports plain step name ({@code "CreateSalesForceJWT"}) and dot-notation
     * ({@code "fetchSalesForceAccessToken.accessToken"}).
     */
    public static JsonNode resolveFromContext(String ref, Map<String, JsonNode> stepOutputs) {
        if (stepOutputs == null) {
            return null;
        }

        String[] parts = ref.split("\\.", 2);
        JsonNode stepOutput = stepOutputs.get(parts[0]);
        if (stepOutput == null) {
            return null;
        }
        if (parts.length == 1) {
            return stepOutput;
        }
        return stepOutput.get(parts[1]);
    }

    public static String resolveFromContext(String ref, Map<String, JsonNode> stepOutputs, Map<String, String> resolvedSoFar) {
        if (resolvedSoFar != null && resolvedSoFar.containsKey(ref)) {
            return resolvedSoFar.get(ref);
        }

        JsonNode field = resolveFromContext(ref, stepOutputs);
        if(field == null) return null;
        if(field.isString()) return field.asString();
        return field.toString();
    }

    /**
     * Replaces every {@code ${KEY}} occurrence in {@code template} with the resolved
     * value from {@code vars}. Null values resolve to empty strings.
     */
    public static Object substitute(String template, Map<String, String> vars) {
        if (template == null) return "";
        String result = template;
        for (Map.Entry<String, String> e : vars.entrySet()) {
            result = result.replace("${" + e.getKey() + "}", e.getValue() != null ? e.getValue() : "");
        }
        return JsonUtil.safeParse(result);
    }
}

package com.star.databridge.util;

public class LogConstants {
    public static final String REQUEST_LOG_MESSAGE = "Request : {} to URL: {} ";
    public static final String ERROR = "Error : {}, {}";
    public static final String WENT_LOG = "something went Wrong with url: {} body"+" :-  {} statusCode {}";
    public static final String RESPONSE_STATUS_CODE = "ResponseStatusCode: {}, ErrorMessage: {}, url: {}";
    public static final String TIMEOUT_EXCEPTION = "Timeout exception : {}";
    public static final String RESPONSE = "Response : {}";
    public static final String FETCHED = "Fetched response for Url:{} in {}ms";


    private LogConstants() {
        throw new UnsupportedOperationException("LogConstants class- utils");
    }
}

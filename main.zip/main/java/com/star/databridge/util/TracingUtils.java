package com.star.databridge.util;

import io.micrometer.tracing.Span;
import io.micrometer.tracing.Tracer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.concurrent.Callable;

@Slf4j
@Service
@RequiredArgsConstructor
public class TracingUtils {

    private final Tracer tracer;

    public Runnable wrapRunnableWithSpan(String spanName, Runnable task) {
        Span parentSpan = tracer.currentSpan();

        return () -> {
            Span newSpan = tracer.nextSpan(parentSpan).name(spanName).start();
            try (Tracer.SpanInScope ws = tracer.withSpan(newSpan)) {
                task.run();
            } catch (Exception e) {
                newSpan.error(e);
                throw e;
            } finally {
                newSpan.end();
            }
        };
    }

    public <T> Callable<T> wrapCallableWithSpan(String spanName, Callable<T> task) {
        Span parentSpan = tracer.currentSpan();

        return () -> {
            Span newSpan = tracer.nextSpan(parentSpan).name(spanName).start();
            try (Tracer.SpanInScope ws = tracer.withSpan(newSpan)) {
                return task.call();
            } catch (Exception e) {
                newSpan.error(e);
                throw e;
            } finally {
                newSpan.end();
            }
        };
    }
}
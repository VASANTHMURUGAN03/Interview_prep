package com.star.databridge.util;

import io.micrometer.common.util.StringUtils;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component
public class MDCUtil {

    public static String get(String key) {
        Assert.isTrue(StringUtils.isNotBlank(key), "Key is blank");
        return MDC.get(key);
    }
    public static void put(String key, Object value) {
        Assert.notNull(value, "Value can't be null");
        if (get(key) == null)
            MDC.put(key, value.toString());
    }

    public static void clear() {
        MDC.clear();
    }

}
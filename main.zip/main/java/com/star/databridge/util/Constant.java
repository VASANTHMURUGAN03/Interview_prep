package com.star.databridge.util;

import lombok.experimental.UtilityClass;

@UtilityClass
public class Constant {
    public static String TRACE = "traceId";
}

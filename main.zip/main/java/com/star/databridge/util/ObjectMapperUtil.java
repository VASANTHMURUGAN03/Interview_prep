package com.star.databridge.util;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import tools.jackson.core.JacksonException;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.DeserializationFeature;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.cfg.DateTimeFeature;
import tools.jackson.databind.json.JsonMapper;
import com.star.databridge.exception.SyncErrorCode;
import com.star.databridge.exception.DataBridgeException;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@UtilityClass
public class ObjectMapperUtil {

    private final ObjectMapper objectMapper;
    public static final String ERROR_DESERIALIZING_JSON = "Error deserializing JSON";
    public static final String ERROR_SERIALIZING_JSON = "Error serializing JSON";


    static {
        // Jackson 3 makes ObjectMapper immutable, so configuration is applied via the builder.
        // Java time (JSR-310) support is auto-registered, so no module needs to be added explicitly.
        objectMapper = JsonMapper.builder()
                .configure(DateTimeFeature.WRITE_DATES_AS_TIMESTAMPS, false)
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
                .changeDefaultPropertyInclusion(incl -> incl.withValueInclusion(JsonInclude.Include.NON_NULL))
                .changeDefaultVisibility(vc -> vc.withFieldVisibility(JsonAutoDetect.Visibility.ANY))
                .build();
    }

    public static <T> T convertJsonToObject(String json, Class<T> targetType) {
        try {
            return objectMapper.readValue(json, targetType);
        } catch (Exception e) {
            log.error(ERROR_DESERIALIZING_JSON, e);
            throw new DataBridgeException(SyncErrorCode.SOMETHING_WENT_WRONG);
        }
    }

    public static <T> T convertJsonToObjectSilently(String json, Class<T> targetType) {
        try {
            return objectMapper.readValue(json, targetType);
        } catch (Exception e) {
            log.error(ERROR_DESERIALIZING_JSON, e);
            return null;
        }
    }

    public static <T> T convertJsonToObject(byte[] jsonBytes, TypeReference<T> typeReference) {
        try {
            return objectMapper.readValue(jsonBytes, typeReference);
        } catch (JacksonException e) {
            log.error(ERROR_DESERIALIZING_JSON, e);
            throw new DataBridgeException(SyncErrorCode.SOMETHING_WENT_WRONG);
        }
    }

    public static <T> T convertObject(Object request, Class<T> targetType) {
        return objectMapper.convertValue(request, targetType);
    }

    public static <T> T convertObject(Object request, TypeReference<T> typeReference) {
        return objectMapper.convertValue(request, typeReference);
    }

    public static <T> T convertJsonToObject(String str, TypeReference<T> typeReference) {
        try {
            return objectMapper.readValue(str, typeReference);
        } catch (JacksonException e) {
            log.error(ERROR_DESERIALIZING_JSON, e);
            throw new DataBridgeException(SyncErrorCode.SOMETHING_WENT_WRONG);
        }
    }

    public static <T> T convertJsonToObject(byte[] bytes, Class<T> targetType) {
        try {
            return objectMapper.readValue(bytes, targetType);
        } catch (Exception e) {
            log.error(ERROR_DESERIALIZING_JSON, e);
            throw new DataBridgeException(SyncErrorCode.SOMETHING_WENT_WRONG);
        }
    }

    public static <T> String convertObjectToString(T object) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (JacksonException e) {
            log.error(ERROR_SERIALIZING_JSON, e);
            throw new DataBridgeException(SyncErrorCode.SOMETHING_WENT_WRONG);
        }
    }

    public String convertToJsonString(Object data) {
        if (data == null) {
            return "null";
        }

        // Case 2: Already a String
        if (data instanceof String) {
            return data.toString();
        } else return convertObjectToString(data);
    }

    public static <T> String convertObjectToStringSilently(T object) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (JacksonException e) {
            log.error(ERROR_SERIALIZING_JSON, e);
            return null;
        }
    }

    public static JsonNode readTree(String object) {
        try {
            return objectMapper.readTree(object);
        } catch (JacksonException e) {
            log.error(ERROR_SERIALIZING_JSON + "object : {}", e, object);
            throw new DataBridgeException(SyncErrorCode.SOMETHING_WENT_WRONG);
        }
    }
    public static <T> T readValue(String value, Class<T> targetType) {
        try {
            return objectMapper.readValue(value, targetType);
        } catch (JacksonException e) {
            log.error(ERROR_SERIALIZING_JSON, e);
            throw new DataBridgeException(SyncErrorCode.SOMETHING_WENT_WRONG);
        }
    }

}

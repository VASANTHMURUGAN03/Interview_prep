package com.star.databridge.util;

import tools.jackson.databind.JsonNode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.util.Locale;

/**
 * Registry of named field-level transform implementations.
 *
 * <p>Each implementation maps a {@link JsonNode} input value to a {@link String} output
 * (or {@code null} on failure / unparseable input). New transforms are added by extending
 * the dispatch in {@link #apply(String, JsonNode)}.
 */
@Slf4j
@Service
public class FieldTransformer {

    private static final DateTimeFormatter SALESFORCE_DATE_FORMAT = DateTimeFormatter.ISO_LOCAL_DATE;
    private static final DateTimeFormatter SALESFORCE_DATETIME_FORMAT = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
    private static final DateTimeFormatter DD_MMM_YY = new DateTimeFormatterBuilder()
            .parseCaseInsensitive()
            .appendPattern("dd-MMM-yy")
            .toFormatter(Locale.ENGLISH);
    private static final DateTimeFormatter YYYY_MM_DD_HH_MM = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    private static final DateTimeFormatter YYYY_MM_DD_HH_MM_SS = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public String apply(String implementation, JsonNode value) {
        return switch (implementation) {
            case "safeConvertToYYYYMMDD" -> safeConvertToYYYYMMDD(value);
            case "safeConvertDateDDMMMYYToYYYYMMDD" -> safeConvertDateDDMMMYYToYYYYMMDD(value);
            case "safeConvertToDateTime" -> safeConvertToDateTime(value);
            case "safeConvertToLong" -> safeConvertToLong(value);
            case "safeConvertToBoolean" -> safeConvertToBoolean(value);
            case "safeConvertToDecimal" -> safeConvertToDecimal(value);
            case "safeTruncateString255" -> safeTruncate(value, 255);
            default -> throw new IllegalArgumentException(
                    "Unknown field transform implementation: " + implementation);
        };
    }

    private String asString(JsonNode value) {
        if (value == null || value.isNull()) return null;
        String s = value.asString();
        return (s == null || s.isBlank()) ? null : s.trim();
    }

    private String safeConvertToYYYYMMDD(JsonNode value) {
        String dateStr = asString(value);
        if (dateStr == null) return null;
        try {
            if (dateStr.matches("\\d{4}-\\d{2}-\\d{2}$")) {
                return dateStr;
            }
            if (dateStr.contains("T")) {
                String trimmed = dateStr;
                if (trimmed.endsWith("Z")) {
                    trimmed = trimmed.substring(0, trimmed.length() - 1);
                }
                if (trimmed.contains(".")) {
                    trimmed = trimmed.substring(0, trimmed.indexOf('.'));
                }
                return LocalDateTime.parse(trimmed).toLocalDate().format(SALESFORCE_DATE_FORMAT);
            }
            return LocalDate.parse(dateStr).format(SALESFORCE_DATE_FORMAT);
        } catch (Exception e) {
            log.warn("[FieldTransformer] Failed to format date: {}", dateStr, e);
            return null;
        }
    }

    private String safeConvertDateDDMMMYYToYYYYMMDD(JsonNode value) {
        String dateStr = asString(value);
        if (dateStr == null) return null;
        try {
            if (dateStr.contains("~")) {
                dateStr = dateStr.split("~")[0];
            }
            if (dateStr.matches("\\d{4}-\\d{2}-\\d{2}$")) {
                return LocalDate.parse(dateStr).format(SALESFORCE_DATE_FORMAT);
            }
            try {
                return LocalDate.parse(dateStr, DD_MMM_YY).format(SALESFORCE_DATE_FORMAT);
            } catch (DateTimeParseException ignore) {
                // fall through
            }
            if (dateStr.contains("T")) {
                String trimmed = dateStr;
                if (trimmed.endsWith("Z")) {
                    trimmed = trimmed.substring(0, trimmed.length() - 1);
                }
                if (trimmed.contains(".")) {
                    trimmed = trimmed.substring(0, trimmed.indexOf('.'));
                }
                return LocalDateTime.parse(trimmed).toLocalDate().format(SALESFORCE_DATE_FORMAT);
            }
            return LocalDate.parse(dateStr).format(SALESFORCE_DATE_FORMAT);
        } catch (Exception e) {
            log.warn("[FieldTransformer] Failed to format dd-MMM-yy date: {}", dateStr, e);
            return null;
        }
    }

    private String safeConvertToDateTime(JsonNode value) {
        String dateTimeStr = asString(value);
        if (dateTimeStr == null) return null;
        try {
            if (dateTimeStr.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}")) {
                return LocalDateTime.parse(dateTimeStr, YYYY_MM_DD_HH_MM).format(SALESFORCE_DATETIME_FORMAT);
            }
            if (dateTimeStr.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}")) {
                return LocalDateTime.parse(dateTimeStr, YYYY_MM_DD_HH_MM_SS).format(SALESFORCE_DATETIME_FORMAT);
            }
            return OffsetDateTime.parse(dateTimeStr, DateTimeFormatter.ISO_DATE_TIME).format(SALESFORCE_DATETIME_FORMAT);
        } catch (Exception e) {
            log.warn("[FieldTransformer] Failed to format datetime: {}", dateTimeStr, e);
            return null;
        }
    }

    private String safeConvertToLong(JsonNode value) {
        if (value == null || value.isNull()) return null;
        try {
            if (value.isNumber()) {
                return Long.toString(value.asLong());
            }
            String s = value.asString   ();
            if (s == null || s.isBlank()) return null;
            return Long.toString(new BigDecimal(s.trim()).longValue());
        } catch (Exception e) {
            log.warn("[FieldTransformer] Failed to parse long value: {}", value, e);
            return null;
        }
    }

    private String safeConvertToBoolean(JsonNode value) {
        if (value == null || value.isNull()) return null;
        if (value.isBoolean()) return Boolean.toString(value.asBoolean());
        String s = value.asString();
        if (s == null || s.isBlank()) return null;
        String lower = s.trim().toLowerCase(Locale.ROOT);
        if (lower.equals("true") || lower.equals("1") || lower.equals("yes") || lower.equals("y")) return "true";
        if (lower.equals("false") || lower.equals("0") || lower.equals("no") || lower.equals("n")) return "false";
        log.warn("[FieldTransformer] Failed to parse boolean value: {}", value);
        return null;
    }

    private String safeTruncate(JsonNode value, int maxLength) {
        if (value == null || value.isNull()) return null;
        String s = value.asString();
        if (s == null) return null;
        if (s.length() <= maxLength) return s;
        log.warn("[FieldTransformer] String truncated. Original length: {}, truncated to {}", s.length(), maxLength);
        return s.substring(0, maxLength);
    }

    private String safeConvertToDecimal(JsonNode value) {
        if (value == null || value.isNull()) return null;

        try {
            // If already numeric → preserve precision
            if (value.isNumber()) {
                return new BigDecimal(value.asText()).toPlainString();
            }

            // Handle String values
            String s = value.asText();
            if (s == null || s.isBlank()) return null;

            return new BigDecimal(s.trim()).toPlainString();

        } catch (Exception e) {
            log.warn("[FieldTransformer] Failed to parse decimal value: {}", value, e);
            return null;
        }
    }
}

package com.demo.feature_flag.service;

import com.demo.feature_flag.enums.MyFeatures;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.togglz.core.Feature;
import org.togglz.core.manager.FeatureManager;
import org.togglz.core.util.NamedFeature;

@Service
@RequiredArgsConstructor
public class CustomerService {

   private final FeatureManager featureManager;

    public static Feature MOBILE_HASHING = new NamedFeature("MOBILE_HASHING");

    public String process() {
        if (featureManager.isActive(MOBILE_HASHING)) {
            // call hashing
             System.out.print("Toggle Enabled");
             return "Toggle Enabled";
        } else {
            // fallback logic
            System.out.print("Toggle Disabled");
            return "Toggle Disabled";
        }
    }
}
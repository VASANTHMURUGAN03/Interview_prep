// ============================================================================
// MODIFY EXISTING FILE: controller/JobExecutionController.java
//
// REPLACE the existing trigger endpoint's body to call triggerJobManually()
// instead of triggerJob() directly — same URL, same request/response shape,
// so nothing calling this endpoint today breaks; it now also accepts two
// optional headers and writes one audit row per call.
//
// Add this import: import org.springframework.web.bind.annotation.RequestHeader;
// ============================================================================

    @PostMapping("/trigger/{name}")
    public ResponseEntity<ApiResponse<?>> triggerJob(
            @PathVariable String name,
            @RequestHeader(value = "X-User-Id", required = false) String userId,
            @RequestHeader(value = "X-User-Name", required = false) String username) {
        jobExecutionService.triggerJobManually(name, userId, username);

        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("Job triggered: " + name)
                .build());
    }

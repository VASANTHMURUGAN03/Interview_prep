// ============================================================================
// MODIFY EXISTING FILE: controller/JobConfigController.java
//
// No auth/session system exists yet (flagged as an open item across this
// whole project) — so there's no SecurityContext to pull a real user from.
// Until that's decided, user identity for audit purposes comes from two
// optional request headers, defaulting to "system" if absent (handled
// inside AuditService.recordAudit, not here). Swap this for
// @AuthenticationPrincipal or similar once real auth exists — the
// audit-writing code doesn't need to change, just where userId/username
// come from.
//
// Add these imports:
//   import org.springframework.web.bind.annotation.RequestHeader;
//   import com.star.databridge.dto.request.UpdateCronRequest;
//
// REPLACE the existing upsertJobConfig, deleteConfigByName, and
// activateConfig (from JobConfigController_ADD.java) method bodies with
// these, and ADD the new cron endpoint:
// ============================================================================

    @PostMapping()
    public ResponseEntity<ApiResponse<?>> upsertJobConfig(
            @RequestBody UpsertJobConfigDto jobConfigDto,
            @RequestHeader(value = "X-User-Id", required = false) String userId,
            @RequestHeader(value = "X-User-Name", required = false) String username) {
        JobConfigEntity jobConfig = jobConfigService.upsertConfig(jobConfigDto, userId, username);

        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(jobConfig)
                .build());
    }

    @DeleteMapping("/{name}")
    public ResponseEntity<ApiResponse<?>> deleteConfigByName(
            @PathVariable String name,
            @RequestHeader(value = "X-User-Id", required = false) String userId,
            @RequestHeader(value = "X-User-Name", required = false) String username) {
        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(jobConfigService.deleteConfigByName(name, userId, username))
                .build());
    }

    @PostMapping("/{name}/activate")
    public ResponseEntity<ApiResponse<?>> activateConfig(
            @PathVariable String name,
            @RequestHeader(value = "X-User-Id", required = false) String userId,
            @RequestHeader(value = "X-User-Name", required = false) String username) {
        JobConfigEntity jobConfig = jobConfigService.activateConfig(name, userId, username);

        if (jobConfig == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse
                    .builder()
                    .statusCode(HttpStatus.NOT_FOUND.value())
                    .message("Job configuration not found: " + name)
                    .build());
        }

        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(jobConfig)
                .build());
    }

    @PatchMapping("/{name}/cron")
    public ResponseEntity<ApiResponse<?>> updateCron(
            @PathVariable String name,
            @RequestBody UpdateCronRequest request,
            @RequestHeader(value = "X-User-Id", required = false) String userId,
            @RequestHeader(value = "X-User-Name", required = false) String username) {
        try {
            JobConfigEntity jobConfig = jobConfigService.updateCron(name, request.getCron(), userId, username);
            return ResponseEntity.ok().body(ApiResponse
                    .builder()
                    .statusCode(HttpStatus.OK.value())
                    .message("success")
                    .data(jobConfig)
                    .build());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ApiResponse
                    .builder()
                    .statusCode(HttpStatus.NOT_FOUND.value())
                    .message(e.getMessage())
                    .build());
        }
    }

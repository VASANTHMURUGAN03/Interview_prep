// ============================================================================
// MODIFY EXISTING FILE: service/JobConfigService.java
//
// SUPERSEDES: if you already applied JobConfigService_ADD.java from the
// earlier "missing APIs" batch (the plain activateConfig(name) method with
// no audit/scheduling), replace that method with the two-overload version
// below instead of having both — the version here calls the earlier one's
// same FindAndModify logic, just also writes an audit row and syncs JobRunr.
//
// Add two new fields (Lombok picks them up automatically — no constructor
// to hand-edit):
//   private final AuditService auditService;
//   private final SchedulingService schedulingService;
//
// Add this import:
//   import com.star.databridge.entity.AuditAction;
//
// The EXISTING public methods (upsertConfig(dto), deleteConfigByName(name),
// activateConfig(name) — the last one added in the earlier "new APIs" batch)
// are left completely untouched, so any existing caller keeps working
// exactly as before. These are NEW OVERLOADS added alongside them, which is
// what the controller should call going forward; the old ones become thin
// wrappers that just delegate with null user info (so nothing breaks if
// something else in the codebase still calls the old signature).
// ============================================================================

    // --- REPLACE the existing upsertConfig(UpsertJobConfigDto) body with a
    //     delegating call, and ADD the new overload: -----------------------

    public JobConfigEntity upsertConfig(UpsertJobConfigDto upsertJobConfigDto) {
        return upsertConfig(upsertJobConfigDto, null, null);
    }

    public JobConfigEntity upsertConfig(UpsertJobConfigDto upsertJobConfigDto, String userId, String username) {
        boolean isUpdate = jobConfigRepository.findByName(upsertJobConfigDto.getName()).isPresent();
        JobConfigEntity previous = isUpdate
                ? jobConfigRepository.findByName(upsertJobConfigDto.getName()).orElse(null)
                : null;

        // --- unchanged existing logic below ---
        JobConfigEntity jobConfigEntity = createJobConfigEntity(upsertJobConfigDto);
        JobConfigEntity saved = upsertConfig(upsertJobConfigDto.getName(), jobConfigEntity);
        // --- end unchanged existing logic ---

        auditService.recordAudit(
                saved.getId(), saved.getName(),
                isUpdate ? AuditAction.CONFIG_UPDATED : AuditAction.CONFIG_CREATED,
                previous, saved, userId, username, null);

        // Keep JobRunr's registered schedule in sync with whatever this
        // upsert just set the trigger to (covers a brand-new SCHEDULER job,
        // a cron change made via the general upsert path, or a job that
        // stopped being SCHEDULER-type and needs its old schedule removed).
        if (saved.getTrigger() != null && "SCHEDULER".equalsIgnoreCase(saved.getTrigger().getType()) && saved.isActive()) {
            schedulingService.scheduleJob(saved);
        } else {
            schedulingService.unscheduleJob(saved.getName());
        }

        return saved;
    }

    // --- REPLACE the existing deleteConfigByName(name) body similarly: ----

    public JobConfigEntity deleteConfigByName(String name) {
        return deleteConfigByName(name, null, null);
    }

    public JobConfigEntity deleteConfigByName(String name, String userId, String username) {
        JobConfigEntity previous = jobConfigRepository.findByName(name).orElse(null);

        // --- unchanged existing logic ---
        JobConfigEntity config = new JobConfigEntity();
        config.setName(name);
        config.setActive(false);
        JobConfigEntity saved = upsertConfig(config.getName(), config);
        // --- end unchanged existing logic ---

        schedulingService.unscheduleJob(name);

        auditService.recordAudit(
                saved.getId(), name, AuditAction.JOB_DISABLED,
                previous, saved, userId, username, null);

        return saved;
    }

    // --- ADD alongside the activateConfig(name) method from the earlier
    //     "new APIs" batch (JobConfigService_ADD.java): ---------------------

    public JobConfigEntity activateConfig(String name) {
        return activateConfig(name, null, null);
    }

    public JobConfigEntity activateConfig(String name, String userId, String username) {
        JobConfigEntity previous = jobConfigRepository.findByName(name).orElse(null);

        Query query = new Query(Criteria.where("name").is(name));
        Update update = new Update().set("active", true).set("updatedAt", Instant.now());
        FindAndModifyOptions options = new FindAndModifyOptions().upsert(false).returnNew(true);
        JobConfigEntity saved = mongoTemplate.findAndModify(query, update, options, JobConfigEntity.class);

        if (saved == null) {
            return null;
        }

        if (saved.getTrigger() != null && "SCHEDULER".equalsIgnoreCase(saved.getTrigger().getType())) {
            schedulingService.scheduleJob(saved);
        }

        auditService.recordAudit(
                saved.getId(), name, AuditAction.JOB_ENABLED,
                previous, saved, userId, username, null);

        return saved;
    }

    // --- ADD — the dedicated "Update Cron Expression" operation. Reuses the
    //     same FindAndModify pattern as activateConfig() above, touching only
    //     the trigger.cron field so nothing else about the config changes. ---

    public JobConfigEntity updateCron(String name, String newCron, String userId, String username) {
        JobConfigEntity existing = jobConfigRepository.findByName(name)
                .orElseThrow(() -> new IllegalArgumentException("Job config not found: " + name));

        String previousCron = existing.getTrigger() != null ? existing.getTrigger().getCron() : null;

        Query query = new Query(Criteria.where("name").is(name));
        Update update = new Update()
                .set("trigger.cron", newCron)
                .set("trigger.type", "SCHEDULER")
                .set("updatedAt", Instant.now());
        FindAndModifyOptions options = new FindAndModifyOptions().upsert(false).returnNew(true);
        JobConfigEntity saved = mongoTemplate.findAndModify(query, update, options, JobConfigEntity.class);

        if (saved.isActive()) {
            schedulingService.scheduleJob(saved); // upsert semantics — replaces the old cron registration
        }

        auditService.recordAudit(
                saved.getId(), name, AuditAction.CRON_CHANGED,
                previousCron, newCron, userId, username, null);

        return saved;
    }

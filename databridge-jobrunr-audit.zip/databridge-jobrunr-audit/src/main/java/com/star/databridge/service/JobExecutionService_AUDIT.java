// ============================================================================
// MODIFY EXISTING FILE: service/JobExecutionService.java (continued —
// alongside the ADD/ADD2/ADD3/ADD4 snippets from the earlier "new APIs" batch)
//
// Add a new field: private final AuditService auditService;
// Add this import: import com.star.databridge.entity.AuditAction;
//
// IMPORTANT: the EXISTING triggerJob(name) method is left completely
// unchanged and is NOT audited — it's called both by REST (today) and, after
// the JobRunr migration, by every scheduled/recurring firing too. Auditing
// it directly would log an entry every time a cron fires, which isn't what
// "Manual Job Execution" audit means. Instead, add this new method and have
// ONLY the controller's manual-trigger endpoint call it:
// ============================================================================

    public void triggerJobManually(String name, String userId, String username) {
        triggerJob(name); // unchanged existing logic — do not modify

        auditService.recordAudit(
                null, name, AuditAction.MANUAL_EXECUTION,
                null, null, userId, username, "Triggered manually via API");
    }

package com.star.databridge.service;

import com.star.databridge.dto.response.ScheduledJobDto;
import com.star.databridge.entity.JobConfigEntity;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.jobrunr.jobs.RecurringJob;
import org.jobrunr.scheduling.JobScheduler;
import org.jobrunr.storage.StorageProvider;
import org.springframework.stereotype.Service;

import java.time.ZoneId;
import java.util.List;
import java.util.Optional;

/**
 * NEW FILE — replaces service/JobSchedulerService.java.
 *
 * Where the old service used a @PostConstruct + Spring TaskScheduler +
 * ShedLock, this delegates entirely to JobRunr's JobScheduler:
 *
 *  - scheduleJob(): calls scheduleRecurrently() with the job's NAME (prefixed)
 *    as the recurring-job id. JobRunr's scheduleRecurrently is an upsert —
 *    calling it again with the same id (e.g. after a cron edit) replaces
 *    the existing schedule rather than creating a duplicate. This is what
 *    "Update Cron Expression" and "Enable Job" both reduce to.
 *  - unscheduleJob(): removes the recurring job — this is what
 *    "Disable Job" and "Delete Job" both reduce to for a SCHEDULER-type job.
 *  - runNow(): enqueues a one-off immediate execution via JobRunr, separate
 *    from any recurring schedule.
 *  - getJob() / getAllJobs(): reads JobRunr's own recurring-job storage
 *    (not our job_configs collection) — this is "the scheduler's view" of
 *    what's registered, useful for confirming a config change actually took
 *    effect.
 *
 * IMPORTANT — verify the exact StorageProvider.getRecurringJobs() /
 * RecurringJob accessor names against the JobRunr version you pin in
 * pom.xml; these shifted slightly across JobRunr major versions and this
 * wasn't compiled against your actual dependency.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class SchedulingService {

    private static final ZoneId TIME_ZONE = ZoneId.of("Asia/Kolkata");

    private final JobScheduler jobScheduler;
    private final StorageProvider storageProvider;
    private final JobExecutionService jobExecutionService;
    private final com.star.databridge.repository.JobConfigRepository jobConfigRepository;

    /**
     * Runs on every startup, not just once ever — scheduleJob() is an
     * upsert, so re-running this is always safe and self-healing (e.g. if
     * someone edited job_configs directly in Mongo, or a config was created
     * while JobRunr's BackgroundJobServer happened to be down). This is
     * also what makes "existing scheduled jobs continue to work after
     * migration" true: on first boot after the JobRunr cutover, every
     * currently-active SCHEDULER job gets (re)registered from job_configs,
     * with no manual re-entry needed.
     */
    @jakarta.annotation.PostConstruct
    public void syncAllSchedulesOnStartup() {
        List<JobConfigEntity> scheduledJobs = jobConfigRepository.findByTriggerTypeAndActive("SCHEDULER", true);
        log.info("[Scheduling] Syncing {} active SCHEDULER job configs into JobRunr on startup", scheduledJobs.size());
        scheduledJobs.forEach(this::scheduleJob);
    }

    /**
     * Registers or updates the recurring job for this config. No-ops (and
     * logs) if the config isn't a SCHEDULER-type trigger — call
     * unscheduleJob() in that case instead.
     */
    public void scheduleJob(JobConfigEntity jobConfig) {
        if (jobConfig.getTrigger() == null || !"SCHEDULER".equalsIgnoreCase(jobConfig.getTrigger().getType())) {
            log.debug("[Scheduling] '{}' has no SCHEDULER trigger — nothing to schedule", jobConfig.getName());
            return;
        }

        String cron = jobConfig.getTrigger().getCron();
        String recurringJobId = recurringJobId(jobConfig.getName());

        jobScheduler.scheduleRecurrently(
                recurringJobId,
                cron,
                TIME_ZONE,
                () -> jobExecutionService.triggerJob(jobConfig.getName())
        );

        log.info("[Scheduling] Registered/updated recurring job '{}' with cron '{}'", jobConfig.getName(), cron);
    }

    /** Disable or delete a SCHEDULER-type job — removes its recurring schedule. */
    public void unscheduleJob(String jobName) {
        String recurringJobId = recurringJobId(jobName);
        jobScheduler.deleteRecurringJob(recurringJobId);
        log.info("[Scheduling] Removed recurring job '{}'", jobName);
    }

    /** "Run Job Immediately" — a one-off enqueue via JobRunr, independent of any recurring schedule. */
    public void runNow(String jobName) {
        jobScheduler.enqueue(() -> jobExecutionService.triggerJob(jobName));
        log.info("[Scheduling] Enqueued immediate run for '{}'", jobName);
    }

    public Optional<ScheduledJobDto> getJob(String jobName) {
        return getAllJobs().stream()
                .filter(j -> j.getJobName().equals(jobName))
                .findFirst();
    }

    public List<ScheduledJobDto> getAllJobs() {
        return storageProvider.getRecurringJobs().stream()
                .map(this::toDto)
                .toList();
    }

    private ScheduledJobDto toDto(RecurringJob recurringJob) {
        return ScheduledJobDto.builder()
                .recurringJobId(recurringJob.getId())
                .jobName(jobNameFromRecurringJobId(recurringJob.getId()))
                .cronExpression(recurringJob.getScheduleExpression())
                .nextRun(recurringJob.getNextRun() != null ? recurringJob.getNextRun().toInstant() : null)
                .build();
    }

    private String recurringJobId(String jobName) {
        return "databridge-job-" + jobName;
    }

    private String jobNameFromRecurringJobId(String recurringJobId) {
        return recurringJobId.replaceFirst("^databridge-job-", "");
    }
}

package com.star.databridge.config;

import com.mongodb.client.MongoClient;
import org.jobrunr.jobs.mappers.JobMapper;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.nosql.mongo.MongoDBStorageProvider;
import org.jobrunr.utils.mapper.jackson.JacksonJsonMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * NEW FILE — replaces config/SchedulerConfig.java.
 *
 * Removes Spring's TaskScheduler + ShedLock entirely. JobRunr's own storage
 * provider (backed by the same MongoDB instance, in new "jobrunr_*"
 * collections) natively guarantees a recurring job only fires on one node
 * at a time in a multi-pod deployment — there's no separate distributed
 * lock bean needed the way ShedLock was for the old TaskScheduler approach.
 *
 * This uses the official `jobrunr-spring-boot-3-starter`, which
 * auto-configures a `JobScheduler` bean and a `BackgroundJobServer` bean as
 * soon as it finds a `StorageProvider` bean on the context (this class) and
 * `org.jobrunr.background-job-server.enabled=true` is set (see below) — no
 * manual `JobRunr.configure()...initialize()` wiring needed, and no custom
 * job-activator class needed; the starter uses Spring's own
 * ApplicationContext to resolve `@Autowired` dependencies inside scheduled
 * lambdas automatically.
 *
 * DELETE config/SchedulerConfig.java and service/JobSchedulerService.java
 * once this is in place — see SchedulingService.java (new) for the
 * replacement of JobSchedulerService's responsibilities.
 *
 * --------------------------------------------------------------------------
 * pom.xml changes needed (can't write the exact diff — no build file was in
 * the shared source):
 *
 *   ADD:
 *     <dependency>
 *       <groupId>org.jobrunr</groupId>
 *       <artifactId>jobrunr-spring-boot-3-starter</artifactId>
 *       <version>7.3.1</version>  <!-- pin to your team's chosen version -->
 *     </dependency>
 *
 *   REMOVE:
 *     net.javacrumbs.shedlock:shedlock-spring
 *     net.javacrumbs.shedlock:shedlock-provider-mongo
 *
 * application.yml additions needed:
 *
 *   org:
 *     jobrunr:
 *       background-job-server:
 *         enabled: true
 *       dashboard:
 *         enabled: true   # optional — JobRunr's own job-monitoring UI;
 *                         # set false if you don't want it exposed
 *       database:
 *         skip-create: true  # we hand it an already-connected MongoClient below
 * --------------------------------------------------------------------------
 */
@Configuration
public class JobRunrConfig {

    @Value("${jobrunr.mongo.database-name:databridge}")
    private String databaseName;

    /**
     * The starter auto-detects this bean and uses it instead of its SQL
     * default. Reuses whatever MongoClient bean Spring Data MongoDB already
     * created for the rest of the app — this does not open a second
     * connection pool.
     */
    @Bean
    public StorageProvider storageProvider(MongoClient mongoClient) {
        MongoDBStorageProvider storageProvider = new MongoDBStorageProvider(mongoClient, databaseName);
        storageProvider.setJobMapper(new JobMapper(new JacksonJsonMapper()));
        return storageProvider;
    }
}

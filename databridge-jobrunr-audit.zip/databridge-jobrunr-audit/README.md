# Data Bridge — JobRunr Migration + Job Audit (Backend)

This is **backend only** — the frontend wiring (Create/Edit Job forms, Audit
History screen) is the natural next step; see "Not done yet" below.

Same conventions as the earlier `databridge-new-apis` batch: files with **no
suffix** are brand-new, `_ADD`/`_JOBRUNR_AUDIT`/`_AUDIT` suffixed files are
snippets to paste into an existing file (header comment tells you exactly
where).

## Files to DELETE

- `config/SchedulerConfig.java` — replaced by `config/JobRunrConfig.java`
- `service/JobSchedulerService.java` — replaced by `service/SchedulingService.java`

Nothing else in the codebase referenced ShedLock (confirmed by a project-wide
search) — these two files were the whole of it.

## Install order

1. **Delete** the two files above.
2. **pom.xml**: add `jobrunr-spring-boot-3-starter`, remove the two
   `shedlock-*` dependencies (see `JobRunrConfig.java`'s header comment for
   exact coordinates and the `application.yml` properties needed).
3. **New files, no dependencies on the snippets below**: `JobRunrConfig.java`,
   `SchedulingService.java`, `ScheduledJobDto.java`, `SchedulerController.java`,
   `AuditAction.java`, `AuditEntity.java`, `AuditRepository.java`,
   `AuditService.java`, `AuditController.java`, `UpdateCronRequest.java`.
4. **Then the `_JOBRUNR_AUDIT`/`_AUDIT` snippets**, in this order (each
   depends on the plain new files from step 3 existing first):
   - `JobConfigService_JOBRUNR_AUDIT.java` → paste into `service/JobConfigService.java`
   - `JobExecutionService_AUDIT.java` → paste into `service/JobExecutionService.java`
   - `JobConfigController_JOBRUNR_AUDIT.java` → paste into `controller/JobConfigController.java`
   - `JobExecutionController_AUDIT.java` → paste into `controller/JobExecutionController.java`

If you already applied `JobConfigService_ADD.java` / `JobConfigController_ADD.java`
from the earlier "missing APIs" batch (the plain `activateConfig`), the
`_JOBRUNR_AUDIT` versions here **replace** those methods, not sit alongside
them — see the note at the top of `JobConfigService_JOBRUNR_AUDIT.java`.

## What each requested capability maps to

| Requirement | Endpoint | Notes |
|---|---|---|
| Create Job | `POST /v1/job-configs` (existing, now audited + schedules if SCHEDULER) | unchanged URL/shape |
| Update Job | same endpoint (upsert) | detects create-vs-update by whether the name existed before, for the right audit action |
| Delete Job | `DELETE /v1/job-configs/{name}` (existing) | soft-delete, same as before — now also unregisters from JobRunr + audits `JOB_DISABLED` |
| Enable Job | `POST /v1/job-configs/{name}/activate` | now schedules via JobRunr + audits `JOB_ENABLED` |
| Disable Job | same as Delete (this codebase's "disable" and "delete" are the same soft-delete operation — see the retry/backend analysis from earlier in this project for why) |
| Update Cron Expression | `PATCH /v1/job-configs/{name}/cron` (new) | dedicated endpoint, only touches `trigger.cron`, audits `CRON_CHANGED` with before/after cron strings |
| Run Job Immediately | `POST /v1/scheduler/jobs/{name}/run-now` (new) | one-off JobRunr enqueue, independent of the recurring schedule |
| Get Job Details | `GET /v1/scheduler/jobs/{name}` (new) | JobRunr's view (cron, next run) — pair with the existing `GET /v1/job-configs/{name}` for the business-config view |
| Get All Jobs | `GET /v1/scheduler/jobs` (new) | same idea, all jobs |
| Get Audit History | `GET /v1/audit` (new) | filters: `jobName`, `userId`, `action`, `from`/`to`; `page`/`size`; `sortBy`/`sortDirection` |
| Get Audit History by Job | `GET /v1/audit/job/{jobName}` (new) | paginated, newest first |

## Honest caveats

- **JobRunr API surface wasn't compiled against your actual pinned version.**
  I know the shape of `JobScheduler.scheduleRecurrently/deleteRecurringJob/enqueue`
  and `StorageProvider.getRecurringJobs()` well, but exact accessor names on
  `RecurringJob` (`getNextRun()` specifically) have shifted slightly across
  JobRunr major versions — flagged in `SchedulingService.java`'s header
  comment. Budget time for a real build + a quick look at your JobRunr
  version's `RecurringJob` javadoc before trusting this compiles as-is.
- **User identity for audit is header-based** (`X-User-Id`/`X-User-Name`),
  defaulting to `"system"`, because there's still no real auth/session system
  in this project (a standing open item from earlier in this engagement).
  Swap the header reads for `@AuthenticationPrincipal` (or whatever the real
  mechanism ends up being) once that's decided — the audit-writing code
  itself doesn't change.
- **"Disable" and "Delete" are the same operation** in this codebase (both
  set `active=false` via the existing soft-delete) — I didn't invent a
  separate hard-delete, since the request said "Delete Job (if applicable)"
  and the existing architecture already treats disable as delete.
- **Audit never blocks the operation it's describing.** `recordAudit()`
  swallows its own exceptions (logged, not thrown) — a Mongo hiccup writing
  an audit row should never fail a job trigger or config save.
- **Manual vs. scheduled triggering is intentionally separated.** The
  existing `triggerJob(name)` is untouched and used by both JobRunr's
  recurring callback and (indirectly) the manual path — only
  `triggerJobManually()` (new) writes an audit row, so a cron firing every
  15 minutes doesn't flood the audit log with `MANUAL_EXECUTION` entries
  that aren't actually manual.

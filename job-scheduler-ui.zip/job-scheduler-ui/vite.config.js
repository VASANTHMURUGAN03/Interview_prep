import { defineConfig } from 'vite'

import react from '@vitejs/plugin-react'
 
export default defineConfig({
  base:'/job-scheduler',

  plugins: [

    react(),

    {

      name: 'health-check',

      configureServer(server) {

        server.middlewares.use('/health', (req, res) => {

          res.statusCode = 200

          res.setHeader('Content-Type', 'application/json')

          res.end(JSON.stringify({ status: 'ok' }))

        })

      }

    }

  ],

  server: {

    host : '0.0.0.0',

    port: 5000,

    open: true,

    hmr: false,

    allowedHosts: true 

  }

})

 
import Cookies from 'js-cookie';

export const getPartnerAccessToken = () => Cookies.get('employee_accessToken');
export const getPartnerChannelName = () => Cookies.get('employee_channelName');

export const getPartnerAccessTokenExpiry = () => Cookies.get('employee_accessTokenExpiry');
export const getPartnerRefreshToken = () => Cookies.get('employee_refreshToken');

export const getPartnerRefreshTokenExpiry = () => Cookies.get('employee_refreshTokenExpiry');
export const getPartnerUserProfile = () => Cookies.get('employee_userProfile');


const getPath = () => {
    let path
    let getDomainName = window.location.hostname
    if(getDomainName === 'localhost'){
        path = '/sso';
    }
    else{
        path = '/';
    }
    return path;
}

const getDomain = () => {
    let name
    let getDomainName = window.location.hostname
    if(getDomainName === 'localhost'){
        name = "localhost";
    }
    else{
        name = '.star-app.in';

    }
    return name;
}

export const clearCookies = () => {
    Cookies.remove('employee_accessToken', {path:getPath(), domain: getDomain() });
    Cookies.remove('employee_accessTokenExpiry', {path:getPath(), domain: getDomain() });
    Cookies.remove('employee_channelName', {path:getPath(), domain: getDomain() });
    Cookies.remove('employee_refreshToken', {path:getPath(), domain: getDomain() });
    Cookies.remove('employee_refreshTokenExpiry', {path:getPath(), domain: getDomain() });
    Cookies.remove('employee_userProfile', {path:getPath(), domain: getDomain() });
};
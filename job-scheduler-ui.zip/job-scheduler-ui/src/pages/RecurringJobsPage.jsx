
// src/pages/RecurringJobs.jsx
import { useEffect, useState } from "react";
import Toast from "../Components/Toast";
import "bootstrap/dist/css/bootstrap.min.css";
import { enableJob, disableJob, updateCron, fetchJobs } from "../apis/JobApi";
import { IoIosTimer } from "react-icons/io";
import { FaChevronCircleUp } from "react-icons/fa";

export default function RecurringJobs() {
  const [jobs, setJobs] = useState([
    // Seed data for local testing; will be replaced if fetchJobs() returns data
    { id: "report-job", cron: "0 0 * * *", nextRun: "2025-12-21T00:00:00", status: "ACTIVE" },
    { id: "cleanup-job", cron: "0 */6 * * *", nextRun: "2025-12-20T23:00:00", status: "ACTIVE" },
    { id: "backup-job", cron: "0 2 * * *", nextRun: "2025-12-21T02:00:00", status: "PAUSED" },
  ]);

  const [toast, setToast] = useState(null);
  const [editing, setEditing] = useState(null);
  const [newCron, setNewCron] = useState("");
  const [loading, setLoading] = useState(false);

  const notify = (msg, type = "info") => setToast({ msg, type });

  // Load jobs from backend on mount (optional; if you have GET /jobs)
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        setLoading(true);
        const data = await fetchJobs(); // Should return: [{ id, cron, nextRun, status }, ...]
        if (mounted && Array.isArray(data) && data.length > 0) {
          setJobs(data);
        }
      } catch (err) {
        console.error("Failed to fetch jobs", err);
        notify("Failed to load jobs", "error");
      } finally {
        setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  // Minimal cron validation (replace with a robust validator if needed)
  const isCronValid = (cron) => typeof cron === "string" && cron.trim().length > 0;

  const handleUpdateCron = async (id, cron) => {
    if (!isCronValid(cron)) {
      notify("Please enter a valid cron expression.", "warning");
      return;
    }

    // Optimistic update
    const prev = [...jobs];
    setJobs((curr) => curr.map((j) => (j.id === id ? { ...j, cron } : j)));

    try {
      const serverMsg = await updateCron(id, cron); // String from backend
      notify(serverMsg || `Cron updated for ${id}`, "success");
      setEditing(null);
      setNewCron("");
    } catch (err) {
      // rollback on error
      setJobs(prev);
      console.error(err);
      notify(`Failed to update cron for ${id}`, "error");
    }
  };

  const handleEnable = async (id, cron) => {
    // Optimistic update
    const prev = [...jobs];
    setJobs((curr) => curr.map((j) => (j.id === id ? { ...j, status: "ACTIVE" } : j)));

    try {
      const serverMsg = await enableJob(id, cron); // String from backend
      notify(serverMsg || `Enabled ${id}`, "success");
    } catch (err) {
      setJobs(prev);
      console.error(err);
      notify(`Failed to enable ${id}`, "error");
    }
  };

  const handleDisable = async (id) => {
    // Optimistic update
    const prev = [...jobs];
    setJobs((curr) => curr.map((j) => (j.id === id ? { ...j, status: "PAUSED" } : j)));

    try {
      const serverMsg = await disableJob(id); // String from backend
      notify(serverMsg || `Disabled ${id}`, "warning");
    } catch (err) {
      setJobs(prev);
      console.error(err);
      notify(`Failed to disable ${id}`, "error");
    }
  };

  return (
    <div className="container mt-4">
      {toast && <Toast message={toast.msg} type={toast.type} onHide={() => setToast(null)} />}

      <div className="d-flex align-items-center gap-2 mb-3">
        <h3 className="mb-0">Recurring Jobs</h3>
        {loading && <span className="badge bg-info">Loading...</span>}
      </div>

      <div className="row">
        {jobs.map((job) => (
          <div key={job.id} className="col-md-4 mb-3">
            <div className="card shadow-sm h-100">
              <div className="card-body">
                <h5 className="card-title text-primary">{job.id}</h5>
                <p className="card-text">
                  <strong>Cron:</strong> {job.cron}
                </p>
                <p className="card-text">
                  <strong>Next Run:</strong> {job.nextRun}
                </p>
                <p className="card-text">
                  <strong>Status:</strong>{" "}
                  <span
                    className={`badge ${
                      job.status === "ACTIVE" ? "bg-success" : "bg-warning text-dark"
                    }`}
                  >
                    {job.status}
                  </span>
                </p>

                {editing === job.id && (
                  <div className="mb-3">
                    <div className="input-group">
                      <input
                        type="text"
                        className="form-control"
                        value={newCron}
                        onChange={(e) => setNewCron(e.target.value)}
                        placeholder="Enter new cron (e.g. 0 0 * * *)"
                      />
                      <button
                        className="btn btn-success"
                        onClick={() => handleUpdateCron(job.id, newCron)}
                      >
                        Save
                      </button>
                      <button
                        className="btn btn-secondary"
                        onClick={() => {
                          setEditing(null);
                          setNewCron("");
                        }}
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                )}

                <div className="d-flex justify-content-between mt-3">
                  <button
                   className="primary"
                    // className="btn btn-outline-primary btn-sm d-flex align-items-center gap-1"
                    onClick={() => {
                      setEditing(job.id);
                      setNewCron(job.cron); // preload current cron
                    }}
                  ><IoIosTimer /> Update Cron
                  </button>
                  <button
                  
                  className="primary"
                   
            onClick={() => handleEnable(job.id, job.cron)}
                    disabled={job.status === "ACTIVE"}
                  ><FaChevronCircleUp />
                    Enable
                  </button>
                  <button
                  
                     className="primary"
                    // className="btn btn-outline-danger btn-sm"
                    onClick={() => handleDisable(job.id)}
                    disabled={job.status === "PAUSED"}
                  >
                     Disable
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}

        {jobs.length === 0 && (
          <div className="col-12">
            <div className="alert alert-secondary">No recurring jobs found</div>
          </div>
        )}
      </div>
    </div>
  );
}
``


// src/pages/JobsPage.jsx
import { useEffect, useMemo, useState } from "react";
import Card from "../Components/Card";
import Filters from "../Components/Filters";
import JobsTable from "../Components/JobsTable";
import Pagination from "../Components/Pagination";
import JobOverview from "../Components/JobOverview";
import Toast from "../Components/Toast";
import { fetchJobOverviewStats } from "../apis/JobApi"; 
// ← NEW

export default function JobsPage() {
  const [filters, setFilters] = useState({});
  const [toast, setToast] = useState(null);
  const [loadingStats, setLoadingStats] = useState(false);

  // Default stats (until backend loads)
  const [stats, setStats] = useState({
    enqueued: 0,
    scheduled: 0,
    processing: 0,
    succeeded: 0,
    failed: 0,
  });

  const jobs = useMemo(
    () => [
      { id: "injdnx-claim",  cron: "0 */15 * * * *", status: "ACTIVE",  group: "claims",  createdAt: "2025-12-20T18:00:00", lastRun: "2025-12-20T18:30:00" },
      { id: "injdnx-claim2", cron: "0 0/30 * * * *", status: "PAUSED",  group: "claims",  createdAt: "2025-12-20T19:00:00", lastRun: "" },
      { id: "etl-nightly",   cron: "0 0 2 * * *",    status: "ACTIVE",  group: "etl" },
      { id: "invoice-sync",  cron: "0 */10 * * * *", status: "FAILED",  group: "billing" },
    ],
    []
  );

  const filteredJobs = jobs.filter((job) => {
    const f = filters || {};
    const matchId = f.jobId ? job.id.toLowerCase().includes(f.jobId.toLowerCase()) : true;
    const matchCron = f.cron ? job.cron.toLowerCase().includes(f.cron.toLowerCase()) : true;
    const matchStatus = f.status ? job.status === f.status : true;
    return matchId && matchCron && matchStatus;
  });

  const notify = (msg, type = "info") => setToast({ msg, type });

  const handlePause  = (id) => notify(`Paused ${id}`,  "info");
  const handleResume = (id) => notify(`Resumed ${id}`, "success");
  const handleRetry  = (id) => notify(`Retry queued for ${id}`, "info");

  // Load stats from backend on mount
  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        setLoadingStats(true);
        const data = await fetchJobOverviewStats();
        if (mounted && data) {
          // Defensive mapping in case backend adds/removes fields
          setStats({
            enqueued:  Number(data.enqueued ?? 0),
            scheduled: Number(data.scheduled ?? 0),
            processing: Number(data.processing ?? 0),
            failed:    Number(data.failed ?? 0),
            succeeded: Number(data.succeeded ?? 0),
          });
        }
      } catch (err) {
        console.error("Failed to fetch job overview stats:", err);
        notify("Failed to load job overview stats", "error");
      } finally {
        setLoadingStats(false);
      }
    })();
    return () => { mounted = false; };
  }, []);

  return (
    <div className="page">
      {toast && <Toast message={toast.msg} type={toast.type} onHide={() => setToast(null)} />}

      <Card
        title="Job overview"
        right={loadingStats ? <span className="badge bg-info">Loading...</span> : null}
      >
        <JobOverview stats={stats} />
      </Card>

      <Card title="Filters" right={<span className="muted">Use filters to narrow down jobs</span>}>
        <Filters onChange={setFilters} />
      </Card>

      <Card title="Jobs" right={<span className="muted">Total records: {filteredJobs.length}</span>}>
        <JobsTable jobs={filteredJobs} onPause={handlePause} onResume={handleResume} onRetry={handleRetry} />
        <Pagination />
      </Card>
    </div>
  );
}

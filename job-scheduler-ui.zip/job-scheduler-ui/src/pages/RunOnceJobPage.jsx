import { useMemo, useState, useEffect, useRef } from "react";
import {
  Button,
  Card,
  DatePicker,
  Radio,
  Form,
  Modal,
  Select,
  Typography,
  message,
  Timeline,
  Tag,
  Tabs,
  Table,
} from "antd";
import { ExclamationCircleOutlined } from "@ant-design/icons";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import dayjs from "dayjs";

import {
  fetchJobs,
  triggerOneTimeJob,
  getAllOneTimeJob,
  cancleOneTimeJob,
} from "../apis/JobApi";

const { Text, Title } = Typography;

/* ---------------- constants ---------------- */

const STATUS_OPTIONS = [
  { label: "All", value: null },
  { label: "SCHEDULED", value: "SCHEDULED" },
  { label: "PROCESSING", value: "PROCESSING" },
  { label: "SUCCESS", value: "SUCCESS" },
  { label: "FAILED", value: "FAILED" },
  { label: "CANCELLED", value: "CANCELLED" },
];

const TYPE_OPTIONS = [
  { label: "All", value: null },
  { label: "IMMEDIATE", value: "IMMEDIATE" },
  { label: "SCHEDULED", value: "SCHEDULED" },
];

export default function JobDashboard() {
  /* ---------------- common ---------------- */

  const fetchedRef = useRef(false);
  const [jobs, setJobs] = useState([]);

  const jobOptions = useMemo(
    () =>
      jobs.map((j) => ({
        label: j.jobName,
        value: j.jobName,
      })),
    [jobs],
  );

  /* ---------------- trigger once ---------------- */

  const [selectedJob, setSelectedJob] = useState(null);
  const [runType, setRunType] = useState("NOW");
  const [scheduledTime, setScheduledTime] = useState(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [triggering, setTriggering] = useState(false);

  /* ---------------- scheduled jobs ---------------- */

  const [scheduledJobs, setScheduledJobs] = useState([]);
  const [scheduledPage, setScheduledPage] = useState(0);
  const [scheduledPageSize] = useState(20); // window size
  const [scheduledHasMore, setScheduledHasMore] = useState(true);
  const [scheduledLoading, setScheduledLoading] = useState(false);

  /* ---------------- trigger history ---------------- */

  const [historyJobs, setHistoryJobs] = useState([]);
  const [historyTotal, setHistoryTotal] = useState(0);
  const [historyPage, setHistoryPage] = useState(0);
  const [historyPageSize, setHistoryPageSize] = useState(10);
  const [historyLoading, setHistoryLoading] = useState(false);

  const [historyFilters, setHistoryFilters] = useState({
    jobName: null,
    type: null,
    status: null,
  });

  /* ---------------- initial load ---------------- */

  useEffect(() => {
    if (fetchedRef.current) return;
    fetchedRef.current = true;

    fetchJobs()
      .then(setJobs)
      .catch(() => message.error("Failed to load jobs"));

    loadHistory(0);
    loadScheduled();
  }, []);

  /* ---------------- API calls ---------------- */

  const loadHistory = async (page = 0, size = historyPageSize) => {
    setHistoryLoading(true);
    try {
      const res = await getAllOneTimeJob({
        page,
        size, // ✅ dynamic now
        ...(historyFilters.jobName && { jobName: historyFilters.jobName }),
        ...(historyFilters.type && { type: historyFilters.type }),
        ...(historyFilters.status && { status: historyFilters.status }),
      });

      setHistoryJobs(res.jobs || []);
      setHistoryTotal(res.totalRecords || 0);
      setHistoryPage(page);
    } finally {
      setHistoryLoading(false);
    }
  };

  const loadScheduled = async (page = 0) => {
    if (scheduledLoading) return;

    setScheduledLoading(true);
    try {
      const res = await getAllOneTimeJob({
        type: "SCHEDULED",
        status: "SCHEDULED",
        page,
        size: scheduledPageSize,
      });

      const jobs = Array.isArray(res?.jobs) ? res.jobs : [];

      setScheduledJobs((prev) => (page === 0 ? jobs : [...prev, ...jobs]));

      setScheduledHasMore(jobs.length === scheduledPageSize);
      setScheduledPage(page);
    } catch {
      message.error("Failed to load scheduled jobs");
    } finally {
      setScheduledLoading(false);
    }
  };

  /* ---------- cancel scheduled job ---------- */

  const confirmCancel = (job) => {
    Modal.confirm({
      title: "Cancel Scheduled Job",
      icon: <ExclamationCircleOutlined />,
      content: `Are you sure you want to cancel "${job.jobName}"?`,
      okText: "Yes, Cancel",
      cancelText: "No",
      onOk: async () => {
        try {
          await cancleOneTimeJob({ customId: job.id });
          message.success("Job cancelled successfully");

          setScheduledJobs((prev) => prev.filter((j) => j.id !== job.id));
        } catch {
          message.error("Failed to cancel job");
        }
      },
    });
  };

  useEffect(() => {
    loadHistory(0);
  }, [historyFilters]);

  /* ---------------- trigger job ---------------- */

  const triggerJob = async () => {
    setConfirmOpen(false);
    setTriggering(true);
    try {
      const delay =
        runType === "LATER" && scheduledTime
          ? dayjs(scheduledTime).format("YYYY-MM-DDTHH:mm:ss") + "Z"
          : null;

      await triggerOneTimeJob({
        jobId: selectedJob,
        ...(delay ? { delay } : {}),
      });

      message.success("Job triggered successfully!");
      loadHistory(0);
      loadScheduled();
    } catch {
      message.error("Error triggering job");
    } finally {
      setTriggering(false);
    }
  };

  /* ---------------- tables ---------------- */

  const historyColumns = [
    { title: "Job Name", dataIndex: "jobName" },
    { title: "Type", dataIndex: "type" },
    {
      title: "Status",
      dataIndex: "status",
      render: (status) => {
        const colorMap = {
          SUCCESS: "green",
          FAILED: "red",
          PROCESSING: "blue",
          SCHEDULED: "gold",
          CANCELLED: "default",
        };
        return <Tag color={colorMap[status]}>{status}</Tag>;
      },
    },
    { title: "Requested By", dataIndex: "requestedBy" },
    {
      title: "Created At",
      dataIndex: "createdAt",
      render: (v) => dayjs(v).format("YYYY-MM-DD HH:mm:ss"),
    },
  ];

  /* ---------------- UI ---------------- */

  return (
    <Container fluid className="mt-3">
      <Card style={{ padding: 16, minHeight: "100vh" }}>
        <Row>
          {/* ---------- LEFT ---------- */}
          <Col md={4}>
            <Card style={{ padding: 16, minHeight: 510 }}>
              <Title level={4}>Run Job Once</Title>

              <Form layout="vertical">
                <Form.Item label="Job">
                  <Select
                    showSearch
                    options={jobOptions}
                    onChange={setSelectedJob}
                  />
                </Form.Item>

                <Form.Item label="Execution Type">
                  <Radio.Group
                    value={runType}
                    onChange={(e) => setRunType(e.target.value)}
                  >
                    <Radio value="NOW">Run Now</Radio>
                    <Radio value="LATER">Run Later</Radio>
                  </Radio.Group>
                </Form.Item>

                {runType === "LATER" && (
                  <Form.Item label="Schedule Time">
                    <DatePicker
                      showTime
                      onChange={(v) =>
                        setScheduledTime(v ? v.toISOString() : null)
                      }
                    />
                  </Form.Item>
                )}

                <Button
                  type="primary"
                  loading={triggering}
                  disabled={!selectedJob}
                  onClick={() => setConfirmOpen(true)}
                >
                  Trigger
                </Button>
              </Form>
            </Card>
          </Col>

          {/* ---------- RIGHT ---------- */}
          <Col md={8}>
            <Card>
              <Tabs
                items={[
                  {
                    key: "history",
                    label: "Trigger History",
                    children: (
                      <>
                        {/* Filters */}
                        <Form layout="inline" style={{ marginBottom: 12 }}>
                          <Form.Item label="Job">
                            <Select
                              allowClear
                              options={jobOptions}
                              style={{ width: 200 }}
                              onChange={(v) =>
                                setHistoryFilters((p) => ({
                                  ...p,
                                  jobName: v,
                                }))
                              }
                            />
                          </Form.Item>

                          <Form.Item label="Type">
                            <Select
                              options={TYPE_OPTIONS}
                              value={historyFilters.type}
                              style={{ width: 140 }}
                              onChange={(v) =>
                                setHistoryFilters((p) => ({ ...p, type: v }))
                              }
                            />
                          </Form.Item>

                          <Form.Item label="Status">
                            <Select
                              options={STATUS_OPTIONS}
                              value={historyFilters.status}
                              style={{ width: 150 }}
                              onChange={(v) =>
                                setHistoryFilters((p) => ({ ...p, status: v }))
                              }
                            />
                          </Form.Item>
                          <Form.Item>
                            <Button
                              onClick={() => {
                                // 1️⃣ Reset filters
                                setHistoryFilters({
                                  jobName: null,
                                  type: null,
                                  status: null,
                                });

                                // 2️⃣ Reset pagination
                                setHistoryPage(0);

                                // 3️⃣ Reload data (page 0, current page size)
                                loadHistory(0, historyPageSize);
                              }}
                            >
                              Refresh
                            </Button>
                          </Form.Item>
                          
<div style={{ marginBottom: 8 }}>
  <Text type="secondary">
    Total Records: <b>{historyTotal}</b>
  </Text>
</div>

                        </Form>
                        <Table
                          size="small"
                          rowKey="id"
                          columns={historyColumns}
                          dataSource={historyJobs}
                          loading={historyLoading}
                          pagination={{
                            current: historyPage + 1,
                            pageSize: historyPageSize,
                            total: historyTotal,
                            showSizeChanger: true,
                            pageSizeOptions: ["10", "20", "50"],
                            onChange: (page, size) => {
                              setHistoryPage(page - 1);
                              setHistoryPageSize(size);
                              loadHistory(page - 1, size); // ✅ single API call
                            },
                          }}
                          scroll={{ y: 320 }}
                        />
                        
                      </>
                    ),
                  },

                  {
                    key: "scheduled",
                    label: "Scheduled Jobs",
                    children: (
                      <>
                        <div style={{ maxHeight: 400, overflowY: "auto" }}>
                          <Timeline>
                            {scheduledJobs.map((job) => (
                              <Timeline.Item key={job.id} color="blue">
                                <div
                                  style={{
                                    display: "flex",
                                    justifyContent: "space-between",
                                  }}
                                >
                                  <div>
                                    <b>{job.jobName}</b> —{" "}
                                    {dayjs(job.scheduleAt).format(
                                      "YYYY-MM-DD HH:mm:ss",
                                    )}
                                    <Tag color="blue" style={{ marginLeft: 8 }}>
                                      {job.status}
                                    </Tag>
                                  </div>
                                  <Button
                                    size="small"
                                    danger
                                    loading={scheduledLoading}
                                    onClick={() => confirmCancel(job)}
                                  >
                                    Cancel
                                  </Button>
                                </div>
                              </Timeline.Item>
                            ))}
                          </Timeline>
                        </div>

                        {scheduledHasMore && (
                          <Button
                            style={{ marginTop: 12 }}
                            loading={scheduledLoading}
                            onClick={() => loadScheduled(scheduledPage + 1)}
                          >
                            Load more
                          </Button>
                        )}
                      </>
                    ),
                  },
                ]}
              />
            </Card>
          </Col>
        </Row>
      </Card>

       <Modal
        open={confirmOpen}
        onCancel={() => setConfirmOpen(false)}
        onOk={triggerJob}
        confirmLoading={triggering}
        title="Confirm One-time Execution"
      >
        <p>
          <b>Job:</b> {selectedJob}
        </p>
        <p>
          <b>Type:</b> {runType === "NOW" ? "Immediate Run" : "Delayed Run"}
        </p>
        {runType === "LATER" && scheduledTime && (
          <p>
            <b>Will run at:</b>{" "}
            {dayjs(scheduledTime).format("YYYY-MM-DDTHH:mm:ss") + "Z"}
          </p>
        )}
      </Modal>
    </Container>
  );
}

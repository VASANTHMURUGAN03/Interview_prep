import React, { useEffect, useState } from "react";

import {
  Card,
  Table,
  Button,
  Dropdown,
  Input,
  Select,
  DatePicker,
  Space,
  Pagination,
  Empty,
} from "antd";

import {
  MoreOutlined,
  FilterOutlined,
  ReloadOutlined,
  SearchOutlined,
} from "@ant-design/icons";

import dayjs from "dayjs";

import JobDetailsModal from "../Components/JobDetailsModal";

import { fetchJobHistory } from "../apis/JobApi";
import { addMinutes, format, isValid, parseISO } from "date-fns";
import { formatInTimeZone } from "date-fns-tz";

const { RangePicker } = DatePicker;

const { Option } = Select;

const PAGE_SIZE = 10;

const today = dayjs();

/* ---------- UTILS ---------- */

const humanizeDuration = (duration) => {
  if (!duration) return "-";

  const [hours, minutes, seconds] = duration.split(":").map(Number);

  const days = Math.floor(hours / 24);

  const hrs = hours % 24;

  return [
    days ? `${days}d` : null,

    hrs ? `${hrs}h` : null,

    minutes ? `${minutes}m` : null,

    seconds ? `${seconds}s` : null,
  ]

    .filter(Boolean)

    .join(" ");
};

const JobHistoryPage = () => {
  /* ---------- STATE ---------- */

  const [filters, setFilters] = useState({
    startDate: today,

    endDate: today,

    scheduler: "",

    status: "",
  });

  const [jobs, setJobs] = useState([]);

  const [loading, setLoading] = useState(false);

  const [currentPage, setCurrentPage] = useState(1);

  const [totalRecords, setTotalRecords] = useState(0);

  const [showFilters, setShowFilters] = useState(false);

  const [showDetailsModal, setShowDetailsModal] = useState(false);

  const [detailsJob, setDetailsJob] = useState(null);

 



// const dateUtcToReadable = (utcString) => {
//   if (typeof utcString !== "string") {
//     return ""; // or throw error
//   }

//   // Parse as UTC
//   const utcDate = parseISO(utcString);

//   // Check if parsed date is valid
//   if (!isValid(utcDate)) {
//     return ""; // or return utcString or throw error
//   }

//   // Convert to IST (UTC+5:30)
//   const istDate = addMinutes(utcDate, 330);

//   // Format: 26 Feb 2026, 12:50 pm
//   return format(istDate, "dd MMM yyyy, hh:mm:ss a");
// };
const dateUtcToReadable = (utcString) => {
  if (typeof utcString !== "string") return "";
 
  const utcDate = parseISO(utcString);
  if (!isValid(utcDate)) return "";
 
  return formatInTimeZone(utcDate, "Asia/Kolkata", "dd MMM yyyy, hh:mm:ss a");
};
  /* ---------- API ---------- */

  const loadJobs = async () => {
    console.log("loadJobs");
    setLoading(true);

    try {
      // 👇 PARAMS KEPT EXACTLY SAME

      const params = {
        page: currentPage - 1,

        size: PAGE_SIZE,

        ...(filters.status && { state: filters.status }),

        ...(filters.scheduler && { SchedulerName: filters.scheduler }),

        ...(filters.startDate && {
          createdFrom: filters.startDate.format("DD-MM-YYYY"),

          createdTo: filters.endDate.format("DD-MM-YYYY"),
        }),
      };

      const json = await fetchJobHistory(params);
      console.log("json", json);
      const content = json?.content || [];
      // const content = data?.data?.content || [];

      console.log("content", content);
      const mapped = content.map((job) => ({
        key: job.id,

        id: job.id,

        jobName: job.id,

        scheduler: job.recurringJobId,

        startTime: dateUtcToReadable(job.startTime),

        endTime: dateUtcToReadable(job.endTime),

        duration: humanizeDuration(job.duration),

        status: job.currentState,

        summary: job.summary,

        history: job.history,
      }));
      console.log("mapped", mapped);
      setJobs(mapped);

      setTotalRecords(json.totalElements);
    } catch (e) {
      // setJobs([]);

      setTotalRecords(0);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (currentPage && filters) {
      loadJobs();
    }
  }, [currentPage, filters]);

  /* ---------- HANDLERS ---------- */

  const resetFilters = () => {
    setFilters({
      startDate: today,

      endDate: today,

      scheduler: "",

      status: "",
    });
  };

  const handleView = (job) => {
    setDetailsJob(job);

    setShowDetailsModal(true);
  };

  /* ---------- STATUS BADGE ---------- */

  const renderStatus = (status) => {
    const map = {
      SUCCEEDED: { color: "#52C41A", bg: "#F6FFED", border: "#B7EB8F" },

      FAILED: { color: "#FF4D4F", bg: "#FFF2F0", border: "#FFCCC7" },

      ENQUEUED: { color: "#FAAD14", bg: "#FFFBE6", border: "#FFE58F" },

      PROCESSING: { color: "#1890FF", bg: "#E6F7FF", border: "#91D5FF" },

      SCHEDULED: { color: "#722ED1", bg: "#F9F0FF", border: "#D3ADF7" },

      DELETED: { color: "#595959", bg: "#FAFAFA", border: "#D9D9D9" },
    };

    const s = map[status];

    if (!s) return null;

    return (
      <span
        style={{
          padding: "4px 10px",

          borderRadius: 999,

          border: `1px solid ${s.border}`,

          background: s.bg,

          color: s.color,

          fontWeight: 500,
        }}
      >
        {status}
      </span>
    );
  };

  /* ---------- TABLE ---------- */

  const columns = [
    // { title: "Job Id", dataIndex: "jobName" },

    { title: "Scheduler Name", dataIndex: "scheduler" },

    { title: "Start Time", dataIndex: "startTime" },

    { title: "End Time", dataIndex: "endTime" },

    { title: "Duration", dataIndex: "duration" },

    { title: "Status", dataIndex: "status", render: renderStatus },

    {
      title: "Action",

      align: "center",

      render: (_, record) => (
        <Dropdown
          menu={{
            items: [
              {
                key: "details",

                label: "More Details",

                onClick: () => handleView(record),
              },
            ],
          }}
        >
          <Button type="text" icon={<MoreOutlined />} />
        </Dropdown>
      ),
    },
  ];

  return (
    <>
      <Card style={{ borderRadius: 12, minHeight: "100vh" }}>
        {/* HEADER */}
        <Space style={{ width: "100%", justifyContent: "space-between" }}>
          <Space>
            <Input
              placeholder="Search Scheduler"
              style={{ width: 260 }}
              suffix={<SearchOutlined />}
              value={filters.scheduler}
              onChange={(e) =>
                setFilters({ ...filters, scheduler: e.target.value })
              }
            />
            <Button
              icon={<FilterOutlined />}
              onClick={() => setShowFilters(!showFilters)}
            >
              Filter
            </Button>
            <Button type="link" onClick={resetFilters}>
              Reset
            </Button>
          </Space>
          <Button icon={<ReloadOutlined />} onClick={loadJobs}>
            Refresh
          </Button>
        </Space>

        {/* FILTERS */}

        {showFilters && (
          <Space wrap style={{ margin: "16px 0" }}>
            <RangePicker
              value={[filters.startDate, filters.endDate]}
              onChange={(dates) =>
                setFilters({
                  ...filters,

                  startDate: dates?.[0],

                  endDate: dates?.[1],
                })
              }
            />
            <Select
              placeholder="Status"
              style={{ width: 200 }}
              allowClear
              value={filters.status || undefined}
              onChange={(v) => setFilters({ ...filters, status: v })}
            >
              <Option value="SUCCEEDED">Succeeded</Option>
              <Option value="FAILED">Failed</Option>
              <Option value="ENQUEUED">Enqueued</Option>
              <Option value="PROCESSING">Processing</Option>
              <Option value="SCHEDULED">Scheduled</Option>
              <Option value="DELETED">Deleted</Option>
            </Select>
          </Space>
        )}

        {/* TABLE */}
        {console.log("jobs", jobs)}
        <Table
          columns={columns}
          dataSource={jobs}
          loading={loading}
          pagination={false}
          locale={{ emptyText: <Empty description="No jobs found" /> }}
          bordered
        />

        {/* FOOTER */}
        <div
          style={{
            marginTop: 16,

            display: "flex",

            justifyContent: "space-between",
          }}
        >
          <span>{totalRecords} total results</span>
          <Pagination
            current={currentPage}
            total={totalRecords}
            pageSize={PAGE_SIZE}
            onChange={setCurrentPage}
            showSizeChanger={false}
          />
        </div>
      </Card>

      <JobDetailsModal
        show={showDetailsModal}
        job={detailsJob}
        onClose={() => setShowDetailsModal(false)}
      />
    </>
  );
};

export default JobHistoryPage;

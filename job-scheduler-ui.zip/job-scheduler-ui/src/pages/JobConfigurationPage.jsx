import { useState, useEffect, useMemo } from "react";

import ConfirmDisableModal from "../Components/ConfirmDisableModal";
import ConfirmEnableModal from "../Components/ConfirmEnableModal";
import UpdateCronModal from "../Components/UpdateCronModal";
import JobHistoryModal from "../Components/JobHistoryModel";

import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Card from "react-bootstrap/Card";

import { Input, Button, message, Modal } from "antd";
import { HistoryOutlined, SearchOutlined } from "@ant-design/icons";
import { IoIosTimer } from "react-icons/io";

import {
  fetchJobs,
  enableJob,
  disableJob,
  fetchJobSummary,
  fetchJobAudit,
} from "../apis/JobApi";

export default function JobConfigurationPage() {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(false);

  const [showEnableModal, setShowEnableModal] = useState(false);
  const [showDisableModal, setShowDisableModal] = useState(false);
  const [showUpdateCronModal, setShowUpdateCronModal] = useState(false);

  const [selectedJob, setSelectedJob] = useState(null);
  const [cronJobName, setCronJobName] = useState(null);

  const [search, setSearch] = useState("");

  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [historyData, setHistoryData] = useState([]);

  // Optional: configure global message position/duration
  message.config({
    top: 16,
    duration: 2.5,
    maxCount: 3,
  });

  const notify = (msg, type = "info") => {
    // fallback to info if unknown type
    const fn =
      {
        info: message.info,
        success: message.success,
        warning: message.warning,
        error: message.error,
        // 'danger' used in your old code -> map to error
        danger: message.error,
        loading: message.loading,
      }[type] || message.info;

    fn(msg);
  };

  useEffect(() => {
    loadJobs();
  }, []);

  // -------------------- Load Jobs --------------------
  const loadJobs = async () => {
    try {
      setLoading(true);

      const jobList = await fetchJobs();

      const enriched = await Promise.all(
        jobList.map(async (job) => {
          try {
            const summary = await fetchJobSummary(job.jobName);
            return {
              id: job.jobName,
              cron: job.cron,
              status: job.active ? "ACTIVE" : "PAUSED",
              instance: summary.totalRuns,
              lastRun: summary.lastRun,
              scheduler: job.scheduler || "-",
              duration: summary.duration || "-",
              startTime: summary.startTime || "-",
              endTime: summary.endTime || "-",
            };
          } catch {
            return {
              id: job.jobName,
              cron: job.cron,
              status: job.active ? "ACTIVE" : "PAUSED",
              instance: 0,
              lastRun: "-",
              scheduler: job.scheduler || "-",
              duration: "-",
              startTime: "-",
              endTime: "-",
            };
          }
        }),
      );

      setJobs(enriched);
    } catch {
      notify("Failed to load jobs", "error");
    } finally {
      setLoading(false);
    }
  };

  const filteredJobs = useMemo(() => {
    if (!search) return jobs;
    return jobs.filter((job) =>
      job.id.toLowerCase().includes(search.toLowerCase()),
    );
  }, [jobs, search]);

  const getJobById = (id) => jobs.find((j) => j.id === id);

  // -------------------- Enable / Disable --------------------
  const handleEnable = (id) => {
    setSelectedJob(id);
    setShowEnableModal(true);
  };

  const handleDisable = (id) => {
    setSelectedJob(id);
    setShowDisableModal(true);
  };

  const confirmEnable = async () => {
    // Close modal first so toast is not hidden by backdrop
    setShowEnableModal(false);

    try {
      const job = getJobById(selectedJob);
      await enableJob(selectedJob, job?.cron);
      notify(`Enabled ${selectedJob}`, "success");
      await loadJobs();
    } catch (err) {
      if (err?.response?.status === 409) {
        Modal.warning({
          title: "Action not allowed",
          content: `The "${selectedJob}" is configured as a one-time job. You can’t enable.`,
          centered: true,
        });
      } else {
        notify("Enable failed", "error");
      }
    }
  };

  const confirmDisable = async () => {
    // Close modal first
    setShowDisableModal(false);

    try {
      await disableJob(selectedJob);
      notify(`Disabled ${selectedJob}`, "warning");
      await loadJobs();
    } catch {
      notify("Disable failed", "error");
    }
  };

  // -------------------- Update Cron --------------------
  const openUpdateCron = (job) => {
    if (job.status === "PAUSED") return;
    setCronJobName(job.id);
    setShowUpdateCronModal(true);
  };

  const saveUpdatedCron = async (newCron) => {
    // Close modal first
    setShowUpdateCronModal(false);

    try {
      await enableJob(cronJobName, newCron);
      notify(`Cron updated for ${cronJobName}`, "success");
      await loadJobs();
    } catch (err) {
      if (err?.response?.status === 409) {
        Modal.warning({
          title: "Action not allowed",
          content: `The "${cronJobName}" is configured as a one-time job. You can’t  update cron.`,
          centered: true,
        });
      } else {
        notify("Cron update failed", "error");
      }
    } finally {
      setCronJobName(null);
    }
  };

  const handleCloseModal = () => {
    setShowEnableModal(false);
    setShowDisableModal(false);
    setShowUpdateCronModal(false);
    setCronJobName(null);
  };

  // -------------------- View History --------------------
  const loadHistory = async () => {
    try {
      setLoading(true);

      const audit = await fetchJobAudit(); // expects res.data.data (array)

      const mapped = (audit || [])
        .slice()
        .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
        .map((item) => ({
          id: item.id,
          jobName: item.jobName || "-",
          action: item.action || "-",
          employeeCode: item.performedBy ?? "-", // performedBy -> employeeCode
          time: formatToYMDHMS(item.timestamp), // "YYYY-MM-DD HH:mm:ss"
          details: item.originalData ?? "", // ONLY originalData
        }));

      setHistoryData(mapped);
    } catch (e) {
      notify("Failed to load job history", "error");
      setHistoryData([]); // ensure modal renders "No history available"
    } finally {
      setLoading(false);
    }
  };

  // Helper: format ISO timestamp -> "YYYY-MM-DD HH:mm:ss" in local time
  function formatToYMDHMS(isoString) {
    if (!isoString) return "-";
    const d = new Date(isoString);
    if (isNaN(d.getTime())) return "-";
    const pad = (n) => String(n).padStart(2, "0");
    const yyyy = d.getFullYear();
    const MM = pad(d.getMonth() + 1);
    const dd = pad(d.getDate());
    const hh = pad(d.getHours());
    const mm = pad(d.getMinutes());
    const ss = pad(d.getSeconds());
    return `${yyyy}-${MM}-${dd} ${hh}:${mm}:${ss}`;
  }

  return (
    <Container fluid className="mt-3">
      {/* Parent Card */}
      <Card
        style={{
          padding: "16px",
          backgroundColor: "#f8f9fa",
          minHeight: "100vh",
        }}
      >
        <Card.Body>
          {/* Top Row: Search + View History */}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 16,
            }}
          >
            <Input
              allowClear
              prefix={<SearchOutlined style={{ color: "#9ca3af" }} />}
              placeholder="Search job name"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={{ width: 320, borderRadius: 6 }}
            />

            <Button
              type="primary"
              icon={<HistoryOutlined />}
              loading={loading}
              onClick={() => {
                loadHistory();
                setShowHistoryModal(true);
              }}
            >
              View History
            </Button>
          </div>

          {/* Job Cards */}
          <Row style={{ rowGap: "20px" }}>
            {filteredJobs.map((job) => (
              <Col key={job.id} md={4}>
                <Card
                  style={{
                    padding: "16px",
                    boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
                  }}
                >
                  <Card.Body>
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                      }}
                    >
                      <span
                        style={{
                          display: "inline-flex",
                          alignItems: "center",
                          padding: "2px 10px",
                          borderRadius: "999px",
                          fontSize: "12px",
                          fontWeight: 600,
                          lineHeight: 1,
                          backgroundColor:
                            job.status === "ACTIVE" ? "#E9F8EC" : "#F3F4F6",
                          border: `1px solid ${job.status === "ACTIVE" ? "#6CC68D" : "#D1D5DB"}`,
                          color:
                            job.status === "ACTIVE" ? "#137B3A" : "#374151",
                        }}
                      >
                        {job.status === "ACTIVE" ? "Active" : "Paused"}
                      </span>

                      <Button
                        type="link"
                        // onClick={() => notify("View individual job history", "info")}
                        icon={<IoIosTimer />}
                      />
                    </div>

                    <div
                      style={{
                        fontSize: "14px",
                        fontWeight: 600,
                        marginBottom: "8px",
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                      }}
                    >
                      {job.id}
                    </div>

                    <div
                      style={{
                        fontSize: "12px",
                        color: "#6b7280",
                        marginBottom: "8px",
                      }}
                    >
                      <div>Cron: {job.cron}</div>
                      <div>Instances: {job.instance}</div>
                      <div>Last run: {job.lastRun}</div>
                    </div>

                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                      }}
                    >
                      {job.status === "PAUSED" ? (
                        <Button
                          size="small"
                          onClick={() => handleEnable(job.id)}
                        >
                          Enable
                        </Button>
                      ) : (
                        <Button
                          size="small"
                          onClick={() => handleDisable(job.id)}
                        >
                          Disable
                        </Button>
                      )}

                      <span
                        style={{
                          cursor:
                            job.status === "PAUSED" ? "not-allowed" : "pointer",
                          color:
                            job.status === "PAUSED" ? "#9ca3af" : "#2684dc",
                          fontWeight: 500,
                          fontSize: "12px",
                        }}
                        onClick={() => openUpdateCron(job)}
                      >
                        Update Cron
                      </span>
                    </div>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        </Card.Body>
      </Card>

      {/* Modals */}
      <ConfirmEnableModal
        show={showEnableModal}
        onClose={handleCloseModal}
        onConfirm={confirmEnable}
        jobName={selectedJob}
      />

      <ConfirmDisableModal
        show={showDisableModal}
        onClose={handleCloseModal}
        onConfirm={confirmDisable}
        jobName={selectedJob}
      />

      <UpdateCronModal
        show={showUpdateCronModal}
        onClose={handleCloseModal}
        onSave={saveUpdatedCron}
        jobName={cronJobName}
        initialCron={cronJobName ? getJobById(cronJobName)?.cron : ""}
      />

      <JobHistoryModal
        show={showHistoryModal}
        onClose={() => setShowHistoryModal(false)}
        history={historyData}
      />
    </Container>
  );
}

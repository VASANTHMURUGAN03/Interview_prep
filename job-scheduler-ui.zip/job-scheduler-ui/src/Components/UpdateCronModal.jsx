
// UpdateCronModal.jsx
import React, { useState, useEffect } from "react";
import { Modal, Button, Form } from "react-bootstrap";

const UpdateCronModal = ({ show, onClose, onSave, jobName, initialCron }) => {
  const [cron, setCron] = useState(initialCron || "");
  const [error, setError] = useState("");

  useEffect(() => {
    setCron(initialCron || "");
    setError("");
  }, [initialCron, show]);

  // Simple validation: allow 5 or 6 space-separated fields
  const isCronValid = (value) => {
    if (!value) return false;
    const parts = value.trim().split(/\s+/);
    return parts.length === 5 || parts.length === 6;
  };

  const handleSave = () => {
    if (!isCronValid(cron)) {
      setError("Please enter a valid cron expression (5 or 6 fields).");
      return;
    }
    onSave(cron);
  };

  return (
    <Modal show={show} onHide={onClose} centered>
      <Modal.Header closeButton>
        <Modal.Title>Update Cron</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <div style={{ marginBottom: 8, fontSize: 12, color: "#6b7280" }}>
          Job: <strong>{jobName}</strong>
        </div>

        <Form.Group controlId="updateCronInput">
          <Form.Label>Cron Expression</Form.Label>
          <Form.Control
            type="text"
            placeholder="e.g. */5 * * * *"
            value={cron}
            onChange={(e) => setCron(e.target.value)}
            isInvalid={!!error}
          />
          <Form.Control.Feedback type="invalid">{error}</Form.Control.Feedback>
          <Form.Text muted>
            Format: minute hour day-of-month month day-of-week (optionally seconds at the beginning).
          </Form.Text>
        </Form.Group>
      </Modal.Body>

      <Modal.Footer>
        <Button variant="outline-secondary" onClick={onClose}>
          Close
        </Button>
        <Button variant="primary" onClick={handleSave}>
          Save
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default UpdateCronModal;



import { Modal, Button } from "react-bootstrap";

function ConfirmDisableModal({
  show,
  onClose,
  onConfirm,
  jobName,
}) {
  return (
    <Modal
      show={show}
      onHide={onClose}
      centered
      backdrop="static"
      keyboard={true}
      size="sm" // compact dialog width
    >
      <Modal.Header
        closeButton
        style={{
          padding: "12px 16px",
          borderBottom: "1px solid #f0f2f5",
          // Rounded corners are handled by Bootstrap; small tweak to feel like the screenshot
          backgroundColor: "#fff",
        }}
      >
        <Modal.Title
          style={{
            fontSize: "16px",
            fontWeight: 600,
            color: "#111827",
            margin: 0,
          }}
        >
          Confirm
        </Modal.Title>
      </Modal.Header>

      <Modal.Body
        style={{
          padding: "16px",
          fontSize: "14px",
          color: "#1f2937",
          lineHeight: 1.5,
          backgroundColor: "#fff",
        }}
      >
        <p style={{ margin: 0 }}>
          Are you sure you want to disable this job
          {jobName ? (
            <>
              : <strong>{jobName}</strong>
            </>
          ) : (
            "?"
          )}
        </p>
      </Modal.Body>

      <Modal.Footer
        style={{
          padding: "12px 16px 16px",
          borderTop: "none",
          display: "flex",
          justifyContent: "flex-end",
          gap: "8px",
          backgroundColor: "#fff",
        }}
      >
        <Button
          onClick={onClose}
          style={{
            backgroundColor: "#f9fafb",   // light gray
            color: "#374151",
            border: "1px solid #e5e7eb",
            borderRadius: "8px",
            padding: "6px 14px",
            fontSize: "14px",
            fontWeight: 500,
          }}
          // keep Bootstrap focus/hover states via variants if you prefer
          // variant="light"
        >
          No
        </Button>

        <Button
          onClick={onConfirm}
          style={{
            backgroundColor: "#1f6feb",   // blue like the screenshot
            borderColor: "#1f6feb",
            color: "#fff",
            borderRadius: "8px",
            padding: "6px 14px",
            fontSize: "14px",
            fontWeight: 600,
          }}
          // variant="primary"
        >
          Yes
        </Button>
      </Modal.Footer>
    </Modal>
  );
}

export default ConfirmDisableModal;

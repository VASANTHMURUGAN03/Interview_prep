
import React from "react";
import {
  DashboardOutlined,
  HistoryOutlined,
  FieldTimeOutlined,
  ThunderboltOutlined 
} from "@ant-design/icons";

export default function Tabs({ activeTab, onChange }) {
  const container = {
    display: "flex",
    gap: "8px",
    background: "#f1f3f5",
    padding: "6px",
    borderRadius: "12px",
    width: "fit-content",
    margin: "12px 16px",
    userSelect: "none",
  };

  const tab = {
    padding: "10px 20px",
    borderRadius: "10px",
    fontWeight: 600,
    cursor: "pointer",
    color: "#6c757d",
    background: "transparent",
    transition: "all 0.2s ease-in-out",
    display: "inline-flex",
    alignItems: "center",
    gap: "8px", // spacing between icon and label
  };

  const active = {
    background: "#ffffff",
    color: "#212529",
    boxShadow: "0 2px 8px rgba(0,0,0,0.12)",
  };

  const hover = {
    background: "#e9ecef",
  };

  const iconStyle = {
    fontSize: 16, // tweak icon size if needed
  };

  const tabs = [
    { key: "JOBS", label: "Dashboard", icon: <DashboardOutlined style={iconStyle} /> },
    { key: "HISTORY", label: "Job History", icon: <HistoryOutlined style={iconStyle} /> },
    { key: "CONFIG", label: "Job Config", icon: <FieldTimeOutlined style={iconStyle} /> },
     {key: "ONETIMEJOB", label: "Run Once", icon: <ThunderboltOutlined style={iconStyle} /> },
  ];

  return (
    <div style={container} role="tablist" aria-label="Job Scheduler Tabs">
      {tabs.map((t) => (
        <span
          key={t.key}
          role="tab"
          aria-selected={activeTab === t.key}
          tabIndex={0}
          style={{
            ...tab,
            ...(activeTab === t.key ? active : {}),
          }}
          onClick={() => onChange(t.key)}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") onChange(t.key);
          }}
          onMouseEnter={(e) => {
            if (activeTab !== t.key) e.currentTarget.style.background = hover.background;
          }}
          onMouseLeave={(e) => {
            if (activeTab !== t.key) e.currentTarget.style.background = "transparent";
          }}
        >
          {t.icon}
          <span>{t.label}</span>
        </span>
      ))}
    </div>
  );
}

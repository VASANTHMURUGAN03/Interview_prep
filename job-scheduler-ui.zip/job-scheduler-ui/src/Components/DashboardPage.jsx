import { useEffect, useState } from "react";

import { Container, Row, Col, Card, Form, InputGroup, Button } from "react-bootstrap";

import { fetchDashboardStateCounts } from "../apis/JobApi";

import { Doughnut } from "react-chartjs-2";

import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";
 
ChartJS.register(ArcElement, Tooltip, Legend);
 
export default function DashboardPage() {

  const [filters, setFilters] = useState({

    jobName: "",

    timeRange: "24hr",

  });
 
  const [cardData, setCardData] = useState({

    totalJobs: 0,

    activeJobs: 0,

    succeededJobs: 0,

  });
 
  const [chartData, setChartData] = useState({

    enqueued: 0,

    scheduled: 0,

    processing: 0,

    failed: 0,

    succeeded: 0,

  });
 
  const handleFilterChange = (e) => {

    const { name, value } = e.target;

    setFilters((p) => ({ ...p, [name]: value }));

  };
 
  const clearJobName = () => setFilters((p) => ({ ...p, jobName: "" }));
 
 const fetchStateCounts = async () => {
  try {
    const data = await fetchDashboardStateCounts(); // axios → already parsed

    if (data.responseCode === 200) {
      const { cardData, chartData } = data.data;
      setCardData(cardData);
      setChartData(chartData);
    }
  } catch (err) {
    console.error("Failed to fetch state counts", err);
  }
};
  useEffect(() => {

    fetchStateCounts();

  }, []);
 
  // ----- Stat Cards -----

  const stats = [

    { label: "Total Jobs", value: cardData.totalJobs, color: "#3498db" },

    { label: "Active Jobs", value: cardData.activeJobs, color: "#f1c40f" },

    { label: "Failed Jobs", value: chartData.failed, color: "#e74c3c" },

    { label: "Success Jobs", value: cardData.succeededJobs, color: "#2ecc71" },

  ];
 
  // ----- Charts -----

  const successFailureData = {

    labels: ["Success", "Failure"],

    datasets: [

      {

        data: [chartData.succeeded, chartData.failed],

        backgroundColor: ["#2ecc71", "#e74c3c"],

        borderWidth: 1,

      },

    ],

  };
 
  const statusDistributionData = {

    labels: ["Scheduled", "Enqueued", "Processing", "Succeeded", "Failed"],

    datasets: [

      {

        data: [

          chartData.scheduled,

          chartData.enqueued,

          chartData.processing,

          chartData.succeeded,

          chartData.failed,

        ],

        backgroundColor: ["#0aa2b0", "#c2a89a", "#ff9f43", "#f6b26b", "#e05666"],

        borderWidth: 1,

      },

    ],

  };
 
  return (
<Container

      fluid

      style={{

        background: "#f8f9fb",

        minHeight: "100vh",

        padding: "24px",

      }}
>

      {/* ---------- Filters ---------- */}
{/* <Row className="mb-4 g-2">
<Col md={4}>
<InputGroup>
<Form.Control

              placeholder="Search Job Name"

              name="jobName"

              value={filters.jobName}

              onChange={handleFilterChange}

              style={{ borderRadius: "8px" }}

            />

            {filters.jobName && (
<Button variant="outline-secondary" onClick={clearJobName} style={{ borderRadius: "8px" }}>
<X />
</Button>

            )}
</InputGroup>
</Col>
 
        <Col md={4}>
<Form.Select

            name="timeRange"

            value={filters.timeRange}

            onChange={handleFilterChange}

            style={{ borderRadius: "8px" }}
>
<option value="1hr">Last 1 Hour</option>
<option value="6hr">Last 6 Hours</option>
<option value="24hr">Last 24 Hours</option>
<option value="yesterday">Yesterday</option>
<option value="thisweek">This Week</option>
</Form.Select>
</Col>
 
        <Col md={4} className="d-flex justify-content-end">
<Button

            variant="outline-primary"

            onClick={fetchStateCounts}

            style={{ borderRadius: "8px", display: "flex", alignItems: "center", gap: "6px" }}
>
<ArrowRepeat /> Refresh
</Button>
</Col>
</Row> */}
 
      {/* ---------- Stat Cards ---------- */}
<Row className="g-3 mb-4">

        {stats.map((s) => (
<Col md={3} key={s.label}>
<Card

              className="shadow-sm"

              style={{

                borderRadius: "12px",

                padding: "16px",

                borderLeft: `6px solid ${s.color}`,

              }}
>

<div style={{ fontSize: "14px", color: "#6c757d", marginBottom: "6px" }}>{s.label}</div>
<div style={{ fontSize: "26px", fontWeight: 700, color: "#212529" }}>{s.value}</div>
</Card>
</Col>

        ))}
</Row>
 
      {/* ---------- Charts ---------- */}
<Row className="g-3">
<Col md={6}>
<Card

            className="shadow-sm"

            style={{ borderRadius: "12px", padding: "16px", height: "89%" }}
>
<div style={{ fontWeight: 600, marginBottom: "12px", fontSize: "16px" }}>JOB PERFORMANCE</div>
<div

              style={{

                height: "340px",

                display: "flex",

                justifyContent: "center",

                alignItems: "center",

              }}
>
<Doughnut

                data={successFailureData}

                options={{

                  cutout: "70%",

                  plugins: {

                    legend: { position: "right" },

                  },

                }}

              />
</div>
</Card>
</Col>
 
        <Col md={6}>
<Card

            className="shadow-sm"

            style={{ borderRadius: "12px", padding: "16px", height: "89%" }}
>
<div style={{ fontWeight: 600, marginBottom: "12px", fontSize: "16px" }}>

              JOB STATUS DISTRIBUTION
</div>
<div

              style={{

                height: "340px",

                display: "flex",

                justifyContent: "center",

                alignItems: "center",

              }}
>
<Doughnut

                data={statusDistributionData}

                options={{

                  cutout: "65%",

                  plugins: {

                    legend: { position: "right" },

                  },

                }}

              />
</div>
</Card>
</Col>
</Row>
</Container>

  );

}

 
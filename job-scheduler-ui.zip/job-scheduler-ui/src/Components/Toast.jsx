
import { useEffect } from "react";

export default function Toast({ message, type = "info", onHide }) {
  useEffect(() => {
    const t = setTimeout(onHide, 2500);
    return () => clearTimeout(t);
  }, [onHide]);

  return <div className={`toast ${type}`}>{message}</div>;
}

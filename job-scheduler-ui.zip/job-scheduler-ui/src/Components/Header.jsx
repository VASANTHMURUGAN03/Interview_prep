import React, { useEffect, useState } from "react";
import { Space, Avatar } from "antd";
import { UserOutlined } from "@ant-design/icons";
import star from "../assets/star.png";
import axiosClient from "../apis/axiosClient"; // adjust path if needed

export default function Header() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    async function fetchUserDetails() {
      try {
        const res = await axiosClient.post("/ext/api/v1/auth/user/details");
        setUser(res.data.data);
      } catch (err) {
        console.error("Failed to fetch user details", err);
      }
    }
    fetchUserDetails();
  }, []);

  return (
    <header
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "16px 24px",
        backgroundColor: "#ffffff",
        borderBottom: "1px solid #e0e0e0",
        boxShadow: "0 2px 4px rgba(0,0,0,0.05)",
      }}
    >
      {/* Left: Logo */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 8,
          fontWeight: 600,
          fontSize: 14,
          color: "#111827",
        }}
      >
        <img
          src={star}
          alt="Star Health Logo"
          style={{
            height: 40,
            width: "auto",
          }}
        />
      </div>

      {/* Middle: Title */}
      <div
        style={{
          position: "absolute",
          left: "50%",
          transform: "translateX(-50%)",
          fontSize: 20,
          fontWeight: 600,
          color: "#2E3C8A",
          letterSpacing: "0.4px",
        }}
      >
        JOB SCHEDULER
      </div>

      {/* Right: Profile */}
      <Space size="small" style={{ fontWeight: 500, color: "#2E3C8A" }}>
        <Avatar
          size="small"
          icon={<UserOutlined />}
          style={{ backgroundColor: "#2E3C8A" }}
        />
        <span>{user ? user.userFirstName : "Loading..."}</span>
      </Space>
    </header>
  );
}

export default function Card({ title, children, right }) {
  return (
    <div className="card">
      <div className="card-header">
        <h4>{title}</h4>
        <div>{right}</div>
      </div>
      <div className="card-body">{children}</div>
    </div>
  );
}

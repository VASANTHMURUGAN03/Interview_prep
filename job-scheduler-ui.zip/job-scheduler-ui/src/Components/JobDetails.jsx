export default function JobDetails({ job }) {
  if (!job) return null;
  return (
    <div className="job-details">
      <h4>Job Details</h4>
      <p><strong>ID:</strong> {job.id}</p>
      <p><strong>Cron:</strong> {job.cron}</p>
      <p><strong>Status:</strong> {job.status}</p>
      <p><strong>Group:</strong> {job.group}</p>
      <p><strong>Created:</strong> {job.createdAt}</p>
      <p><strong>Last Run:</strong> {job.lastRun}</p>
    </div>
  );
}

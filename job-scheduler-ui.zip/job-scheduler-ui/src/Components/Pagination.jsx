export default function Pagination() {
  return (
    <div className="pagination">
      <button>{"<"}</button>
      <button className="active">1</button>
      <button>{">"}</button>
    </div>
  );
}


import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Card from "react-bootstrap/Card";

export default function JobOverview({ stats }) {
  const enqueued = Number(stats.enqueued ?? 0);
  const scheduled = Number(stats.scheduled ?? 0);
  const processing = Number(stats.processing ?? 0);
  const succeeded = Number(stats.succeeded ?? 0);
  const failed = Number(stats.failed ?? 0);
  const activeJobs = Number(stats.activeJobs ?? 0);

  const triggered = enqueued + scheduled + processing + succeeded + failed;
  const successRate = triggered ? Math.round((succeeded / triggered) * 100) : 0;
console.log("Inside JobOverview Component");
  const items = [
    { label: "Jobs Triggered", value: triggered, color: "#2f5fa7" },
    { label: "Success Rate", value: `${successRate}%`, color: "#6b8fcf" },
    { label: "Active Jobs", value: activeJobs, color: "#8560a8" },
    { label: "Successful", value: succeeded, color: "#3aa57c" },
    { label: "Failed", value: failed, color: "#e06666" },
  ];

  return (
    <Row xs={1} md={2} lg={3} className="g-3">
      {items.map((x) => (
        <Col key={x.label}>
          <Card className="h-100 border-0 shadow-sm">
            <Card.Body className="d-flex flex-column">
              <div
                className="display-6 fw-bold"
                style={{ color: x.color, lineHeight: 1 }}
              >
                {x.value}
              </div>
              <div className="text-muted mt-1">{x.label}</div>
            </Card.Body>
          </Card>
        </Col>
      ))}
    </Row>
  );
}

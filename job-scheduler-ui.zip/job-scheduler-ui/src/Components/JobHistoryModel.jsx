// src/Components/JobHistoryModal.jsx

import React from "react";
import { Modal, Table, Button } from "antd";

// props: show (boolean), onClose (function), history (array of objects)

const JobHistoryModal = ({ show, onClose, history }) => {
  if (!history) return null;

  // Define AntD table columns
  const columns = [
    {
      title: "Job Name",
      dataIndex: "jobName",
      key: "jobName",
    },
    {
      title: "Action",
      dataIndex: "action",
      key: "action",
    },
    {
      title: "Employee",
      dataIndex: "employeeCode",
      key: "employeeCode",
    },
    {
      title: "Date/Time",
      dataIndex: "time",
      key: "time",
    },
    {
      title: "Details",
      dataIndex: "details",
      key: "details",
      // If details can be long, consider word wrapping:
      render: (text) => <span style={{ whiteSpace: "pre-wrap" }}>{text}</span>,
    },
  ];

  return (
    <Modal
      title="Job History"
      open={show}
      onCancel={onClose}
      centered
      width={900}              // roughly similar to a "lg" modal
      maskClosable={false}     // equivalent to backdrop="static"
      footer={
        <Button onClick={onClose}>
          Close
        </Button>
      }
      bodyStyle={{ maxHeight: "60vh", overflowY: "auto" }} // keep scroll behavior
      destroyOnClose
    >
      <Table
        dataSource={history.map((h, idx) => ({ ...h, key: idx }))}
        columns={columns}
        size="small"               // similar to size="sm"
        bordered
        pagination={false}
        scroll={{ x: true }}       // allow horizontal scroll if needed
        locale={{ emptyText: "No history available" }}
      />
    </Modal>
  );
};

export default JobHistoryModal;
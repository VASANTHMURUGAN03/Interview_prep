export default function Footer() {
  console.log("Inside Footer Component");
  return (
<footer
      style={{
        height: 44,
        backgroundColor: "#ffffff",
        borderTop: "1px solid #e5e7eb",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "0 16px",
        fontSize: 12,
        color: "#6b7280",
      }}
>
      {/* Left */}
<div   style={{
          position: "absolute",
          left: "50%",
          transform: "translateX(-50%)",
          fontSize: 16,
          fontWeight: 400,
          color: "#111827",
          letterSpacing: "0.4px",
        }}>
        © {new Date().getFullYear()},copyright www.starhealth.in
</div>
 
      {/* Right */}
{/* <div
        style={{
          display: "flex",
          gap: 16,
          fontWeight: 500,
        }}
>
<span style={{ cursor: "pointer" }}>Privacy</span>
<span style={{ cursor: "pointer" }}>Terms</span>
<span style={{ cursor: "pointer" }}>Help</span>
</div> */}
</footer>
  );
}

import { useState } from "react";
import { BsThreeDots } from "react-icons/bs";
import "bootstrap/dist/css/bootstrap.min.css";

/**
 * JobsTable
 * - mode: "config" | "history"
 */
export default function JobsTable({
  jobs = [],
  mode = "config",
  onRetry, // used only in config mode
}) {
  const [detailsJob, setDetailsJob] = useState(null);

  const handleOpen = (job) => setDetailsJob(job);
  const handleClose = () => setDetailsJob(null);

  const isActive = (status) => String(status).toUpperCase() === "ACTIVE";

  return (
    <>
      <div className="table-responsive">
        <table className="table table-hover align-middle">
          <thead className="table-light">
            {mode === "history" ? (
              <tr>
                <th>Scheduler</th>
                <th>Status</th>
                <th>Start Time</th>
                <th>End Time</th>
                <th>Duration</th>
                <th>Success</th>
              </tr>
            ) : (
              <tr>
                <th>Job Id</th>
                <th>Cron</th>
                <th>Status</th>
                <th>Job Name</th>
                <th style={{ width: 80 }}>Actions</th>
              </tr>
            )}
          </thead>
          <tbody>
            {jobs.map((job) => {
              if (mode === "history") {
                const started = job.startTime ? new Date(job.startTime) : null;
                const ended = job.endTime ? new Date(job.endTime) : null;
                const durationMs = started && ended ? Math.max(0, ended - started) : null;
                const dur = durationMs
                  ? (() => {
                      const s = Math.floor(durationMs / 1000);
                      const h = Math.floor(s / 3600);
                      const m = Math.floor((s % 3600) / 60);
                      const sec = s % 60;
                      return `${h}h ${m}m ${sec}s`;
                    })()
                  : "-";
                const success = String(job.status).toLowerCase() === "success";
                return (
                  <tr key={job.id || `${job.schedulerName}-${job.startTime}`}>
                    <td className="text-truncate" title={job.schedulerName || ""}>
                      {job.schedulerName || "-"}
                    </td>
                    <td className={success ? "text-success" : job.status === "failed" ? "text-danger" : ""}>
                      {job.status || "-"}
                    </td>
                    <td>{job.startTime || "-"}</td>
                    <td>{job.endTime || "-"}</td>
                    <td>{dur}</td>
                    <td>{success ? "Yes" : "No"}</td>
                  </tr>
                );
              }

              const method =
                job.className && job.methodName
                  ? `${job.className}.${job.methodName}()`
                  : job.signature || "-";

              return (
                <tr
                  key={job.id || job.jobRunrId}
                  className={isActive(job.status) ? "" : "opacity-50"}
                >
                  <td>
                    <button
                      type="button"
                      className="btn btn-link p-0 text-decoration-none"
                      onClick={() => handleOpen(job)}
                      title="View details"
                    >
                      {job.id || job.jobRunrId}
                    </button>
                  </td>

                  <td className="text-truncate" title={method}>
                    {method}
                  </td>

                  <td>
                    <span
                      className={`badge rounded-pill ${
                        isActive(job.status)
                          ? "bg-success"
                          : String(job.status).toUpperCase() === "PAUSED"
                          ? "bg-warning text-dark"
                          : String(job.status).toUpperCase() === "FAILED"
                          ? "bg-danger"
                          : "bg-secondary"
                      }`}
                    >
                      {job.status || "-"}
                    </span>
                  </td>

                  <td
                    className="text-truncate"
                    title={job.recurringJobId || job.group || ""}
                  >
                    {job.recurringJobId || job.group || "-"}
                  </td>

                  <td>
                    <div className="actions-dot-wrap">
                      <button
                        type="button"
                        className="btn btn-link actions-dot-btn"
                        title="Actions"
                      >
                        <BsThreeDots size={18} />
                      </button>

                      <div className="actions-hover-menu">
                        <button
                          type="button"
                          className="dropdown-item"
                          onClick={() => onRetry?.(job.id || job.jobRunrId)}
                          disabled={!isActive(job.status)} // only enable when ACTIVE
                          title={
                            isActive(job.status)
                              ? "Retry job"
                              : "Retry visible only when ACTIVE"
                          }
                        >
                          Retry
                        </button>
                      </div>
                    </div>
                  </td>
                </tr>
              );
            })}

            {jobs.length === 0 && (
              <tr>
                <td
                  colSpan={mode === "history" ? 6 : 5}
                  className="text-center text-muted py-4"
                >
                  No jobs found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Small controlled modal (Bootstrap-like) */}
      <div
        className={`modal fade ${detailsJob ? "show d-block" : ""}`}
        tabIndex="-1"
        role="dialog"
        aria-modal={detailsJob ? "true" : undefined}
        style={{
          backgroundColor: detailsJob ? "rgba(0,0,0,0.35)" : "transparent",
        }}
      >
        <div className="modal-dialog modal-sm modal-dialog-centered">
          <div className="modal-content">
            <div className="modal-header py-2">
              <h6 className="modal-title">Job details</h6>
              <button
                type="button"
                className="btn-close"
                onClick={handleClose}
                aria-label="Close"
              />
            </div>

            <div className="modal-body small">
              {detailsJob ? (
                <div className="d-flex flex-column gap-2">
                  <div>
                    <strong>Job ID:</strong>{" "}
                    {detailsJob.id || detailsJob.jobRunrId}
                  </div>
                  <div>
                    <strong>Method:</strong>{" "}
                    {detailsJob.className && detailsJob.methodName
                      ? `${detailsJob.className}.${detailsJob.methodName}()`
                      : detailsJob.signature || "-"}
                  </div>
                  <div>
                    <strong>Status:</strong> {detailsJob.status || "-"}
                  </div>
                  <div>
                    <strong>Job Name:</strong>{" "}
                    {detailsJob.recurringJobId || detailsJob.group || "-"}
                  </div>
                  <div>
                    <strong>Cron:</strong> {detailsJob.cron || "-"}
                  </div>
                  <div>
                    <strong>Created At:</strong> {detailsJob.createdAt || "-"}
                  </div>
                  <div>
                    <strong>Scheduled At:</strong>{" "}
                    {detailsJob.scheduledAt || "-"}
                  </div>
                  <div>
                    <strong>Last run:</strong> {detailsJob.lastRun || "-"}
                  </div>
                  <div>
                    <strong>Latency Seconds:</strong>{" "}
                    {detailsJob.latencySeconds || "-"}
                  </div>
                  <div>
                    <strong>Process Millis:</strong>{" "}
                    {detailsJob.processMillis || "-"}
                  </div>
                </div>
              ) : (
                <div className="text-muted">No data</div>
              )}
            </div>

            <div className="modal-footer py-2">
              <button
                type="button"
                className="btn btn-primary btn-sm"
                onClick={handleClose}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

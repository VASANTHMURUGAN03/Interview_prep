import { Modal, Card, Row, Col, Divider, Tag, Empty } from "antd";

import { ArrowLeftOutlined } from "@ant-design/icons";

import dayjs from "dayjs";
 
const STATUS_MAP = {

  SCHEDULED: "default",

  ENQUEUED: "blue",

  PROCESSING: "gold",

  SUCCEEDED: "green",

  FAILED: "red",

  DELETED: "default"

};
 
const JobDetailsModal = ({ show, onClose, job }) => {

  if (!job) return null;
 
  return (
<Modal

      open={show}

      footer={null}

      onCancel={onClose}

      centered

      width={700}

      closeIcon={null}
>

      {/* ---------- HEADER ---------- */}
<div style={{ display: "flex", justifyContent: "space-between" }}>
<div style={{ cursor: "pointer" }} onClick={onClose}>
<ArrowLeftOutlined /> Go back
</div>
<Tag color={STATUS_MAP[job.status]}>{job.status}</Tag>
</div>
 
      {/* ---------- SUMMARY ---------- */}
<Card title="Job Summary" style={{ marginTop: 16 }}>
<Row gutter={[16, 12]}>
<Col span={12}><b>Scheduler</b><br />{job.scheduler}</Col>
<Col span={12}><b>Duration</b><br />{job.duration}</Col>
</Row>
</Card>
 
      {/* ---------- HISTORY ---------- */}
<Card title="State History" style={{ marginTop: 16 }}>

        {job.history?.length ? (

          job.history.map((h, i) => (
<div key={i}>
<Tag color={STATUS_MAP[h.state]}>{h.state}</Tag>
<span style={{ marginLeft: 8 }}>

                {dayjs(h.createdAt).format("YYYY-MM-DD HH:mm:ss")}
</span>
<div style={{ marginLeft: 80, color: "#666" }}>

                {h.reason || "-"}
</div>

              {i !== job.history.length - 1 && <Divider />}
</div>

          ))

        ) : (
<Empty />

        )}
</Card>
</Modal>

  );

};
 
export default JobDetailsModal;

 
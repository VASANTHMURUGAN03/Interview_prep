
import { useState } from "react";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";

/**
 * Filters
 * - variant: "config" | "history"
 */
export default function Filters({ onChange, variant = "config" }) {
  const [open, setOpen] = useState(true);
  const [local, setLocal] = useState(
    variant === "history"
      ? { start: "", end: "", scheduler: "", status: "" }
      : { jobId: "", cron: "", status: "", jobName: "", dateTo: "" }
  );

  const apply = () => onChange?.(local);

  const reset =
    variant === "history"
      ? { start: "", end: "", scheduler: "", status: "" }
      : { jobId: "", cron: "", status: "", dateFrom: "", dateTo: "" };

  return (
    <Card className="shadow-sm">
      <Card.Header className="d-flex justify-content-between align-items-center">
        <Card.Title className="mb-0">Filters</Card.Title>
        <Button variant="link" className="text-decoration-none" onClick={() => setOpen((v) => !v)}>
          {open ? "Hide" : "Show"}
        </Button>
      </Card.Header>

      {open && (
        <Card.Body>
          {variant === "history" ? (
            <Form onSubmit={(e) => e.preventDefault()}>
              <Row className="g-3">
                <Col md={3}>
                  <Form.Label>Start</Form.Label>
                  <Form.Control
                    type="datetime-local"
                    value={local.start}
                    onChange={(e) => setLocal({ ...local, start: e.target.value })}
                  />
                </Col>
                <Col md={3}>
                  <Form.Label>End</Form.Label>
                  <Form.Control
                    type="datetime-local"
                    value={local.end}
                    onChange={(e) => setLocal({ ...local, end: e.target.value })}
                  />
                </Col>
                <Col md={3}>
                  <Form.Label>Scheduler name</Form.Label>
                  <Form.Control
                    placeholder="e.g. nightly-report"
                    value={local.scheduler}
                    onChange={(e) => setLocal({ ...local, scheduler: e.target.value })}
                  />
                </Col>
                <Col md={3}>
                  <Form.Label>Status</Form.Label>
                  <Form.Select
                    value={local.status}
                    onChange={(e) => setLocal({ ...local, status: e.target.value })}
                  >
                    <option value="">All</option>
                    <option value="success">Success</option>
                    <option value="failed">Failed</option>
                    <option value="running">Running</option>
                    <option value="queued">Queued</option>
                  </Form.Select>
                </Col>
              </Row>

              <div className="d-flex gap-2 mt-3">
                <Button variant="primary" onClick={apply}>
                  Apply
                </Button>
                <Button
                  variant="outline-secondary"
                  onClick={() => {
                    setLocal(reset);
                    onChange?.(reset);
                  }}
                >
                  Reset
                </Button>
              </div>
            </Form>
          ) : (
            <Form onSubmit={(e) => e.preventDefault()}>
              <Row className="g-3">
                <Col md={3}>
                  <Form.Label>Job ID</Form.Label>
                  <Form.Control
                    placeholder="Job ID"
                    value={local.jobId}
                    onChange={(e) => setLocal({ ...local, jobId: e.target.value })}
                  />
                </Col>
                <Col md={3}>
                  <Form.Label>Cron</Form.Label>
                  <Form.Control
                    placeholder="*/5 * * * *"
                    value={local.cron}
                    onChange={(e) => setLocal({ ...local, cron: e.target.value })}
                  />
                </Col>
                <Col md={3}>
                  <Form.Label>Status</Form.Label>
                  <Form.Select
                    value={local.status}
                    onChange={(e) => setLocal({ ...local, status: e.target.value })}
                  >
                    <option value="">All</option>
                    <option value="ACTIVE">Active</option>
                    <option value="PAUSED">Paused</option>
                    <option value="FAILED">Failed</option>
                  </Form.Select>
                </Col>
                <Col md={3}>
                  <Form.Label>Job Name</Form.Label>
                  <Form.Control
                    placeholder="Group/Recurring"
                    value={local.jobName}
                    onChange={(e) => setLocal({ ...local, jobName: e.target.value })}
                  />
                </Col>
              </Row>

              <div className="d-flex gap-2 mt-3">
                <Button variant="primary" onClick={apply}>
                  Apply
                </Button>
                <Button
                  variant="outline-secondary"
                  onClick={() => {
                    setLocal(reset);
                    onChange?.(reset);
                  }}
                >
                  Reset
                </Button>
              </div>
            </Form>
          )}
        </Card.Body>
      )}
    </Card>
  );
}

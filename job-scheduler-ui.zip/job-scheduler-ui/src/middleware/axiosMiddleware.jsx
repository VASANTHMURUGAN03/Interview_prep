import axiosClient from "../apis/axiosClient";
import { clearCookies, getPartnerAccessToken } from '../utils/cookieUtils';

let installed = false;

export function initAxiosInterceptors() {
  if (installed) return;
  installed = true;

  axiosClient.interceptors.request.use(
    (config) => {
      const token = getPartnerAccessToken(); // fetch per request
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    },
    (error) => Promise.reject(error)
  );

  axiosClient.interceptors.response.use(
    (response) => response,
    (error) => {
      if (error?.response?.status === 401) {
        clearCookies();
        window.location.href = '/sso/login';
      } else if (error.message === 'Network Error') {
        window.location.href = '/network-error';
      }
      return Promise.reject(error);
    }
  );
}

import { useState } from "react";
import Header from "./Components/Header";
import JobHistoryPage from "./pages/JobHistroyPage";
import DashboardPage from "./Components/DashboardPage";
import JobConfigurationPage from "./pages/JobConfigurationPage";
import RunOnceJobPage from "./pages/RunOnceJobPage";
import Tabs from "./Components/Tabs";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import Footer from "./Components/Footer";


function App() {
  const [tab, setTab] = useState("JOBS"); // "JOBS" | "HISTORY" | "CONFIG"

  return (
    <div>
      <Header /> 
      <Tabs activeTab={tab} onChange={setTab} />
      {tab === "JOBS" && <DashboardPage />}
      {tab === "HISTORY" && <JobHistoryPage />}
      {tab === "CONFIG" && <JobConfigurationPage />}
       {tab === "ONETIMEJOB" && <RunOnceJobPage />}
      <Footer />
    </div>
  );
}

export default App;
   

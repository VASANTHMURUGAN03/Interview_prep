import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import 'bootstrap/dist/css/bootstrap.min.css'
import "antd/dist/reset.css";
import { initAxiosInterceptors } from './middleware/axiosMiddleware'

// Set up axios interceptors once at startup
 initAxiosInterceptors();
createRoot(document.getElementById('root')).render(
  // <StrictMode>

<App />

  // </StrictMode>,
)

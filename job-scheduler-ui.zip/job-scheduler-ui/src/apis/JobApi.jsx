import axiosClient from "./axiosClient";
 
// GET job list
export async function fetchJobs() {
  const res = await axiosClient.get(
    "/ext/api/v1/jobConfig/jobList"
  );
  return res.data.data;
}
 
// ENABLE job / UPDATE cron (same API)
export async function enableJob(jobId, cron) {
  const res = await axiosClient.post(
    "/ext/api/v1/jobConfig/enableJob",
    null,
    { params: { jobId, cron } }
  );
  return res.data;
}
 
// DISABLE job
export async function disableJob(jobId) {
  const res = await axiosClient.post(
    "/ext/api/v1/jobConfig/disableJob",
    null,
    { params: { jobId } }
  );
  return res.data;
}
 
// JOB SUMMARY
export async function fetchJobSummary(jobId) {
  const res = await axiosClient.get(
    "/ext/api/v1/jobConfig/jobSummary",
    { params: { jobId } }
  );
  return res.data.data;
}


export async function fetchDashboardStateCounts() {
  const res = await axiosClient.get(
    "/ext/api/v1/dashboard/stateCounts"
  );
  return res.data;
}

export async function fetchJobHistory(params) {
    const res = await axiosClient.get(
    "/ext/api/v1/jobTable/jobHistory",
    {  params }
  );
  return res.data.data;
}

export async function fetchJobAudit() {
    const res = await axiosClient.post(
    "/ext/api/v1/auth/audit/details"
  );
  return res.data.data;
}

export async function triggerOneTimeJob(params) {
  const res = await axiosClient.post(
    "/ext/api/v1/oneTimeJob/triggerJob",
    null, // no body at all
    {
      params, // jobId and delay go here as query params
    }
  );
  return res.data.data;
}

export async function cancleOneTimeJob(params) {
  const res = await axiosClient.post(
    "ext/api/v1/oneTimeJob/cancelJob",
    null, // no body at all
    {
      params, // jobId and delay go here as query params
    }
  );
  return res.data.data;
}

export async function getAllOneTimeJob(params) {
  const res = await axiosClient.get(
    "ext/api/v1/oneTimeJob/getList",
    {
      params,
    }
  );
  return res.data.data;
}

export async function getAllOneTimeJobById(params) {
  const res = await axiosClient.post(
    "ext/api/v1/oneTimeJob/getJobById",
    null, // no body at all
    {
      params, // jobId and delay go here as query params
    }
  );
  return res.data.data;
}
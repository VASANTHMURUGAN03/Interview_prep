
import axios from 'axios';
const headers =  {
		'Strict-Transport-Security': 'max-age=31536000; includeSubDomains; preload',
		'X-XSS-Protection': '1; mode=block',
    'X-Content-Type-Options': 'nosniff',
		'X-Frame-Options': 'sameorigin',
		'Content-Security-Policy': 'default-src "self"'
}
const axiosClient = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL ||'https://sit-shapi.starhealth.in/job-scheduler-bff', 
  timeout: 10000,

  
});

export default axiosClient;

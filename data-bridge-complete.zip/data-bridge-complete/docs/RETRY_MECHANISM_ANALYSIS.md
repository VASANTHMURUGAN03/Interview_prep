# Data Bridge — Retry Mechanism Analysis & Manual Step-Retry Feasibility

Analysis performed directly against the shared backend source
(`com.star.databridge`). Every claim below is traced to a specific file/method —
nothing here is assumed.

---

## 1. Current Retry Mechanism — How It Actually Works

**Headline finding: retries happen at the *batch* level (read side) and the
*record* level (write side) — never at the individual *process/sink/ack step*
level. There is no code path anywhere that retries a single failed step in
isolation.**

There is also no workflow engine (no Temporal/Camunda/Flowable, no Spring
State Machine — confirmed by dependency/import search). Orchestration is
hand-rolled: Kafka messages carry "what to do next," and MongoDB document
fields (`status`, `retryCount`) carry "what happened so far." Retrying means
*re-publishing a Kafka message that re-runs a whole unit of work*, not
resuming a paused workflow.

### 1.1 Read side — retry unit = one read batch (source read + ALL process steps)

`MigrationReadBatchConsumer.execute()` does three things inside **one**
try/catch:
1. Reads a page of source data (`DataReader.read`)
2. Runs it through **every** configured process step
   (`ProcessExecutorService.execute`, which loops `stepService.executeStep()`
   over the full `process` step list with zero try/catch of its own)
3. Persists the results as `sync_records` (status=`READY`)

If **anything** in that sequence throws — a source-read failure, or a
failure in process step 1, 3, or 5 of 5 — the whole batch is treated as
failed and `handleReadBatchError()` runs:

- If `readBatch.retryCount < read.maxRetryCount` (default 3): increments
  `retryCount`, sets `ReadBatchExecutionEntity.status = "RETRY"`, and
  **republishes the identical batch message** — meaning the source is
  re-read from the same cursor/offset and **all process steps run again
  from the beginning**, including any that already succeeded on the
  previous attempt.
- If retries are exhausted: status becomes `FAILED`. Then:
  - **CURSOR pagination**: always aborts the whole job
    (`jobExecutionService.abortJob`) — a cursor pagination can't skip a
    batch because the next cursor value only comes from the response you
    failed to get.
  - **OFFSET pagination + `failureStrategy=IGNORE`**: skips the batch,
    continues at the next offset.
  - **OFFSET pagination + `failureStrategy=ABORT`** (default): aborts the job.

So on the read side, "retry" = **re-run source-read + every process step for
that batch, from scratch.** There is no concept of "process step 3 failed,
re-run just step 3."

### 1.2 Write side — retry unit = one write batch (ALL sink steps, per record)

`WriteBatchProcessor.process()` runs `SinkExecutorService.execute()`, which
loops every sink step (`stepService.executeStep()`) with **no try/catch
around the loop at all** (only a `finally` for temp-file cleanup). Any
exception from any sink step propagates straight out.

- On success: ack handling proceeds (see 1.3).
- On any exception (`WriteBatchProcessor.process()`'s catch block) →
  `handleFailure()` → `SyncRecordService.handleFailedRecords()`:
  ```java
  if (retryCount < maxRetryCount) {
      record.setStatus("RETRY");
      record.setRetryCount(retryCount + 1);
  } else {
      record.setStatus("FAILED");
  }
  ```
  This is evaluated **per `SyncRecordEntity`**, not per step. If any
  record is now `RETRY`, `publishWriteRetry()` creates a **new**
  `WriteBatchExecutionEntity` and publishes to the `migration-write-retry`
  topic. `MigrationWriteRetryConsumer` picks it up and calls
  `writeBatchProcessor.process(msg, "RETRY")`, which re-queries
  `sync_records` where `status = RETRY` and **re-runs the entire sink step
  list again** — JWT/token steps, batch-creation steps, upload steps, all
  of it — for those records.

  This is architecturally necessary given the current design: sink steps
  build up shared context in `stepOutputs` (e.g., an access token from step
  1 used by step 3). Nothing per-step is persisted, so there's no way to
  "resume" at step 3 without re-deriving step 1's output first.

### 1.3 Ack side — the *only* place a step-level "restart" exists, and it isn't error-driven

`StepService.executeStep()` supports a `RESTART` outcome (`FlowDecision.RESTART`)
via the `postExecution` rule effect `restartSteps`. But:

- `validateRestartAllowed()` explicitly **throws `IllegalStateException` if
  used outside the ACK flow** — `ProcessExecutorService` and
  `SinkExecutorService` both reject `RESTART` with
  `"restartSteps effect is not supported in {process|sink} flow"`.
- Even within ACK, `restartSteps` means **"re-run the entire ack step list
  from step 0,"** not "retry the one step that failed." It's driven by
  *rule evaluation of step output content* (e.g., "if `jobStatus == InProgress`,
  restart") — a poll-loop pattern for async operations like Salesforce bulk
  job polling — not by exceptions or failures at all.
- In practice: `AckExecutorService.executeAck()` returns `restart=true` →
  `MigrationWriteBatchAckConsumer` republishes the same ack message to the
  same topic and returns. This is really "poll again later," not error retry.

### 1.4 Kafka-level: there is no automatic retry at all

`BaseConsumer.handleMessage()` (used by every consumer):
```
Every message is always acknowledged exactly once — no Spring Kafka retries.
```
Any exception that escapes a consumer's own `execute()` method (i.e., not
already caught by that consumer's own manual retry logic) is published to a
DLQ Kafka topic (`KafkaUtil.publishToDlq`) and the message is acknowledged
— done. **There is no DLQ consumer in the codebase** (confirmed by file
search) — nothing automatically replays DLQ messages. A failure that isn't
caught by one of the manual retry paths above is simply parked, permanently,
until someone manually intervenes.

`MigrationOrchestratorConsumer` is a concrete example of this gap: it has
no try/catch of its own around `orchestrate()`. If it throws, the message
goes straight to the DLQ with no retry of any kind.

### 1.5 Job level: "retry" doesn't exist — only "trigger a brand new execution"

`JobExecutionService.triggerJob()`:
```java
JobExecutionEntity jobExecution = createJobExecution(jobConfig); // new UUID, fresh entity
ReadBatchExecutionEntity firstReadBatch = readBatchService.createBatch(jobConfig, jobExecution.getId(), 1);
kafkaUtil.pushReadBatchMsg(firstReadBatch, null);
```
Every trigger call creates a **brand-new `JobExecutionEntity`** (new
`jobUuid`) and starts at read batch #1. There is no "resume this specific
failed `JobExecutionEntity` from where it stopped." So, answering your
Objective #2 directly:

> **When a process step fails, is only the step retried, or is the whole
> job restarted?**
> **Neither, precisely — the *batch containing that step* is retried in
> full (source read + all process steps, or all sink steps), up to
> `maxRetryCount` times. If that's exhausted, the *job* is aborted
> (terminal) and the only way to redo the work is to trigger a completely
> new job execution from scratch — there's no partial-job resume either.**

### 1.6 Where retry state lives

No separate queue or workflow-state store — it's plain MongoDB document
fields, mutated in place:

| Entity / Collection | Field(s) | Meaning |
|---|---|---|
| `ReadBatchExecutionEntity` (`read_batch_executions`) | `status`, `retryCount`, `remarks` | Per-read-batch retry state. `status` cycles `RETRY → FAILED` or `RETRY → SUCCESS`. |
| `SyncRecordEntity` (`sync_records`) | `status`, `retryCount`, `errorMessage` | Per-record retry state on the write side. `status` cycles `READY → PICKED → RETRY/FAILED/SUCCESS`. **This is the finest-grained retry state that exists anywhere in the system** — but it's per-record, not per-step. |
| `WriteBatchExecutionEntity` (`write_batch_executions`) | `status`, `errorMessage` | Batch-level outcome only; no retryCount field on the batch itself (retry counting lives on the records). |
| `JobExecutionEntity` (`job_executions`) | `status` | `IN_PROGRESS → COMPLETED/FAILED/ABORTED`. Terminal-only; no retry semantics at this level. |
| `step_executions` | `status`, `stepName`, `stepType`, `batchId`, `batchType` | **Write-only audit log.** Published via `kafkaUtil.publishStepExecutionLog()` inside `StepService.runStep()` for observability. Nothing reads this collection back to drive retry decisions — it's a log, not state. |

### 1.7 Is retry configurable?

Yes, per job config, but only at the batch/record granularity described
above:
- `read.maxRetryCount`, `read.failureStrategy` (`ABORT`/`IGNORE`) — read-batch retries
- `sink.maxRetryCount` — write-record retries (also governs ack-triggered retries, since `AckExecutorService` receives the same `maxRetryCount`)
- No retry **delay/backoff** is configurable — retries republish immediately (except the ack restart path, which has a hardcoded, currently-commented-out `Thread.sleep(5000)` in `MigrationWriteBatchAckConsumer` — i.e., backoff was attempted there and is presently disabled)
- No per-step retry configuration exists, because no per-step retry exists

---

## 2. Execution Flow — Sequence Diagram

```mermaid
sequenceDiagram
    participant API as JobExecutionController
    participant JES as JobExecutionService
    participant ReadK as Kafka: migration-read-batch
    participant RC as MigrationReadBatchConsumer
    participant PE as ProcessExecutorService
    participant SS as StepService
    participant Orch as MigrationOrchestratorConsumer
    participant WriteK as Kafka: migration-write-batch
    participant WBP as WriteBatchProcessor
    participant SE as SinkExecutorService
    participant Ack as AckExecutorService / MigrationWriteBatchAckConsumer
    participant Mongo as MongoDB

    API->>JES: POST /v1/jobs/trigger/{name}
    JES->>Mongo: new JobExecutionEntity (status=IN_PROGRESS)
    JES->>Mongo: new ReadBatchExecutionEntity (batchNo=1)
    JES->>ReadK: publish ReadBatchMessage

    ReadK->>RC: consume
    RC->>RC: read source data
    RC->>PE: execute(process steps, data)
    loop each process step
        PE->>SS: executeStep()
        alt step throws
            SS-->>PE: exception propagates (no local catch)
        end
    end
    alt success
        RC->>Mongo: insert sync_records (status=READY)
        RC->>Orch: publish OrchestrationMessage
        RC->>ReadK: publish next batch (if hasMore)
    else failure (read OR any process step)
        RC->>RC: handleReadBatchError()
        alt retryCount < maxRetryCount
            RC->>Mongo: readBatch.status=RETRY, retryCount++
            RC->>ReadK: republish SAME batch (full re-read + full re-process)
        else retries exhausted
            RC->>Mongo: readBatch.status=FAILED
            alt CURSOR pagination OR failureStrategy=ABORT
                RC->>JES: abortJob() — job terminates
            else OFFSET + IGNORE
                RC->>ReadK: publish NEXT batch, skipping this one
            end
        end
    end

    Orch->>Mongo: count unassigned READY sync_records
    Orch->>WriteK: publish WriteBatchMessage(s)

    WriteK->>WBP: process(msg, sourceStatus=READY)
    WBP->>Mongo: mark records PICKED
    WBP->>SE: execute(sink steps, records)
    loop each sink step
        SE->>SS: executeStep()
        alt step throws
            SS-->>SE: exception propagates (no local catch)
        end
    end
    alt sink succeeds
        WBP->>Ack: handleAck() — NONE / POLL / IMMEDIATE
        Ack->>Mongo: mark records SUCCESS (or ACK_PENDING for POLL)
    else sink fails
        WBP->>Mongo: handleFailedRecords() — per record: RETRY (if under max) or FAILED
        WBP->>WriteK: publishWriteRetry() — NEW batch, RE-RUNS ALL SINK STEPS
    end
```

---

## 3. Exact Files/Classes Responsible for Retry

| Concern | Class | Key method(s) |
|---|---|---|
| Read-batch retry decision + republish | `kafka/consumer/MigrationReadBatchConsumer.java` | `execute()`, `handleReadBatchError()`, `continueAtNextOffset()` |
| Process-step execution loop (no retry of its own) | `service/ProcessExecutorService.java` | `execute()` |
| Sink-step execution loop (no retry of its own) | `service/SinkExecutorService.java` | `execute()`, `runSteps()` |
| Single-step execution + pre/post rule evaluation | `service/StepService.java` | `executeStep()`, `runStep()`, `evaluatePre()`, `evaluatePost()` |
| Write-batch retry orchestration (batch + record level) | `service/WriteBatchProcessor.java` | `process()`, `handleFailure()`, `publishWriteRetry()` |
| Per-record retry-count bookkeeping | `service/SyncRecordService.java` | `handleFailedRecords()` (two overloads) |
| Ack execution + the one "restart" mechanism (not error-driven) | `service/AckExecutorService.java` | `executeAck()`, `runSteps()` |
| Ack polling consumer, republishes on `restart=true` | `kafka/consumer/MigrationWriteBatchAckConsumer.java` | `execute()` |
| Write-retry topic consumer | `kafka/consumer/MigrationWriteRetryConsumer.java` | `execute()` |
| Job-level terminal state (abort) | `service/JobExecutionService.java` | `triggerJob()`, `abortJob()` (referenced), `TERMINAL_STATUSES` |
| Kafka-level failure fallback (no retry, DLQ only) | `kafka/consumer/BaseConsumer.java` | `handleMessage()` |
| Rule evaluation that can trigger the ack-only restart | `service/RuleService.java` | `evaluate()` |
| Step execution audit log (write-only, doesn't drive retries) | `util/KafkaUtil.java` → `step_executions` | `publishStepExecutionLog()` |

---

## 4. Job-Level or Step-Level?

**Neither, in the strict sense of either term.** Concretely:

- **Not job-level** — a failure doesn't restart the whole job from scratch automatically; only a full job *abort* happens, and re-running requires a fresh manual trigger.
- **Not step-level** — no code path retries one failed step while preserving the outputs of steps that already succeeded.
- **Actual granularity: batch-level (read side) and record-level (write side)**, where "retry" means "re-run the complete step sequence for that batch/record from position zero."

---

## 5. Feasibility: Manual Retry of Only the Failed Step

### Short answer: **not feasible as a true "resume from failed step" without architectural changes** — but a well-scoped, low-risk version is feasible if you accept one constraint (below).

### Why the current architecture blocks it

1. **No per-step state persistence.** `stepOutputs` (the map every step reads/writes) lives entirely in-memory for the duration of one `ProcessExecutorService`/`SinkExecutorService`/`AckExecutorService` call. Nothing about a step's output is durably saved except the very last one (via the audit-only `step_executions` log, which stores `status`/timing, not the actual output payload). If step 1 produced an auth token and step 4 failed, that token is gone the moment the JVM call stack unwinds — there's nothing to resume *into*.
2. **`RESTART` is deliberately fenced off.** `StepService.validateRestartAllowed()` actively throws if any flow other than ACK tries to use step-level restart — this isn't an oversight, it's an explicit guard, presumably because process/sink steps weren't designed to be safely re-entrant mid-sequence.
3. **Steps aren't guaranteed idempotent.** E.g. `salesforceBatchId` (an `API` step) calls Salesforce's bulk-job-creation endpoint — re-running just this step in isolation, disconnected from the steps around it, could create a duplicate remote batch job if called with stale/wrong context.
4. **The record/batch is the unit of "what to retry," everywhere.** APIs, Kafka message schemas, and Mongo queries are all built around `batchId` / `recordId`, not `(batchId, stepName)`.

### What IS feasible without a major rebuild

A **"replay a batch/record starting from a specific step"** feature is realistic, with one accepted constraint: **steps before the retry point are re-executed to reconstruct their outputs (cheaply, since most are cache/lookup steps), rather than truly skipped.** This gets you 90% of the practical benefit (you don't have to explain a rerun of the *whole* pipeline as "acceptable"; you get an explicit, informed choice of where to resume) without requiring durable per-step-output storage.

Concretely: use the existing `step_executions` log (which already records step name, type, status, batchId, batchType, timestamps) to let a user **see** which step failed and **choose** to re-trigger processing for that batch/record starting at that step, while the executor still runs the preceding steps in the list to rebuild required context (tokens, IDs) — it just won't re-hit *external side-effecting* calls if those are marked idempotent/cacheable (some already are, via `stepEntity.getCache()` + `CaffeineCacheService`).

---

## 6. Recommended Implementation Approach (Minimal Impact)

### Backend

1. **New read-only endpoint(s)** to power a "why did this fail, retry from here" UI:
   - `GET /v1/jobs/executions/{jobExecutionId}/step-executions?batchId=&batchType=` — list step executions for a batch (this data already exists in `step_executions`; just needs a controller).
   - `GET /v1/jobs/executions/{jobExecutionId}/sync-records?status=FAILED` — list failed records (already queryable via `SyncRecordRepository`).

2. **New "Retry From Step" endpoint**:
   `POST /v1/jobs/executions/{jobExecutionId}/batches/{batchId}/retry?fromStep={stepName}`
   - Validates the batch/records are in a terminal failed state.
   - Loads the step list (process or sink, per `batchType`) and truncates it to start at `fromStep` (steps before it still execute, per the constraint above — this is a UI/intent change, not an executor change, unless you also do step 3 below).
   - Resets the relevant `SyncRecordEntity.status` (write side) or creates a new `ReadBatchExecutionEntity` (read side) and republishes to the existing retry topic, reusing `WriteBatchProcessor.publishWriteRetry()` / the read-batch publish path — **no new Kafka topics needed**.
   - Distinct from the existing automatic retry: this is *manually triggered*, doesn't consume `maxRetryCount` budget (or optionally resets it), and is audited as `triggeredBy=MANUAL_RETRY` (new field or reuse an existing trigger-type concept).

3. **Optional, higher-effort step 3 — true "skip already-succeeded steps":**
   Persist each step's *output* (not just its status) to a new collection
   (e.g. `step_execution_outputs`, keyed by `jobExecutionId + batchId + stepName`)
   whenever `StepService.runStep()` succeeds. On manual retry, hydrate
   `stepOutputs` from this collection for every step before `fromStep`
   instead of re-executing them. This is the real "resume, don't
   re-derive" capability — bigger lift (new collection, write path in
   `StepService`, read/hydration path in the retry endpoint, and you must
   audit every existing step type for idempotency before trusting a skip).

### Database

- No schema changes required for the minimal version (steps 1–2) — everything needed already exists in `step_executions`, `sync_records`, `read_batch_executions`.
- For the "true skip" version (step 3): new `step_execution_outputs` collection.

### UI (this app)

- **Execution Detail page**: surface `step_executions` per batch (this was already flagged as a gap — the current mock UI shows a fixed step timeline, not real per-batch step data). Add a "Retry from this step" action on the failed step.
- **Job Instances / Related Retries**: show retry history (`retryCount`, `remarks`/`errorMessage`) per batch/record, which already exists in the data but isn't surfaced anywhere yet.
- Confirmation dialog before manual retry, explaining that preceding steps will re-run (until step 3 above is built).

### Downstream behavior after a successful manual retry

- Read side: subsequent read batches were unaffected by the failure (each batch is independent once created), so no special handling needed beyond marking this batch `SUCCESS` and letting the orchestrator pick up its records normally.
- Write side: identical to the existing automatic-retry success path — `handleAck()` runs normally; ack/report logic doesn't need to know whether the retry was automatic or manual.

### Workflow state updates

- `ReadBatchExecutionEntity`/`SyncRecordEntity` status transitions back to `RETRY` → (on success) `SUCCESS`, exactly as today — reuse the existing state machine rather than inventing a new one.
- Add one new value to track *why* a retry happened: `triggeredBy: SYSTEM | MANUAL` on the batch/record, so the UI (and any future audit/compliance need) can distinguish automatic from human-initiated retries.

---

## 7. Risks, Edge Cases, Data Consistency Concerns

- **Non-idempotent external calls.** Any `API`/`BANCS_API` step that creates something remotely (e.g. `salesforceBatchId`) must not be blindly re-run as part of "re-execute preceding steps to rebuild context" — audit which steps are safe to repeat vs. which need caching/skip logic before enabling manual retry broadly. This is the single biggest risk.
- **Stale `stepOutputs` across a manual retry gap.** If a retry happens hours after the original failure (e.g. an access token step's output was time-limited), re-deriving preceding steps is actually *required*, not optional — reinforcing that the "true skip" version (§6.3) needs per-step TTL/staleness awareness, not just presence.
- **Double-processing / double-write risk.** If a manual retry is triggered while the *automatic* retry for the same batch/record is also in flight (race), you could get two write-batches processing the same records concurrently. Guard with a status check-and-set (e.g., only allow manual retry when status is the terminal `FAILED`, not `RETRY`/`PICKED`), and prefer an atomic Mongo `findAndModify`-style update over separate find+save calls.
- **`maxRetryCount` semantics.** Decide explicitly whether manual retries count against the same budget as automatic ones, or are unlimited/separately tracked — otherwise a batch that exhausted automatic retries may appear "stuck" even though a human wants to retry it once more.
- **Cursor-pagination jobs remain unretryable at the batch level by design** (per §1.1) — a step-level or batch-level manual retry doesn't change the fundamental limitation that a cursor-based job can't skip/redo an isolated batch without the next cursor value, which only comes from a successful response. Manual retry for cursor-paginated read failures is really "manual retry of the *next unattempted* read," not a true point-in-time retry.
- **`step_executions` isn't currently unique/queryable in a way optimized for this.** Confirm indexes on `(jobExecutionId, batchId, batchType)` before building the "list steps for this batch" endpoint at any scale.
- **Audit/compliance.** Since this pipeline moves customer PII (per the `sync_records` sample data reviewed earlier), a manual-retry feature should be access-controlled and logged distinctly from automatic system retries — who clicked retry, when, and why is worth capturing from day one rather than retrofitting later.

# Data Bridge — Complete Project

**This single ZIP is the current state of the entire application** —
backend, BFF, and frontend, each a complete, independently buildable
project. No file here depends on anything from a previous delivery; this
replaces every zip sent before it.

```
data-bridge-complete/
├── backend/    Spring Boot core service (Mongo, Kafka, JobRunr, the ETL pipeline itself)
├── bff/        Spring Boot Backend-for-Frontend (proxies + aggregates for the UI)
├── frontend/   React app (Vite) — the Sync Console UI
└── docs/       Gap analysis + retry-mechanism deep dive (still-current reference docs)
```

## Current state of each piece

- **`backend/`** — complete, includes every change from this whole
  engagement (JobRunr migration, Job Audit, all API batches) merged
  directly into the real source files. See `backend/README.md`.
- **`bff/`** — complete and functional as a proxy/aggregation layer. Points
  at the backend by default at `http://localhost:8080/data-bridge`.
- **`frontend/`** — complete as a UI, but **still running on mock data**,
  not yet wired to the backend/BFF. This is the known next step whenever
  you want it done — flagging clearly rather than implying it's finished.

## Run order

1. Backend: `cd backend && mvn spring-boot:run` (needs Mongo + Kafka reachable)
2. BFF: `cd bff && mvn spring-boot:run` (needs the backend reachable)
3. Frontend: `cd frontend && npm install && npm run dev` (currently mock-only — see above)

## On the delivery format going forward

Per your instruction: every future delivery will be one ZIP, containing
the complete, current state of all three projects, not a patch against a
previous one. This ZIP is the new baseline — if I hand you another one
later in this engagement, it supersedes this one entirely and you should
be able to use it standalone.

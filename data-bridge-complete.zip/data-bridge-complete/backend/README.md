# Data Bridge Backend (consolidated)

This is the full backend as one buildable project — your original source
plus every change made across this engagement (JobRunr migration, Job
Audit, and all API batches) merged directly into the real files. Nothing
here is a patch/snippet; every file is the complete, current version.

## What changed from your original source

- **Scheduling**: `config/SchedulerConfig.java` and
  `service/JobSchedulerService.java` (Spring `TaskScheduler` + ShedLock)
  are **deleted**. Replaced by `config/JobRunrConfig.java` +
  `service/SchedulingService.java`, using JobRunr's own MongoDB-backed
  storage for distributed-safe recurring jobs — no separate lock needed.
- **Job Audit**: new `job_audit_logs` collection
  (`entity/AuditEntity.java`, `entity/AuditAction.java`,
  `repository/AuditRepository.java`, `service/AuditService.java`,
  `controller/AuditController.java`). Wired into `JobConfigService`
  (create/update/enable/disable/cron-change) and `JobExecutionService`
  (manual trigger only — not the scheduler/chain path).
- **Read/reporting APIs**: everything under `GET /v1/jobs/executions/**`,
  `GET /v1/dashboard/**`, `GET /v1/jobs/executions/{id}/sync-records`,
  `GET /v1/job-configs/summary` — none of this existed before; the backend
  only had config CRUD + trigger/abort at the start of this engagement.
- **Manual retry + Related Retries**: `POST .../batches/{batchId}/retry`,
  `GET .../batches/{batchId}/retries` (branches READ vs WRITE — see the
  javadoc on `JobExecutionService.getReadBatchRetryState()` for why those
  two are architecturally different, not just two variants of the same thing).
- **Trigger with parameters**: `POST /v1/jobs/trigger/{name}` now accepts a
  body. Read the javadoc on `triggerJobWithContext()` in
  `JobExecutionService` — there's an honest, deliberate limitation on how
  far these params currently reach into the pipeline.
- Full list, endpoint-by-endpoint: `../docs/GAP_ANALYSIS.md`.
  Full retry-mechanism deep dive: `../docs/RETRY_MECHANISM_ANALYSIS.md`.

## Important environment detail

`application.yaml` sets `server.servlet.context-path: /data-bridge` — every
endpoint in this service is actually served under `/data-bridge/v1/...`,
not bare `/v1/...`. The BFF's default backend URL
(`bff/src/main/resources/application.yml`) already accounts for this.

## Running it

```bash
mvn spring-boot:run
```

Needs a reachable MongoDB (`spring.mongodb.uri`, per-profile — see
`application-LOCAL.yaml` for a local default) and Kafka
(`kafka.config.bootstrap-servers`). Active profile via `env_name`
(defaults to `LOCAL`).

## Honest caveats — read before you trust this compiles

1. **`pom.xml` is reconstructed, not your original.** No build file was
   ever included in the source you shared with me — I built this one from
   what your code actually imports (confirmed via grep, not guessed):
   Jackson 3.x (`tools.jackson.*` throughout your codebase — unusual,
   double-check the version pin), `com.auth0:java-jwt`,
   `com.bazaarvoice.jolt:jolt-core`, MySQL/Postgres JDBC drivers,
   `spring-kafka`, `jobrunr-spring-boot-3-starter`. **Diff this against
   your team's real pom.xml if one exists anywhere** — this is a
   best-effort reconstruction, flagged clearly in the pom's own header
   comment too.
2. **JobRunr's exact API surface wasn't compiled against your pinned
   version** — `SchedulingService.java` and `JobRunrConfig.java` both have
   inline notes on the specific methods to double-check.
3. **The Mongo date-aggregation syntax in `DashboardService.
   getExecutionTrends()`** is flagged in its own javadoc as needing
   version verification.
4. **`application-LOCAL.yaml` contains what look like real hardcoded
   credentials** (DB passwords, API keys, a Databricks token, Zoho
   secrets) as default fallback values. This predates my changes — found
   while consolidating, not introduced by it — flagging again here since
   it's now sitting in a fresh delivery: worth rotating and moving to a
   secrets manager if this has ever left a fully trusted environment.
5. **Still no real auth/session system.** User identity for audit is
   `X-User-Id`/`X-User-Name` request headers, defaulting to `"system"`.
   Standing open item since early in this engagement.

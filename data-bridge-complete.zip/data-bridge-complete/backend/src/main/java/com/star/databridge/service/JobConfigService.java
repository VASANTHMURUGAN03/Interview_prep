package com.star.databridge.service;

import tools.jackson.databind.ObjectMapper;
import com.star.databridge.dto.mongo.AckConfig;
import com.star.databridge.dto.mongo.SinkConfig;
import com.star.databridge.dto.mongo.StepConfig;
import com.star.databridge.dto.request.UpsertJobConfigDto;
import com.star.databridge.dto.response.JobConfigSummaryDto;
import com.star.databridge.entity.AuditAction;
import com.star.databridge.entity.JobConfigEntity;
import com.star.databridge.entity.JobExecutionEntity;
import com.star.databridge.entity.ProcessStepEntity;
import com.star.databridge.repository.JobConfigRepository;
import com.star.databridge.repository.JobExecutionRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class JobConfigService {
    private final MongoTemplate mongoTemplate;
    private final JobConfigRepository jobConfigRepository;
    private final ProcessStepConfigService processStepConfigService;
    private final ObjectMapper objectMapper;
    private final AuditService auditService;
    private final SchedulingService schedulingService;
    private final JobExecutionRepository jobExecutionRepository;

    public JobConfigEntity upsertConfig(UpsertJobConfigDto upsertJobConfigDto) {
        return upsertConfig(upsertJobConfigDto, null, null);
    }

    /**
     * Same as upsertConfig(dto) but also records an audit entry
     * (CONFIG_CREATED or CONFIG_UPDATED, detected by whether the name
     * already existed) and syncs the JobRunr schedule to match whatever
     * this upsert just set the trigger to.
     */
    public JobConfigEntity upsertConfig(UpsertJobConfigDto upsertJobConfigDto, String userId, String username) {
        boolean isUpdate = jobConfigRepository.findByName(upsertJobConfigDto.getName()).isPresent();
        JobConfigEntity previous = isUpdate
                ? jobConfigRepository.findByName(upsertJobConfigDto.getName()).orElse(null)
                : null;

        JobConfigEntity jobConfigEntity = createJobConfigEntity(upsertJobConfigDto);
        JobConfigEntity saved = upsertConfig(upsertJobConfigDto.getName(), jobConfigEntity);

        auditService.recordAudit(
                saved.getId(), saved.getName(),
                isUpdate ? AuditAction.CONFIG_UPDATED : AuditAction.CONFIG_CREATED,
                previous, saved, userId, username, null);

        if (saved.getTrigger() != null && "SCHEDULER".equalsIgnoreCase(saved.getTrigger().getType()) && saved.isActive()) {
            schedulingService.scheduleJob(saved);
        } else {
            schedulingService.unscheduleJob(saved.getName());
        }

        return saved;
    }

    private JobConfigEntity createJobConfigEntity(UpsertJobConfigDto upsertJobConfigDto) {
        JobConfigEntity jobConfigEntity = new JobConfigEntity();
        jobConfigEntity.setName(upsertJobConfigDto.getName());
        jobConfigEntity.setEntity(upsertJobConfigDto.getEntity());
        jobConfigEntity.setStrategy(upsertJobConfigDto.getStrategy());
        jobConfigEntity.setTrigger(upsertJobConfigDto.getTrigger());
        jobConfigEntity.setRead(upsertJobConfigDto.getRead());
        jobConfigEntity.setProcess(upsertJobConfigDto.getProcess());
        jobConfigEntity.setSink(upsertJobConfigDto.getSink());
        jobConfigEntity.setAck(upsertJobConfigDto.getAck());
        jobConfigEntity.setPostComplete(upsertJobConfigDto.getPostComplete());
        jobConfigEntity.setActive(true);

        return jobConfigEntity;
    }

    private JobConfigEntity upsertConfig(String configName, JobConfigEntity jobConfigEntity) {
        Query query = new Query(Criteria.where("name").is(configName));

        Update update = new Update();

        for (Field field : jobConfigEntity.getClass().getDeclaredFields()) {
            field.setAccessible(true);
            String fieldName = field.getName();
            try {
                Object value = field.get(jobConfigEntity);
                if ((fieldName.equals("ack") || fieldName.equals("postComplete")) && value == null) {
                    update.set(field.getName(), value);
                    continue;
                }

                if (value != null &&
                    !fieldName.equals("name") &&
                    !fieldName.equals("createdAt") &&
                    !fieldName.equals("updatedAt")) {
                    update.set(field.getName(), value);
                }
            } catch (IllegalAccessException e) {
                log.error("Error in upsert job config name = {}, field = {}, message = {}",
                        configName, field, e.getMessage());
            }
        }

        update.set("updatedAt", Instant.now());
        update.setOnInsert("createdAt", Instant.now());

        FindAndModifyOptions options = new FindAndModifyOptions().upsert(true).returnNew(true);

        return mongoTemplate.findAndModify(query, update, options, JobConfigEntity.class);
    }

    public List<JobConfigEntity> getConfigs(Integer limit, Integer pageNumber) {
        int intLimit = limit != null ? Math.min(limit, 10) : 10;
        int offset = pageNumber != null ? pageNumber : 0;

        Pageable pageable = PageRequest.of(offset, intLimit, Sort.by("updatedAt").descending());

        return jobConfigRepository.findAll(pageable).getContent();
    }

    public JobConfigEntity getConfigByName(String name) {
        JobConfigEntity jobConfig = jobConfigRepository.findByName(name).orElse(null);
        if (jobConfig == null) {
            return null;
        }

        List<String> stepNames = extractStepNames(jobConfig);
        List<ProcessStepEntity> processSteps = processStepConfigService.getConfigsByNames(stepNames);
        return addStepDetails(jobConfig, processSteps);
    }

    public JobConfigEntity deleteConfigByName(String name) {
        return deleteConfigByName(name, null, null);
    }

    /** Soft-delete/disable — also unregisters any JobRunr schedule and audits JOB_DISABLED. */
    public JobConfigEntity deleteConfigByName(String name, String userId, String username) {
        JobConfigEntity previous = jobConfigRepository.findByName(name).orElse(null);

        JobConfigEntity config = new JobConfigEntity();
        config.setName(name);
        config.setActive(false);
        JobConfigEntity saved = upsertConfig(config.getName(), config);

        schedulingService.unscheduleJob(name);

        auditService.recordAudit(
                saved.getId(), name, AuditAction.JOB_DISABLED,
                previous, saved, userId, username, null);

        return saved;
    }

    /** Re-enables a previously disabled config without resubmitting the whole thing. */
    public JobConfigEntity activateConfig(String name) {
        return activateConfig(name, null, null);
    }

    public JobConfigEntity activateConfig(String name, String userId, String username) {
        JobConfigEntity previous = jobConfigRepository.findByName(name).orElse(null);

        Query query = new Query(Criteria.where("name").is(name));
        Update update = new Update().set("active", true).set("updatedAt", Instant.now());
        FindAndModifyOptions options = new FindAndModifyOptions().upsert(false).returnNew(true);
        JobConfigEntity saved = mongoTemplate.findAndModify(query, update, options, JobConfigEntity.class);

        if (saved == null) {
            return null;
        }

        if (saved.getTrigger() != null && "SCHEDULER".equalsIgnoreCase(saved.getTrigger().getType())) {
            schedulingService.scheduleJob(saved);
        }

        auditService.recordAudit(
                saved.getId(), name, AuditAction.JOB_ENABLED,
                previous, saved, userId, username, null);

        return saved;
    }

    /** Dedicated "Update Cron Expression" operation — touches only trigger.cron. */
    public JobConfigEntity updateCron(String name, String newCron, String userId, String username) {
        JobConfigEntity existing = jobConfigRepository.findByName(name)
                .orElseThrow(() -> new IllegalArgumentException("Job config not found: " + name));

        String previousCron = existing.getTrigger() != null ? existing.getTrigger().getCron() : null;

        Query query = new Query(Criteria.where("name").is(name));
        Update update = new Update()
                .set("trigger.cron", newCron)
                .set("trigger.type", "SCHEDULER")
                .set("updatedAt", Instant.now());
        FindAndModifyOptions options = new FindAndModifyOptions().upsert(false).returnNew(true);
        JobConfigEntity saved = mongoTemplate.findAndModify(query, update, options, JobConfigEntity.class);

        if (saved.isActive()) {
            schedulingService.scheduleJob(saved);
        }

        auditService.recordAudit(
                saved.getId(), name, AuditAction.CRON_CHANGED,
                previousCron, newCron, userId, username, null);

        return saved;
    }

    /**
     * Joins each config with its latest execution (status/lastRun) and
     * current JobRunr scheduler state (nextRun) — neither entity alone has
     * enough for the Jobs List / Job Configuration tables. Computed at read
     * time; doesn't touch either entity's write path.
     */
    public List<JobConfigSummaryDto> getConfigSummaries(Integer limit, Integer pageNumber) {
        List<JobConfigEntity> configs = getConfigs(limit, pageNumber);

        return configs.stream()
                .map(config -> {
                    JobExecutionEntity lastExecution = jobExecutionRepository
                            .findTopByJobNameOrderByCreatedAtDesc(config.getName())
                            .orElse(null);

                    java.time.Instant nextRun = schedulingService.getJob(config.getName())
                            .map(com.star.databridge.dto.response.ScheduledJobDto::getNextRun)
                            .orElse(null);

                    return JobConfigSummaryDto.builder()
                            .name(config.getName())
                            .entity(config.getEntity())
                            .strategy(config.getStrategy())
                            .active(config.isActive())
                            .triggerType(config.getTrigger() != null ? config.getTrigger().getType() : null)
                            .cron(config.getTrigger() != null ? config.getTrigger().getCron() : null)
                            .lastRun(lastExecution != null ? lastExecution.getCreatedAt() : null)
                            .lastStatus(lastExecution != null ? lastExecution.getStatus() : null)
                            .nextRun(nextRun)
                            .build();
                })
                .toList();
    }

    private List<String> extractStepNames(JobConfigEntity config) {
        List<String> stepNames = new ArrayList<>();

        if (config.getProcess() != null) {
            config.getProcess().stream().map(StepConfig::getName).forEach(stepNames::add);
        }

        Optional<List<StepConfig>> sinkSteps = Optional.ofNullable(config.getSink()).map(SinkConfig::getSteps);
        sinkSteps.ifPresent(stepConfigs ->
                stepConfigs.stream().map(StepConfig::getName).forEach(stepNames::add)
        );

        Optional<List<StepConfig>> ackSteps = Optional.ofNullable(config.getAck()).map(AckConfig::getSteps);
        ackSteps.ifPresent(stepConfigs ->
                stepConfigs.stream().map(StepConfig::getName).forEach(stepNames::add)
        );

        return stepNames;
    }

    private JobConfigEntity addStepDetails(JobConfigEntity config, List<ProcessStepEntity> steps) {
        if (steps == null || steps.isEmpty()) {
            return null;
        }

        JobConfigEntity clonedConfig = objectMapper.convertValue(config, JobConfigEntity.class);

        Map<String, ProcessStepEntity> stepLookup = steps.stream()
                .collect(Collectors.toMap(
                        ProcessStepEntity::getName,
                        step -> step,
                        (existing, replacement) -> existing
                ));


        if (clonedConfig.getProcess() != null) {
            clonedConfig.setProcess(getStepConfigs(clonedConfig.getProcess(), stepLookup));
        }

        Optional<List<StepConfig>> sinkSteps = Optional.ofNullable(clonedConfig.getSink()).map(SinkConfig::getSteps);
        sinkSteps.ifPresent(stepConfigs ->
                clonedConfig.getSink().setSteps(getStepConfigs(stepConfigs, stepLookup))
        );

        Optional<List<StepConfig>> ackSteps = Optional.ofNullable(clonedConfig.getAck()).map(AckConfig::getSteps);
        ackSteps.ifPresent(stepConfigs ->
                clonedConfig.getAck().setSteps(getStepConfigs(stepConfigs, stepLookup))
        );

        return clonedConfig;
    }

    private List<StepConfig> getStepConfigs(List<StepConfig> steps, Map<String, ProcessStepEntity> stepLookup) {
        return steps.stream()
                .map(stepConfig -> {
                    ProcessStepEntity matchingStep = stepLookup.get(stepConfig.getName());
                    if (matchingStep == null) {
                        return stepConfig;
                    }

                    return StepConfig.builder()
                            .name(stepConfig.getName())
                            .type(matchingStep.getType())
                            .params(matchingStep.getParams())
                            .preExecution(stepConfig.getPreExecution())
                            .postExecution(stepConfig.getPostExecution())
                            .build();
                }).toList();
    }
}

package com.star.databridge.config;

import com.mongodb.client.MongoClient;
import org.jobrunr.jobs.mappers.JobMapper;
import org.jobrunr.storage.StorageProvider;
import org.jobrunr.storage.nosql.mongo.MongoDBStorageProvider;
import org.jobrunr.utils.mapper.jackson.JacksonJsonMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDatabaseFactory;

/**
 * Replaces config/SchedulerConfig.java (deleted — see git history / the
 * old zip if you need to compare). Removes Spring's TaskScheduler +
 * ShedLock entirely: JobRunr's own storage provider (backed by the SAME
 * MongoDB database as the rest of the app, in new "jobrunr_*" collections)
 * natively guarantees a recurring job only fires on one node at a time —
 * no separate distributed-lock bean needed the way ShedLock was.
 *
 * Deliberately mirrors the deleted SchedulerConfig's exact pattern for
 * getting the right database — injects the same auto-configured
 * MongoDatabaseFactory bean Spring Data Mongo already provides for the
 * rest of the app (mongoDatabaseFactory.getMongoDatabase()), rather than a
 * separately-configured database name that could drift out of sync with
 * the real per-environment Mongo URI (application-QA.yml / -UAT.yml / etc
 * all set spring.mongodb.uri per environment, with the actual database
 * name embedded in that URI — reusing the factory means JobRunr always
 * points at the same database this app is actually connected to).
 *
 * This uses the official `jobrunr-spring-boot-3-starter`, which
 * auto-configures a `JobScheduler` bean and a `BackgroundJobServer` bean as
 * soon as it finds a `StorageProvider` bean on the context (this class) —
 * no manual `JobRunr.configure()...initialize()` wiring needed.
 *
 * --------------------------------------------------------------------------
 * pom.xml dependency change: this project's pom.xml (reconstructed for
 * this delivery, since none was in the originally shared source) already
 * includes jobrunr-spring-boot-3-starter and has shedlock removed — see
 * pom.xml at the project root.
 *
 * application.yml additions needed — already added under the `org.jobrunr`
 * key in application.yaml.
 * --------------------------------------------------------------------------
 */
@Configuration
public class JobRunrConfig {

    @Bean
    public StorageProvider storageProvider(MongoClient mongoClient, MongoDatabaseFactory mongoDatabaseFactory) {
        String databaseName = mongoDatabaseFactory.getMongoDatabase().getName();
        MongoDBStorageProvider storageProvider = new MongoDBStorageProvider(mongoClient, databaseName);
        storageProvider.setJobMapper(new JobMapper(new JacksonJsonMapper()));
        return storageProvider;
    }
}

package com.star.databridge.service;

import com.star.databridge.dto.response.DashboardStatsResponse;
import com.star.databridge.dto.response.ExecutionTrendDto;
import com.star.databridge.dto.response.TopFailedJobDto;
import com.star.databridge.entity.JobExecutionEntity;
import com.star.databridge.repository.JobConfigRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * NEW FILE — powers the Dashboard page. This aggregation didn't exist
 * anywhere internally before; there was nothing to just "expose."
 */
@Service
@RequiredArgsConstructor
public class DashboardService {

    private final MongoTemplate mongoTemplate;
    private final JobConfigRepository jobConfigRepository;

    public DashboardStatsResponse getStats(String jobName, LocalDateTime from, LocalDateTime to) {
        List<Criteria> filters = new java.util.ArrayList<>();
        if (jobName != null && !jobName.isBlank()) {
            filters.add(Criteria.where("jobName").is(jobName));
        }
        if (from != null) {
            filters.add(Criteria.where("createdAt").gte(from));
        }
        if (to != null) {
            filters.add(Criteria.where("createdAt").lte(to));
        }

        Aggregation.MatchOperation match = filters.isEmpty()
                ? Aggregation.match(new Criteria())
                : Aggregation.match(new Criteria().andOperator(filters.toArray(new Criteria[0])));

        Aggregation aggregation = Aggregation.newAggregation(
                match,
                Aggregation.group("status").count().as("count")
        );

        AggregationResults<Map> results = mongoTemplate.aggregate(aggregation, JobExecutionEntity.class, Map.class);

        long completed = 0, failed = 0, inProgress = 0, aborted = 0, total = 0;
        for (Map<String, Object> row : results.getMappedResults()) {
            String status = String.valueOf(row.get("_id"));
            long count = ((Number) row.get("count")).longValue();
            total += count;
            switch (status) {
                case "COMPLETED" -> completed = count;
                case "FAILED" -> failed = count;
                case "IN_PROGRESS" -> inProgress = count;
                case "ABORTED" -> aborted = count;
                default -> { /* ignore unknown/null status */ }
            }
        }

        double successRate = (completed + failed) > 0
                ? Math.round((completed / (double) (completed + failed)) * 1000) / 10.0
                : 0.0;

        long activeJobConfigs = jobConfigRepository.countByActive(true);

        return DashboardStatsResponse.builder()
                .totalExecutions(total)
                .activeJobConfigs(activeJobConfigs)
                .completedCount(completed)
                .failedCount(failed)
                .inProgressCount(inProgress)
                .abortedCount(aborted)
                .successRate(successRate)
                .build();
    }

    public List<TopFailedJobDto> getTopFailedJobs(Integer limit, LocalDateTime from, LocalDateTime to) {
        int effectiveLimit = limit != null ? Math.min(limit, 20) : 5;

        List<Criteria> filters = new java.util.ArrayList<>();
        filters.add(Criteria.where("status").is("FAILED"));
        if (from != null) filters.add(Criteria.where("createdAt").gte(from));
        if (to != null) filters.add(Criteria.where("createdAt").lte(to));

        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(new Criteria().andOperator(filters.toArray(new Criteria[0]))),
                Aggregation.group("jobName").count().as("failureCount"),
                Aggregation.sort(org.springframework.data.domain.Sort.Direction.DESC, "failureCount"),
                Aggregation.limit(effectiveLimit)
        );

        AggregationResults<Map> results = mongoTemplate.aggregate(aggregation, JobExecutionEntity.class, Map.class);

        return results.getMappedResults().stream()
                .map(row -> TopFailedJobDto.builder()
                        .jobName(String.valueOf(row.get("_id")))
                        .failureCount(((Number) row.get("failureCount")).longValue())
                        .build())
                .toList();
    }

    /**
     * Daily success/failure counts, optionally scoped to one job. Defaults
     * to the last 7 days if no range is given.
     *
     * NOTE — verify the date-to-string projection syntax against your
     * Spring Data MongoDB version; if `.andExpression("dateToString(...)")`
     * is rejected, use `DateOperators.DateToString.dateOf("createdAt")
     * .toString("%Y-%m-%d")` instead — same result via Spring Data's typed
     * DSL rather than a raw expression string.
     */
    public List<ExecutionTrendDto> getExecutionTrends(String jobName, LocalDateTime from, LocalDateTime to) {
        LocalDateTime effectiveFrom = from != null ? from : LocalDateTime.now().minusDays(7);
        LocalDateTime effectiveTo = to != null ? to : LocalDateTime.now();

        List<Criteria> filters = new java.util.ArrayList<>();
        filters.add(Criteria.where("createdAt").gte(effectiveFrom).lte(effectiveTo));
        if (jobName != null && !jobName.isBlank()) {
            filters.add(Criteria.where("jobName").is(jobName));
        }

        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(new Criteria().andOperator(filters.toArray(new Criteria[0]))),
                Aggregation.project("status")
                        .andExpression("dateToString('%Y-%m-%d', createdAt)").as("day"),
                Aggregation.group("day", "status").count().as("count")
        );

        AggregationResults<Map> results = mongoTemplate.aggregate(aggregation, JobExecutionEntity.class, Map.class);

        Map<String, long[]> byDay = new LinkedHashMap<>(); // [0]=success [1]=failed
        for (Map<String, Object> row : results.getMappedResults()) {
            Map<String, Object> id = (Map<String, Object>) row.get("_id");
            String day = String.valueOf(id.get("day"));
            String status = String.valueOf(id.get("status"));
            long count = ((Number) row.get("count")).longValue();

            long[] arr = byDay.computeIfAbsent(day, k -> new long[2]);
            if ("COMPLETED".equals(status)) arr[0] += count;
            else if ("FAILED".equals(status)) arr[1] += count;
        }

        return byDay.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .map(e -> ExecutionTrendDto.builder()
                        .date(e.getKey())
                        .successCount(e.getValue()[0])
                        .failedCount(e.getValue()[1])
                        .build())
                .toList();
    }
}

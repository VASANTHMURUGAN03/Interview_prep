# Data Bridge BFF

A standalone Spring Boot service that sits between the React app
(`data-bridge-app`) and the core `databridge` backend. This is a genuinely
new, separate service — not a modification to the existing backend, and not
part of the React app either. Runs on port `8081` by default; the core
backend keeps running wherever it already runs (`8080` by default, per
`databridge.backend.base-url`).

## Why this exists

- **The UI never talks to the core backend directly again** — only to this
  BFF. That's the point of a BFF: the core service can evolve (add fields,
  rename things, eventually add real auth) without every change rippling
  straight into the React app's fetch calls.
- **Fewer round trips for two specific pages.** Dashboard needed 4 backend
  calls; Execution Detail needed 4 more. Both are now 1 call each through
  this service (see "Aggregation endpoints" below) — proxy everything,
  aggregate only where it actually helps, per what you asked for.

## How it works

### 1. Generic proxy — `/api/**`

Every existing backend endpoint (all 20+ from the last three engagement
batches, plus anything added later) is reachable at
`http://localhost:8081/api/v1/...` — same path, method, query params, and
body as the real backend at `/v1/...`, just fronted by the BFF.

This is a **single catch-all controller** (`ProxyController`), not one
method per route. Given how much the backend surface has grown across this
engagement, hand-mirroring every endpoint here would just be a second
place to forget to update — a new backend endpoint works through the BFF
automatically, no BFF code change needed.

Example: the frontend's `POST /v1/jobs/trigger/{name}` becomes
`POST http://localhost:8081/api/v1/jobs/trigger/{name}` — identical
request/response shape, just through the BFF.

### 2. Aggregation endpoints — `/aggregate/**`

Two endpoints that don't fit the pass-through model because they
deliberately combine multiple backend calls, fetched **in parallel**
(`Mono.zip`, not sequential — one slow call doesn't make the others wait):

- `GET /aggregate/dashboard/overview?jobName=&from=&to=` → `{ stats, topFailedJobs, executionTrends, recentExecutions }`
- `GET /aggregate/jobs/executions/{id}/overview` → `{ execution, readBatches, writeBatches, stepSummary }`

If any one sub-call fails, that section becomes `{"error": "..."}` in the
response instead of failing the whole request — a flaky
`execution-trends` call shouldn't blank out the entire Dashboard.

### 3. Header forwarding

`X-User-Id`, `X-User-Name`, `Authorization`, `Content-Type`, and `Accept`
are forwarded through to the backend (needed for the audit system added
earlier — those headers are how `recordAudit()` currently learns who did
what). `Authorization` is forwarded even though there's no real auth
system yet — this is deliberately the natural seam for adding real
session/token handling at the BFF layer later, without touching the core
backend's controllers again.

## Running it

```bash
mvn spring-boot:run
# or, after packaging:
java -jar target/databridge-bff-1.0.0.jar
```

Environment variables (all optional, sensible defaults in `application.yml`):

- `DATABRIDGE_BACKEND_URL` — where the core backend actually lives (default `http://localhost:8080`)
- `BFF_ALLOWED_ORIGINS` — comma-separated CORS origins for the React app (default `http://localhost:5173`, Vite's default dev port)

## What the React app needs to change (not done here — this task was BFF-only)

One line: point `axios`/`fetch` base URLs at `http://localhost:8081/api`
instead of the backend's own `8080`. Everything else — every service file,
every endpoint path — stays identical, since the proxy preserves the exact
`/v1/...` shape underneath `/api`. Say the word if you want that change
made too.

## Honest caveats

- **Not compiled/run** — same situation as every backend batch in this
  engagement: no build environment here to verify against. The
  WebClient/Netty timeout wiring and the wildcard `@RequestMapping("/api/{*path}")`
  pattern are standard Spring, but give it a real build before trusting it.
- **No real auth yet** — this BFF is the right place to eventually add it
  (session cookie in, forwarded as a bearer token out, or similar), but
  that's not implemented here; it just passes `Authorization` through
  untouched today.
- **CORS is wide open to whatever origin you configure** — fine for one
  known frontend, worth tightening if this ever serves multiple UIs.

package com.star.databridge.bff.client;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

/**
 * Every call to the core databridge backend goes through here — both the
 * generic proxy (ProxyController) and the two aggregation endpoints use
 * this rather than talking to WebClient directly, so timeout/logging/error
 * handling behavior stays in one place.
 *
 * forward()/exchangeToMono() deliberately relays the backend's real status
 * code and body rather than translating everything into a generic 500 —
 * a 404 from the backend should still look like a 404 through the BFF.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class BackendClient {

    private final WebClient backendWebClient;
    private final ObjectMapper objectMapper;

    /**
     * Used by the aggregation endpoints — fetches one backend call and
     * parses its JSON body directly, rather than round-tripping through
     * ResponseEntity<String> and re-parsing. Never errors out to the
     * caller: a failed sub-call becomes {"error": "..."} in the merged
     * response so one flaky endpoint doesn't take down the whole
     * aggregate (e.g. Dashboard shouldn't go blank just because
     * execution-trends timed out).
     */
    public Mono<JsonNode> getJson(String pathAndQuery, HttpHeaders headers) {
        return backendWebClient.get()
                .uri(pathAndQuery)
                .headers(h -> copyForwardableHeaders(headers, h))
                .retrieve()
                .bodyToMono(String.class)
                .map(body -> {
                    try {
                        return objectMapper.readTree(body);
                    } catch (Exception e) {
                        log.error("[BFF] Failed to parse JSON from {}", pathAndQuery, e);
                        return errorNode("Malformed response from " + pathAndQuery);
                    }
                })
                .onErrorResume(ex -> {
                    log.error("[BFF] Aggregation sub-call failed: {}", pathAndQuery, ex);
                    return Mono.just(errorNode(ex.getMessage()));
                });
    }

    private ObjectNode errorNode(String message) {
        ObjectNode node = objectMapper.createObjectNode();
        node.put("error", message != null ? message : "unknown error");
        return node;
    }

    public Mono<ResponseEntity<String>> forward(HttpMethod method, String pathAndQuery, HttpHeaders headers, String body) {
        WebClient.RequestBodySpec requestSpec = backendWebClient
                .method(method)
                .uri(pathAndQuery)
                .headers(h -> copyForwardableHeaders(headers, h));

        WebClient.RequestHeadersSpec<?> spec = (body != null && !body.isBlank())
                ? requestSpec.bodyValue(body)
                : requestSpec;

        return spec.exchangeToMono(response -> response.bodyToMono(String.class)
                        .defaultIfEmpty("")
                        .map(responseBody -> ResponseEntity.status(response.statusCode())
                                .headers(h -> copyResponseHeaders(response.headers().asHttpHeaders(), h))
                                .body(responseBody)))
                .onErrorResume(ex -> {
                    log.error("[BFF] Backend call failed: {} {}", method, pathAndQuery, ex);
                    return Mono.just(ResponseEntity.status(HttpStatusCode.valueOf(502))
                            .body("{\"statusCode\":502,\"message\":\"Upstream databridge service unavailable\"}"));
                });
    }

    /**
     * Only forward headers that are safe/meaningful to pass through — not
     * hop-by-hop headers like Host/Content-Length, which the underlying
     * WebClient call recomputes for its own outgoing request.
     */
    private void copyForwardableHeaders(HttpHeaders source, HttpHeaders target) {
        if (source == null) return;
        java.util.List<String> forwardable = java.util.List.of(
                "X-User-Id", "X-User-Name", "Authorization", "Content-Type", "Accept");
        forwardable.forEach(name -> {
            if (source.containsKey(name)) {
                target.put(name, source.get(name));
            }
        });
    }

    private void copyResponseHeaders(HttpHeaders source, HttpHeaders target) {
        if (source.getContentType() != null) {
            target.setContentType(source.getContentType());
        }
    }
}

package com.star.databridge.bff.controller;

import com.star.databridge.bff.client.BackendClient;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.Collections;
import java.util.Enumeration;

/**
 * The React app calls the BFF at /api/v1/... (instead of calling the core
 * backend's /v1/... directly). This controller strips the /api prefix and
 * forwards everything else — path, query string, method, body, and the
 * safe subset of headers (see BackendClient) — to the backend unchanged.
 *
 * This is deliberately a catch-all rather than one method per resource:
 * with 20+ endpoints already added across three batches on the backend
 * side, hand-mirroring every route here would just be a second place to
 * keep in sync and forget to update. Aggregation endpoints (which DON'T
 * fit this pass-through model) live in their own controllers under a
 * different path — see DashboardAggregationController /
 * ExecutionAggregationController.
 */
@RestController
@RequiredArgsConstructor
public class ProxyController {

    private final BackendClient backendClient;

    @RequestMapping("/api/{*path}")
    public Mono<ResponseEntity<String>> proxy(
            @PathVariable String path,
            @RequestBody(required = false) String body,
            HttpServletRequest request) {

        HttpMethod method = HttpMethod.valueOf(request.getMethod());
        String queryString = request.getQueryString();
        String pathAndQuery = path + (queryString != null ? "?" + queryString : "");

        HttpHeaders headers = new HttpHeaders();
        Enumeration<String> headerNames = request.getHeaderNames();
        if (headerNames != null) {
            Collections.list(headerNames).forEach(name ->
                    headers.put(name, Collections.list(request.getHeaders(name))));
        }

        return backendClient.forward(method, pathAndQuery, headers, body);
    }
}

package com.star.databridge.bff.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.star.databridge.bff.client.BackendClient;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

/**
 * The Dashboard page previously needed 4 separate round trips
 * (stats, top-failed-jobs, execution-trends, recent executions). This
 * fetches all 4 from the core backend IN PARALLEL (Mono.zip — not
 * sequential) and returns one combined JSON object, cutting page load to
 * one BFF round trip regardless of backend latency on any single call.
 */
@RestController
@RequiredArgsConstructor
public class DashboardAggregationController {

    private final BackendClient backendClient;
    private final ObjectMapper objectMapper;

    @GetMapping("/aggregate/dashboard/overview")
    public Mono<ResponseEntity<JsonNode>> getOverview(
            @RequestParam(required = false) String jobName,
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to,
            @RequestHeader HttpHeaders headers) {

        String rangeQuery = buildRangeQuery(jobName, from, to);

        Mono<JsonNode> stats = backendClient.getJson("/v1/dashboard/stats" + rangeQuery, headers);
        Mono<JsonNode> topFailedJobs = backendClient.getJson("/v1/dashboard/top-failed-jobs" + rangeQuery, headers);
        Mono<JsonNode> executionTrends = backendClient.getJson("/v1/dashboard/execution-trends" + rangeQuery, headers);
        Mono<JsonNode> recentExecutions = backendClient.getJson(
                "/v1/jobs/executions?size=10&page=0" + (jobName != null ? "&jobName=" + jobName : ""), headers);

        return Mono.zip(stats, topFailedJobs, executionTrends, recentExecutions)
                .map(tuple -> {
                    ObjectNode combined = objectMapper.createObjectNode();
                    combined.set("stats", tuple.getT1());
                    combined.set("topFailedJobs", tuple.getT2());
                    combined.set("executionTrends", tuple.getT3());
                    combined.set("recentExecutions", tuple.getT4());
                    return ResponseEntity.ok(combined);
                });
    }

    private String buildRangeQuery(String jobName, String from, String to) {
        StringBuilder sb = new StringBuilder();
        if (jobName != null) sb.append(sb.isEmpty() ? "?" : "&").append("jobName=").append(jobName);
        if (from != null) sb.append(sb.isEmpty() ? "?" : "&").append("from=").append(from);
        if (to != null) sb.append(sb.isEmpty() ? "?" : "&").append("to=").append(to);
        return sb.toString();
    }
}

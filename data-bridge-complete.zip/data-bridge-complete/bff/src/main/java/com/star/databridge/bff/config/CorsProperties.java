package com.star.databridge.bff.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "bff.cors")
public record CorsProperties(String allowedOrigins) {
}

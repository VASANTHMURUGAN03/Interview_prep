package com.star.databridge.bff.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.star.databridge.bff.client.BackendClient;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

/**
 * Execution Detail needs the execution itself plus read-batches,
 * write-batches, and the step-execution summary — 4 backend calls that
 * were previously 4 separate frontend requests. Fetched in parallel here.
 */
@RestController
@RequiredArgsConstructor
public class ExecutionAggregationController {

    private final BackendClient backendClient;
    private final ObjectMapper objectMapper;

    @GetMapping("/aggregate/jobs/executions/{jobExecutionId}/overview")
    public Mono<ResponseEntity<JsonNode>> getExecutionOverview(
            @PathVariable String jobExecutionId,
            @RequestHeader HttpHeaders headers) {

        String base = "/v1/jobs/executions/" + jobExecutionId;

        Mono<JsonNode> execution = backendClient.getJson(base, headers);
        Mono<JsonNode> readBatches = backendClient.getJson(base + "/read-batches", headers);
        Mono<JsonNode> writeBatches = backendClient.getJson(base + "/write-batches", headers);
        Mono<JsonNode> stepSummary = backendClient.getJson(base + "/step-executions/summary", headers);

        return Mono.zip(execution, readBatches, writeBatches, stepSummary)
                .map(tuple -> {
                    ObjectNode combined = objectMapper.createObjectNode();
                    combined.set("execution", tuple.getT1());
                    combined.set("readBatches", tuple.getT2());
                    combined.set("writeBatches", tuple.getT3());
                    combined.set("stepSummary", tuple.getT4());
                    return ResponseEntity.ok(combined);
                });
    }
}

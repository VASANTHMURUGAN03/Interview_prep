package com.star.databridge.bff.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Map;

/**
 * Catches anything unexpected that happens INSIDE the BFF itself (bad
 * request binding, a bug in an aggregation controller, etc). Backend
 * upstream failures are already handled gracefully inside BackendClient
 * and never reach here as exceptions.
 */
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleUnexpected(Exception ex) {
        log.error("[BFF] Unhandled exception", ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                "statusCode", 500,
                "message", "Unexpected BFF error: " + ex.getMessage()
        ));
    }
}

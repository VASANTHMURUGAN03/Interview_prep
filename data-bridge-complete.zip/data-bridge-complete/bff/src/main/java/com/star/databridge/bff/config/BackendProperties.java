package com.star.databridge.bff.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "databridge.backend")
public record BackendProperties(String baseUrl, long connectTimeoutMs, long responseTimeoutMs) {
}

# Data Bridge — Complete API Gap Analysis

Every frontend screen/component/modal/table/filter/action, checked against
every backend endpoint that exists as of this analysis (the original 9,
plus the two batches added in this engagement: 7 "missing APIs" endpoints,
and the JobRunr + Audit batch).

Legend: ✅ covered · ⚠️ partially covered / needs a new field or endpoint · ❌ missing entirely · 🚫 not supported by the architecture at all (flag to remove from UI, not to build)

## Dashboard

| UI element | Backend need | Status |
|---|---|---|
| Stat cards (total/active/success/fail/rate) | `GET /v1/dashboard/stats` | ✅ |
| Job/time filter dropdowns | `jobName`/`from`/`to` params on stats | ✅ |
| Success-vs-failure trend chart | time-bucketed counts | ❌ **implementing: Execution Trends API** |
| Recent Executions table | list executions, newest first, limit N | ✅ (`GET /v1/jobs/executions`, no filter, small `size`) |
| Top Failed Jobs list | executions grouped by job, failure count | ❌ **implementing: Top Failed Jobs API** |

## Jobs List

| UI element | Backend need | Status |
|---|---|---|
| Job card grid | `GET /v1/job-configs` | ✅ for config fields (name/entity/strategy) |
| Card's instance count / last run / status | no such fields on `JobConfigEntity` — needs a join against `job_executions` | ❌ **implementing: Job Config Summary API** |
| Search by name | client-side filter over the list | ✅ (no API needed) |
| Trigger button + params modal | `POST /v1/jobs/trigger/{name}` takes no body | ❌ **implementing: Trigger Job API with request body** |

## Job Instances

| UI element | Backend need | Status |
|---|---|---|
| Instance table, paginated | `GET /v1/jobs/executions?jobName=` | ✅ |
| Status filter | `status` param | ✅ |
| "Triggered By" filter/column | no field distinguishing manual/scheduled/chained on `JobExecutionEntity` | ⚠️ **implementing: new `triggeredBy` field** |
| Stop action | `POST /v1/jobs/abort/{jobUuid}` | ✅ |
| Resume action | — | 🚫 **the architecture has no resume concept — abort is terminal, confirmed in the earlier retry-mechanism analysis. Recommend removing "Resume" from the UI rather than building a fake API for it.** |
| View Execution → detail | `GET /v1/jobs/executions/{id}` | ✅ |

## Execution Detail

| UI element | Backend need | Status |
|---|---|---|
| Execution summary (status/start/end/duration) | `GET /v1/jobs/executions/{id}` | ✅ |
| Step timeline, per-step success/fail | raw `GET .../step-executions` exists but returns one row per batch — no aggregation | ❌ **implementing: Step Execution Summary API** |
| Read/Write batch panels | `GET .../read-batches`, `GET .../write-batches` | ✅ |
| "View Related Retries" button | operates on a **batch id**, not the execution id — current UI routes by execution id, a wiring bug to fix during frontend integration, not an API gap | ⚠️ frontend fix, not backend |

## Related Retries

| UI element | Backend need | Status |
|---|---|---|
| Write-batch retry chain | `GET .../batches/{batchId}/retries` (batchType=WRITE) | ✅ |
| Read-batch retry history | no equivalent for READ batches | ❌ **implementing — see the architectural note below, this isn't a simple parity gap** |

**Important finding, not just a missing endpoint**: write-batch retries create a **new** `WriteBatchExecutionEntity` per attempt (hence a chain to walk). Read-batch retries do **not** — `MigrationReadBatchConsumer` mutates the *same* `ReadBatchExecutionEntity` in place (`status`, `retryCount++`) and republishes the same batch. There is no historical chain to walk for read batches; only the latest attempt's state is visible (`remarks` from a prior failed attempt gets overwritten). Changing that would mean changing existing retry business logic, which was explicitly ruled out — so what I'm implementing is a **read-only "current retry state" endpoint**, not a chain-walk, and the UI needs to present it differently for READ vs WRITE (a single status card, not a table of past attempts).

## Data Migration Search

| UI element | Backend need | Status |
|---|---|---|
| Search by recordId/referenceId/status | `GET .../sync-records` | ✅ |
| Job filter dropdown | `GET /v1/job-configs` | ✅ |
| PII mask/reveal toggle | none — client-side only | ✅ (no API needed) |

## Job Configuration (list)

| UI element | Backend need | Status |
|---|---|---|
| Table: name/entity/strategy | `GET /v1/job-configs` | ✅ |
| Table: trigger/cron | same (embedded in config) | ✅ |
| Table: last run / status | same gap as Jobs List above | ⚠️ **Job Config Summary API** |
| Table: next execution time | `GET /v1/scheduler/jobs/{name}` (from the JobRunr batch) | ✅ — needs wiring, not a new endpoint |
| Enable/Disable toggle | `activate` / `DELETE` | ✅ |
| Trigger action | same as Jobs List | ❌ Trigger Job API with body |
| Edit → Job Config Builder | `GET/POST /v1/job-configs/{name}` | ✅ |

## Job Config Builder

| UI element | Backend need | Status |
|---|---|---|
| Load/save config (all sections) | `GET/POST /v1/job-configs/{name}` | ✅ |
| Step reference picker (process/sink/ack) | `GET /v1/process-steps/configs` | ✅ |
| Post-Complete job picker | `GET /v1/job-configs` | ✅ |
| Cron section (live preview, next-run) | client-side cron parser; no API | ✅ (no API needed) |
| SQL query modal | client-side only, saved as part of config | ✅ (no API needed) |

## Process Step Library

| UI element | Backend need | Status |
|---|---|---|
| List/search steps | `GET /v1/process-steps/configs` | ✅ |
| Create/edit step (all 8 types) | `POST /v1/process-steps/configs` | ✅ |

## Audit History (new screen, not yet built in the UI)

| UI element | Backend need | Status |
|---|---|---|
| Table, paginated | `GET /v1/audit` | ✅ |
| Filter by job/user/action/date range | same, query params | ✅ |
| Sort | `sortBy`/`sortDirection` params | ✅ |
| Per-job history | `GET /v1/audit/job/{jobName}` | ✅ |

## Summary of what's being implemented this pass

1. Step Execution Summary API
2. Dashboard Top Failed Jobs API
3. Dashboard Execution Trends API
4. Trigger Job API with request body parameters (+ honest limitation noted below)
5. Related Retry API for read-side batches (current-state, not a chain — see note above)
6. Job Config Summary API (discovered gap — needed by both Jobs List and Job Configuration)
7. `triggeredBy` field on `JobExecutionEntity` (discovered gap — needed for the Job Instances filter to mean anything)

## Flagged, not built

- **"Resume" job instance action** — no backing capability exists or should be faked; recommend cutting from the UI. (Already known from the earlier retry-mechanism report — repeating it here since this is the definitive gap list.)
- **Auth/login** — still nothing; standing item since early in this engagement.

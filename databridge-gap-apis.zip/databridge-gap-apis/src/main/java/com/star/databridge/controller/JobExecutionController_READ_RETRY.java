// ============================================================================
// MODIFY EXISTING FILE: controller/JobExecutionController.java
//
// SUPERSEDES JobExecutionController_ADD4.java's getRetryChain() method —
// apply this version instead of that one.
//
// Default batchType=WRITE preserves the exact existing behavior/contract
// for any caller not passing the new param, so this is backward compatible.
// ============================================================================

    @GetMapping("/executions/{jobExecutionId}/batches/{batchId}/retries")
    public ResponseEntity<ApiResponse<?>> getRetryInfo(
            @PathVariable String jobExecutionId,
            @PathVariable String batchId,
            @RequestParam(value = "batchType", defaultValue = "WRITE") String batchType) {

        Object data = "READ".equalsIgnoreCase(batchType)
                ? jobExecutionService.getReadBatchRetryState(batchId)
                : jobExecutionService.getWriteBatchRetryChain(batchId);

        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(data)
                .build());
    }

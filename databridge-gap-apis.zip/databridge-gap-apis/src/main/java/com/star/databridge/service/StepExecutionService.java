package com.star.databridge.service;

import com.star.databridge.dto.response.StepExecutionSummaryDto;
import com.star.databridge.entity.StepExecutionEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * NEW FILE. StepExecutionRepository (added in the earlier "missing APIs"
 * batch) only supported raw per-row lookups — this adds the aggregated
 * view the Execution Detail UI actually needs, so the frontend isn't
 * shipping potentially thousands of raw rows (one per batch per step) just
 * to compute counts client-side.
 */
@Service
@RequiredArgsConstructor
public class StepExecutionService {

    private final MongoTemplate mongoTemplate;

    /** Small local accumulator — one per call, never shared across requests. */
    private static final class Counts {
        long success, failed, running;
        String stepType;
    }

    public List<StepExecutionSummaryDto> getSummary(String jobExecutionId) {
        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(Criteria.where("jobExecutionId").is(jobExecutionId)),
                Aggregation.group("stepName", "stepType", "status").count().as("count")
        );

        AggregationResults<Map> results = mongoTemplate.aggregate(aggregation, StepExecutionEntity.class, Map.class);

        // Key by stepName only — stepType is stable per step name in practice,
        // and this keeps one row per step in the final result.
        Map<String, Counts> byStep = new LinkedHashMap<>();

        for (Map<String, Object> row : results.getMappedResults()) {
            Map<String, Object> id = (Map<String, Object>) row.get("_id");
            String stepName = String.valueOf(id.get("stepName"));
            String stepType = String.valueOf(id.get("stepType"));
            String status = String.valueOf(id.get("status"));
            long count = ((Number) row.get("count")).longValue();

            Counts counts = byStep.computeIfAbsent(stepName, k -> new Counts());
            counts.stepType = stepType;
            switch (status) {
                case "SUCCESS" -> counts.success += count;
                case "FAILED" -> counts.failed += count;
                case "RUNNING" -> counts.running += count;
                default -> { /* ignore unknown status */ }
            }
        }

        return byStep.entrySet().stream()
                .map(e -> StepExecutionSummaryDto.builder()
                        .stepName(e.getKey())
                        .stepType(e.getValue().stepType)
                        .successCount(e.getValue().success)
                        .failedCount(e.getValue().failed)
                        .runningCount(e.getValue().running)
                        .totalCount(e.getValue().success + e.getValue().failed + e.getValue().running)
                        .build())
                .toList();
    }
}

package com.star.databridge.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StepExecutionSummaryDto {
    private String stepName;
    private String stepType;
    private long successCount;
    private long failedCount;
    private long runningCount;
    private long totalCount;
}

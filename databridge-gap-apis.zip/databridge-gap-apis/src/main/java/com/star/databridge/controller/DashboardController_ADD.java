// ============================================================================
// MODIFY EXISTING FILE: controller/DashboardController.java
// Add these methods inside the existing class.
// ============================================================================

    @GetMapping("/top-failed-jobs")
    public ResponseEntity<ApiResponse<?>> getTopFailedJobs(
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "from", required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
            @RequestParam(value = "to", required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime to) {

        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(dashboardService.getTopFailedJobs(limit, from, to))
                .build());
    }

    @GetMapping("/execution-trends")
    public ResponseEntity<ApiResponse<?>> getExecutionTrends(
            @RequestParam(value = "jobName", required = false) String jobName,
            @RequestParam(value = "from", required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime from,
            @RequestParam(value = "to", required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime to) {

        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(dashboardService.getExecutionTrends(jobName, from, to))
                .build());
    }

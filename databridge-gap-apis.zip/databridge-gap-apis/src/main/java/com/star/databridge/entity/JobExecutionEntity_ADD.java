// ============================================================================
// MODIFY EXISTING FILE: entity/JobExecutionEntity.java
// Add this field to the existing class. Nullable/optional — existing
// documents in job_executions simply won't have it set, which is fine;
// Spring Data Mongo maps it as null for those, nothing breaks.
// ============================================================================

    /** "SYSTEM" (scheduler/chained — the existing, unmodified triggerJob() path)
     *  or "MANUAL" (a human via the REST trigger endpoint). See
     *  JobExecutionService_TRIGGER_PARAMS.java for where this gets set. */
    private String triggeredBy;

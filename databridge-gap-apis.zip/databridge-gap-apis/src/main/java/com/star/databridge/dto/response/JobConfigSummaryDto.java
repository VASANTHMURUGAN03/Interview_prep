package com.star.databridge.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.time.LocalDateTime;

/**
 * NEW FILE. Neither JobConfigEntity nor JobExecutionEntity alone has enough
 * to render the Jobs List / Job Configuration tables (name+status+lastRun+
 * nextRun all in one row) — this is the join, computed at read time rather
 * than denormalized onto either entity, so existing write paths for both
 * stay untouched.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JobConfigSummaryDto {
    private String name;
    private String entity;
    private String strategy;
    private boolean active;
    private String triggerType;
    private String cron;

    private LocalDateTime lastRun;
    private String lastStatus;

    private Instant nextRun; // null if not SCHEDULER-type or not currently registered
}

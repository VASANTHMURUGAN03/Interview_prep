// ============================================================================
// MODIFY EXISTING FILE: service/JobConfigService.java
//
// Add a new field: private final JobExecutionRepository jobExecutionRepository;
// (schedulingService is already a field from the JobRunr batch)
//
// Add these imports:
//   import com.star.databridge.dto.response.JobConfigSummaryDto;
//   import com.star.databridge.repository.JobExecutionRepository;
//   import com.star.databridge.entity.JobExecutionEntity;
//   import java.time.Instant;
//
// Add this method inside the existing class.
// ============================================================================

    public List<JobConfigSummaryDto> getConfigSummaries(Integer limit, Integer pageNumber) {
        List<JobConfigEntity> configs = getConfigs(limit, pageNumber); // reuses the existing method, unchanged

        return configs.stream()
                .map(config -> {
                    JobExecutionEntity lastExecution = jobExecutionRepository
                            .findTopByJobNameOrderByCreatedAtDesc(config.getName())
                            .orElse(null);

                    Instant nextRun = schedulingService.getJob(config.getName())
                            .map(job -> job.getNextRun())
                            .orElse(null);

                    return JobConfigSummaryDto.builder()
                            .name(config.getName())
                            .entity(config.getEntity())
                            .strategy(config.getStrategy())
                            .active(config.isActive())
                            .triggerType(config.getTrigger() != null ? config.getTrigger().getType() : null)
                            .cron(config.getTrigger() != null ? config.getTrigger().getCron() : null)
                            .lastRun(lastExecution != null ? lastExecution.getCreatedAt() : null)
                            .lastStatus(lastExecution != null ? lastExecution.getStatus() : null)
                            .nextRun(nextRun)
                            .build();
                })
                .toList();
    }

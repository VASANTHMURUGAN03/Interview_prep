// ============================================================================
// MODIFY EXISTING FILE: service/JobExecutionService.java
//
// Add this method alongside getWriteBatchRetryChain() (added in the earlier
// "missing APIs" batch, JobExecutionService_ADD4.java).
//
// Add this import: import com.star.databridge.dto.response.ReadBatchRetryStateDto;
// ============================================================================

    public ReadBatchRetryStateDto getReadBatchRetryState(String batchId) {
        ReadBatchExecutionEntity batch = readBatchService.getById(batchId);
        if (batch == null) {
            throw new IllegalArgumentException("Read batch not found: " + batchId);
        }
        return ReadBatchRetryStateDto.builder()
                .batchId(batch.getId())
                .batchNo(batch.getBatchNo())
                .status(batch.getStatus())
                .retryCount(batch.getRetryCount() != null ? batch.getRetryCount() : 0)
                .remarks(batch.getRemarks())
                .build();
    }

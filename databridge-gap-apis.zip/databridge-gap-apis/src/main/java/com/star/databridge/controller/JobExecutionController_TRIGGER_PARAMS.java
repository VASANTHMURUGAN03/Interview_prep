// ============================================================================
// MODIFY EXISTING FILE: controller/JobExecutionController.java
//
// SUPERSEDES JobExecutionController_AUDIT.java from the earlier JobRunr+Audit
// batch — apply this version instead, not both.
//
// Add these imports:
//   import org.springframework.web.bind.annotation.RequestHeader;
//   import com.star.databridge.dto.request.TriggerJobRequest;
// ============================================================================

    @PostMapping("/trigger/{name}")
    public ResponseEntity<ApiResponse<?>> triggerJob(
            @PathVariable String name,
            @RequestBody(required = false) TriggerJobRequest request,
            @RequestHeader(value = "X-User-Id", required = false) String userId,
            @RequestHeader(value = "X-User-Name", required = false) String username) {

        Map<String, Object> params = request != null ? request.getParams() : null;
        TriggerJobResponse response = jobExecutionService.triggerJobManually(name, params, userId, username);

        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(response)
                .build());
    }

// ============================================================================
// MODIFY EXISTING FILE: service/JobExecutionService.java
//
// This REPLACES the triggerJobManually() method added in the earlier
// JobRunr+Audit batch (JobExecutionService_AUDIT.java) with a version that
// also accepts trigger params and returns the actual TriggerJobResponse
// (the earlier version discarded it) — apply this instead of that one, not
// both.
//
// IMPORTANT — HONEST LIMITATION: `params` are stored on
// JobExecutionEntity.context, which is visible via the execution-detail API
// and safe to store, but nothing in the current pipeline (VariableResolver,
// ReadConfig/ProcessExecutorService/SinkExecutorService) reads FROM that
// context field today. VariableResolver's "context" variable type means
// "read another step's output," not "read the job execution's stored
// context map" — those are two different meanings of the word "context" in
// this codebase, confirmed by tracing util/VariableResolver.java. Making
// trigger-time params actually override reader/step parameters (e.g. an
// ad-hoc `asOfDate` overriding what's baked into a job's SQL query) would
// need a genuinely new variable-resolution path — e.g. a new ApiVariable
// type such as "trigger" that VariableResolver.resolve() checks against
// jobExecution.context before falling through to static/env/implementation/
// context(step-output). That's a real, separate change to existing
// business logic (VariableResolver + every call site that currently builds
// its `builtinVars` map), which per this task's constraints ("do not
// change existing business logic") isn't done here. What IS done: params
// are accepted, validated, and durably stored against the execution, ready
// for that follow-up to consume once you decide it's worth the change.
//
// Add these imports:
//   import java.util.Map;
// (java.util.* is likely already imported given the existing file's imports)
// ============================================================================

    public TriggerJobResponse triggerJobManually(String name, Map<String, Object> params, String userId, String username) {
        TriggerJobResponse response = triggerJobWithContext(name, "MANUAL", params);

        auditService.recordAudit(
                response.getJobExecutionId(), name, AuditAction.MANUAL_EXECUTION,
                null, params, userId, username, "Triggered manually via API");

        return response;
    }

    /**
     * Parallel path to the existing, UNCHANGED triggerJob(String) — reuses
     * the same read-batch-creation and Kafka-publish calls, just builds the
     * JobExecutionEntity with triggeredBy + context populated. triggerJob(String)
     * itself is not touched, so the JobRunr recurring callback and the
     * postComplete chain-trigger call site (JobCompletionCheckConsumer) keep
     * working exactly as they do today, with triggeredBy left null for them
     * (meaning "system/unspecified") rather than guessing SCHEDULER vs CHAINED.
     */
    private TriggerJobResponse triggerJobWithContext(String jobName, String triggeredBy, Map<String, Object> params) {
        Optional<JobConfigEntity> optionalJobConfig = jobConfigRepository.findByNameAndActive(jobName, true);
        if (optionalJobConfig.isEmpty()) {
            throw new RuntimeException("Job configuration not found: " + jobName);
        }
        JobConfigEntity jobConfig = optionalJobConfig.get();

        log.info("Triggering Job: {} (triggeredBy={})", jobConfig.getName(), triggeredBy);

        JobExecutionEntity jobExecution = createJobExecution(jobConfig);
        jobExecution.setTriggeredBy(triggeredBy);
        if (params != null && !params.isEmpty()) {
            jobExecution.getContext().putAll(params);
        }
        jobExecutionRepository.save(jobExecution);

        ReadBatchExecutionEntity firstReadBatch = readBatchService.createBatch(jobConfig, jobExecution.getId(), 1);
        kafkaUtil.pushReadBatchMsg(firstReadBatch, null);
        kafkaUtil.pushCompletionCheckMsg(jobConfig.getId(), jobExecution.getId());

        return TriggerJobResponse.builder()
                .jobId(jobExecution.getJobUuid())
                .jobName(jobName)
                .jobExecutionId(jobExecution.getId())
                .build();
    }

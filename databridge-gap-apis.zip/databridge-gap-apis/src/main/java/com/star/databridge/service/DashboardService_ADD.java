// ============================================================================
// MODIFY EXISTING FILE: service/DashboardService.java (the one created in
// the earlier "missing APIs" batch)
//
// Add these imports:
//   import com.star.databridge.dto.response.ExecutionTrendDto;
//   import com.star.databridge.dto.response.TopFailedJobDto;
//   import org.springframework.data.mongodb.core.aggregation.SortOperation;
//   import java.time.format.DateTimeFormatter;
//   import java.util.LinkedHashMap;
//
// Add these methods inside the existing class.
// ============================================================================

    public List<TopFailedJobDto> getTopFailedJobs(Integer limit, LocalDateTime from, LocalDateTime to) {
        int effectiveLimit = limit != null ? Math.min(limit, 20) : 5;

        List<Criteria> filters = new java.util.ArrayList<>();
        filters.add(Criteria.where("status").is("FAILED"));
        if (from != null) filters.add(Criteria.where("createdAt").gte(from));
        if (to != null) filters.add(Criteria.where("createdAt").lte(to));

        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(new Criteria().andOperator(filters.toArray(new Criteria[0]))),
                Aggregation.group("jobName").count().as("failureCount"),
                Aggregation.sort(org.springframework.data.domain.Sort.Direction.DESC, "failureCount"),
                Aggregation.limit(effectiveLimit)
        );

        AggregationResults<Map> results = mongoTemplate.aggregate(aggregation, JobExecutionEntity.class, Map.class);

        return results.getMappedResults().stream()
                .map(row -> TopFailedJobDto.builder()
                        .jobName(String.valueOf(row.get("_id")))
                        .failureCount(((Number) row.get("failureCount")).longValue())
                        .build())
                .toList();
    }

    /**
     * Daily success/failure counts, optionally scoped to one job. Defaults
     * to the last 7 days if no range is given — matches the Dashboard UI's
     * default chart window.
     *
     * NOTE — verify the date-to-string projection syntax against your
     * Spring Data MongoDB version. The `.andExpression("dateToString(...)")`
     * form below is the common pattern, but if your version rejects raw
     * Mongo operator strings in `.andExpression()`, use
     * `DateOperators.DateToString.dateOf("createdAt").toString("%Y-%m-%d")`
     * instead — same result, Spring Data's typed DSL rather than a raw
     * expression string. Same caveat class as SchedulingService's JobRunr
     * calls: this wasn't compiled against your actual dependency versions.
     */
    public List<ExecutionTrendDto> getExecutionTrends(String jobName, LocalDateTime from, LocalDateTime to) {
        LocalDateTime effectiveFrom = from != null ? from : LocalDateTime.now().minusDays(7);
        LocalDateTime effectiveTo = to != null ? to : LocalDateTime.now();

        List<Criteria> filters = new java.util.ArrayList<>();
        filters.add(Criteria.where("createdAt").gte(effectiveFrom).lte(effectiveTo));
        if (jobName != null && !jobName.isBlank()) {
            filters.add(Criteria.where("jobName").is(jobName));
        }

        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(new Criteria().andOperator(filters.toArray(new Criteria[0]))),
                Aggregation.project("status")
                        .andExpression("dateToString('%Y-%m-%d', createdAt)").as("day"),
                Aggregation.group("day", "status").count().as("count")
        );

        AggregationResults<Map> results = mongoTemplate.aggregate(aggregation, JobExecutionEntity.class, Map.class);

        Map<String, long[]> byDay = new LinkedHashMap<>(); // [0]=success [1]=failed
        for (Map<String, Object> row : results.getMappedResults()) {
            Map<String, Object> id = (Map<String, Object>) row.get("_id");
            String day = String.valueOf(id.get("day"));
            String status = String.valueOf(id.get("status"));
            long count = ((Number) row.get("count")).longValue();

            long[] arr = byDay.computeIfAbsent(day, k -> new long[2]);
            if ("COMPLETED".equals(status)) arr[0] += count;
            else if ("FAILED".equals(status)) arr[1] += count;
        }

        return byDay.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .map(e -> ExecutionTrendDto.builder()
                        .date(e.getKey())
                        .successCount(e.getValue()[0])
                        .failedCount(e.getValue()[1])
                        .build())
                .toList();
    }

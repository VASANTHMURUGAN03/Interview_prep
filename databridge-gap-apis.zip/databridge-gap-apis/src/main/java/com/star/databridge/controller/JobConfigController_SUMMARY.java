// ============================================================================
// MODIFY EXISTING FILE: controller/JobConfigController.java
// Add this method inside the existing class. Route is BEFORE /{name} in
// registration order doesn't matter here since Spring disambiguates
// "/summary" as a literal segment vs "/{name}" — but keep it defined
// clearly as its own mapping regardless.
// ============================================================================

    @GetMapping("/summary")
    public ResponseEntity<ApiResponse<?>> getConfigSummaries(
            @RequestParam(value = "limit", required = false) Integer limit,
            @RequestParam(value = "pageNumber", required = false) Integer pageNumber) {
        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(jobConfigService.getConfigSummaries(limit, pageNumber))
                .build());
    }

package com.star.databridge.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * NEW FILE. Unlike a write batch, a read batch's retries mutate the SAME
 * document in place (see MigrationReadBatchConsumer.handleReadBatchError) —
 * there's no chain of linked entities to walk, only the current state.
 * This DTO is intentionally "one row," not a list, to make that
 * architectural difference obvious to whoever consumes this endpoint
 * rather than hiding it behind a same-shaped-but-misleading list response.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReadBatchRetryStateDto {
    private String batchId;
    private int batchNo;
    private String status;
    private int retryCount;
    private String remarks;
}

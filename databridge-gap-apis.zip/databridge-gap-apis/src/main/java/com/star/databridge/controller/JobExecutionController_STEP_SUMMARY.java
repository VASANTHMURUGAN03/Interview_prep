// ============================================================================
// MODIFY EXISTING FILE: controller/JobExecutionController.java
//
// Add a new field: private final StepExecutionService stepExecutionService;
// Add this method inside the existing class.
// ============================================================================

    @GetMapping("/executions/{jobExecutionId}/step-executions/summary")
    public ResponseEntity<ApiResponse<?>> getStepExecutionSummary(@PathVariable String jobExecutionId) {
        return ResponseEntity.ok().body(ApiResponse
                .builder()
                .statusCode(HttpStatus.OK.value())
                .message("success")
                .data(stepExecutionService.getSummary(jobExecutionId))
                .build());
    }

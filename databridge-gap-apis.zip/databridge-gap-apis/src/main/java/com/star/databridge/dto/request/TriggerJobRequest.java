package com.star.databridge.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/** NEW FILE. */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TriggerJobRequest {
    /** Stored on JobExecutionEntity.context — see the limitation noted in
     *  JobExecutionService_TRIGGER_PARAMS.java about how far these
     *  currently reach into the actual read/process/sink pipeline. */
    private Map<String, Object> params;
}

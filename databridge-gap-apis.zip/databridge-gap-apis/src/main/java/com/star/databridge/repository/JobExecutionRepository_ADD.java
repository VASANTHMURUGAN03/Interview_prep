// ============================================================================
// MODIFY EXISTING FILE: repository/JobExecutionRepository.java
// Add this method to the existing interface.
// ============================================================================

    Optional<JobExecutionEntity> findTopByJobNameOrderByCreatedAtDesc(String jobName);

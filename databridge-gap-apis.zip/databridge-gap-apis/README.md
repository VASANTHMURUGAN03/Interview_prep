# Data Bridge — Gap Analysis API Batch

Read `GAP_ANALYSIS.md` first — it's the full screen-by-screen comparison
this batch was derived from. This README is just the "how to install it."

## ⚠️ Supersession — apply these INSTEAD of two files from the JobRunr+Audit batch

- `JobExecutionController_TRIGGER_PARAMS.java` **replaces**
  `JobExecutionController_AUDIT.java` (don't apply both — the version here
  adds request-body params on top of the same audit behavior).
- `JobExecutionController_READ_RETRY.java` **replaces**
  `JobExecutionController_ADD4.java`'s `getRetryChain()` method (the version
  here adds the `batchType` branch; everything else in that file is still
  needed as-is).
- `service/JobExecutionService_TRIGGER_PARAMS.java`'s `triggerJobManually()`
  **replaces** the one from `JobExecutionService_AUDIT.java` (same reason —
  extra param support, same audit call underneath).

If you haven't applied the JobRunr+Audit batch yet, just apply these
versions directly and skip the superseded ones entirely.

## Install order

1. **Entity field**: `JobExecutionEntity_ADD.java` (`triggeredBy` field)
2. **Repository**: `JobExecutionRepository_ADD.java`
3. **New services**: `StepExecutionService.java`
4. **Service snippets**: `DashboardService_ADD.java`,
   `JobConfigService_SUMMARY.java`, `JobExecutionService_TRIGGER_PARAMS.java`,
   `JobExecutionService_READ_RETRY.java`
5. **Controller snippets**: all the rest

`JobConfigService` and `JobExecutionService` now each have several
accumulated field additions across both this batch and the JobRunr+Audit
one — worth doing a single pass adding all new fields at once rather than
one at a time, since Lombok's `@RequiredArgsConstructor` regenerates the
constructor from whatever `final` fields exist at compile time regardless
of the order you add them in.

## Final coverage check (per the task's own instruction — confirm before frontend work)

Cross-referencing `GAP_ANALYSIS.md`'s "Summary of what's being implemented"
list against what's actually in this folder:

| Requirement | Implemented? |
|---|---|
| Step Execution Summary API | Yes — `StepExecutionService.getSummary()` + endpoint |
| Dashboard Top Failed Jobs API | Yes — `DashboardService.getTopFailedJobs()` + endpoint |
| Dashboard Execution Trends API | Yes — `DashboardService.getExecutionTrends()` + endpoint (date-aggregation syntax flagged for version verification) |
| Trigger Job API with request body | Yes — `TriggerJobRequest` + `triggerJobWithContext()` (limitation on actual pipeline usage clearly documented in that file) |
| Related Retry API for read-side batches | Yes — `getReadBatchRetryState()` — a current-state endpoint, not a chain (architecturally correct given how read-batch retries actually work — see `GAP_ANALYSIS.md`) |
| Job Config Summary API (discovered) | Yes — `GET /v1/job-configs/summary` |
| `triggeredBy` field (discovered) | Yes — added to `JobExecutionEntity`, set on the manual-trigger path |

**Nothing from the gap analysis is left unimplemented except the two items
explicitly flagged as *not* to build**: the "Resume" UI action (no backing
capability — recommend removing it from the frontend) and auth/login
(pre-existing open item, out of scope for this pass).

Given that, per the task's own sequencing instruction, the next step is
frontend integration — say the word when you want that to start.

// src/components/Sidebar.tsx

import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home, Briefcase, Database, RefreshCw, ChevronLeft, ChevronRight } from 'lucide-react';
import '../styles/Sidebar.css';

const Sidebar: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isCollapsed, setIsCollapsed] = useState(false);

  const navItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: Home,
      path: '/',
    },
    {
      id: 'jobs',
      label: 'Jobs',
      icon: Briefcase,
      path: '/jobs',
    },
    {
      id: 'data-migration-search',
      label: 'Data Migration Search',
      icon: Database,
      path: '/data-migration-search',
    },
    {
      id: 'event-tracking-app',
      label: 'Event Tracking App',
      icon: Database,
      path: '/event-tracking',
    },
  ];

  const isActive = (path: string): boolean => {
    if (path === '/') {
      return location.pathname === '/';
    }
    return location.pathname.startsWith(path);
  };

  const toggleSidebar = () => {
    setIsCollapsed(!isCollapsed);
  };

  // Update CSS variable when collapsed state changes
  useEffect(() => {
    document.documentElement.style.setProperty(
      '--sidebar-width',
      isCollapsed ? '80px' : '280px'
    );
  }, [isCollapsed]);

  return (
    <div className={`sidebar ${isCollapsed ? 'collapsed' : ''}`}>
      <div className="sidebar-header">
        <div className="sidebar-logo">
          <RefreshCw size={isCollapsed ? 24 : 32} className="sidebar-logo-icon" />
        </div>
        {!isCollapsed && (
          <div className="sidebar-title">
            <h2>Spring Batch</h2>
            <p>Monitor</p>
          </div>
        )}
      </div>

      <button className="sidebar-toggle" onClick={toggleSidebar}>
        {isCollapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
      </button>

      <nav className="sidebar-nav">
        
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.path);

          const handleClick = () => {
            if (item.id === 'event-tracking-app') {
              // Open in new tab
              window.open(item.path, '_blank');
            } else {
              navigate(item.path);
            }
          };

          return (
            <button
              key={item.id}
              className={`nav-item ${active ? 'active' : ''}`}
              onClick={handleClick}
              title={isCollapsed ? item.label : ''}
            >
              <Icon size={20} />
              {!isCollapsed && <span>{item.label}</span>}
            </button>
          );
        })}

      </nav>

      <div className="sidebar-footer">
        {!isCollapsed && (
          <div className="version-info">
            <span>Version 1.0.0</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default Sidebar;
// src/components/StatusBadge.tsx
import React from 'react';

interface StatusBadgeProps {
  status: string;
}

const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  const getStatusStyles = (status: string) => {
    const normalizedStatus = status?.toUpperCase() || '';
    
    switch (normalizedStatus) {
      case 'COMPLETED':
      case 'SUCCESS':
        return {
          background: 'linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%)',
          color: '#065f46',
          borderLeft: '3px solid #10b981'
        };
      case 'FAILED':
      case 'FAILURE':
        return {
          background: 'linear-gradient(135deg, #fee2e2 0%, #fecaca 100%)',
          color: '#991b1b',
          borderLeft: '3px solid #ef4444'
        };
      case 'PARTIAL_FAILURE':
        return {
          background: 'linear-gradient(135deg, #fee2e2 0%, #fecaca 100%)',
          color: '#da5b5b',
          borderLeft: '3px solid #e97f7f'
        };
      case 'RUNNING':
      case 'STARTED':
      case 'IN_PROGRESS':
        return {
          background: 'linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%)',
          color: '#1e40af',
          borderLeft: '3px solid #3b82f6'
        };
      case 'STOPPED':
      case 'STOPPING':
        return {
          background: 'linear-gradient(135deg, #fed7aa 0%, #fdba74 100%)', // Orange
          color: '#9a3412',
          borderLeft: '3px solid #f97316'
        };
      case 'PENDING':
      case 'PENDING_CALLBACK':
      case 'QUEUED':
        return {
          background: 'linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)',
          color: '#92400e',
          borderLeft: '3px solid #f59e0b'
        };
      case 'ABANDONED':
        return {
          background: 'linear-gradient(135deg, #e9d5ff 0%, #d8b4fe 100%)',
          color: '#6b21a8',
          borderLeft: '3px solid #8b5cf6'
        };
      default:
        return {
          background: 'linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%)',
          color: '#6b7280',
          borderLeft: '3px solid #9ca3af'
        };
    }
  };

  const styles = getStatusStyles(status);
  
  // Display "RUNNING" instead of "STARTED"
  const displayStatus = status?.toUpperCase() === 'STARTED' ? 'RUNNING' : status?.toUpperCase();

  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        padding: '0.375rem 0.75rem',
        borderRadius: '0.5rem',
        fontSize: '0.75rem',
        fontWeight: 700,
        textTransform: 'uppercase',
        letterSpacing: '0.05em',
        ...styles
      }}
    >
      {displayStatus}
    </span>
  );
};

export default StatusBadge;
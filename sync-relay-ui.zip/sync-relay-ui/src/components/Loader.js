// src/components/Loader.js
import React from 'react';
import '../styles/loader.css';

const Loader = ({ hidden }) => {
  // If hidden is true, we should hide the loader
  // If hidden is false or undefined, show the loader
  const display = hidden ? 'none' : 'flex';

  return (
    <section id="loader" style={{ display }}>
      <center>
        <div className="loader">
          <div className="loader__bar"></div>
          <div className="loader__bar"></div>
          <div className="loader__bar"></div>
          <div className="loader__bar"></div>
          <div className="loader__bar"></div>
          <div className="loader__ball"></div>
        </div>
        <div>Loading.....</div>
      </center>
      <div className="loader_overlay"></div>
    </section>
  );
};

export default Loader;
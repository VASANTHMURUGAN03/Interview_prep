import React, { useState } from 'react';
import { X } from 'lucide-react';

interface BatchSummaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: any;
  loading: boolean;
  error: string | null;
  summaryId: string;
  totalPages?: number; // total pages from API
  onPageChange?: (page: number) => void; // callback to parent
}

const BatchSummaryModal: React.FC<BatchSummaryModalProps> = ({
  isOpen,
  onClose,
  data,
  loading,
  error,
  summaryId,
  totalPages = 1,
  onPageChange
}) => {
  const [currentPage, setCurrentPage] = useState(0);

  if (!isOpen) return null;

  const handlePageChange = (newPage: number) => {
    if (newPage >= 0 && newPage < totalPages) {
      setCurrentPage(newPage);
      onPageChange?.(newPage); // notify parent to fetch data
    }
  };

  return (
    <div
      style={{
        position: 'fixed',
        top: 0, left: 0, right: 0, bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1000,
        padding: '1rem'
      }}
      onClick={onClose}
    >
      <div
       
  style={{
    backgroundColor: 'white',
    borderRadius: '0.75rem',
    width: '75vw',
    maxWidth: '1200px',
    height: '80vh',
    maxHeight: '90vh',
    display: 'flex',
    flexDirection: 'column',
    boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04)'
  }}


        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div style={{ padding: '1.25rem', borderBottom: '1px solid #e5e7eb', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <h2 style={{ fontSize: '1.25rem', fontWeight: 600, color: '#111827', margin: 0 }}>
              Batch Summary Details
            </h2>
            <p style={{ fontSize: '0.875rem', color: '#6b7280', margin: '0.25rem 0 0 0' }}>
              Summary ID: {summaryId}
            </p>
          </div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
            <X size={20} />
          </button>
        </div>

        {/* Content */}
  <div style={{ flex: 1, overflow: 'auto', padding: '1.25rem' }}>
  {loading && <p>Loading batch details...</p>}
  {error && <p style={{ color: 'red' }}>{error}</p>}

  {!loading && !error && data && Array.isArray(data.content) && data.content.length > 0 && (
    <pre style={{ backgroundColor: '#f9fafb', padding: '1rem', borderRadius: '0.5rem' }}>
      {JSON.stringify(data.content, null, 2)}
    </pre>
  )}

  {!loading && !error && data && Array.isArray(data.content) && data.content.length === 0 && (
    <p style={{ color: '#6b7280', fontSize: '0.875rem' }}>
      No batch summary records found.
    </p>
  )}
</div>



        {/* Footer with pagination */}
        <div style={{ padding: '1rem 1.25rem', borderTop: '1px solid #e5e7eb', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <button
              disabled={currentPage === 0}
              onClick={() => handlePageChange(currentPage - 1)}
              style={{ marginRight: '0.5rem' }}
            >
              Previous
            </button>
            <button
              disabled={currentPage >= totalPages - 1}
              onClick={() => handlePageChange(currentPage + 1)}
            >
              Next
            </button>
        <span style={{ marginLeft: '1rem', fontSize: '0.875rem' }}>
         Page {currentPage + 1} of {Math.max(totalPages, 1)}
         </span>

          </div>
          <button onClick={onClose} style={{ backgroundColor: '#3b82f6', color: 'white', padding: '0.5rem 1rem', borderRadius: '0.5rem' }}>
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default BatchSummaryModal;

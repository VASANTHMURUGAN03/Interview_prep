// src/components/RetryStepModal.tsx

import React, { useState } from 'react';
import { RefreshCw, AlertTriangle } from 'lucide-react';
import { Step } from '../types/batch.types';

interface RetryStepModalProps {
  step: Step;
  onRetry: (startIndex: number, endIndex: number) => Promise<void>;
  onClose: () => void;
}

const RetryStepModal: React.FC<RetryStepModalProps> = ({ step, onRetry, onClose }) => {
  const [retryParams, setRetryParams] = useState<{ startIndex: string; endIndex: string }>({
    startIndex: '',
    endIndex: ''
  });
  const [retrying, setRetrying] = useState<boolean>(false);

  const handleRetry = async (): Promise<void> => {
    if (!retryParams.startIndex || !retryParams.endIndex) {
      alert('Please provide both start and end index');
      return;
    }

    if (parseInt(retryParams.startIndex) > parseInt(retryParams.endIndex)) {
      alert('Start index must be less than or equal to end index');
      return;
    }

    try {
      setRetrying(true);
      await onRetry(parseInt(retryParams.startIndex), parseInt(retryParams.endIndex));
      onClose();
    } catch (error) {
      console.error('Failed to retry step:', error);
    } finally {
      setRetrying(false);
    }
  };

  return (
    <div className="modal-overlay-modern">
      <div className="modal-modern">
        <h3 className="modal-title-modern">Retry Step: {step.name}</h3>

        <div className="modal-notice-modern modal-notice-warning">
          <AlertTriangle size={20} style={{ color: '#f59e0b', flexShrink: 0 }} />
          <div style={{ fontSize: '0.875rem', color: '#92400e' }}>
            <strong>Note:</strong> Each retry will create a new job instance with the specified index range.
          </div>
        </div>

        <div className="form-group-modern">
          <label className="form-label-modern">Start Index</label>
          <input
            type="number"
            value={retryParams.startIndex}
            onChange={(e) => setRetryParams({ ...retryParams, startIndex: e.target.value })}
            className="form-input-modern"
            placeholder="e.g., 0"
            min="0"
          />
        </div>

        <div className="form-group-modern">
          <label className="form-label-modern">End Index</label>
          <input
            type="number"
            value={retryParams.endIndex}
            onChange={(e) => setRetryParams({ ...retryParams, endIndex: e.target.value })}
            className="form-input-modern"
            placeholder="e.g., 100"
            min="0"
          />
        </div>

        <div style={{ fontSize: '0.75rem', color: '#6b7280', marginBottom: '1.5rem' }}>
          Total records in this step: <strong>{step.writeCount || 0}</strong>
        </div>

        <div className="form-actions-modern">
          <button
            className="btn-modern btn-primary-gradient"
            onClick={handleRetry}
            disabled={retrying}
            style={{ flex: 1 }}
          >
            <RefreshCw size={16} className={retrying ? 'animate-spin' : ''} />
            {retrying ? 'Creating...' : 'Create Retry Job'}
          </button>
          <button
            className="btn-modern btn-ghost"
            onClick={onClose}
            disabled={retrying}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default RetryStepModal;
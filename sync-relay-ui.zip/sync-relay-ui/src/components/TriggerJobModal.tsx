import React, { useEffect, useRef } from 'react';
import { Play, Info, Lock, Unlock, Code, Maximize2, Minimize2, Copy, Check, Shield } from 'lucide-react';
import { useForm } from 'react-hook-form';
import Editor from '@monaco-editor/react';
import * as monaco from 'monaco-editor';
import { Job } from '../types/batch.types';
import batchApiService from '../services/batchApiService';

interface TriggerJobModalProps {
  job: Job;
  onClose: () => void;
  onTriggerSuccess: (message: string) => void;
  retryConfig?: RetryConfig;
}

interface FormData {
  [key: string]: string;
}

export interface RetryConfig {
  childInstance: boolean;
  parentJobInstance?: string;
  parentExecutionId?: string;
}

interface TriggerPayload {
  jobName: string;
  jobParams: Record<string, string>;
  retryConfig?: RetryConfig;
}

const TriggerJobModal: React.FC<TriggerJobModalProps> = ({ job, onClose, onTriggerSuccess, retryConfig  }) => {
  const [triggering, setTriggering] = React.useState<boolean>(false);
  const [fieldStates, setFieldStates] = React.useState<{ [key: string]: { disabled: boolean; useCustom: boolean } }>({});
  const [maximizedEditor, setMaximizedEditor] = React.useState<string | null>(null);
  const [copiedStates, setCopiedStates] = React.useState<{ [key: string]: boolean }>({});

  const editorRefs = useRef<{ [key: string]: monaco.editor.IStandaloneCodeEditor | null }>({});
  const monacoRef = useRef<typeof monaco | null>(null);
  const decorationsRef = useRef<{ [key: string]: string[] }>({});
  const protectedContentRef = useRef<{ [key: string]: string }>({});

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch
  } = useForm<FormData>();

  const effectiveRetryConfig = retryConfig || { childInstance: false };

  const defaultGroovyScript = `// ========================================
// GROOVY READER SCRIPT
// ========================================
// Entry Point: fetchData(offset, limit, jobParameters)
// This function will be called by Spring Batch for each page

// ----------------------------------------
// AVAILABLE VARIABLES IN SCOPE:
// ----------------------------------------
// offset (int)              - Current offset for pagination (0, 100, 200...)
// limit (int)               - Number of records to fetch per batch
// jobParameters             - Access all job parameters
// restTemplate              - Spring RestTemplate for HTTP calls
// environment               - Spring Environment (access application.properties)
// ----------------------------------------

import org.springframework.http.*

def fetchData(int offset, int limit, jobParameters) {

}
// ========================================`;

  // Initialize form with default values and field states
  useEffect(() => {
    if (job.paramDetail) {
      const initialStates: { [key: string]: { disabled: boolean; useCustom: boolean } } = {};

      job.paramDetail.forEach((param) => {
        // Set initial disabled state
        initialStates[param.paramName] = {
          disabled: param.defaultDisabled,
          useCustom: false
        };

        // Set default value if available
        if (param.defaultValue && param.defaultValue.length > 0) {
          setValue(param.paramName, String(param.defaultValue[0]));
        } else if (param.type.toLowerCase() === 'groovy') {
          // Set default Groovy script
          setValue(param.paramName, defaultGroovyScript);
        } else {
          setValue(param.paramName, '');
        }
      });

      setFieldStates(initialStates);
    }
  }, [job, setValue]);

  const toggleFieldEnabled = (paramName: string) => {
    setFieldStates(prev => ({
      ...prev,
      [paramName]: {
        ...prev[paramName],
        disabled: !prev[paramName].disabled
      }
    }));
  };

  const toggleCustomInput = (paramName: string) => {
    setFieldStates(prev => ({
      ...prev,
      [paramName]: {
        ...prev[paramName],
        useCustom: !prev[paramName].useCustom
      }
    }));

    // Clear the value when switching to custom input
    if (!fieldStates[paramName]?.useCustom) {
      setValue(paramName, '');
    }
  };

  const copyToClipboard = async (paramName: string) => {
    const content = watch(paramName);
    try {
      await navigator.clipboard.writeText(content || '');
      setCopiedStates(prev => ({ ...prev, [paramName]: true }));
      setTimeout(() => {
        setCopiedStates(prev => ({ ...prev, [paramName]: false }));
      }, 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  // Setup read-only decorations for non-editable lines
  const setupReadOnlyLines = (editor: monaco.editor.IStandaloneCodeEditor, monacoInstance: typeof monaco, nonEditableLines: number, paramName: string) => {
    if (nonEditableLines <= 0) return;

    const model = editor.getModel();
    if (!model) return;

    // Store the original protected content ONCE when editor mounts
    const originalContent = model.getValue();
    const originalLines = originalContent.split('\n');
    protectedContentRef.current[paramName] = originalLines.slice(0, nonEditableLines).join('\n');

    console.log(`[Protected Lines] Protecting first ${nonEditableLines} lines for ${paramName}`);
    console.log('Protected content:', protectedContentRef.current[paramName]);

    // Create decorations for non-editable lines
    const decorations: monaco.editor.IModelDeltaDecoration[] = [];

    for (let i = 1; i <= nonEditableLines; i++) {
      decorations.push({
        range: new monacoInstance.Range(i, 1, i, model.getLineMaxColumn(i)),
        options: {
          isWholeLine: true,
          className: 'read-only-line',
          glyphMarginClassName: 'read-only-line-glyph',
          glyphMarginHoverMessage: { value: '🔒 This line is protected and cannot be edited' },
          hoverMessage: { value: '**Protected Line** - This section cannot be modified' }
        }
      });
    }

    // Apply decorations
    const decorationIds = editor.deltaDecorations([], decorations);
    decorationsRef.current[paramName] = decorationIds;

    // Block all editing attempts in protected area using onDidChangeModelContent
    let isReverting = false;

    model.onDidChangeContent((e) => {
      if (isReverting) return;

      const changes = e.changes;
      let needsRevert = false;

      // Check if any change affects protected lines
      for (const change of changes) {
        const startLine = change.range.startLineNumber;
        const endLine = change.range.endLineNumber;

        if (startLine <= nonEditableLines || endLine <= nonEditableLines) {
          needsRevert = true;
          console.log(`[Protected Lines] Blocked edit attempt on line ${startLine}`);
          break;
        }
      }

      if (needsRevert) {
        isReverting = true;

        // Get current content
        const currentContent = model.getValue();
        const currentLines = currentContent.split('\n');

        // Get original protected lines from ref
        const protectedLines = protectedContentRef.current[paramName].split('\n');

        // Restore: Protected lines (original) + Editable lines (current)
        const restoredLines = [
          ...protectedLines,
          ...currentLines.slice(nonEditableLines)
        ];

        // Save cursor position
        const position = editor.getPosition();

        // Use pushEditOperations for smoother restoration
        const range = model.getFullModelRange();
        const restoredContent = restoredLines.join('\n');

        model.pushEditOperations(
          [],
          [{
            range: range,
            text: restoredContent
          }],
          () => null
        );

        // Move cursor to editable area if it was in protected area
        if (position) {
          if (position.lineNumber <= nonEditableLines) {
            editor.setPosition({
              lineNumber: nonEditableLines + 1,
              column: 1
            });
            editor.revealLine(nonEditableLines + 1);
          } else {
            // Try to maintain cursor position
            const newPosition = {
              lineNumber: Math.min(position.lineNumber, restoredLines.length),
              column: position.column
            };
            editor.setPosition(newPosition);
          }
        }

        setTimeout(() => {
          isReverting = false;
        }, 0);
      }
    });

    // Also prevent keyboard input in protected area
    editor.onKeyDown((e) => {
      const position = editor.getPosition();
      const selection = editor.getSelection();

      if (position && position.lineNumber <= nonEditableLines) {
        // Check if selection spans into editable area
        if (selection && selection.endLineNumber > nonEditableLines) {
          // Allow if selection goes into editable area
          return;
        }

        // Allow navigation keys
        const allowedKeys = [
          monacoInstance.KeyCode.UpArrow,
          monacoInstance.KeyCode.DownArrow,
          monacoInstance.KeyCode.LeftArrow,
          monacoInstance.KeyCode.RightArrow,
          monacoInstance.KeyCode.Home,
          monacoInstance.KeyCode.End,
          monacoInstance.KeyCode.PageUp,
          monacoInstance.KeyCode.PageDown,
          monacoInstance.KeyCode.Escape,
          monacoInstance.KeyCode.Tab
        ];

        // Allow Ctrl+C (copy)
        if (e.ctrlKey && e.keyCode === monacoInstance.KeyCode.KeyC) {
          return;
        }

        // Allow Ctrl+A (select all)
        if (e.ctrlKey && e.keyCode === monacoInstance.KeyCode.KeyA) {
          return;
        }

        // Allow Ctrl+F (find)
        if (e.ctrlKey && e.keyCode === monacoInstance.KeyCode.KeyF) {
          return;
        }

        // Allow Ctrl+H (replace)
        if (e.ctrlKey && e.keyCode === monacoInstance.KeyCode.KeyH) {
          return;
        }

        if (!allowedKeys.includes(e.keyCode)) {
          e.preventDefault();
          e.stopPropagation();
          console.log(`[Protected Lines] Blocked key press: ${e.keyCode} at line ${position.lineNumber}`);
        }
      }
    });

    // Add CSS for styling (inject once)
    if (!document.getElementById('read-only-line-styles')) {
      const style = document.createElement('style');
      style.id = 'read-only-line-styles';
      style.innerHTML = `
        .read-only-line {
          background-color: rgba(255, 152, 0, 0.08) !important;
          border-left: 3px solid #ff9800 !important;
          cursor: not-allowed !important;
        }
        .read-only-line-glyph {
          background-color: #ff9800 !important;
          width: 10px !important;
          margin-left: 3px;
          border-radius: 2px;
        }
        .monaco-editor .margin-view-overlays .read-only-line-glyph {
          background: #ff9800;
          border-radius: 2px;
        }
        .monaco-editor .view-lines .view-line.read-only-line {
          cursor: not-allowed !important;
        }
      `;
      document.head.appendChild(style);
    }
  };

  // Handle editor mount
  const handleEditorDidMount = (editor: monaco.editor.IStandaloneCodeEditor, monacoInstance: typeof monaco, paramName: string, param: any) => {
    editorRefs.current[paramName] = editor;
    monacoRef.current = monacoInstance;

    // Setup read-only lines if specified
    if (param.nonEditableLines && param.nonEditableLines > 0) {
      setupReadOnlyLines(editor, monacoInstance, param.nonEditableLines, paramName);
    }
  };

  const onSubmit = async (data: FormData): Promise<void> => {
    const payload: TriggerPayload = {
      jobName: job.name,
      jobParams: data,
    };

    if (effectiveRetryConfig.childInstance) {
      payload.retryConfig = effectiveRetryConfig;
    }

    try {
      setTriggering(true);
      
      // Use the batchApiService to trigger the job
      const result = await batchApiService.triggerJobLatest(payload);
      console.log('API Response:', result);

      // Close modal first
      onClose();
      // Then show success notification in parent
      onTriggerSuccess(`✅ ${effectiveRetryConfig.childInstance ? 'Retry' : 'Trigger'} request received for job "${job.name}"`);

    } catch (error) {
      console.error('Failed to trigger job:', error);
      // Show error notification in parent without closing modal
      onTriggerSuccess(`❌ Failed to ${effectiveRetryConfig.childInstance ? 'retry' : 'trigger'} job. Check console for details.`);
    } finally {
      setTriggering(false);
    }
  };

  const getInputType = (paramType: string): string => {
    const type = paramType.toLowerCase();
    if (type === 'datetime') return 'datetime-local';
    if (type === 'date') return 'date';
    if (type === 'integer') return 'number';
    return 'text';
  };

  const getValidationRules = (param: any) => {
    const rules: any = {};

    if (param.mandatory) {
      rules.required = `${param.labelName || param.paramName} is required`;
    }

    // Add type-specific validation
    if (param.type.toLowerCase() === 'integer') {
      rules.validate = {
        isNumber: (value: string) =>
          !value || !isNaN(Number(value)) || 'Must be a valid number'
      };
    }

    return rules;
  };

  // Enhanced Monaco Editor configuration for Groovy
  const editorOptions = {
    minimap: { enabled: false },
    fontSize: 14,
    fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', 'Consolas', monospace",
    fontLigatures: true,
    lineNumbers: 'on' as const,
    scrollBeyondLastLine: false,
    automaticLayout: true,
    wordWrap: 'on' as const,
    tabSize: 4,
    formatOnPaste: true,
    formatOnType: true,
    renderWhitespace: 'selection' as const,
    bracketPairColorization: { enabled: true },
    folding: true,
    lineHeight: 22,
    padding: { top: 12, bottom: 12 },
    smoothScrolling: true,
    cursorBlinking: 'smooth' as const,
    cursorSmoothCaretAnimation: 'on' as const,
    renderLineHighlight: 'all' as const,
    guides: {
      bracketPairs: true,
      indentation: true
    },
    suggest: {
      showKeywords: true,
      showSnippets: true
    },
    glyphMargin: true
  };

  const renderGroovyEditor = (param: any) => {
    const isDisabled = fieldStates[param.paramName]?.disabled;
    const isMaximized = maximizedEditor === param.paramName;
    const isCopied = copiedStates[param.paramName];
    const hasProtectedLines = param.nonEditableLines && param.nonEditableLines > 0;

    return (
      <>
        <div key={param.paramName} style={{ display: 'flex', flexDirection: 'column', marginBottom: '1.5rem' }}>
          {/* Enhanced Header */}
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            marginBottom: '0.75rem',
            padding: '0.75rem 1rem',
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            borderRadius: '8px 8px 0 0',
            boxShadow: '0 2px 8px rgba(102, 126, 234, 0.2)'
          }}>
            <label style={{
              fontWeight: 600,
              display: 'flex',
              alignItems: 'center',
              gap: '0.75rem',
              color: 'white',
              fontSize: '0.95rem'
            }}>
              <div style={{
                background: 'rgba(255, 255, 255, 0.2)',
                padding: '6px',
                borderRadius: '6px',
                display: 'flex',
                alignItems: 'center'
              }}>
                <Code size={18} />
              </div>
              {param.labelName || param.paramName}
              {param.mandatory && <span style={{ color: '#fef3c7' }}> *</span>}
              {param.defaultDisabled && (
                <span style={{
                  fontSize: '0.7rem',
                  color: 'white',
                  background: isDisabled
                    ? 'rgba(239, 68, 68, 0.3)'
                    : 'rgba(16, 185, 129, 0.3)',
                  padding: '3px 8px',
                  borderRadius: '12px',
                  fontWeight: 600,
                  border: `1.5px solid ${isDisabled ? 'rgba(239, 68, 68, 0.5)' : 'rgba(16, 185, 129, 0.5)'}`,
                  backdropFilter: 'blur(4px)'
                }}>
                  {isDisabled ? '🔒 Locked' : '🔓 Unlocked'}
                </span>
              )}
              {hasProtectedLines && (
                <span style={{
                  fontSize: '0.7rem',
                  color: 'white',
                  background: 'rgba(255, 152, 0, 0.3)',
                  padding: '3px 8px',
                  borderRadius: '12px',
                  fontWeight: 600,
                  border: '1.5px solid rgba(255, 152, 0, 0.5)',
                  backdropFilter: 'blur(4px)',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.35rem'
                }}>
                  <Shield size={11} />
                  Lines 1-{param.nonEditableLines} Protected
                </span>
              )}
            </label>

            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              {/* Language Badge */}
              <span style={{
                fontSize: '0.75rem',
                color: 'white',
                background: 'rgba(255, 255, 255, 0.2)',
                padding: '4px 10px',
                borderRadius: '12px',
                display: 'flex',
                alignItems: 'center',
                gap: '0.35rem',
                fontWeight: 600,
                backdropFilter: 'blur(4px)',
                border: '1px solid rgba(255, 255, 255, 0.3)'
              }}>
                <Code size={12} />
                Groovy
              </span>

              {/* Copy Button */}
              <button
                type="button"
                onClick={() => copyToClipboard(param.paramName)}
                disabled={isDisabled || triggering}
                style={{
                  padding: '6px 10px',
                  background: 'rgba(255, 255, 255, 0.2)',
                  color: 'white',
                  border: '1px solid rgba(255, 255, 255, 0.3)',
                  borderRadius: '6px',
                  cursor: isDisabled || triggering ? 'not-allowed' : 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.4rem',
                  fontSize: '0.75rem',
                  fontWeight: 600,
                  transition: 'all 0.2s',
                  opacity: isDisabled || triggering ? 0.5 : 1,
                  backdropFilter: 'blur(4px)'
                }}
                onMouseEnter={(e) => {
                  if (!isDisabled && !triggering) {
                    e.currentTarget.style.background = 'rgba(255, 255, 255, 0.3)';
                  }
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'rgba(255, 255, 255, 0.2)';
                }}
                title="Copy to clipboard"
              >
                {isCopied ? (
                  <>
                    <Check size={13} />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy size={13} />
                    Copy
                  </>
                )}
              </button>

              {/* Maximize Button */}
              <button
                type="button"
                onClick={() => setMaximizedEditor(isMaximized ? null : param.paramName)}
                disabled={isDisabled || triggering}
                style={{
                  padding: '6px 10px',
                  background: 'rgba(255, 255, 255, 0.2)',
                  color: 'white',
                  border: '1px solid rgba(255, 255, 255, 0.3)',
                  borderRadius: '6px',
                  cursor: isDisabled || triggering ? 'not-allowed' : 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.4rem',
                  fontSize: '0.75rem',
                  fontWeight: 600,
                  transition: 'all 0.2s',
                  opacity: isDisabled || triggering ? 0.5 : 1,
                  backdropFilter: 'blur(4px)'
                }}
                onMouseEnter={(e) => {
                  if (!isDisabled && !triggering) {
                    e.currentTarget.style.background = 'rgba(255, 255, 255, 0.3)';
                  }
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'rgba(255, 255, 255, 0.2)';
                }}
                title="Maximize to full screen"
              >
                <Maximize2 size={13} />
                Fullscreen
              </button>

              {/* Lock/Unlock Toggle */}
              {param.defaultDisabled && (
                <button
                  type="button"
                  onClick={() => toggleFieldEnabled(param.paramName)}
                  style={{
                    position: 'relative',
                    width: '48px',
                    height: '26px',
                    background: isDisabled
                      ? 'rgba(239, 68, 68, 0.3)'
                      : 'rgba(16, 185, 129, 0.3)',
                    borderRadius: '13px',
                    border: `1.5px solid ${isDisabled ? 'rgba(239, 68, 68, 0.5)' : 'rgba(16, 185, 129, 0.5)'}`,
                    cursor: 'pointer',
                    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                    padding: 0,
                    outline: 'none',
                    backdropFilter: 'blur(4px)'
                  }}
                  title={isDisabled ? 'Click to unlock and enable editing' : 'Click to lock field'}
                >
                  <span style={{
                    position: 'absolute',
                    top: '1px',
                    left: isDisabled ? '2px' : '24px',
                    width: '22px',
                    height: '22px',
                    background: 'white',
                    borderRadius: '50%',
                    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    boxShadow: '0 2px 6px rgba(0,0,0,0.3)'
                  }}>
                    {isDisabled ? <Lock size={12} color="#ef4444" /> : <Unlock size={12} color="#10b981" />}
                  </span>
                </button>
              )}
            </div>
          </div>

          {/* Protected Lines Warning */}
          {hasProtectedLines && (
            <div style={{
              padding: '0.75rem 1rem',
              background: 'linear-gradient(135deg, #fff7ed 0%, #ffedd5 100%)',
              border: '1px solid #fed7aa',
              borderRadius: '6px',
              marginBottom: '0.75rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.75rem',
              fontSize: '0.813rem',
              color: '#9a3412'
            }}>
              <Shield size={18} style={{ flexShrink: 0, color: '#ea580c' }} />
              <div>
                <strong style={{ display: 'block', marginBottom: '0.25rem' }}>
                  Protected Template Section
                </strong>
                The first <strong>{param.nonEditableLines} lines</strong> are protected and cannot be modified.
                You can edit code starting from <strong>line {param.nonEditableLines + 1}</strong> onwards.
              </div>
            </div>
          )}

          {/* Editor Container with Enhanced Styling */}
          <div style={{
            border: '2px solid #e0e7ff',
            borderRadius: '8px',
            overflow: 'hidden',
            opacity: isDisabled ? 0.6 : 1,
            pointerEvents: isDisabled || triggering ? 'none' : 'auto',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.08)',
            background: '#1e1e1e'
          }}>
            <Editor
              height="400px"
              language="groovy"
              theme="vs-dark"
              value={watch(param.paramName) || defaultGroovyScript}
              onChange={(value: string | undefined) => setValue(param.paramName, value || '')}
              onMount={(editor, monaco:any) => handleEditorDidMount(editor, monaco, param.paramName, param)}
              options={{
                ...editorOptions,
                readOnly: isDisabled || triggering
              }}
            />
          </div>

          {/* Enhanced Info Footer */}
          <div style={{
            marginTop: '0.75rem',
            padding: '0.75rem 1rem',
            fontSize: '0.75rem',
            color: '#4b5563',
            background: 'linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%)',
            borderRadius: '6px',
            display: 'flex',
            alignItems: 'flex-start',
            gap: '0.5rem',
            border: '1px solid #bae6fd'
          }}>
            <Info size={14} style={{ marginTop: '1px', flexShrink: 0, color: '#0284c7' }} />
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
              <div style={{ fontWeight: 600, color: '#0369a1' }}>
                💡 Editor Tips:
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.75rem', marginTop: '0.25rem' }}>
                <span><kbd style={kbdStyle}>Ctrl+Space</kbd> Autocomplete</span>
                <span><kbd style={kbdStyle}>Ctrl+/</kbd> Comment</span>
                <span><kbd style={kbdStyle}>Ctrl+F</kbd> Find</span>
                <span><kbd style={kbdStyle}>Alt+↑/↓</kbd> Move Line</span>
              </div>
              <div style={{ marginTop: '0.5rem', color: '#0369a1' }}>
                <strong>Available Variables:</strong> offset, limit, jobParameters, restTemplate, environment
              </div>
            </div>
          </div>

          {errors[param.paramName] && (
            <span style={{
              color: '#dc2626',
              fontSize: '0.75rem',
              marginTop: '0.5rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.35rem',
              background: '#fef2f2',
              padding: '0.5rem 0.75rem',
              borderRadius: '6px',
              border: '1px solid #fecaca'
            }}>
              <span style={{ fontSize: '1rem' }}>⚠️</span>
              {errors[param.paramName]?.message as string}
            </span>
          )}
        </div>

        {/* Enhanced Full Screen Modal */}
        {isMaximized && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0, 0, 0, 0.95)',
            zIndex: 9999,
            display: 'flex',
            flexDirection: 'column',
            padding: '1.5rem',
            backdropFilter: 'blur(8px)'
          }}>
            {/* Enhanced Full Screen Header */}
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '1rem',
              padding: '1.25rem 1.5rem',
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              borderRadius: '12px',
              color: 'white',
              boxShadow: '0 4px 16px rgba(102, 126, 234, 0.3)'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                <div style={{
                  background: 'rgba(255, 255, 255, 0.2)',
                  padding: '10px',
                  borderRadius: '10px',
                  display: 'flex',
                  alignItems: 'center',
                  backdropFilter: 'blur(4px)'
                }}>
                  <Code size={24} />
                </div>
                <div>
                  <h3 style={{ margin: 0, fontSize: '1.25rem', fontWeight: 700 }}>
                    {param.labelName || param.paramName}
                  </h3>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginTop: '0.35rem' }}>
                    <span style={{
                      fontSize: '0.8rem',
                      color: 'rgba(255, 255, 255, 0.8)'
                    }}>
                      Groovy Script Editor - Full Screen Mode
                    </span>
                    {hasProtectedLines && (
                      <span style={{
                        fontSize: '0.7rem',
                        background: 'rgba(255, 152, 0, 0.3)',
                        padding: '3px 8px',
                        borderRadius: '10px',
                        border: '1px solid rgba(255, 152, 0, 0.5)',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.35rem'
                      }}>
                        <Shield size={11} />
                        Lines 1-{param.nonEditableLines} Protected
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '0.75rem' }}>
                {/* Copy Button in Fullscreen */}
                <button
                  type="button"
                  onClick={() => copyToClipboard(param.paramName)}
                  style={{
                    padding: '10px 18px',
                    background: 'rgba(255, 255, 255, 0.2)',
                    color: 'white',
                    border: '1px solid rgba(255, 255, 255, 0.3)',
                    borderRadius: '8px',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                    fontSize: '0.875rem',
                    fontWeight: 600,
                    transition: 'all 0.2s',
                    backdropFilter: 'blur(4px)'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 255, 255, 0.3)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 255, 255, 0.2)';
                  }}
                >
                  {isCopied ? (
                    <>
                      <Check size={16} />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy size={16} />
                      Copy Code
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setMaximizedEditor(null)}
                  style={{
                    padding: '10px 18px',
                    background: 'rgba(255, 255, 255, 0.2)',
                    color: 'white',
                    border: '1px solid rgba(255, 255, 255, 0.3)',
                    borderRadius: '8px',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.5rem',
                    fontSize: '0.875rem',
                    fontWeight: 600,
                    transition: 'all 0.2s',
                    backdropFilter: 'blur(4px)'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 255, 255, 0.3)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 255, 255, 0.2)';
                  }}
                >
                  <Minimize2 size={16} />
                  Exit Fullscreen
                </button>
              </div>
            </div>

            {/* Protected Lines Warning in Fullscreen */}
            {hasProtectedLines && (
              <div style={{
                padding: '0.75rem 1rem',
                background: 'linear-gradient(135deg, #1e293b 0%, #0f172a 100%)',
                border: '1px solid #f59e0b',
                borderRadius: '8px',
                marginBottom: '1rem',
                display: 'flex',
                alignItems: 'center',
                gap: '0.75rem',
                fontSize: '0.813rem',
                color: '#fbbf24'
              }}>
                <Shield size={18} style={{ flexShrink: 0 }} />
                <div>
                  <strong>Protected:</strong> Lines 1-{param.nonEditableLines} cannot be modified.
                  Edit from line {param.nonEditableLines + 1} onwards.
                </div>
              </div>
            )}

            {/* Enhanced Full Screen Editor */}
            <div style={{
              flex: 1,
              border: '2px solid #4c1d95',
              borderRadius: '12px',
              overflow: 'hidden',
              boxShadow: '0 8px 24px rgba(0, 0, 0, 0.4)'
            }}>
              <Editor
                height="100%"
                language="groovy"
                theme="vs-dark"
                value={watch(param.paramName) || defaultGroovyScript}
                onChange={(value: string | undefined) => setValue(param.paramName, value || '')}
                onMount={(editor, monaco:any) => handleEditorDidMount(editor, monaco, param.paramName, param)}
                options={{
                  ...editorOptions,
                  minimap: { enabled: true },
                  fontSize: 15,
                  readOnly: isDisabled || triggering,
                  renderWhitespace: 'all'
                }}
              />
            </div>

            {/* Enhanced Full Screen Tips Footer */}
            <div style={{
              marginTop: '1rem',
              padding: '1rem 1.5rem',
              background: 'linear-gradient(135deg, #1e293b 0%, #0f172a 100%)',
              borderRadius: '12px',
              color: '#cbd5e1',
              fontSize: '0.813rem',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              border: '1px solid #334155',
              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)'
            }}>
              <div style={{ display: 'flex', gap: '2.5rem', flexWrap: 'wrap' }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  💡 <kbd style={kbdStyleDark}>Ctrl+Space</kbd> Autocomplete
                </span>
                <span style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  📝 <kbd style={kbdStyleDark}>Ctrl+/</kbd> Comment
                </span>
                <span style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  🔍 <kbd style={kbdStyleDark}>Ctrl+F</kbd> Find
                </span>
                <span style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  🔄 <kbd style={kbdStyleDark}>Ctrl+H</kbd> Replace
                </span>
                <span style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  ⬆️ <kbd style={kbdStyleDark}>Alt+↑/↓</kbd> Move Line
                </span>
              </div>
              <span style={{ color: '#94a3b8', fontWeight: 500 }}>
                Press <kbd style={kbdStyleDark}>ESC</kbd> to exit fullscreen
              </span>
            </div>
          </div>
        )}
      </>
    );
  };

  const renderInputField = (param: any) => {
    // Check if this is a Groovy script field
    if (param.type.toLowerCase() === 'groovy') {
      return renderGroovyEditor(param);
    }

    const hasDefaultValues = param.defaultValue && param.defaultValue.length > 0;
    const isDisabled = fieldStates[param.paramName]?.disabled;
    const useCustom = fieldStates[param.paramName]?.useCustom;

    return (
      <div key={param.paramName} style={{ display: 'flex', flexDirection: 'column', marginBottom: '0.75rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
          <label style={{ fontWeight: 500, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            {param.labelName || param.paramName}
            {param.mandatory && <span style={{ color: '#ef4444' }}> *</span>}
            {param.defaultDisabled && (
              <span style={{
                fontSize: '0.7rem',
                color: isDisabled ? '#ef4444' : '#10b981',
                background: isDisabled ? '#fee2e2' : '#d1fae5',
                padding: '2px 6px',
                borderRadius: '4px',
                fontWeight: 500
              }}>
                {isDisabled ? 'Locked' : 'Unlocked'}
              </span>
            )}
          </label>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <span style={{ fontSize: '0.8rem', color: '#6b7280' }}>{param.type}</span>
            {param.defaultDisabled && (
              <button
                type="button"
                onClick={() => toggleFieldEnabled(param.paramName)}
                style={{
                  position: 'relative',
                  width: '44px',
                  height: '24px',
                  background: isDisabled ? '#e5e7eb' : '#10b981',
                  borderRadius: '12px',
                  border: 'none',
                  cursor: 'pointer',
                  transition: 'background 0.2s',
                  padding: 0,
                  outline: 'none'
                }}
                title={isDisabled ? 'Click to unlock and enable editing' : 'Click to lock field'}
              >
                <span style={{
                  position: 'absolute',
                  top: '2px',
                  left: isDisabled ? '2px' : '22px',
                  width: '20px',
                  height: '20px',
                  background: 'white',
                  borderRadius: '50%',
                  transition: 'left 0.2s',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: '0 1px 3px rgba(0,0,0,0.2)'
                }}>
                  {isDisabled ? <Lock size={12} color="#6b7280" /> : <Unlock size={12} color="#10b981" />}
                </span>
              </button>
            )}
          </div>
        </div>

        {hasDefaultValues && !useCustom ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
            <select
              {...register(param.paramName, getValidationRules(param))}
              className="form-input-modern"
              disabled={isDisabled || triggering}
              style={{ paddingRight: '2rem' }}
            >
              {param.defaultValue.map((value: any) => (
                <option key={String(value)} value={String(value)}>
                  {String(value)}
                </option>
              ))}
            </select>
            <button
              type="button"
              onClick={() => toggleCustomInput(param.paramName)}
              disabled={isDisabled || triggering}
              style={{
                fontSize: '0.75rem',
                color: '#3b82f6',
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                textAlign: 'left',
                padding: '0',
                textDecoration: 'underline'
              }}
            >
              Enter custom value
            </button>
          </div>
        ) : hasDefaultValues && useCustom ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
            <input
              type={getInputType(param.type)}
              {...register(param.paramName, getValidationRules(param))}
              className="form-input-modern"
              placeholder={`Enter custom ${param.labelName || param.paramName}`}
              disabled={isDisabled || triggering}
            />
            <button
              type="button"
              onClick={() => toggleCustomInput(param.paramName)}
              disabled={isDisabled || triggering}
              style={{
                fontSize: '0.75rem',
                color: '#3b82f6',
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                textAlign: 'left',
                padding: '0',
                textDecoration: 'underline'
              }}
            >
              Choose from dropdown
            </button>
          </div>
        ) : (
          <input
            type={getInputType(param.type)}
            {...register(param.paramName, getValidationRules(param))}
            className="form-input-modern"
            placeholder={`Enter ${param.labelName || param.paramName}`}
            disabled={isDisabled || triggering}
          />
        )}

        {errors[param.paramName] && (
          <span style={{ color: 'red', fontSize: '0.75rem', marginTop: '0.25rem' }}>
            {errors[param.paramName]?.message as string}
          </span>
        )}
      </div>
    );
  };

  return (
    <div className="modal-overlay-modern">
      <div className="modal-modern" style={{ position: 'relative', paddingTop: 0, maxWidth: '1000px' }}>
        {/* Sticky Header with Close Button */}
        <div style={{
          position: 'sticky',
          top: 0,
          background: 'white',
          zIndex: 10,
          paddingTop: '1.5rem',
          paddingBottom: '1rem',
          marginLeft: '-1.5rem',
          marginRight: '-1.5rem',
          paddingLeft: '1.5rem',
          paddingRight: '1.5rem',
          borderBottom: '1px solid #e5e7eb'
        }}>
          <h3 className="modal-title-modern" style={{ margin: 0, paddingRight: '2rem' }}>
            Trigger Job: {job.name}
          </h3>

          {/* Close Button - Fixed at top right */}
          <button
            type="button"
            onClick={onClose}
            disabled={triggering}
            style={{
              position: 'absolute',
              top: '1rem',
              right: '1rem',
              background: 'white',
              border: '1px solid #e5e7eb',
              cursor: triggering ? 'not-allowed' : 'pointer',
              padding: '6px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: '#6b7280',
              borderRadius: '6px',
              transition: 'all 0.2s',
              opacity: triggering ? 0.5 : 1,
              boxShadow: '0 1px 2px rgba(0,0,0,0.05)'
            }}
            onMouseEnter={(e) => {
              if (!triggering) {
                e.currentTarget.style.background = '#fee2e2';
                e.currentTarget.style.borderColor = '#fca5a5';
                e.currentTarget.style.color = '#dc2626';
              }
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'white';
              e.currentTarget.style.borderColor = '#e5e7eb';
              e.currentTarget.style.color = '#6b7280';
            }}
            title="Close"
          >
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>

        {/* Scrollable Content */}
        <div style={{ paddingTop: '1rem' }}>
          <div className="modal-notice-modern">
            <Info size={20} style={{ color: '#3b82f6', flexShrink: 0 }} />
            <div style={{ fontSize: '0.875rem', color: '#1e40af' }}>
              <strong>Note:</strong> This will create a new job instance with the specified parameters.
            </div>
          </div>

          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="form-group-modern">
              <label className="form-label-modern">Job Parameters</label>

              {job.paramDetail && job.paramDetail.length > 0 ? (
                job.paramDetail.map((param) => renderInputField(param))
              ) : (
                <div style={{ color: '#6b7280' }}>No parameters defined for this job.</div>
              )}
            </div>

            <div className="form-actions-modern">
              <button
                type="submit"
                className="btn-modern btn-success-gradient"
                disabled={triggering}
                style={{ flex: 1 }}
              >
                {triggering ? (
                  <>
                    <div className="loading-spinner-small"></div>
                    Triggering...
                  </>
                ) : (
                  <>
                    <Play size={16} />
                    Trigger Job
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

// Keyboard shortcut styles
const kbdStyle: React.CSSProperties = {
  background: 'white',
  border: '1px solid #cbd5e1',
  borderRadius: '4px',
  padding: '2px 6px',
  fontSize: '0.7rem',
  fontFamily: 'monospace',
  fontWeight: 600,
  color: '#334155',
  boxShadow: '0 1px 2px rgba(0,0,0,0.1)'
};

const kbdStyleDark: React.CSSProperties = {
  background: '#334155',
  border: '1px solid #475569',
  borderRadius: '4px',
  padding: '2px 6px',
  fontSize: '0.7rem',
  fontFamily: 'monospace',
  fontWeight: 600,
  color: '#e2e8f0',
  boxShadow: '0 1px 3px rgba(0,0,0,0.3)'
};

export default TriggerJobModal;
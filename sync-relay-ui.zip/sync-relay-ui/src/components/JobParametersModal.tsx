import React, { useEffect, useState } from 'react';
import { X, Info, Loader } from 'lucide-react';
import batchApiService from '../services/batchApiService';
import '../styles/JobParametersModal.css';

interface JobParameter {
  key: string;
  value: string;
  type?: string;
}

interface JobParametersModalProps {
  isOpen: boolean;
  onClose: () => void;
  instanceId: number;
  jobName?: string;
}

const JobParametersModal: React.FC<JobParametersModalProps> = ({
  isOpen,
  onClose,
  instanceId,
  jobName
}) => {
  const [parameters, setParameters] = useState<JobParameter[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && instanceId) {
      fetchJobParameters();
    }
  }, [isOpen, instanceId]);

  const fetchJobParameters = async () => {
    try {
      setLoading(true);
      setError(null);

      // Call your backend API to get job parameters
      const params = await batchApiService.getJobParameters(instanceId);

      // Convert object to array format for display
      const paramArray = Object.entries(params).map(([key, value]) => ({
        key,
        value: String(value),
        type: typeof value
      }));

      setParameters(paramArray);
    } catch (err) {
      console.error('Failed to fetch job parameters:', err);
      setError('Failed to load job parameters');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-container" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div className="modal-title-section">
            <Info size={24} />
            <div>
              <h2 className="modal-title">Job Parameters</h2>
              {jobName && <p className="modal-subtitle">Instance #{instanceId} - {jobName}</p>}
            </div>
          </div>
          <button className="modal-close-btn" onClick={onClose}>
            <X size={20} />
          </button>
        </div>

        <div className="modal-body">
          {loading ? (
            <div className="modal-loading">
              <Loader size={32} className="spinning" />
              <p>Loading parameters...</p>
            </div>
          ) : error ? (
            <div className="modal-error">
              <p>{error}</p>
              <button className="btn-modern btn-primary" onClick={fetchJobParameters}>
                Retry
              </button>
            </div>
          ) : parameters.length === 0 ? (
            <div className="modal-empty">
              <Info size={48} />
              <p>No parameters found for this job instance</p>
            </div>
          ) : (
            <div className="parameters-grid">
              <div className="parameters-header">
                <div className="param-column">Parameter Name</div>
                <div className="param-column">Value</div>
                <div className="param-column param-type">Type</div>
              </div>
              <div className="parameters-body">
                {parameters.map((param, index) => (
                  <div key={index} className="parameter-row">
                    <div className="param-cell param-name">
                      <strong>{param.key}</strong>
                    </div>
                    <div className="param-cell param-value">
                      <code>{param.value}</code>
                    </div>
                    <div className="param-cell param-type">
                      <span className="type-badge">{param.type}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="modal-footer">
          <button className="btn-modern btn-secondary" onClick={onClose}>
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default JobParametersModal;


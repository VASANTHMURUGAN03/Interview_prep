// src/components/StepCard.tsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, XCircle, Clock, AlertCircle, ChevronDown, ChevronUp, RefreshCw, Download, FileDown, Eye } from 'lucide-react';
import StatusBadge from './StatusBadge';
import BatchSummaryModal from './BatchSummaryModal';
import { Step } from '../types/batch.types';
import batchApiService, { BatchSummaryDTO } from '../services/batchApiService';

interface StepCardProps {
  executionId: number;
  step: Step;
  jobId?: number;
  onNavigateToInstance: (instanceId: number) => void;
  onRetryFailedBatches: () => void;
  highlightedSummaryId?: string | null;
  refreshTrigger?: number; // NEW: Add refresh trigger prop
}

const StepCard: React.FC<StepCardProps> = ({ 
  executionId,
  jobId,
  step, 
  onRetryFailedBatches,
  highlightedSummaryId,
  refreshTrigger // NEW: Receive refresh trigger
}) => {
  const navigate = useNavigate();
  const [expanded, setExpanded] = useState(false);
  const [downloadingAll, setDownloadingAll] = useState(false);
  const [downloadingSummaries, setDownloadingSummaries] = useState<Set<string>>(new Set());
  
  // Batch summaries state
  const [batchSummaries, setBatchSummaries] = useState<BatchSummaryDTO[]>([]);
  const [loadingSummaries, setLoadingSummaries] = useState(false);
  const [summariesPage, setSummariesPage] = useState(0);
  const [summariesTotalPages, setSummariesTotalPages] = useState(0);
  const [summariesTotalElements, setSummariesTotalElements] = useState(0);

  // Modal state for viewing batch details
  const [modalState, setModalState] = useState<{
    isOpen: boolean;
    summaryId: string | null;
    data: any;
    loading: boolean;
    error: string | null;
  }>({
    isOpen: false,
    summaryId: null,
    data: null,
    loading: false,
    error: null
  });

  // Auto-expand if this step contains the highlighted summary
  useEffect(() => {
    if (highlightedSummaryId && step.summaries) {
      const hasHighlightedSummary = step.summaries.some(
        summary => summary.summaryId === highlightedSummaryId
      );
      if (hasHighlightedSummary) {
        setExpanded(true);
      }
    }
  }, [highlightedSummaryId, step.summaries]);

  // Fetch batch summaries when expanded
  useEffect(() => {
    if (expanded && batchSummaries.length === 0) {
      fetchBatchSummaries(0);
    }
  }, [expanded]);

  // NEW: Refresh batch summaries when refreshTrigger changes
  useEffect(() => {
    if (refreshTrigger && expanded) {
      fetchBatchSummaries(summariesPage);
    }
  }, [refreshTrigger]);

 const fetchBatchSummaries = async (page: number) => {
  try {
    setLoadingSummaries(true);
    const response = await batchApiService.getBatchSummaryByExecutionStep(
      executionId.toString(),
      page,
      10
    );

    // Deep clone response content
    let batchResponse = JSON.parse(JSON.stringify(response.content));

    // Transform status if needed
    batchResponse = batchResponse.map((item: any) => {
       const failureCount = item.jobInfoResponse?.numberRecordsFailed ?? 0;
      if (
        item.status === "COMPLETED" &&
        item.jobInfoResponse?.numberRecordsFailed > 0
      ) {
        return {
          ...item,
          status: "PARTIAL_FAILURE",
          failureCount,
           // override status
        };
      }
      return {
    ...item,
    failureCount,
  };
    });

    // Collect client IDs if needed
    let getAllclientIds = batchResponse.map((data: any) => data.clientIdentifier);

    console.log("updatedBatchResponse", batchResponse);
    console.log("test", response.content, getAllclientIds);

    setBatchSummaries(batchResponse);
    setSummariesPage(page);
    setSummariesTotalPages(response.totalPages);
    setSummariesTotalElements(response.totalElements);
  } catch (error) {
    console.error("Failed to fetch batch summaries:", error);
  } finally {
    setLoadingSummaries(false);
  }
};


  const handleNextPage = () => {
    if (summariesPage + 1 < summariesTotalPages) {
      fetchBatchSummaries(summariesPage + 1);
    }
  };

  const handlePreviousPage = () => {
    if (summariesPage > 0) {
      fetchBatchSummaries(summariesPage - 1);
    }
  };

  const getStepIcon = (status?: string) => {
    switch (status?.toUpperCase()) {
      case 'COMPLETED':
        return <CheckCircle size={20} className="text-green-600" />;
      case 'FAILED':
        return <XCircle size={20} className="text-red-600" />;
      case 'RUNNING':
        return <Clock size={20} className="text-blue-600" />;
      default:
        return <AlertCircle size={20} className="text-gray-400" />;
    }
  };

  const hasFailedSummaries = step.summaries?.some(
    s => s.status === 'FAILED'
  );

  const hasSummaries = step.summaries && step.summaries.length > 0;

  const isSummaryHighlighted = (summaryId: string) => {
    return highlightedSummaryId && summaryId === highlightedSummaryId;
  };

  const handleViewRelatedRetries = () => {
    navigate(`/executions/${executionId}/related-retries`, {
      state: {
        stepName: step.name,
        executionId: executionId,
        jobId: jobId
      }
    });
  };

  const handleDownloadAll = async () => {
    if (!step.summaries || step.summaries.length === 0) {
      alert('No summaries available to download');
      return;
    }

    try {
      setDownloadingAll(true);

      const blob = await batchApiService.downloadAllSummaries(
        step.id, 
        step.name, 
        executionId.toString()
      );

      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${step.name}_all_batches_${Date.now()}.xlsx`;

      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to download summaries:', error);
      alert('Failed to download summaries. Please try again.');
    } finally {
      setDownloadingAll(false);
    }
  };

  const handleDownloadSummary = async (summaryId: string, summaryIndex: number) => {
    try {
      setDownloadingSummaries(prev => new Set(prev).add(summaryId));

      const { blob, filename } = await batchApiService.downloadSummary(summaryId);

      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;

      const downloadFilename = filename || `${step.name}_batch_${summaryIndex + 1}_${summaryId}.xlsx`;
      link.download = downloadFilename;

      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

    } catch (error) {
      console.error(`Failed to download batch ${summaryId}:`, error);
      alert('Failed to download batch. Please try again.');
    } finally {
      setDownloadingSummaries(prev => {
        const newSet = new Set(prev);
        newSet.delete(summaryId);
        return newSet;
      });
    }
  };

 const [currentPage, setCurrentPage] = useState(0);
const [totalPages, setTotalPages] = useState(1);

const handleViewBatchSummaryStatus = async (summaryId: string, page: number = currentPage) => {
  setModalState({
    isOpen: true,
    summaryId,
    data: null,
    loading: true,
    error: null
  });

  try {
    const payloadData = { reasonRequired: true, jobIds: [summaryId] };

    // use dynamic page
    const response = await batchApiService.getFailureDetails(payloadData, { page, size: 20 });
     
    // format response
    const formatted = JSON.stringify(response, null, 2);

    setModalState(prev => ({
      ...prev,
      data: response,
      loading: false
    }));

    setCurrentPage(page);
   setTotalPages(response.totalPages && response.totalPages > 0 ? response.totalPages : 1);
 // if API returns totalPages
  } catch (error) {
    setModalState(prev => ({
      ...prev,
      loading: false,
      error: error instanceof Error ? error.message : 'Failed to fetch batch details.'
    }));
  }
};


  const closeModal = () => {
    setModalState({
      isOpen: false,
      summaryId: null,
      data: null,
      loading: false,
      error: null
    });
  };

  return (
    <>
      <div className="modern-card" style={{ marginBottom: '1rem' }}>
        {/* Step Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            {getStepIcon(step.status)}
            <h3 style={{ fontSize: '1.125rem', fontWeight: 600, color: '#111827', margin: 0 }}>
              {step.name}
            </h3>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            {step.status && <StatusBadge status={step.status} />}

            {/* Download All Button */}
            {hasSummaries && (
              <button
                className="btn-modern btn-secondary"
                onClick={handleDownloadAll}
                disabled={downloadingAll}
                style={{
                  fontSize: '0.875rem',
                  padding: '0.5rem 1rem',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem'
                }}
                title="Download all batches for this step"
              >
                <FileDown size={16} />
                {downloadingAll ? 'Downloading...' : 'Download All'}
              </button>
            )}
          </div>
        </div>

        {/* Horizontal Step Details Row */}
        <div className="step-details-horizontal" style={{ marginBottom: hasSummaries ? '1rem' : '0' }}>
          <div className="step-detail-item">
            <span className="step-detail-label">Start:</span>
            <span className="step-detail-value">{step.startTime}</span>
          </div>
          
          <div className="step-detail-separator">|</div>
          
          <div className="step-detail-item">
            <span className="step-detail-label">End:</span>
            <span className="step-detail-value">{step.endTime}</span>
          </div>

          {step.readCount !== undefined && (
            <>
              <div className="step-detail-separator">|</div>
              <div className="step-detail-item">
                <span className="step-detail-label">Read:</span>
                <span className="step-detail-value">{step.readCount}</span>
              </div>
            </>
          )}

          {step.writeCount !== undefined && (
            <>
              <div className="step-detail-separator">|</div>
              <div className="step-detail-item">
                <span className="step-detail-label">Write:</span>
                <span className="step-detail-value">{step.writeCount}</span>
              </div>
            </>
          )}

          {step.salesforceJobId && (
            <>
              <div className="step-detail-separator">|</div>
              <div className="step-detail-item">
                <span className="step-detail-label">SF Job ID:</span>
                <span className="step-detail-value">{step.salesforceJobId}</span>
              </div>
            </>
          )}
        </div>

        {hasSummaries && (
          <>
            <div style={{ 
              borderTop: '1px solid #e5e7eb', 
              paddingTop: '1rem',
              marginBottom: '1rem'
            }}>
              <button
                onClick={() => setExpanded(!expanded)}
                style={{
                  width: '100%',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  padding: '0.5rem 0',
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  fontSize: '0.875rem',
                  fontWeight: 600,
                  color: '#374151'
                }}
              >
                <span>
                  Batch Summary Details ({summariesTotalElements || step.summaries!.length} batches)
                  {loadingSummaries && ' - Loading...'}
                </span>
                {expanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
              </button>

              {expanded && (
                <div style={{ marginTop: '1rem', overflowX: 'auto' }}>
                  {loadingSummaries && batchSummaries.length === 0 ? (
                    <div style={{ textAlign: 'center', padding: '2rem', color: '#6b7280' }}>
                      <div className="loading-spinner" style={{ margin: '0 auto 1rem' }}></div>
                      Loading batch summaries...
                    </div>
                  ) : (
                    <>
                      <table style={{ width: '100%', fontSize: '0.875rem', minWidth: '900px' }}>
                        <thead>
                          <tr style={{ borderBottom: '1px solid #e5e7eb' }}>
                            <th style={{ textAlign: 'left', padding: '0.5rem', fontWeight: 600, color: '#6b7280' }}>
                              Batch #
                            </th>
                            <th style={{ textAlign: 'left', padding: '0.5rem', fontWeight: 600, color: '#6b7280' }}>
                              Batch ID
                            </th>
                            <th style={{ textAlign: 'left', padding: '0.5rem', fontWeight: 600, color: '#6b7280' }}>
                              Range
                            </th>
                            <th style={{ textAlign: 'center', padding: '0.5rem', fontWeight: 600, color: '#6b7280' }}>
                              Status
                            </th>
                            <th style={{ textAlign: 'center', padding: '0.5rem', fontWeight: 600, color: '#6b7280' }}>
                              Failed Count
                            </th>
                            <th style={{ textAlign: 'center', padding: '0.5rem', fontWeight: 600, color: '#6b7280' }}>
                              Items Read
                            </th>
                            <th style={{ textAlign: 'center', padding: '0.5rem', fontWeight: 600, color: '#6b7280' }}>
                              Written %
                            </th>
                            <th style={{ textAlign: 'center', padding: '0.5rem', fontWeight: 600, color: '#6b7280', width: '120px' }}>
                              Actions
                            </th>
                          </tr>
                        </thead>
                        <tbody>

                          {batchSummaries.map((summary, index) => {
                            const isHighlighted = isSummaryHighlighted(summary.summaryId);
                            const isDownloading = downloadingSummaries.has(summary.summaryId);

                            return (
                              <tr
                                key={summary.summaryId}
                                id={`summary-${summary.summaryId}`}
                                className={isHighlighted ? 'summary-highlighted' : ''}
                                style={{
                                  borderBottom: '1px solid #f3f4f6',
                                  backgroundColor: isHighlighted ? '#fef3c7' : 'transparent',
                                  position: 'relative',
                                  transition: 'all 0.3s ease'
                                }}
                              >
                                <td style={{ padding: '0.75rem 0.5rem', position: 'relative' }}>
                                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', position: 'relative' }}>
                                    <span style={{ fontWeight: isHighlighted ? 600 : 400, color: isHighlighted ? '#78350f' : 'inherit' }}>
                                      #{(summariesPage * 10) + index + 1}
                                    </span>
                                  </div>
                                </td>

                                <td style={{ padding: '0.75rem 0.5rem', fontSize: '0.75rem', color: '#6b7280', fontWeight: isHighlighted ? 600 : 400 }}>
                                  {summary.summaryId}
                                </td>

                                <td style={{ padding: '0.75rem 0.5rem', fontWeight: isHighlighted ? 600 : 400 }}>
                                  {summary.requestedStartIndex} - {summary.requestedEndIndex}
                                </td>

                                <td style={{ padding: '0.75rem 0.5rem', textAlign: 'center' }}>
                                  <StatusBadge status={summary.status} />
                                </td>
                                <td style={{ padding: '0.75rem 0.5rem', fontWeight: isHighlighted ? 600 : 400,textAlign: 'center' }}>
                                   {summary.failureCount}
                                </td>

                                <td style={{ padding: '0.75rem 0.5rem', textAlign: 'center', fontWeight: isHighlighted ? 600 : 400 }}>
                                  {summary.totalReadItems}
                                </td>

                                <td style={{ padding: '0.75rem 0.5rem', textAlign: 'center', fontWeight: isHighlighted ? 600 : 400 }}>
                                  <span style={{
                                    padding: '0.25rem 0.625rem',
                                    borderRadius: '0.375rem',
                                    fontSize: '0.875rem',
                                    fontWeight: 600,
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    gap: '0.25rem',
                                    minWidth: '65px',
                                    justifyContent: 'center',
                                    backgroundColor: (summary.writtenPerentage ?? 0) < 100 ? '#fee2e2' : '#d1fae5',
                                    color: (summary.writtenPerentage ?? 0) < 100 ? '#991b1b' : '#065f46',
                                    border: (summary.writtenPerentage ?? 0) < 100 ? '1px solid #fecaca' : '1px solid #86efac'
                                  }}>
                                    {summary.writtenPerentage ?? 0}%
                                    {(summary.writtenPerentage ?? 0) < 100 && (
                                      <span style={{ fontSize: '0.75rem' }}>⚠️</span>
                                    )}
                                  </span>
                                </td>

                                <td style={{ padding: '0.75rem 0.5rem', textAlign: 'center' }}>
                                  <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'center' }}>
                                    {/* Download Button */}
                                    <button
                                      className="btn-modern btn-icon-only"
                                      onClick={() => handleDownloadSummary(summary.summaryId, index)}
                                      disabled={isDownloading}
                                      title="Download this batch"
                                      style={{
                                        padding: '0.375rem',
                                        background: isDownloading ? '#e5e7eb' : 'transparent',
                                        border: '1px solid #d1d5db',
                                        color: isDownloading ? '#9ca3af' : '#667eea',
                                        cursor: isDownloading ? 'not-allowed' : 'pointer'
                                      }}
                                    >
                                      {isDownloading ? (
                                        <div className="loading-spinner-small"></div>
                                      ) : (
                                        <Download size={16} />
                                      )}
                                    </button>

                                    {/* View Batch Status Button */}
                                    <button
                                      className="btn-modern btn-icon-only"
                                      onClick={() => handleViewBatchSummaryStatus(summary.clientIdentifier)}
                                      title="View batch details"
                                      style={{
                                        padding: '0.375rem',
                                        background: 'transparent',
                                        border: '1px solid #d1d5db',
                                        color: '#10b981',
                                        cursor: 'pointer'
                                      }}
                                    >
                                      <Eye size={16} />
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>

                      {/* Pagination Controls */}
                      {summariesTotalPages > 1 && (
                        <div style={{ 
                          display: 'flex', 
                          justifyContent: 'space-between', 
                          alignItems: 'center',
                          marginTop: '1rem',
                          padding: '0.75rem',
                          borderTop: '1px solid #e5e7eb'
                        }}>
                          <button
                            className="btn-modern btn-secondary"
                            onClick={handlePreviousPage}
                            disabled={summariesPage === 0 || loadingSummaries}
                            style={{
                              padding: '0.5rem 1rem',
                              fontSize: '0.875rem',
                              opacity: summariesPage === 0 ? 0.5 : 1
                            }}
                          >
                            Previous
                          </button>

                          <span style={{ fontSize: '0.875rem', color: '#6b7280' }}>
                            Page {summariesPage + 1} of {summariesTotalPages} 
                            <span style={{ margin: '0 0.5rem' }}>•</span>
                            Showing {batchSummaries.length} of {summariesTotalElements} batches
                          </span>

                          <button
                            className="btn-modern btn-secondary"
                            onClick={handleNextPage}
                            disabled={summariesPage + 1 >= summariesTotalPages || loadingSummaries}
                            style={{
                              padding: '0.5rem 1rem',
                              fontSize: '0.875rem',
                              opacity: summariesPage + 1 >= summariesTotalPages ? 0.5 : 1
                            }}
                          >
                            Next
                          </button>
                        </div>
                      )}
                    </>
                  )}
                </div>
              )}
            </div>

            {hasFailedSummaries && (
              <div style={{ marginTop: '1rem', display: 'flex', justifyContent: 'flex-end', gap: '0.5rem' }}>
                <button
                  className="btn-modern btn-secondary"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleViewRelatedRetries();
                  }}
                  style={{ fontSize: '0.875rem' }}
                >
                  <Eye size={14} />
                  View Related Retries
                </button>

                <button
                  className="btn-modern btn-warning-gradient"
                  onClick={(e) => {
                    e.stopPropagation();
                    onRetryFailedBatches();
                  }}
                  style={{ fontSize: '0.875rem' }}
                >
                  <RefreshCw size={14} />
                  Retry Failed Batches
                </button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Batch Summary Modal */}
      <BatchSummaryModal
        isOpen={modalState.isOpen}
        onClose={closeModal}
        data={modalState.data}
        loading={modalState.loading}
        error={modalState.error}
        summaryId={modalState.summaryId || ''}
        totalPages={totalPages}
        onPageChange={(page)=>handleViewBatchSummaryStatus(modalState.summaryId!, page)}
      />
    </>
  );
};

export default StepCard;
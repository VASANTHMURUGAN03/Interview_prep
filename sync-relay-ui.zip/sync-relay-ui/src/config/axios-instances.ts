// src/config/axios-instances.ts
import axios from 'axios';
import Cookies from 'js-cookie';

const API_BASE_URL = process.env.REACT_APP_SYNC_RELAY_BFF_BASE_URL;

const getPath = () => ('/');
const getDomain = () => (window.location.hostname === 'localhost' ? 'localhost' : '.star-app.in');

const clearCookies = () => {
  const path = getPath();
  const domain = getDomain();
  const cookieKeys = [
    'employee_accessToken',
    'employee_accessTokenExpiry',
    'employee_channelName',
    'employee_refreshToken',
    'employee_refreshTokenExpiry',
    'employee_userProfile'
  ];
  cookieKeys.forEach(key => Cookies.remove(key, { path, domain }));
};

// Create Axios instance
export const axiosBatch = axios.create({
  baseURL: API_BASE_URL ||'https://sit-shapi.starhealth.in/sync-relay-bff/ext/api',
  timeout: 60000
});

// Request Interceptor
axiosBatch.interceptors.request.use(
  (config) => {
    const token = Cookies.get('employee_accessToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    if (process.env.NODE_ENV === 'development') {
      console.log('Request:', config.method?.toUpperCase(), config.url);
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response Interceptor
axiosBatch.interceptors.response.use(
  (response) => {
    if (process.env.NODE_ENV === 'development') {
      console.log('Response:', response.status, response.config.url);
    }
    return response;
  },
  (error) => {
    const status = error?.response?.status;
    if (status === 401) {
      clearCookies();
      window.location.href = '/sso/login';}
    //   else if (error.message === 'Network Error') {
    //   window.location.href = '/network-error';
    // }
    return Promise.reject(error);
  }
);


export const axiosBatchSearch = axios.create({
  baseURL: API_BASE_URL,
  timeout: 60000
});

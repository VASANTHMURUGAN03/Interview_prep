// src/services/batchApiService.ts

import { axiosBatch } from '../config/axios-instances';
import { Job, JobInstance, ExecutionDetail, PageResponse } from '../types/batch.types';
export type { Job } from '../types/batch.types';

export interface DashboardStats {
  totalJobs: number;
  activeJobs: number;
  successRate: number;
  totalFailed: number;
  runningNow: number;
  totalSuccess: number;
}


// Migration Search Types
export interface ReaderDetails {
  readTimestamp: string;
  batchStartOffset: number;
  batchEndOffset: number;
  recordOffset: number;
  apiEndpoint: string | null;
  sqlQuery: string | null;
  readDurationMs: number;
  rawData: Record<string, any>;
  metadata: Record<string, any>;
}

export interface ProcessorDetails {
  processTimestamp: string;
  processDurationMs: number;
  originalData: Record<string, any>;
  transformedData: Record<string, any>;
  transformationsApplied: string[];
  validationResults: Record<string, any>;
  metadata: Record<string, any>;
}

export interface WriterDetails {
  id: string;
  itemWriterTrackId: string;
  clientUniqueKey: string;
  clientStatus: string;
  status: string;
  apiDetail: {
    requestPayload: string;
    responsePayload: string;
    apiEndpoint: string;
    apiMethod: string;
    httpStatusCode: number;
  };
  groupDetail: {
    groupKey: string;
  } | null;
  errorMessage: string | null;
  errorStackTrace: string | null;
  metadata: any | null;
  duration: number;
}

export interface MigrationRecord {
  jobId: string;
  jobExecutionId: string;
  batchId: string;
  itemStatus: string;
  readTime: string;
  processTime: string | null;
  errorStage: string | null;
  errorMessage: string | null;
  errorStackTrace: string | null;
  readerDetails: ReaderDetails;
  processorDetails: ProcessorDetails | null;
  writerDetails: WriterDetails | null;
}

// Backend DTO interfaces (to match your Spring Boot DTOs)
interface DashboardStatsDTO {
  totalJobs: number;
  activeJobs: number;
  successRate: number;
  totalFailed: number;
  runningNow: number;
  totalSuccess: number;
}

export interface BatchSummaryDTO {
  summaryId: string;
  batchId: string;
  status: string;
  requestedStartIndex: number;
  requestedEndIndex: number;
  requestedPageSize: number;
  totalReadItems: number;
  readStartTime: string;
  readEndTime: string;
  processStartTime: string;
  processEndTime: string;
  writeStartTime: string;
  writeEndTime: string;
  readDurationMs: number;
  processDurationMs: number;
  writeDurationMs: number;
  writtenRecord: number;
  writtenPerentage: number; // Note: Typo in property name matches backend
  clientIdentifier: string;
  failureCount: number;

}


// const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;

class BatchApiService {
  private axiosInstance =  axiosBatch;

  // Dashboard APIs
  async getDashboardStats(timeFilter: string = 'LAST_24_HOURS', jobName?: string): Promise<DashboardStats> {
    try {
      const params: any = { timeFilter };
      if (jobName) {
        params.jobName = jobName;
      }

      const response = await this.axiosInstance.get<DashboardStatsDTO>(
        '/dashboard/stats',
        { params }
      );
      
      return {
        totalJobs: response.data.totalJobs,
        activeJobs: response.data.activeJobs,
        successRate: response.data.successRate,
        totalFailed: response.data.totalFailed,
        runningNow: response.data.runningNow,
        totalSuccess: response.data.totalSuccess
      };
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      throw new Error('Failed to fetch dashboard statistics');
    }
  }

  // Jobs APIs
  async getAllJobs(): Promise<Job[]> {
    try {
      const response = await this.axiosInstance.get<Job[]>('/batch/jobs');
      return response.data;
    } catch (error) {
      console.error('Error fetching jobs:', error);
      throw new Error('Failed to fetch jobs');
    }
  }

  // Job Instances APIs
  async getJobInstances(
    jobName: string,
    fromDate?: string,
    toDate?: string,
    status?: string,
    triggeredBy?: string,
    page: number = 0,
    size: number = 10
  ): Promise<PageResponse<JobInstance>> {
    try {
      const params: any = { page, size };
      if (fromDate) params.fromDate = fromDate;
      if (toDate) params.toDate = toDate;
      if (status) params.status = status;
      if (triggeredBy) params.triggeredBy = triggeredBy;
      const response = await this.axiosInstance.get<PageResponse<JobInstance>>(
        `/batch/jobs/${encodeURIComponent(jobName)}/instances`,
        { params }
      );
      return response.data;
    } catch (error) {
      console.error(`Error fetching instances for job ${jobName}:`, error);
      throw new Error(`Failed to fetch job instances`);
    }
  }

  // Execution APIs
  async getExecutionDetail(instanceId: number): Promise<ExecutionDetail> {
    try {
      const response = await this.axiosInstance.get<ExecutionDetail>(
        `/batch/instances/${instanceId}/execution`
      );
      return response.data;
    } catch (error) {
      console.error(`Error fetching execution detail for instance ${instanceId}:`, error);
      throw new Error('Failed to fetch execution detail');
    }
  }

  // Stop and Resume APIs
  async stopJobInstance(jobInstanceId: number): Promise<string> {
    try {
      const response = await this.axiosInstance.get<string>(
        `/batch/instances/stop/${jobInstanceId}`
      );
      return response.data;
    } catch (error) {
      console.error(`Error stopping job instance ${jobInstanceId}:`, error);
      throw new Error('Failed to stop job instance');
    }
  }

  async resumeJobInstance(jobInstanceId: number): Promise<string> {
    try {
      const response = await this.axiosInstance.get<string>(
        `/batch/instances/start/${jobInstanceId}`
      );
      return response.data;
    } catch (error) {
      console.error(`Error resuming job instance ${jobInstanceId}:`, error);
      throw new Error('Failed to resume job instance');
    }
  }

  async getJobParameters(instanceId: number): Promise<Record<string, any>> {
    try {
      const response = await this.axiosInstance.get(`/batch/instances/${instanceId}/parameters`);
      return response.data;
    } catch (error) {
      console.error('Error fetching job parameters:', error);
      throw new Error('Failed to fetch job parameters');
    }
  }

  async getRelatedRetries(
    executionId: number,
    page: number = 0,
    size: number = 10
  ): Promise<PageResponse<JobInstance>> {
    try {
      const params: any = { page, size };
      const response = await this.axiosInstance.get<PageResponse<JobInstance>>(
        `/batch/execution/${executionId}/related-retries`,
        { params }
      );
      return response.data;
    } catch (error) {
      console.error(`Error fetching related retries for execution ${executionId}:`, error);
      throw new Error('Failed to fetch related retry instances');
    }
  }

  // Download APIs
  async downloadAllSummaries(stepId: string, stepName: string, executionId: string): Promise<Blob> {
    try {
      const response = await this.axiosInstance.get(
        `/chunks/download/all`,
        {
          params: { stepName, executionId },
          responseType: 'blob'
        }
      );
      return response.data;
    } catch (error) {
      console.error(`Error downloading all summaries for step ${stepId}:`, error);
      throw new Error('Failed to download summaries');
    }
  }

  async downloadSummary(summaryId: string): Promise<{ blob: Blob; filename?: string }> {
    try {
      const response = await this.axiosInstance.get(
        `/chunks/download/${summaryId}`,
        { responseType: 'blob' }
      );
      
      // Extract filename from Content-Disposition header if available
      const contentDisposition = response.headers['content-disposition'];
      let filename: string | undefined;
      
      if (contentDisposition) {
        const filenameMatch = contentDisposition.match(/filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/);
        if (filenameMatch && filenameMatch[1]) {
          filename = filenameMatch[1].replace(/['"]/g, '');
        }
      }
      
      return { blob: response.data, filename };
    } catch (error) {
      console.error(`Error downloading summary ${summaryId}:`, error);
      throw new Error('Failed to download summary');
    }
  }

  // Migration Search APIs
  async searchMigrationRecords(jobName: string, searchValue: string): Promise<MigrationRecord[]> {
    try {
      const params = {
        jobName,
        q: searchValue.trim()
      };

      console.log('Search URL:', `/support/records/search?${new URLSearchParams(params).toString()}`);

      const response = await this.axiosInstance.get<MigrationRecord[]>(
        '/support/records/search',
        { params }
      );

      return Array.isArray(response.data) ? response.data : [];
    } catch (error) {
      console.error('Error searching migration records:', error);
      throw new Error('Failed to search migration records');
    }
  }

  // Trigger Job API
  async triggerJobLatest(payload: { 
    jobName: string; 
    jobParams: Record<string, any>;
    retryConfig?: {
      childInstance: boolean;
      parentJobInstance?: string;
      parentExecutionId?: string;
    };
  }): Promise<any> {
    try {
      const response = await this.axiosInstance.post('/batch/start', payload);
      return response.data;
    } catch (error) {
      console.error('Error triggering job:', error);
      throw new Error('Failed to trigger job');
    }
  }

  async getBatchSummaryByExecutionStep(
    executionId: string,
    page: number = 0,
    size: number = 10
  ): Promise<PageResponse<BatchSummaryDTO>> {
    try {
      const response = await this.axiosInstance.get<PageResponse<BatchSummaryDTO>>(
        `/batch/execution/${executionId}/batch-summary`,
        {
          params: { page, size }
        }
      );
      return response.data;
    } catch (error) {
      console.error(`Error fetching batch summaries for execution ${executionId}:`, error);
      throw new Error('Failed to fetch batch summaries');
    }
  }


  // async getFailureAnd

  async getBatchSummaryStatusDetails(jobId: string): Promise<Object> {
    try{ // Real call returning string:
      const response = await this.axiosInstance.get(`/batch/job-status/${jobId}`);
      return JSON.stringify(response.data);
    } catch (error) {
      console.error('Error fetching batch summary details:', error);
      return "Service not avaialable."
    }
  }

 async getFailureDetails(payload: object,params?: { page?: number; size?: number }): Promise<any> {
  try {
    const response = await this.axiosInstance.post( '/batch/job-status',
      payload,
      {
        params: {
          page: params?.page ?? 0,
          size: params?.size ?? 10,
        },
      }
    );
return response.data;
  } catch (error) {
    console.error('Error getting failure job count:', error);
    throw new Error('Failed to get failure job reason');
  }
}

}

const batchApiService = new BatchApiService();
export default batchApiService;
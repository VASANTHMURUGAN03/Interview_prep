// src/pages/JobInstancesPage.tsx
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { ChevronRight, ChevronLeft, ChevronsLeft, ChevronsRight, Layers, Calendar, Play, AlertCircle, Filter, Square, PlayCircle, X, RefreshCw, Clock, Info } from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import { Job, JobInstance, PageResponse } from '../types/batch.types';
import batchApiService from '../services/batchApiService';
import '../styles/JobInstancesPage.css';
import JobParametersModal from '../components/JobParametersModal';

const Notification: React.FC<{ message: string; type: 'success' | 'error'; onClose: () => void }> = ({ 
  message, 
  type, 
  onClose 
}) => {
  useEffect(() => {
    const timer = setTimeout(onClose, 2000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className={`notification ${type}`}>
      <div className="notification-content">
        <span>{message}</span>
        <button onClick={onClose} className="notification-close">
          <X size={16} />
        </button>
      </div>
    </div>
  );
};

const JobInstancesPage: React.FC = () => {
  const navigate = useNavigate();
  const { jobId } = useParams<{ jobId: string }>();
  const location = useLocation();
  
  // Extract jobName directly from location state
  const jobName = location.state?.jobName as string;
  const job = location.state?.job as Job | undefined;
  
  // State declarations - ALL HOOKS MUST BE CALLED BEFORE ANY CONDITIONAL RETURNS
  const [instances, setInstances] = useState<PageResponse<JobInstance> | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [tableLoading, setTableLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedInstanceForParams, setSelectedInstanceForParams] = useState<number | null>(null);
  const [triggeredByFilter, setTriggeredByFilter] = useState<string>('');
  
  const [currentPage, setCurrentPage] = useState<number>(0);
  const [itemsPerPage] = useState<number>(10);
  const [initialLoadComplete, setInitialLoadComplete] = useState<boolean>(false);
  
  // Set today's date by default - rounds up to next minute
  const getTodayDateTime = (): string => {
    const today = new Date();
    // Round up to next minute
    today.setMinutes(today.getMinutes() + 1);
    today.setSeconds(0);
    today.setMilliseconds(0);

    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    const hours = String(today.getHours()).padStart(2, '0');
    const minutes = String(today.getMinutes()).padStart(2, '0');
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  };

  const getOneWeekAgoDateTime = (): string => {
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    const year = oneWeekAgo.getFullYear();
    const month = String(oneWeekAgo.getMonth() + 1).padStart(2, '0');
    const day = String(oneWeekAgo.getDate()).padStart(2, '0');
    const hours = String(oneWeekAgo.getHours()).padStart(2, '0');
    const minutes = String(oneWeekAgo.getMinutes()).padStart(2, '0');
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  };

  const [fromDate, setFromDate] = useState<string>(getOneWeekAgoDateTime());
  const [toDate, setToDate] = useState<string>(getTodayDateTime());
  const [statusFilter, setStatusFilter] = useState<string>('');

  // Track currently applied filters
  const [appliedFilters, setAppliedFilters] = useState({
    fromDate: getOneWeekAgoDateTime(),
    toDate: getTodayDateTime(),
    statusFilter: '',
    triggeredByFilter: ''
  });

  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [autoRefreshEnabled, setAutoRefreshEnabled] = useState<boolean>(true);

  const statusOptions = [
    { value: '', label: 'All Statuses' },
    { value: 'ACTIVE', label: 'Active Jobs' },
    { value: 'COMPLETED', label: 'Completed' },
    { value: 'FAILED', label: 'Failed' },
    { value: 'RUNNING', label: 'Running' },
    { value: 'STOPPED', label: 'Stopped' }
  ];

  const triggeredByOptions = [
    { value: '', label: 'All Triggers' },
    { value: 'MANUAL', label: 'Manual' },
    { value: 'SCHEDULED', label: 'Scheduled' }
  ];

  const [actionLoading, setActionLoading] = useState<{ [key: number]: boolean }>({});

  // Fetch instances using jobName directly from state - MOVED BEFORE CONDITIONAL
  useEffect(() => {
    if (!jobName) return; // Early return if no jobName
    
    console.log('Fetching instances for job name from state:', jobName);
    fetchJobInstances(jobName).then(() => setInitialLoadComplete(true));
  }, [jobName]);

  // Pagination effect - triggers silent fetch on page change
  useEffect(() => {
    // Skip if no jobName or initial load not complete
    if (!jobName || !initialLoadComplete) return;
    
    fetchJobInstancesSilentlyForPagination(jobName);
  },[currentPage, initialLoadComplete, jobName]);

  // Auto-refresh effect - only refreshes table content
  useEffect(() => {
    if (!autoRefreshEnabled || !jobName) return;

    const intervalId = setInterval(async () => {
      console.log('Auto-refreshing job instances...');
      await fetchJobInstancesSilently(jobName);
    }, 5000);

    return () => {
      clearInterval(intervalId);
    };
  }, [autoRefreshEnabled, jobName, appliedFilters, currentPage]);

  // If jobName is not provided in state, redirect back or show error
  // This check must come AFTER all hooks are called
  if (!jobName) {
    console.error('Job name not provided in navigation state. Redirecting...');
    navigate('/jobs');
    return null; // Return null while redirecting
  }

  const showNotification = (message: string, type: 'success' | 'error' = 'success') => {
    setNotification({ message, type });
  };

  const handleResumeInstance = async (instanceId: number): Promise<void> => {
    setActionLoading(prev => ({ ...prev, [instanceId]: true }));
    
    console.log(`Calling resume API for instance: ${instanceId}`);
    showNotification('Resume request sent');
    
    try {
      await batchApiService.resumeJobInstance(instanceId);
      console.log(`Resume request completed for instance ${instanceId}`);
      
      await new Promise(resolve => setTimeout(resolve, 500));
      
      await fetchJobInstancesSilently(jobName);
    } catch (error) {
      console.error(`Resume API error for instance ${instanceId}:`, error);
      showNotification('Resume request failed', 'error');
    } finally {
      setActionLoading(prev => ({ ...prev, [instanceId]: false }));
    }
  };

  const handleStopInstance = async (instanceId: number): Promise<void> => {
    setActionLoading(prev => ({ ...prev, [instanceId]: true }));
    
    console.log(`Calling stop API for instance: ${instanceId}`);
    showNotification('Stop request sent');
    
    try {
      await batchApiService.stopJobInstance(instanceId);
      console.log(`Stop request completed for instance ${instanceId}`);
      
      await new Promise(resolve => setTimeout(resolve, 500));
      
      await fetchJobInstancesSilently(jobName);
    } catch (error) {
      console.error(`Stop API error for instance ${instanceId}:`, error);
      showNotification('Stop request failed', 'error');
    } finally {
      setActionLoading(prev => ({ ...prev, [instanceId]: false }));
    }
  };

  const fetchJobInstances = async (jobName: string): Promise<void> => {
    try {
      setLoading(true);
      setError(null);
      console.log('Fetching instances for job name:', jobName);
      const data = await batchApiService.getJobInstances(
        jobName,
        fromDate || undefined,
        toDate || undefined,
        statusFilter || undefined,
        triggeredByFilter || undefined,
        currentPage,
        itemsPerPage
      );
      console.log('Instances fetched:', data.totalElements);
      setInstances(data);

      // Set applied filters on initial load
      setAppliedFilters({
        fromDate,
        toDate,
        statusFilter,
        triggeredByFilter
      });
    } catch (error) {
      console.error('Failed to fetch job instances:', error);
      setError('Failed to load job instances. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Silent fetch for auto-refresh
  const fetchJobInstancesSilently = async (jobName: string): Promise<void> => {
    try {
      const data = await batchApiService.getJobInstances(
        jobName,
        appliedFilters.fromDate || undefined,
        appliedFilters.toDate || undefined,
        appliedFilters.statusFilter || undefined,
        appliedFilters.triggeredByFilter || undefined,
        currentPage,
        itemsPerPage
      );
      setInstances(data);
      
      setActionLoading(prev => {
        const updated = { ...prev };
        Object.keys(updated).forEach(instanceId => {
          const id = parseInt(instanceId);
          const instance = data.content.find((inst: JobInstance) => inst.id === id);
          if (instance) {
            const status = instance.lastStatus?.toUpperCase();
            if (status === 'RUNNING' || status === 'STARTED' ||
                status === 'COMPLETED' || status === 'STOPPED') {
              delete updated[id];
            }
          }
        });
        return updated;
      });
    } catch (error) {
      console.error('Failed to auto-refresh job instances:', error);
    }
  };

  // Silent fetch for pagination
  const fetchJobInstancesSilentlyForPagination = async (jobName: string): Promise<void> => {
    try {
      setTableLoading(true);
      const data = await batchApiService.getJobInstances(
        jobName,
        appliedFilters.fromDate || undefined,
        appliedFilters.toDate || undefined,
        appliedFilters.statusFilter || undefined,
        appliedFilters.triggeredByFilter || undefined,
        currentPage,
        itemsPerPage
      );
      setInstances(data);
    } catch (error) {
      console.error('Failed to fetch job instances for pagination:', error);
      setError('Failed to load page. Please try again.');
    } finally {
      setTableLoading(false);
    }
  };

  const handleFilter = async (): Promise<void> => {
    try {
      setTableLoading(true);
      setCurrentPage(0);
      setError(null);
      
      const data = await batchApiService.getJobInstances(
        jobName,
        fromDate || undefined,
        toDate || undefined,
        statusFilter || undefined,
        triggeredByFilter || undefined,
        0,
        itemsPerPage
      );

      setInstances(data);

      setAppliedFilters({
        fromDate,
        toDate,
        statusFilter,
        triggeredByFilter
      });
    } catch (error) {
      console.error('Failed to filter job instances:', error);
      setError('Failed to apply filters. Please try again.');
    } finally {
      setTableLoading(false);
    }
  };

  const clearFilters = async (): Promise<void> => {
    const defaultFromDate = getOneWeekAgoDateTime();
    const defaultToDate = getTodayDateTime();

    setFromDate(defaultFromDate);
    setToDate(defaultToDate);
    setStatusFilter('');
    setTriggeredByFilter('');
    setCurrentPage(0);

    try {
      setTableLoading(true);
      setError(null);
      const data = await batchApiService.getJobInstances(
        jobName,
        defaultFromDate,
        defaultToDate,
        undefined,
        undefined,
        0,
        itemsPerPage
      );
      setInstances(data);

      // Update applied filters after successful clear
      setAppliedFilters({
        fromDate: defaultFromDate,
        toDate: defaultToDate,
        statusFilter: '',
        triggeredByFilter: ''
      });
    } catch (error) {
      console.error('Failed to fetch job instances:', error);
      setError('Failed to clear filters. Please try again.');
    } finally {
      setTableLoading(false);
    }
  };

  const hasActiveFilters = (): boolean => {
    return appliedFilters.fromDate !== getOneWeekAgoDateTime() ||
           appliedFilters.toDate !== getTodayDateTime() ||
           !!appliedFilters.statusFilter ||
           !!appliedFilters.triggeredByFilter;
  };

  const hasFilterChanges = (): boolean => {
    return fromDate !== appliedFilters.fromDate ||
           toDate !== appliedFilters.toDate ||
           statusFilter !== appliedFilters.statusFilter ||
           triggeredByFilter !== appliedFilters.triggeredByFilter;
  };

  const handleInstanceClick = (instance: JobInstance): void => {
    navigate(`/jobs/${jobId}/instances/${instance.id}/execution`, {
      state: { instance, job, jobName }
    });
  };

  const formatDate = (dateString: string): string => {
    // API returns UTC time in format "2025-12-05 07:31:09"
    // Convert it to ISO format with Z to indicate UTC
    const normalized = dateString.includes('T') || dateString.endsWith('Z')
      ? dateString
      : dateString.replace(' ', 'T') + 'Z';

    const date = new Date(normalized);

    // Convert to IST (Asia/Kolkata timezone)
    const istDate = date.toLocaleString('en-IN', {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
    
    return istDate;
  };

  const getStatusIcon = (status: string) => {
    const displayStatus = status === 'STARTED' ? 'RUNNING' : status;
    
    switch (displayStatus) {
      case 'RUNNING':
        return <Play size={16} className="status-icon running" />;
      case 'COMPLETED':
        return <Play size={16} className="status-icon success" />;
      case 'FAILED':
        return <AlertCircle size={16} className="status-icon failed" />;
      case 'STOPPED':
        return <Square size={16} className="status-icon stopped" />;
      case 'PENDING_CALLBACK':
        return <Calendar size={16} className="status-icon pending" />;
      default:
        return <Calendar size={16} className="status-icon pending" />;
    }
  };

  const shouldShowStopButton = (status: string): boolean => {
    const normalizedStatus = status?.toUpperCase();
    return normalizedStatus === 'STARTED' || normalizedStatus === 'RUNNING';
  };

  const shouldShowResumeButton = (status: string): boolean => {
    const normalizedStatus = status?.toUpperCase();
    return normalizedStatus === 'STOPPED' || normalizedStatus === 'FAILED';
  };

  const totalPages = instances?.totalPages || 0;
  const currentInstances = instances?.content || [];
  const totalElements = instances?.totalElements || 0;

  const handlePageChange = (page: number): void => {
    if (page >= 0 && page < totalPages) {
      setCurrentPage(page);
    }
  };

  const getVisiblePages = (): number[] => {
    const pages: number[] = [];
    const maxVisiblePages = 5;
    
    if (totalPages <= maxVisiblePages) {
      return Array.from({ length: totalPages }, (_, i) => i);
    }
    
    let start = Math.max(0, currentPage - 2);
    let end = Math.min(totalPages - 1, start + maxVisiblePages - 1);
    
    if (end - start + 1 < maxVisiblePages) {
      start = Math.max(0, end - maxVisiblePages + 1);
    }
    
    for (let i = start; i <= end; i++) {
      pages.push(i);
    }
    
    return pages;
  };

  if (loading) {
    return (
      <div className="page-wrapper">
        <div className="page-container">
          <div className="page-header">
            <h1 className="page-title">
              Loading Instances...
            </h1>
          </div>
          <div style={{ textAlign: 'center', padding: '2rem' }}>
            <div className="loading-spinner"></div>
            <p>
              Loading instances for {jobName}...
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (error && !loading && !tableLoading) {
    return (
      <div className="page-wrapper">
        <div className="page-container">
          <div className="page-header">
            <h1 className="page-title">
              Instances for {jobName}
            </h1>
            <div className="page-actions">
              <button
                className="btn-modern btn-ghost"
                onClick={() => navigate('/jobs')}
              >
                Back to Jobs
              </button>
            </div>
          </div>
          <div className="table-empty">
            <AlertCircle size={64} className="jobs-empty-icon" />
            <h3>{error}</h3>
            <div style={{ marginTop: '1rem', display: 'flex', gap: '0.5rem', justifyContent: 'center' }}>
              <button
                onClick={() => fetchJobInstances(jobName)}
                className="btn-modern btn-primary"
              >
                Retry
              </button>
              <button
                onClick={() => navigate('/jobs')}
                className="btn-modern btn-secondary"
              >
                Back to Jobs
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page-wrapper job-instances-page">
      <div className="notification-container">
        {notification && (
          <Notification
            message={notification.message}
            type={notification.type}
            onClose={() => setNotification(null)}
          />
        )}
      </div>

      <div className="page-container">
        <div className="page-header">
          <div>
            <h1 className="page-title">
              {jobName} Instances
              {loading && <span style={{ fontSize: '0.8em', opacity: 0.7 }}> (Loading...)</span>}
            </h1>
            {job && (
              <p className="page-subtitle">
                Total Instances: {job.totalInstances} • Last Run: {job.lastRun}
              </p>
            )}
          </div>
          <div className="page-actions">
            <button
              className="btn-modern btn-ghost"
              onClick={() => navigate('/jobs')}
            >
              Back to Jobs
            </button>
          </div>
        </div>

        <div className="filters-section">
          <div className="filters-grid">
            <div className="filter-group">
              <label htmlFor="from-date" className="filter-label">
                <Calendar size={16} />
                From Date & Time
              </label>
              <input
                id="from-date"
                type="datetime-local"
                className="filter-input"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
              />
            </div>
            
            <div className="filter-group">
              <label htmlFor="to-date" className="filter-label">
                <Calendar size={16} />
                To Date & Time
              </label>
              <input
                id="to-date"
                type="datetime-local"
                className="filter-input"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
              />
            </div>

            <div className="filter-group">
              <label htmlFor="status-filter" className="filter-label">
                <AlertCircle size={16} />
                Status
              </label>
              <select
                id="status-filter"
                className="filter-input"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                {statusOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="filter-group">
              <label htmlFor="triggered-by-filter" className="filter-label">
                <Filter size={16} />
                Triggered By
              </label>
              <select
                id="triggered-by-filter"
                className="filter-input"
                value={triggeredByFilter}
                onChange={(e) => setTriggeredByFilter(e.target.value)}
              >
                {triggeredByOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="filter-actions">
              <button
                className="btn-modern btn-primary"
                onClick={handleFilter}
              >
                <Filter size={16} />
                Apply Filter
              </button>
              <button
                className="btn-modern btn-secondary"
                onClick={clearFilters}
                disabled={tableLoading}
              >
                Clear
              </button>
            </div>
          </div>

          <div className="auto-refresh-section">
            <label className="auto-refresh-checkbox">
              <input
                type="checkbox"
                checked={autoRefreshEnabled}
                onChange={(e) => setAutoRefreshEnabled(e.target.checked)}
              />
              <RefreshCw size={16} className={autoRefreshEnabled ? 'spinning' : ''} />
              <span>Auto-refresh table (every 5 seconds)</span>
            </label>
          </div>

          <div className="results-summary">
            Showing {currentInstances.length} of {totalElements} instances
            {hasActiveFilters() && ' (with filters applied)'}
          </div>
        </div>

        <div className="table-modern-wrapper">
          <div className="table-header">
            <h3 className="table-title">
              <Layers size={20} />
              Job Instances ({totalElements})
            </h3>
          </div>
          
          <div className="table-content">
            {tableLoading || loading ? (
              <div className="table-loading">
                <div className="loading-spinner"></div>
                <p>Loading instances...</p>
              </div>
            ) : !instances || currentInstances.length === 0 ? (
              <div className="table-empty">
                <p>No instances found</p>
                {hasActiveFilters() ? (
                  <p className="empty-subtitle">Try adjusting your filters</p>
                ) : (
                  <p className="empty-subtitle">This job has no instances yet</p>
                )}
              </div>
            ) : (
              <table className="job-instances-table">
                <thead>
                  <tr>
                    <th className="column-id">ID</th>
                    <th className="column-status">Status</th>
                    <th className="column-created">last Updated Date</th>
                    <th className="column-duration">Duration</th>
                    <th className="column-executions">Executions</th>
                    <th className="column-triggered-by">Triggered By</th>
                    <th className="column-actions">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {currentInstances.map((instance: JobInstance) => (
                    <tr 
                      key={instance.id} 
                      className="table-row clickable"
                      onClick={() => handleInstanceClick(instance)}
                    >
                      <td className="cell-id">
                        <div className="instance-id">
                          <Layers size={16} />
                          #{instance.id}
                        </div>
                      </td>
                      <td className="cell-status">
                        <div className="status-cell">
                          {getStatusIcon(instance.lastStatus)}
                          <StatusBadge status={instance.lastStatus === 'STARTED' ? 'RUNNING' : instance.lastStatus} />
                        </div>
                      </td>
                      <td className="cell-created">
                        <div className="created-date">
                          <Calendar size={16} />
                          {formatDate(instance.lastUpdated)}
                        </div>
                      </td>
                      <td className="cell-duration">
                        <div className="duration-wrapper">
                          <Clock className="duration-icon" size={14} />
                          <span className="duration-text">{instance.duration}</span>
                        </div>
                      </td>
                      <td className="cell-executions">
                        <div className={`execution-count ${instance.executionCount > 0 ? 'has-executions' : 'no-executions'}`}>
                          {instance.executionCount}
                          <span>execution{instance.executionCount !== 1 ? 's' : ''}</span>
                        </div>
                      </td>
                      <td className="cell-triggered-by">
                        <div className="triggered-by-value">
                          {instance.triggeredBy}
                        </div>
                      </td>
                      <td className="cell-actions">
                        <div className="action-buttons">
                          <button
                            className="btn-action btn-info"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedInstanceForParams(instance.id);
                            }}
                            title="View Parameters"
                          >
                            <Info size={16} />
                          </button>

                          <button
                            className={`btn-action btn-stop ${shouldShowStopButton(instance.lastStatus) ? 'active' : 'disabled'}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              if (shouldShowStopButton(instance.lastStatus)) {
                                handleStopInstance(instance.id);
                              }
                            }}
                            disabled={!shouldShowStopButton(instance.lastStatus) || actionLoading[instance.id]}
                            title={shouldShowStopButton(instance.lastStatus) ? 'Stop Instance' : 'Can only stop running instances'}
                          >
                            {actionLoading[instance.id] ? (
                              <div className="button-spinner"></div>
                            ) : (
                              <Square size={16} />
                            )}
                          </button>

                          <button 
                            className={`btn-action btn-resume ${shouldShowResumeButton(instance.lastStatus) ? 'active' : 'disabled'}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              if (shouldShowResumeButton(instance.lastStatus)) {
                                handleResumeInstance(instance.id);
                              }
                            }}
                            disabled={!shouldShowResumeButton(instance.lastStatus) || actionLoading[instance.id]}
                            title={shouldShowResumeButton(instance.lastStatus) ? 'Resume Instance' : 'Can only resume stopped instances'}
                          >
                            {actionLoading[instance.id] ? (
                              <div className="button-spinner"></div>
                            ) : (
                              <PlayCircle size={16} />
                            )}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
          
          {!tableLoading && !loading && instances && currentInstances.length > 0 && totalPages > 1 && (
            <div className="pagination-container">
              <div className="pagination-info">
                Page {currentPage + 1} of {totalPages}
              </div>
              <div className="pagination-controls">
                <button
                  className="pagination-btn"
                  onClick={() => handlePageChange(0)}
                  disabled={currentPage === 0}
                  title="First Page"
                >
                  <ChevronsLeft size={14} />
                </button>
                <button
                  className="pagination-btn"
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 0}
                  title="Previous Page"
                >
                  <ChevronLeft size={14} />
                </button>
                
                {getVisiblePages().map(pageNum => (
                  <button
                    key={pageNum}
                    className={`pagination-btn ${currentPage === pageNum ? 'active' : ''}`}
                    onClick={() => handlePageChange(pageNum)}
                  >
                    {pageNum + 1}
                  </button>
                ))}
                
                <button
                  className="pagination-btn"
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage >= totalPages - 1}
                  title="Next Page"
                >
                  <ChevronRight size={14} />
                </button>
                <button
                  className="pagination-btn"
                  onClick={() => handlePageChange(totalPages - 1)}
                  disabled={currentPage >= totalPages - 1}
                  title="Last Page"
                >
                  <ChevronsRight size={14} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
      <JobParametersModal
        isOpen={selectedInstanceForParams !== null}
        onClose={() => setSelectedInstanceForParams(null)}
        instanceId={selectedInstanceForParams || 0}
        jobName={jobName}
      />
    </div>
  );
};

export default JobInstancesPage;
// src/pages/HomePage.tsx

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  RefreshCw,
  Activity,
  CheckCircle2,
  XCircle,
  Database,
  TrendingUp,
  ChevronDown
} from 'lucide-react';
import batchApiService from '../services/batchApiService';
import { DashboardStats, Job } from '../services/batchApiService';
import '../styles/HomePage.css';

const HomePage: React.FC = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState<DashboardStats>({
    totalJobs: 0,
    activeJobs: 0,
    successRate: 0,
    totalFailed: 0,
    runningNow: 0,
    totalSuccess: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [timeFilter, setTimeFilter] = useState('LAST_24_HOURS');
  const [selectedJob, setSelectedJob] = useState<string>('ALL_JOBS');
  const [jobs, setJobs] = useState<Job[]>([]);
  const [jobsLoading, setJobsLoading] = useState(false);

  useEffect(() => {
    fetchJobs();
  }, []);

  useEffect(() => {
    fetchDashboardData();
  }, [timeFilter, selectedJob]);

  const fetchJobs = async (): Promise<void> => {
    try {
      setJobsLoading(true);
      const jobsData = await batchApiService.getAllJobs();
      setJobs(jobsData);
    } catch (error) {
      console.error('Failed to fetch jobs:', error);
      setError('Failed to load jobs list.');
    } finally {
      setJobsLoading(false);
    }
  };

  const fetchDashboardData = async (): Promise<void> => {
    try {
      setLoading(true);
      setError(null);
      
      // Pass both timeFilter and jobName to the API
      const jobName = selectedJob === 'ALL_JOBS' ? undefined : selectedJob;
      
      const statsData = await batchApiService.getDashboardStats(timeFilter, jobName);

      setStats(statsData);
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
      setError('Failed to load dashboard data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = (): void => {
    fetchDashboardData();
  };

  const handleTimeFilterChange = (event: React.ChangeEvent<HTMLSelectElement>): void => {
    setTimeFilter(event.target.value);
  };

  const handleJobChange = (event: React.ChangeEvent<HTMLSelectElement>): void => {
    setSelectedJob(event.target.value);
  };

  if (error) {
    return (
      <div className="home-page">
        <div className="error-state">
          <XCircle size={48} className="error-icon" />
          <h3>Failed to Load Dashboard</h3>
          <p>{error}</p>
          <button className="btn-primary" onClick={fetchDashboardData}>
            <RefreshCw size={20} />
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="home-page">
      {/* Header Section */}
      <div className="home-header">
        <div className="home-header-content">
          <div className="header-left">
            {/* Job Selection Dropdown */}
            <div className="job-selector">
              <label htmlFor="job-select" className="selector-label">
                Select Job:
              </label>
              <div className="select-wrapper">
                <select 
                  id="job-select"
                  className="job-select"
                  value={selectedJob}
                  onChange={handleJobChange}
                  disabled={jobsLoading || loading}
                >
                  <option value="ALL_JOBS">All Jobs</option>
                  {jobs.map((job) => (
                    <option key={job.id} value={job.name}>
                      {job.name}
                    </option>
                  ))}
                </select>
                <ChevronDown size={16} className="select-chevron" />
              </div>
            </div>
          </div>

          <div className="header-actions">
            <select 
              className="time-filter-select"
              value={timeFilter}
              onChange={handleTimeFilterChange}
              disabled={loading}
            >
              <option value="LAST_1_HOUR">Last 1 Hour</option>
              <option value="LAST_6_HOURS">Last 6 Hours</option>
              <option value="LAST_12_HOURS">Last 12 Hours</option>
              <option value="LAST_24_HOURS">Last 24 Hours</option>
              <option value="TODAY">Today</option>
              <option value="YESTERDAY">Yesterday</option>
              <option value="THIS_WEEK_SUN_YESTERDAY">This Week (Sun - yesterday)</option>
              <option value="LAST_WEEK_SUN_SAT">Last Week (sun - sat)</option>
              <option value="THIS_MONTH_TILL_YESTERDAY">This Month (till yesterday)</option>
              <option value="LAST_MONTH">Last Month</option>
              <option value="THIS_QUARTER_TILL_YESTERDAY">This Quarter (till yesterday)</option>
              <option value="LAST_QUARTER">Last Quarter</option>
              <option value="LAST_3_MONTHS_TILL_LAST_MONTH">Last 3 Months (till last month)</option>
            </select>

            <button
              className="btn-refresh"
              onClick={handleRefresh}
              disabled={loading}
            >
              <RefreshCw size={20} className={loading ? 'spin' : ''} />
              Refresh
            </button>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="stats-container">
        <div className="stat-card stat-primary">
          <div className="stat-icon">
            <Database size={32} />
          </div>
          <div className="stat-content">
            <div className="stat-value">{loading ? '...' : stats.totalJobs}</div>
            <div className="stat-label">Total Jobs</div>
          </div>
        </div>

        <div className="stat-card stat-success">
          <div className="stat-icon">
            <CheckCircle2 size={32} />
          </div>
          <div className="stat-content">
            <div className="stat-value">{loading ? '...' : `${stats.successRate}%`}</div>
            <div className="stat-label">Success Rate</div>
          </div>
        </div>

        <div className="stat-card stat-warning">
          <div className="stat-icon">
            <Activity size={32} />
          </div>
          <div className="stat-content">
            <div className="stat-value">{loading ? '...' : stats.activeJobs}</div>
            <div className="stat-label">Active Jobs</div>
          </div>
        </div>

        <div className="stat-card stat-danger">
          <div className="stat-icon">
            <XCircle size={32} />
          </div>
          <div className="stat-content">
            <div className="stat-value">{loading ? '...' : stats.totalFailed}</div>
            <div className="stat-label">Failed</div>
          </div>
        </div>

        <div className="stat-card stat-info">
          <div className="stat-icon">
            <TrendingUp size={32} />
          </div>
          <div className="stat-content">
            <div className="stat-value">{loading ? '...' : stats.totalSuccess.toLocaleString()}</div>
            <div className="stat-label">Success</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
import React, { useState, useEffect } from 'react';
import { Search, Filter, ChevronRight, ChevronLeft, ChevronsLeft, ChevronsRight, Database, Play, AlertCircle, Clock, Package, Eye, Briefcase, X, Info, FileText, GitMerge, Send, Copy, Check, XCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import '../styles/DataMigrationSearchPage.css';

import batchApiService, { Job, MigrationRecord } from '../services/batchApiService';

// Types
interface MigrationSearchFilters {
  jobName?: string;
  searchValue: string;
}

const DataMigrationSearchPage: React.FC = () => {
  const navigate = useNavigate();

  // State
  const [filters, setFilters] = useState<MigrationSearchFilters>({
    searchValue: ''
  });
  const [searchResults, setSearchResults] = useState<MigrationRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [loadingJobs, setLoadingJobs] = useState<boolean>(true);
  const [jobConfigs, setJobConfigs] = useState<Job[]>([]);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [itemsPerPage] = useState<number>(10);
  const [error, setError] = useState<string | null>(null);

  // Modal state
  const [selectedRecord, setSelectedRecord] = useState<MigrationRecord | null>(null);
  const [showModal, setShowModal] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'reader' | 'processor' | 'writer' | 'error'>('reader');

  // Copy state
  const [copiedStates, setCopiedStates] = useState<Record<string, boolean>>({});

  // Initialize component
  useEffect(() => {
    fetchJobConfigs();
  }, []);

  // Fetch all job configurations from backend
  const fetchJobConfigs = async (): Promise<void> => {
    try {
      setLoadingJobs(true);
      const response = await batchApiService.getAllJobs();
      setJobConfigs(response);
    } catch (error) {
      console.error('Failed to fetch job configurations:', error);
      alert('Failed to load job configurations');
    } finally {
      setLoadingJobs(false);
    }
  };

  // Handle job selection
  const handleJobSelect = (jobName: string): void => {
    setFilters(prev => ({
      ...prev,
      jobName
    }));
    setSearchResults([]);
    setCurrentPage(1);
    setError(null);
  };

  // Handle search value change
  const handleSearchValueChange = (value: string): void => {
    setFilters(prev => ({
      ...prev,
      searchValue: value
    }));
  };

  // Handle search
  const handleSearch = async (): Promise<void> => {
    if (!filters.jobName) {
      alert('Please select a job first');
      return;
    }

    if (!filters.searchValue || filters.searchValue.trim() === '') {
      alert('Please enter a unique ID to search');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      setCurrentPage(1);
      
      // Use the batch API service
      const data = await batchApiService.searchMigrationRecords(
        filters.jobName,
        filters.searchValue
      );
      
      setSearchResults(data);

      if (data.length === 0) {
        setError('No records found matching your search criteria');
      }

    } catch (error) {
      console.error('Failed to search migration records:', error);
      setError(error instanceof Error ? error.message : 'Failed to search records');
      setSearchResults([]);
    } finally {
      setLoading(false);
    }
  };

  // Clear filters
  const clearFilters = (): void => {
    setFilters({
      searchValue: ''
    });
    setSearchResults([]);
    setCurrentPage(1);
    setError(null);
  };

  // Check if search is enabled
  const isSearchEnabled = (): boolean => {
    return !!filters.jobName && !!filters.searchValue && filters.searchValue.trim() !== '';
  };

  // Handle View Status - Navigate to ExecutionDetailPage with chunk highlighted
  const handleViewStatus = async (record: MigrationRecord): Promise<void> => {
    try {
      setLoading(true);
      navigate(`/jobs/${record.jobId}/instances/${record.jobId}/execution`, {
        state: {
          highlightChunkId: record.batchId,
          highlightExecutionId: record.jobExecutionId,
          fromMigrationSearch: true
        }
      });
    } catch (error) {
      console.error('Failed to navigate:', error);
      alert('Failed to navigate to execution details');
    } finally {
      setLoading(false);
    }
  };

  // Handle View Details - Open modal
  const handleViewDetails = (record: MigrationRecord): void => {
    setSelectedRecord(record);
    // Set default tab based on record state
    if (record.errorStage) {
      setActiveTab('error');
    } else {
      setActiveTab('reader');
    }
    setShowModal(true);
  };

  // Close modal
  const closeModal = (): void => {
    setShowModal(false);
    setSelectedRecord(null);
  };

  // Pagination
  const totalPages = Math.ceil(searchResults.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const currentRecords = searchResults.slice(startIndex, startIndex + itemsPerPage);

  const handlePageChange = (page: number): void => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  const getVisiblePages = (): number[] => {
    const pages: number[] = [];
    const maxVisiblePages = 5;

    let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

    if (endPage - startPage < maxVisiblePages - 1) {
      startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }

    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }

    return pages;
  };

  const getStatusIcon = (status: string) => {
    switch (status?.toUpperCase()) {
      case 'SUCCESS':
      case 'COMPLETED':
      case 'WRITTEN':
        return <Play size={16} className="status-icon success" />;
      case 'FAILED':
      case 'FAILED_PROCESSING':
      case 'FAILED_READING':
      case 'FAILED_WRITING':
      case 'ERROR':
        return <AlertCircle size={16} className="status-icon failed" />;
      case 'RUNNING':
      case 'IN_PROGRESS':
        return <Clock size={16} className="status-icon running" />;
      default:
        return <Clock size={16} className="status-icon running" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const normalizedStatus = status?.toUpperCase();
    let badgeClass = 'status-badge';

    switch (normalizedStatus) {
      case 'SUCCESS':
      case 'COMPLETED':
      case 'WRITTEN':
        badgeClass += ' status-success';
        break;
      case 'FAILED':
      case 'FAILED_PROCESSING':
      case 'FAILED_READING':
      case 'FAILED_WRITING':
      case 'ERROR':
        badgeClass += ' status-failed';
        break;
      case 'RUNNING':
      case 'IN_PROGRESS':
        badgeClass += ' status-running';
        break;
      default:
        badgeClass += ' status-unknown';
    }

    return <span className={badgeClass}>{status}</span>;
  };

  // Handle Enter key press for search
  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>): void => {
    if (e.key === 'Enter' && isSearchEnabled() && !loading) {
      handleSearch();
    }
  };

  // Render data viewer - handles both JSON and plain text (like CSV)
  const renderDataViewer = (data: any, title: string) => {
    if (!data) {
      return (
        <div style={{ padding: '1rem', color: '#6b7280', fontStyle: 'italic' }}>
          No {title.toLowerCase()} available
        </div>
      );
    }

    // Check if data is already a string (like CSV)
    const isString = typeof data === 'string';
    
    // Try to determine if it's JSON string
    let isJsonString = false;
    let parsedData = data;
    
    if (isString) {
      try {
        parsedData = JSON.parse(data);
        isJsonString = true;
      } catch (e) {
        // Not JSON, keep as plain string
        isJsonString = false;
      }
    }

    // If it's an object or parsed JSON, display as JSON
    const displayAsJson = !isString || isJsonString;
    const displayData = displayAsJson ? parsedData : data;
    const contentString = displayAsJson ? JSON.stringify(displayData, null, 2) : data;

    const copyId = `${title.replace(/\s+/g, '-').toLowerCase()}`;

    const handleCopy = async () => {
      try {
        await navigator.clipboard.writeText(contentString);
        setCopiedStates(prev => ({ ...prev, [copyId]: true }));
        setTimeout(() => {
          setCopiedStates(prev => ({ ...prev, [copyId]: false }));
        }, 2000);
      } catch (err) {
        console.error('Failed to copy:', err);
        alert('Failed to copy to clipboard');
      }
    };

    return (
      <div style={{ position: 'relative' }}>
        {/* Copy Button */}
        <button
          onClick={handleCopy}
          style={{
            position: 'absolute',
            top: '0.5rem',
            right: '0.5rem',
            padding: '0.5rem 0.75rem',
            background: copiedStates[copyId] ? '#10b981' : '#667eea',
            color: 'white',
            border: 'none',
            borderRadius: '0.375rem',
            cursor: 'pointer',
            fontSize: '0.875rem',
            fontWeight: 500,
            display: 'flex',
            alignItems: 'center',
            gap: '0.375rem',
            zIndex: 10,
            transition: 'all 0.2s',
            boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)'
          }}
          onMouseEnter={(e) => {
            if (!copiedStates[copyId]) {
              e.currentTarget.style.background = '#5568d3';
            }
          }}
          onMouseLeave={(e) => {
            if (!copiedStates[copyId]) {
              e.currentTarget.style.background = '#667eea';
            }
          }}
          title={displayAsJson ? "Copy JSON" : "Copy Text"}
        >
          {copiedStates[copyId] ? (
            <>
              <Check size={14} />
              Copied!
            </>
          ) : (
            <>
              <Copy size={14} />
              Copy
            </>
          )}
        </button>

        {/* Data Type Badge */}
        <div style={{
          position: 'absolute',
          top: '0.5rem',
          left: '0.5rem',
          padding: '0.25rem 0.5rem',
          background: displayAsJson ? '#dbeafe' : '#dcfce7',
          color: displayAsJson ? '#1e40af' : '#166534',
          borderRadius: '0.25rem',
          fontSize: '0.75rem',
          fontWeight: 600,
          zIndex: 10
        }}>
          {displayAsJson ? 'JSON' : 'TEXT'}
        </div>

        {/* Content Display */}
        <div style={{
          maxHeight: '500px',
          overflowY: 'auto',
          background: '#1e1e1e',
          borderRadius: '0.5rem',
          padding: '1rem',
          paddingTop: '3rem',
          border: '1px solid #e5e7eb'
        }}>
          <pre style={{
            margin: 0,
            fontSize: '0.875rem',
            lineHeight: '1.5',
            color: '#d4d4d4',
            fontFamily: "'Consolas', 'Monaco', 'Courier New', monospace",
            whiteSpace: 'pre-wrap',
            wordBreak: 'break-word'
          }}>
            <code style={{ color: '#d4d4d4' }}>
              {contentString}
            </code>
          </pre>
        </div>
      </div>
    );
  };

  return (
    <div className="data-migration-search-page">
      <div className="page-container">
        {/* Header */}
        <div className="page-header">
          <div className="header-content">
            <h1 className="page-title">
              <Database size={28} />
              Data Migration Search
            </h1>
            <p className="page-subtitle">
              Search and track migration records across all batch jobs
            </p>
          </div>
        </div>

        {/* Search Filters Section */}
        <div className="filters-card modern-card">
          <div className="card-header">
            <h2 className="card-title">
              <Filter size={20} />
              Search Filters
            </h2>
          </div>

          <div className="filters-grid">
            {/* Job Selection Dropdown */}
            <div className="filter-group">
              <label htmlFor="jobName" className="filter-label">
                <Briefcase size={16} />
                Select Job
              </label>
              <select
                id="jobName"
                className="filter-input"
                value={filters.jobName || ''}
                onChange={(e) => handleJobSelect(e.target.value)}
                disabled={loadingJobs}
              >
                <option value="">
                  {loadingJobs ? 'Loading jobs...' : 'Select a job...'}
                </option>
                {jobConfigs.map(job => (
                  <option key={job.id} value={job.name}>
                    {job.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Search Value Input */}
            <div className="filter-group" style={{ gridColumn: 'span 2' }}>
              <label htmlFor="searchValue" className="filter-label">
                <Search size={16} />
                Unique ID
              </label>
              <input
                id="searchValue"
                type="text"
                className="filter-input"
                placeholder="Enter unique ID (Batch ID, Execution ID, etc.)"
                value={filters.searchValue}
                onChange={(e) => handleSearchValueChange(e.target.value)}
                onKeyPress={handleKeyPress}
                disabled={!filters.jobName}
              />
            </div>

            {/* Action Buttons */}
            <div className="filter-actions">
              <button
                className="btn-modern btn-primary"
                onClick={handleSearch}
                disabled={!isSearchEnabled() || loading}
              >
                <Filter size={16} />
                {loading ? 'Searching...' : 'Search'}
              </button>
              <button
                className="btn-modern btn-secondary"
                onClick={clearFilters}
                disabled={loading}
              >
                Clear
              </button>
            </div>
          </div>

          {/* Info Message */}
          {!filters.jobName && (
            <div style={{
              marginTop: '1rem',
              padding: '0.75rem 1rem',
              background: '#fef3c7',
              border: '1px solid #fbbf24',
              borderRadius: '0.5rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              fontSize: '0.875rem',
              color: '#92400e'
            }}>
              <AlertCircle size={16} />
              Please select a job to enable search
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div style={{
              marginTop: '1rem',
              padding: '0.75rem 1rem',
              background: '#fee2e2',
              border: '1px solid #ef4444',
              borderRadius: '0.5rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              fontSize: '0.875rem',
              color: '#991b1b'
            }}>
              <AlertCircle size={16} />
              {error}
            </div>
          )}

          {/* Results Summary */}
          {searchResults.length > 0 && !error && (
            <div className="results-summary">
              Found {searchResults.length} migration record{searchResults.length !== 1 ? 's' : ''} for job "{filters.jobName}" with unique ID: "{filters.searchValue}"
            </div>
          )}
        </div>

        {/* Results Table */}
        <div className="table-modern-wrapper">
          <div className="table-header">
            <h3 className="table-title">
              <Database size={20} />
              Migration Records ({searchResults.length})
            </h3>
          </div>
          
          <div className="table-content">
            {loading ? (
              <div className="table-loading">
                <div className="loading-spinner"></div>
                <p>Searching migration records...</p>
              </div>
            ) : searchResults.length === 0 ? (
              <div className="table-empty">
                <p>No migration records found</p>
                <p className="empty-subtitle">
                  {filters.jobName
                    ? 'Try entering a different unique ID to search'
                    : 'Select a job and enter a unique ID to search'}
                </p>
              </div>
            ) : (
              <table className="migration-records-table">
                <thead>
                  <tr>
                    <th className="column-job-id">Job ID</th>
                    <th className="column-execution-id">Job Execution ID</th>
                    <th className="column-chunk-id">Batch ID</th>
                    <th className="column-chunk-status">Item Status</th>
                    <th className="column-actions">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {currentRecords.map((record, index) => (
                    <tr key={`${record.batchId}-${index}`} className="table-row">
                      <td className="cell-job-id">
                        <div className="job-id-value">
                          <Database size={16} />
                          #{record.jobId}
                        </div>
                      </td>
                      <td className="cell-execution-id">
                        <div className="execution-id-value">
                          <Play size={16} />
                          #{record.jobExecutionId}
                        </div>
                      </td>
                      <td className="cell-chunk-id">
                        <div className="chunk-id-value">
                          <Package size={16} />
                          {record.batchId}
                        </div>
                      </td>
                      <td className="cell-chunk-status">
                        <div className="status-cell">
                          {getStatusIcon(record.itemStatus)}
                          {getStatusBadge(record.itemStatus)}
                        </div>
                      </td>
                      <td className="cell-actions">
                        <div style={{ display: 'flex', gap: '0.5rem' }}>
                          <button
                            className="btn-modern btn-secondary"
                            onClick={() => handleViewDetails(record)}
                            title="View detailed information"
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              fontSize: '0.875rem',
                              padding: '0.5rem',
                              minWidth: 'auto'
                            }}
                          >
                            <Info size={16} />
                          </button>
                          <button
                            className="btn-modern btn-primary"
                            onClick={() => handleViewStatus(record)}
                            title="View batch status in execution details"
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '0.5rem',
                              fontSize: '0.875rem',
                              padding: '0.5rem 1rem'
                            }}
                          >
                            <Eye size={16} />
                            Status
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
          
          {/* Pagination */}
          {!loading && searchResults.length > 0 && totalPages > 1 && (
            <div className="pagination-container">
              <div className="pagination-info">
                Page {currentPage} of {totalPages} • Showing {currentRecords.length} of {searchResults.length} records
              </div>
              <div className="pagination-controls">
                <button
                  className="pagination-btn"
                  onClick={() => handlePageChange(1)}
                  disabled={currentPage === 1}
                  title="First Page"
                >
                  <ChevronsLeft size={14} />
                </button>
                <button
                  className="pagination-btn"
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                  title="Previous Page"
                >
                  <ChevronLeft size={14} />
                </button>
                
                {/* Page numbers */}
                {getVisiblePages().map(page => (
                  <button
                    key={page}
                    className={`pagination-btn ${currentPage === page ? 'active' : ''}`}
                    onClick={() => handlePageChange(page)}
                  >
                    {page}
                  </button>
                ))}
                
                <button
                  className="pagination-btn"
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                  title="Next Page"
                >
                  <ChevronRight size={14} />
                </button>
                <button
                  className="pagination-btn"
                  onClick={() => handlePageChange(totalPages)}
                  disabled={currentPage === totalPages}
                  title="Last Page"
                >
                  <ChevronsRight size={14} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Details Modal - (keeping the full modal code from original, just showing structure) */}
      {showModal && selectedRecord && (
        <div className="modal-overlay" onClick={closeModal} style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          background: 'rgba(0, 0, 0, 0.5)', display: 'flex', alignItems: 'center',
          justifyContent: 'center', zIndex: 1000, padding: '2rem'
        }}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{
            background: 'white', borderRadius: '0.75rem', width: '100%',
            maxWidth: '1200px', maxHeight: '90vh', display: 'flex', flexDirection: 'column',
            boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)'
          }}>
            {/* Modal Header */}
            <div style={{ padding: '1.5rem', borderBottom: '1px solid #e5e7eb', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <h2 style={{ fontSize: '1.5rem', fontWeight: 600, color: '#111827', margin: 0 }}>Migration Record Details</h2>
                <p style={{ fontSize: '0.875rem', color: '#6b7280', marginTop: '0.25rem', marginBottom: 0 }}>Batch ID: {selectedRecord.batchId}</p>
              </div>
              <button onClick={closeModal} style={{
                background: 'transparent', border: 'none', cursor: 'pointer', padding: '0.5rem',
                borderRadius: '0.375rem', display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: '#6b7280', transition: 'all 0.2s'
              }} onMouseEnter={(e) => e.currentTarget.style.background = '#f3f4f6'}
                onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}>
                <X size={24} />
              </button>
            </div>

            {/* Summary Info */}
            <div style={{ padding: '1rem 1.5rem', background: '#f9fafb', borderBottom: '1px solid #e5e7eb' }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
                <div>
                  <div style={{ fontSize: '0.75rem', color: '#6b7280', marginBottom: '0.25rem' }}>Job ID</div>
                  <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#111827' }}>#{selectedRecord.jobId}</div>
                </div>
                <div>
                  <div style={{ fontSize: '0.75rem', color: '#6b7280', marginBottom: '0.25rem' }}>Execution ID</div>
                  <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#111827' }}>#{selectedRecord.jobExecutionId}</div>
                </div>
                <div>
                  <div style={{ fontSize: '0.75rem', color: '#6b7280', marginBottom: '0.25rem' }}>Status</div>
                  <div>{getStatusBadge(selectedRecord.itemStatus)}</div>
                </div>
                <div>
                  <div style={{ fontSize: '0.75rem', color: '#6b7280', marginBottom: '0.25rem' }}>Read Time</div>
                  <div style={{ fontSize: '0.875rem', fontWeight: 500, color: '#111827' }}>{selectedRecord.readTime}</div>
                </div>
                {selectedRecord.processTime && (
                  <div>
                    <div style={{ fontSize: '0.75rem', color: '#6b7280', marginBottom: '0.25rem' }}>Process Time</div>
                    <div style={{ fontSize: '0.875rem', fontWeight: 500, color: '#111827' }}>{selectedRecord.processTime}</div>
                  </div>
                )}
                {selectedRecord.errorStage && (
                  <div>
                    <div style={{ fontSize: '0.75rem', color: '#6b7280', marginBottom: '0.25rem' }}>Error Stage</div>
                    <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#dc2626', padding: '0.25rem 0.5rem',
                      background: '#fee2e2', borderRadius: '0.25rem', display: 'inline-block' }}>
                      {selectedRecord.errorStage}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Tabs */}
            <div style={{ borderBottom: '1px solid #e5e7eb', background: '#fff' }}>
              <div style={{ display: 'flex', paddingLeft: '1.5rem', gap: '0.5rem', overflowX: 'auto' }}>
                {selectedRecord.errorStage && (
                  <button onClick={() => setActiveTab('error')} style={{
                    padding: '1rem 1.5rem', border: 'none', background: 'transparent', cursor: 'pointer',
                    fontSize: '0.875rem', fontWeight: 600, color: activeTab === 'error' ? '#dc2626' : '#6b7280',
                    borderBottom: activeTab === 'error' ? '2px solid #dc2626' : '2px solid transparent',
                    transition: 'all 0.2s', display: 'flex', alignItems: 'center', gap: '0.5rem', whiteSpace: 'nowrap'
                  }}>
                    <XCircle size={16} />
                    Error Details
                  </button>
                )}
                <button onClick={() => setActiveTab('reader')} style={{
                  padding: '1rem 1.5rem', border: 'none', background: 'transparent', cursor: 'pointer',
                  fontSize: '0.875rem', fontWeight: 600, color: activeTab === 'reader' ? '#667eea' : '#6b7280',
                  borderBottom: activeTab === 'reader' ? '2px solid #667eea' : '2px solid transparent',
                  transition: 'all 0.2s', display: 'flex', alignItems: 'center', gap: '0.5rem', whiteSpace: 'nowrap'
                }}>
                  <FileText size={16} />
                  Reader Details
                </button>
                {selectedRecord.processorDetails && (
                  <button onClick={() => setActiveTab('processor')} style={{
                    padding: '1rem 1.5rem', border: 'none', background: 'transparent', cursor: 'pointer',
                    fontSize: '0.875rem', fontWeight: 600, color: activeTab === 'processor' ? '#667eea' : '#6b7280',
                    borderBottom: activeTab === 'processor' ? '2px solid #667eea' : '2px solid transparent',
                    transition: 'all 0.2s', display: 'flex', alignItems: 'center', gap: '0.5rem', whiteSpace: 'nowrap'
                  }}>
                    <GitMerge size={16} />
                    Processor Details
                  </button>
                )}
                {selectedRecord.writerDetails && (
                  <button onClick={() => setActiveTab('writer')} style={{
                    padding: '1rem 1.5rem', border: 'none', background: 'transparent', cursor: 'pointer',
                    fontSize: '0.875rem', fontWeight: 600, color: activeTab === 'writer' ? '#667eea' : '#6b7280',
                    borderBottom: activeTab === 'writer' ? '2px solid #667eea' : '2px solid transparent',
                    transition: 'all 0.2s', display: 'flex', alignItems: 'center', gap: '0.5rem', whiteSpace: 'nowrap'
                  }}>
                    <Send size={16} />
                    Writer Details
                  </button>
                )}
              </div>
            </div>

            {/* Tab Content */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '1.5rem' }}>
              {activeTab === 'error' && selectedRecord.errorStage && (
                <div>
                  <div style={{
                    padding: '1.5rem', background: '#fee2e2', borderRadius: '0.5rem',
                    border: '2px solid #ef4444', marginBottom: '1.5rem'
                  }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
                      <XCircle size={24} style={{ color: '#dc2626' }} />
                      <h3 style={{ fontSize: '1.25rem', fontWeight: 600, color: '#991b1b', margin: 0 }}>
                        Processing Error
                      </h3>
                    </div>

                    <div style={{ marginBottom: '1rem' }}>
                      <div style={{ fontSize: '0.75rem', color: '#991b1b', fontWeight: 600,
                        marginBottom: '0.5rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                        Error Stage
                      </div>
                      <div style={{ fontSize: '1rem', fontWeight: 600, color: '#7f1d1d',
                        padding: '0.5rem 0.75rem', background: '#fecaca', borderRadius: '0.375rem', display: 'inline-block' }}>
                        {selectedRecord.errorStage}
                      </div>
                    </div>

                    {selectedRecord.errorMessage && (
                      <div style={{ marginBottom: '1rem' }}>
                        <div style={{ fontSize: '0.75rem', color: '#991b1b', fontWeight: 600,
                          marginBottom: '0.5rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                          Error Message
                        </div>
                        <div style={{ fontSize: '0.9375rem', color: '#7f1d1d', background: '#fff',
                          padding: '0.75rem', borderRadius: '0.375rem', border: '1px solid #fca5a5', lineHeight: '1.6' }}>
                          {selectedRecord.errorMessage}
                        </div>
                      </div>
                    )}

                    {selectedRecord.errorStackTrace && (
                      <div>
                        <div style={{ fontSize: '0.75rem', color: '#991b1b', fontWeight: 600,
                          marginBottom: '0.5rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                          Stack Trace
                        </div>
                        <div style={{ background: '#1e1e1e', borderRadius: '0.5rem', padding: '1rem',
                          border: '1px solid #fca5a5', maxHeight: '400px', overflowY: 'auto' }}>
                          <pre style={{ fontSize: '0.75rem', color: '#fca5a5', margin: 0,
                            fontFamily: "'Consolas', 'Monaco', 'Courier New', monospace",
                            whiteSpace: 'pre-wrap', wordBreak: 'break-word', lineHeight: '1.5' }}>
                            {selectedRecord.errorStackTrace}
                          </pre>
                        </div>
                      </div>
                    )}
                  </div>

                  <div style={{ padding: '1rem', background: '#fef3c7', borderRadius: '0.5rem',
                    border: '1px solid #fbbf24', display: 'flex', gap: '0.75rem' }}>
                    <AlertCircle size={20} style={{ color: '#92400e', flexShrink: 0, marginTop: '0.125rem' }} />
                    <div style={{ fontSize: '0.875rem', color: '#78350f', lineHeight: '1.6' }}>
                      <strong>Note:</strong> This error occurred during the <strong>{selectedRecord.errorStage}</strong> stage. 
                      Review the error message and stack trace above for detailed information about what went wrong.
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'reader' && (
                <div>
                  <div style={{ marginBottom: '1.5rem' }}>
                    <h3 style={{ fontSize: '1rem', fontWeight: 600, color: '#111827', marginBottom: '1rem' }}>
                      Read Metadata
                    </h3>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
                      gap: '1rem', padding: '1rem', background: '#f9fafb', borderRadius: '0.5rem' }}>
                      <div>
                        <div style={{ fontSize: '0.75rem', color: '#6b7280', marginBottom: '0.25rem' }}>Read Duration</div>
                        <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#111827' }}>
                          {selectedRecord.readerDetails.readDurationMs}ms
                        </div>
                      </div>
                      <div>
                        <div style={{ fontSize: '0.75rem', color: '#6b7280', marginBottom: '0.25rem' }}>Batch Range</div>
                        <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#111827' }}>
                          {selectedRecord.readerDetails.batchStartOffset} - {selectedRecord.readerDetails.batchEndOffset}
                        </div>
                      </div>
                      <div>
                        <div style={{ fontSize: '0.75rem', color: '#6b7280', marginBottom: '0.25rem' }}>Record Offset</div>
                        <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#111827' }}>
                          {selectedRecord.readerDetails.recordOffset}
                        </div>
                      </div>
                      {selectedRecord.readerDetails.sqlQuery && (
                        <div style={{ gridColumn: '1 / -1' }}>
                          <div style={{ fontSize: '0.75rem', color: '#6b7280', marginBottom: '0.25rem' }}>SQL Query</div>
                          <div style={{ fontSize: '0.875rem', fontFamily: 'monospace', color: '#111827',
                            background: '#fff', padding: '0.5rem', borderRadius: '0.25rem', border: '1px solid #e5e7eb' }}>
                            {selectedRecord.readerDetails.sqlQuery}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  <div>
                    <h3 style={{ fontSize: '1rem', fontWeight: 600, color: '#111827', marginBottom: '1rem' }}>
                      Raw Data
                    </h3>
                    {renderDataViewer(selectedRecord.readerDetails.rawData, 'Raw Data')}
                  </div>
                </div>
              )}

              {activeTab === 'processor' && selectedRecord.processorDetails && (
                <div>
                  <div style={{ marginBottom: '1.5rem' }}>
                    <h3 style={{ fontSize: '1rem', fontWeight: 600, color: '#111827', marginBottom: '1rem' }}>
                      Processing Metadata
                    </h3>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
                      gap: '1rem', padding: '1rem', background: '#f9fafb', borderRadius: '0.5rem', marginBottom: '1.5rem' }}>
                      <div>
                        <div style={{ fontSize: '0.75rem', color: '#6b7280', marginBottom: '0.25rem' }}>Process Duration</div>
                        <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#111827' }}>
                          {selectedRecord.processorDetails.processDurationMs}ms
                        </div>
                      </div>
                      <div>
                        <div style={{ fontSize: '0.75rem', color: '#6b7280', marginBottom: '0.25rem' }}>Timestamp</div>
                        <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#111827' }}>
                          {selectedRecord.processorDetails.processTimestamp}
                        </div>
                      </div>
                    </div>

                    {selectedRecord.processorDetails.transformationsApplied?.length > 0 && (
                      <div style={{ marginBottom: '1.5rem' }}>
                        <h4 style={{ fontSize: '0.875rem', fontWeight: 600, color: '#111827', marginBottom: '0.5rem' }}>
                          Transformations Applied
                        </h4>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                          {selectedRecord.processorDetails.transformationsApplied.map((transform, idx) => (
                            <span key={idx} style={{ padding: '0.375rem 0.75rem', background: '#dbeafe',
                              color: '#1e40af', borderRadius: '0.375rem', fontSize: '0.75rem', fontWeight: 500 }}>
                              {transform}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div style={{ marginBottom: '1.5rem' }}>
                    <h3 style={{ fontSize: '1rem', fontWeight: 600, color: '#111827', marginBottom: '1rem' }}>
                      Original Data
                    </h3>
                    {renderDataViewer(selectedRecord.processorDetails.originalData, 'Original Data')}
                  </div>

                  <div>
                    <h3 style={{ fontSize: '1rem', fontWeight: 600, color: '#111827', marginBottom: '1rem' }}>
                      Transformed Data
                    </h3>
                    {renderDataViewer(selectedRecord.processorDetails.transformedData, 'Transformed Data')}
                  </div>
                </div>
              )}

              {activeTab === 'writer' && selectedRecord.writerDetails && (
                <div>
                  <div style={{ marginBottom: '1.5rem' }}>
                    <h3 style={{ fontSize: '1rem', fontWeight: 600, color: '#111827', marginBottom: '1rem' }}>
                      Write Metadata
                    </h3>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
                      gap: '1rem', padding: '1rem', background: '#f9fafb', borderRadius: '0.5rem' }}>
                      <div>
                        <div style={{ fontSize: '0.75rem', color: '#6b7280', marginBottom: '0.25rem' }}>Writer ID</div>
                        <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#111827' }}>
                          {selectedRecord.writerDetails.id}
                        </div>
                      </div>
                      <div>
                        <div style={{ fontSize: '0.75rem', color: '#6b7280', marginBottom: '0.25rem' }}>Duration</div>
                        <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#111827' }}>
                          {selectedRecord.writerDetails.duration}ms
                        </div>
                      </div>
                      <div>
                        <div style={{ fontSize: '0.75rem', color: '#6b7280', marginBottom: '0.25rem' }}>Status</div>
                        <div style={{ fontSize: '0.875rem', fontWeight: 600, color: '#111827' }}>
                          {selectedRecord.writerDetails.status}
                        </div>
                      </div>
                    </div>
                  </div>

                  {selectedRecord.writerDetails.apiDetail.requestPayload && (
                    <div style={{ marginBottom: '1.5rem' }}>
                      <h3 style={{ fontSize: '1rem', fontWeight: 600, color: '#111827', marginBottom: '1rem' }}>
                        Request Payload
                      </h3>
                      {renderDataViewer(selectedRecord.writerDetails.apiDetail.requestPayload, 'Request Payload')}
                    </div>
                  )}

                  {selectedRecord.writerDetails.apiDetail.responsePayload && (
                    <div>
                      <h3 style={{ fontSize: '1rem', fontWeight: 600, color: '#111827', marginBottom: '1rem' }}>
                        Response Payload
                      </h3>
                      {renderDataViewer(selectedRecord.writerDetails.apiDetail.responsePayload, 'Response Payload')}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div style={{ padding: '1rem 1.5rem', borderTop: '1px solid #e5e7eb', display: 'flex', justifyContent: 'flex-end' }}>
              <button onClick={closeModal} className="btn-modern btn-secondary" style={{ padding: '0.5rem 1.5rem' }}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DataMigrationSearchPage;
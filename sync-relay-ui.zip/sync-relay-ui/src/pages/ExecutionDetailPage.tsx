// src/pages/ExecutionDetailPage.tsx

import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import {
  Home, Database, Layers, Activity, RefreshCw, AlertCircle, Package, ExternalLink, ChevronDown, ChevronUp, RotateCcw, Play, X
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import TriggerJobModal, { RetryConfig } from '../components/TriggerJobModal';
import StepCard from '../components/StepCard';
import { ExecutionDetail, JobInstance, Step, Job, JobParam } from '../types/batch.types';
import batchApiService from '../services/batchApiService';
import '../styles/UnifiedStyles.css';

const Notification: React.FC<{ message: string; type: 'success' | 'error'; onClose: () => void }> = ({
  message,
  type,
  onClose
}) => {
  React.useEffect(() => {
    const timer = setTimeout(onClose, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className={`notification ${type}`}>
      <div className="notification-content">
        <span>{message}</span>
        <button onClick={onClose} className="notification-close">
          <X size={16} />
        </button>
      </div>
    </div>
  );
};

const ExecutionDetailPage: React.FC = () => {
  const navigate = useNavigate();
  const { jobId, instanceId } = useParams<{ jobId: string; instanceId: string }>();
  const location = useLocation();
  const jobFromState = location.state?.job as Job;
  const highlightChunkId = location.state?.highlightChunkId as string | undefined;
  const highlightExecutionId = location.state?.highlightExecutionId as string | undefined;
  const fromMigrationSearch = location.state?.fromMigrationSearch as boolean | undefined;

  const [executions, setExecutions] = useState<ExecutionDetail[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [showTriggerModal, setShowTriggerModal] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [expandedExecutions, setExpandedExecutions] = useState<Set<number>>(new Set([]));
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [job, setJob] = useState<Job | null>(jobFromState || null);
  const [highlightedChunkId, setHighlightedChunkId] = useState<string | null>(highlightChunkId || null);
  const [highlightedExecutionId, setHighlightedExecutionId] = useState<string | null>(highlightExecutionId || null);
  const [retryConfig, setRetryConfig] = useState<RetryConfig | undefined>();

  const handleRetryFailedBatches = (execution: ExecutionDetail) => {
    setRetryConfig({
      childInstance: true,
      parentJobInstance: instanceId,
      parentExecutionId: execution.id.toString()
    });
    setShowTriggerModal(true);
  };

  console.log('ExecutionDetailPage Params:', { jobId, instanceId });
  console.log('Location state:', location.state);
  console.log('Highlight Chunk ID:', highlightChunkId);
  console.log('Highlight Execution ID:', highlightExecutionId);

  useEffect(() => {
    if (instanceId) {
      fetchExecutionDetail(parseInt(instanceId));
    }
  }, [instanceId]);

  // Auto-expand execution and scroll to highlighted chunk
  useEffect(() => {
    if (highlightedChunkId && highlightedExecutionId && executions.length > 0 && !loading) {
      // Find the execution index that matches the highlightExecutionId
      const executionIndex = executions.findIndex(
        exec => exec.id.toString() === highlightedExecutionId
      );

      if (executionIndex !== -1) {
        // Expand only the specific execution
        setExpandedExecutions(new Set([executionIndex]));

        // Scroll to the execution first
        setTimeout(() => {
          const executionElement = document.getElementById(`execution-${executionIndex}`);
          if (executionElement) {
            executionElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }
        }, 300);

        // Then scroll to the chunk after a delay to ensure DOM is rendered
        setTimeout(() => {
          const chunkElement = document.getElementById(`summary-${highlightedChunkId}`);
          if (chunkElement) {
            chunkElement.scrollIntoView({ behavior: 'smooth', block: 'center' });

            // REMOVED: The timeout that was clearing the highlights
            // Keep the highlights permanently
          }
        }, 800);
      }
    } else if (highlightedChunkId && !highlightedExecutionId && executions.length > 0 && !loading) {
      // Fallback: If no execution ID specified, expand the first one
      setExpandedExecutions(new Set([0]));

      setTimeout(() => {
        const chunkElement = document.getElementById(`summary-${highlightedChunkId}`);
        if (chunkElement) {
          chunkElement.scrollIntoView({ behavior: 'smooth', block: 'center' });

          // REMOVED: The timeout that was clearing the highlight
        }
      }, 500);
    }
  }, [highlightedChunkId, highlightedExecutionId, executions, loading]);

  const [refreshTrigger, setRefreshTrigger] = useState<number>(0);
  const handleRefresh = async (): Promise<void> => {
    if (!instanceId) return;

    try {
      setRefreshing(true);
      setError(null);
      const data = await batchApiService.getExecutionDetail(parseInt(instanceId));
      const executionsArray = Array.isArray(data) ? data : [data];
      setExecutions(executionsArray);

      // Trigger refresh in child components
      setRefreshTrigger(prev => prev + 1);

      setNotification({
        message: 'Execution data refreshed successfully',
        type: 'success'
      });
    } catch (error) {
      console.error('Failed to refresh execution details:', error);
      setNotification({
        message: 'Failed to refresh execution details',
        type: 'error'
      });
    } finally {
      setRefreshing(false);
    }
  };

  const fetchExecutionDetail = async (instanceId: number): Promise<void> => {
    try {
      setLoading(true);
      setError(null);
      const data = await batchApiService.getExecutionDetail(instanceId);
      const executionsArray = Array.isArray(data) ? data : [data];
      setExecutions(executionsArray);
    } catch (error) {
      console.error('Failed to fetch execution details:', error);
      setError('Failed to load execution details. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleBackToInstances = () => {
  console.log('Navigating back to instances with jobId:', jobId);

  if (fromMigrationSearch) {
    navigate('/migration-search');
  } else if (jobId) {
    const jobNameToPass = job?.name || (executions.length > 0 ? executions[0].jobName : '');
    navigate(`/jobs/${jobId}/instances`, {
      state: { 
        jobName: jobNameToPass,
        job: job
      }
    });
  } else {
    console.warn('jobId is undefined, navigating to /jobs');
    navigate('/jobs');
  }
};

  const handleTriggerSuccess = (message: string) => {
    setNotification({ message, type: message.includes('❌') ? 'error' : 'success' });
    setShowTriggerModal(false);
  };

  const handleNavigateToInstance = (retryInstanceId: number): void => {
    navigate(`/jobs/${jobId}/instances/${retryInstanceId}/execution`);
    fetchExecutionDetail(retryInstanceId);
  };

  const toggleExecutionExpansion = (index: number): void => {
    setExpandedExecutions(prev => {
      const newSet = new Set(prev);
      if (newSet.has(index)) {
        newSet.delete(index);
      } else {
        newSet.add(index);
      }
      return newSet;
    });
  };

  const hasFailedBatches = (execution: ExecutionDetail): boolean => {
    return execution.steps.some(step =>
      step.summaries?.some(summary => summary.status === 'FAILED')
    );
  };

  if (loading) {
    return (
      <div className="page-background">
        <div className="page-container">
          <div className="loading-container">
            <div className="loading-spinner"></div>
            <p className="loading-text">Loading execution details...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="page-background">
        <div className="page-container">
          <div className="error-container">
            <AlertCircle size={48} className="error-icon" />
            <h2 className="error-title">Error Loading Execution</h2>
            <p className="error-message">{error}</p>
            <div style={{ display: 'flex', gap: '0.5rem', marginTop: '1rem' }}>
              <button onClick={() => fetchExecutionDetail(parseInt(instanceId!))} className="btn-modern btn-primary">
                Try Again
              </button>
              <button onClick={handleRefresh} className="btn-modern btn-secondary">
                <RefreshCw size={16} />
                Refresh
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (executions.length === 0) {
    return (
      <div className="page-background">
        <div className="page-container">
          <div className="empty-state">
            <Package size={48} />
            <h2>No Execution Data</h2>
            <p>No execution details found for this instance.</p>
            <button onClick={handleRefresh} className="btn-modern btn-primary">
              <RefreshCw size={16} />
              Refresh
            </button>
          </div>
        </div>
      </div>
    );
  }

  const latestExecution = executions[0];

  return (
    <div className="page-background">
      <div className="notification-container">
        {notification && (
          <Notification
            message={notification.message}
            type={notification.type}
            onClose={() => setNotification(null)}
          />
        )}
      </div>

      <div className="page-container">
        {/* Fixed Execution Header */}
        <div className="page-header" style={{ marginTop: '0' }}>
          <div className="page-title-section">
            <h1 className="page-title">Instance #{latestExecution.instanceId}</h1>
            <p className="page-subtitle">
              {latestExecution.jobName} • {executions.length} {executions.length === 1 ? 'Execution' : 'Executions'}
              {fromMigrationSearch && highlightChunkId && (
                <span style={{ color: '#f59e0b', marginLeft: '0.5rem' }}>
                  • Viewing Execution: {highlightedExecutionId} • Chunk: {highlightChunkId}
                </span>
              )}
            </p>
          </div>
          <div className="page-actions">
            {/* Refresh Button */}
            <button
              className="btn-modern btn-secondary"
              onClick={handleRefresh}
              disabled={refreshing}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                opacity: refreshing ? 0.6 : 1
              }}
            >
              <RefreshCw size={16} className={refreshing ? 'spinning' : ''} />
              {refreshing ? 'Refreshing...' : 'Refresh'}
            </button>

            {/* Add Clear Highlight button */}
            {(highlightedChunkId || highlightedExecutionId) && (
              <button
                className="btn-modern btn-secondary"
                onClick={() => {
                  setHighlightedChunkId(null);
                  setHighlightedExecutionId(null);
                }}
                style={{ marginRight: '0.5rem' }}
              >
                <X size={16} />
                Clear Highlight
              </button>
            )}
            <button
              className="btn-modern btn-ghost"
              onClick={handleBackToInstances}
            >
              {fromMigrationSearch ? 'Back to Migration Search' : 'Back to Instances'}
            </button>
          </div>
        </div>

        {/* Executions List */}
        {executions.map((execution, executionIndex) => {
          const isExpanded = expandedExecutions.has(executionIndex);
          const executionHasFailedBatches = hasFailedBatches(execution);
          const isHighlightedExecution = highlightedExecutionId && execution.id.toString() === highlightedExecutionId;

          return (
            <div
              key={executionIndex}
              id={`execution-${executionIndex}`}
              className="execution-container"
            >
              {/* Execution Card - Contains Everything */}
              <div
                className={`modern-card execution-card ${isHighlightedExecution ? 'execution-highlighted' : ''}`}
                style={{
                  position: 'relative'
                }}
              >
                {/* Highlighted Badge */}
                {isHighlightedExecution && (
                  <div
                    className="found-badge"
                    style={{
                      position: 'absolute',
                      top: '-12px',
                      right: '20px',
                      background: '#3b82f6',
                      color: 'white',
                      padding: '0.25rem 0.75rem',
                      borderRadius: '0.5rem',
                      fontSize: '0.75rem',
                      fontWeight: 600,
                      boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                      zIndex: 10
                    }}
                  >
                    ⭐ Selected Execution
                  </div>
                )}

                {/* Execution Header - Clickable to expand/collapse */}
                <div
                  onClick={() => toggleExecutionExpansion(executionIndex)}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    cursor: 'pointer',
                    marginBottom: isExpanded ? '1.5rem' : '0'
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                    <Activity size={24} style={{ color: isHighlightedExecution ? '#3b82f6' : '#3b82f6' }} />
                    <div>
                      <h2 style={{
                        fontSize: '1.25rem',
                        fontWeight: 600,
                        color: isHighlightedExecution ? '#1e40af' : '#111827',
                        margin: 0
                      }}>
                        Execution #{executionIndex + 1} ({execution.id})
                      </h2>
                      <p style={{ fontSize: '0.875rem', color: '#6b7280', margin: '0.25rem 0 0 0' }}>
                        {execution.startTime} - {execution.endTime}
                      </p>
                    </div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <StatusBadge status={execution.status} />
                    {executionHasFailedBatches && (
                      <span style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '0.25rem',
                        padding: '0.25rem 0.75rem',
                        background: '#fee2e2',
                        color: '#991b1b',
                        borderRadius: '0.5rem',
                        fontSize: '0.75rem',
                        fontWeight: 600
                      }}>
                        <AlertCircle size={14} />
                        Has Failed Batches
                      </span>
                    )}
                    {isExpanded ? <ChevronUp size={24} /> : <ChevronDown size={24} />}
                  </div>
                </div>

                {/* Expanded Content */}
                {isExpanded && (
                  <>
                    {/* Execution Details */}
                    <div className="card-info-grid" style={{ marginBottom: '1.5rem' }}>
                      <div className="card-info-label">Start Time:</div>
                      <div className="card-info-value">{execution.startTime}</div>

                      <div className="card-info-label">End Time:</div>
                      <div className="card-info-value">{execution.endTime}</div>
                    </div>

                    {/* Steps Section - NESTED INSIDE execution card */}
                    <div className="steps-nested-container">
                      <div className="steps-header">
                        <Layers size={20} />
                        <h3 className="steps-title">
                          Steps ({execution.steps.length})
                        </h3>
                      </div>

                      <div className="steps-list">
                        {execution.steps.map((step) => (
                          <StepCard
                            executionId={execution.id}
                            jobId={jobId ? parseInt(jobId) : undefined}
                            key={step.id}
                            step={step}
                            onNavigateToInstance={handleNavigateToInstance}
                            onRetryFailedBatches={() => handleRetryFailedBatches(execution)}
                            highlightedSummaryId={highlightedChunkId}
                            refreshTrigger={refreshTrigger}
                          />
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          );
        })}


        {/* Trigger Job Modal for Retry */}
        {showTriggerModal && job && (
          <TriggerJobModal
            job={job}
            onClose={() => {
              setShowTriggerModal(false);
              setRetryConfig(undefined);
            }}
            onTriggerSuccess={handleTriggerSuccess}
            retryConfig={retryConfig}
          />
        )}
      </div>
    </div>
  );
};

export default ExecutionDetailPage;
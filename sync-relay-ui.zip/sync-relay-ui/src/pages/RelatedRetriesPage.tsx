// src/pages/RelatedRetriesPage.tsx
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import {
  ChevronRight, ChevronLeft, ChevronsLeft, ChevronsRight,
  Layers, Calendar, Play, AlertCircle, Square, PlayCircle,
  X, RefreshCw, Clock, Info, ArrowLeft
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import { JobInstance, PageResponse } from '../types/batch.types';
import batchApiService from '../services/batchApiService';
import '../styles/JobInstancesPage.css';
import JobParametersModal from '../components/JobParametersModal';

const Notification: React.FC<{ message: string; type: 'success' | 'error'; onClose: () => void }> = ({
  message,
  type,
  onClose
}) => {
  useEffect(() => {
    const timer = setTimeout(onClose, 2000);
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className={`notification ${type}`}>
      <div className="notification-content">
        <span>{message}</span>
        <button onClick={onClose} className="notification-close">
          <X size={16} />
        </button>
      </div>
    </div>
  );
};

const RelatedRetriesPage: React.FC = () => {
  const navigate = useNavigate();
  const { executionId } = useParams<{ executionId: string }>(); // ✅ Only executionId
  const location = useLocation();

  const stepName = location.state?.stepName as string | undefined;

  const [instances, setInstances] = useState<PageResponse<JobInstance> | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [tableLoading, setTableLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedInstanceForParams, setSelectedInstanceForParams] = useState<number | null>(null);

  const [currentPage, setCurrentPage] = useState<number>(0);
  const [itemsPerPage] = useState<number>(10);

  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [autoRefreshEnabled, setAutoRefreshEnabled] = useState<boolean>(true);
  const [actionLoading, setActionLoading] = useState<{ [key: number]: boolean }>({});
  const jobId = location.state?.jobId as number | undefined;

  // Fetch related retries on mount
  useEffect(() => {
    if (executionId) {
      fetchRelatedRetries(executionId);
    }
  }, [executionId, currentPage]);

  // Auto-refresh effect
  useEffect(() => {
    if (!autoRefreshEnabled || !executionId) return;

    const intervalId = setInterval(async () => {
      console.log('Auto-refreshing related retries...');
      await fetchRelatedRetriesSilently(executionId);
    }, 5000);

    return () => {
      clearInterval(intervalId);
    };
  }, [autoRefreshEnabled, executionId, currentPage]);

  const showNotification = (message: string, type: 'success' | 'error' = 'success') => {
    setNotification({ message, type });
  };

  const fetchRelatedRetries = async (executionId: string): Promise<void> => {
    try {
      setLoading(true);
      setError(null);
      console.log('Fetching related retries for execution:', executionId);

      const data = await batchApiService.getRelatedRetries(
        parseInt(executionId),
        currentPage,
        itemsPerPage
      );

      console.log('Related retries fetched:', data.totalElements);
      setInstances(data);
    } catch (error) {
      console.error('Failed to fetch related retries:', error);
      setError('Failed to load related retry instances. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const fetchRelatedRetriesSilently = async (executionId: string): Promise<void> => {
    try {
      const data = await batchApiService.getRelatedRetries(
        parseInt(executionId),
        currentPage,
        itemsPerPage
      );
      setInstances(data);

      // Clear action loading states for completed actions
      setActionLoading(prev => {
        const updated = { ...prev };
        Object.keys(updated).forEach(id => {
          const instanceId = parseInt(id);
          const instance = data.content.find((inst: JobInstance) => inst.id === instanceId);
          if (instance) {
            const status = instance.lastStatus?.toUpperCase();
            if (status === 'RUNNING' || status === 'STARTED' ||
                status === 'COMPLETED' || status === 'STOPPED') {
              delete updated[instanceId];
            }
          }
        });
        return updated;
      });
    } catch (error) {
      console.error('Failed to auto-refresh related retries:', error);
    }
  };

  const handleResumeInstance = async (instanceId: number): Promise<void> => {
    setActionLoading(prev => ({ ...prev, [instanceId]: true }));
    showNotification('Resume request sent');

    try {
      await batchApiService.resumeJobInstance(instanceId);
      await new Promise(resolve => setTimeout(resolve, 500));

      if (executionId) {
        await fetchRelatedRetriesSilently(executionId);
      }
    } catch (error) {
      console.error(`Resume API error for instance ${instanceId}:`, error);
      showNotification('Resume request failed', 'error');
    } finally {
      setActionLoading(prev => ({ ...prev, [instanceId]: false }));
    }
  };

  const handleStopInstance = async (instanceId: number): Promise<void> => {
    setActionLoading(prev => ({ ...prev, [instanceId]: true }));
    showNotification('Stop request sent');

    try {
      await batchApiService.stopJobInstance(instanceId);
      await new Promise(resolve => setTimeout(resolve, 500));

      if (executionId) {
        await fetchRelatedRetriesSilently(executionId);
      }
    } catch (error) {
      console.error(`Stop API error for instance ${instanceId}:`, error);
      showNotification('Stop request failed', 'error');
    } finally {
      setActionLoading(prev => ({ ...prev, [instanceId]: false }));
    }
  };

  const handleInstanceClick = (instance: JobInstance): void => {
    if (jobId) {
      navigate(`/jobs/${jobId}/instances/${instance.id}/execution`, {
        state: { instance }
      });
    } else {
      console.error('JobId is missing, cannot navigate');
      alert('Cannot navigate: Missing job information');
    }
  };

  const handleBackToExecution = (): void => {
    navigate(-1); // Go back to previous page
  };

  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusIcon = (status: string) => {
    const displayStatus = status === 'STARTED' ? 'RUNNING' : status;

    switch (displayStatus) {
      case 'RUNNING':
        return <Play size={16} className="status-icon running" />;
      case 'COMPLETED':
        return <Play size={16} className="status-icon success" />;
      case 'FAILED':
        return <AlertCircle size={16} className="status-icon failed" />;
      case 'STOPPED':
        return <Square size={16} className="status-icon stopped" />;
      default:
        return <Calendar size={16} className="status-icon pending" />;
    }
  };

  const shouldShowStopButton = (status: string): boolean => {
    const normalizedStatus = status?.toUpperCase();
    return normalizedStatus === 'STARTED' || normalizedStatus === 'RUNNING';
  };

  const shouldShowResumeButton = (status: string): boolean => {
    const normalizedStatus = status?.toUpperCase();
    return normalizedStatus === 'STOPPED' || normalizedStatus === 'FAILED';
  };

  const totalPages = instances?.totalPages || 0;
  const currentInstances = instances?.content || [];
  const totalElements = instances?.totalElements || 0;

  const handlePageChange = (page: number): void => {
    if (page >= 0 && page < totalPages) {
      setCurrentPage(page);
    }
  };

  const getVisiblePages = (): number[] => {
    const pages: number[] = [];
    const maxVisiblePages = 5;

    if (totalPages <= maxVisiblePages) {
      return Array.from({ length: totalPages }, (_, i) => i);
    }

    let start = Math.max(0, currentPage - 2);
    let end = Math.min(totalPages - 1, start + maxVisiblePages - 1);

    if (end - start + 1 < maxVisiblePages) {
      start = Math.max(0, end - maxVisiblePages + 1);
    }

    for (let i = start; i <= end; i++) {
      pages.push(i);
    }

    return pages;
  };

  if (loading) {
    return (
      <div className="page-wrapper">
        <div className="page-container">
          <div className="page-header">
            <h1 className="page-title">Loading Related Retries...</h1>
          </div>
          <div style={{ textAlign: 'center', padding: '2rem' }}>
            <div className="loading-spinner"></div>
            <p>Loading retry instances...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error && !loading && !tableLoading) {
    return (
      <div className="page-wrapper">
        <div className="page-container">
          <div className="page-header">
            <h1 className="page-title">Related Retries</h1>
            <div className="page-actions">
              <button
                className="btn-modern btn-ghost"
                onClick={handleBackToExecution}
              >
                <ArrowLeft size={16} />
                Back to Execution
              </button>
            </div>
          </div>
          <div className="table-empty">
            <AlertCircle size={64} className="jobs-empty-icon" />
            <h3>{error}</h3>
            <div style={{ marginTop: '1rem', display: 'flex', gap: '0.5rem', justifyContent: 'center' }}>
              <button
                onClick={() => executionId && fetchRelatedRetries(executionId)}
                className="btn-modern btn-primary"
              >
                Retry
              </button>
              <button
                onClick={handleBackToExecution}
                className="btn-modern btn-secondary"
              >
                <ArrowLeft size={16} />
                Back to Execution
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="page-wrapper job-instances-page">
      <div className="notification-container">
        {notification && (
          <Notification
            message={notification.message}
            type={notification.type}
            onClose={() => setNotification(null)}
          />
        )}
      </div>

      <div className="page-container">
        <div className="page-header">
          <div>
            <h1 className="page-title">
              Related Retry Instances
            </h1>
            <p className="page-subtitle">
              Retries for Execution #{executionId}
              {stepName && ` - Step: ${stepName}`}
            </p>
          </div>
          <div className="page-actions">
            <button
              className="btn-modern btn-ghost"
              onClick={handleBackToExecution}
            >
              <ArrowLeft size={16} />
              Back to Execution
            </button>
          </div>
        </div>

        <div className="auto-refresh-section" style={{ marginBottom: '1rem' }}>
          <label className="auto-refresh-checkbox">
            <input
              type="checkbox"
              checked={autoRefreshEnabled}
              onChange={(e) => setAutoRefreshEnabled(e.target.checked)}
            />
            <RefreshCw size={16} className={autoRefreshEnabled ? 'spinning' : ''} />
            <span>Auto-refresh table (every 5 seconds)</span>
          </label>
        </div>

        <div className="results-summary" style={{ marginBottom: '1rem' }}>
          Showing {currentInstances.length} of {totalElements} retry instances
        </div>

        <div className="table-modern-wrapper">
          <div className="table-header">
            <h3 className="table-title">
              <Layers size={20} />
              Retry Instances ({totalElements})
            </h3>
          </div>

          <div className="table-content">
            {tableLoading || loading ? (
              <div className="table-loading">
                <div className="loading-spinner"></div>
                <p>Loading retry instances...</p>
              </div>
            ) : !instances || currentInstances.length === 0 ? (
              <div className="table-empty">
                <p>No retry instances found</p>
                <p className="empty-subtitle">This execution has no retries yet</p>
              </div>
            ) : (
              <table className="job-instances-table">
                <thead>
                  <tr>
                    <th className="column-id">ID</th>
                    <th className="column-status">Status</th>
                    <th className="column-created">Last Updated</th>
                    <th className="column-duration">Duration</th>
                    <th className="column-executions">Executions</th>
                    <th className="column-triggered-by">Triggered By</th>
                    <th className="column-actions">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {currentInstances.map((instance: JobInstance) => (
                    <tr
                      key={instance.id}
                      className="table-row clickable"
                      onClick={() => handleInstanceClick(instance)}
                    >
                      <td className="cell-id">
                        <div className="instance-id">
                          <Layers size={16} />
                          #{instance.id}
                        </div>
                      </td>
                      <td className="cell-status">
                        <div className="status-cell">
                          {getStatusIcon(instance.lastStatus)}
                          <StatusBadge status={instance.lastStatus === 'STARTED' ? 'RUNNING' : instance.lastStatus} />
                        </div>
                      </td>
                      <td className="cell-created">
                        <div className="created-date">
                          <Calendar size={16} />
                          {formatDate(instance.lastUpdated)}
                        </div>
                      </td>
                      <td className="cell-duration">
                        <div className="duration-wrapper">
                          <Clock className="duration-icon" size={14} />
                          <span className="duration-text">{instance.duration}</span>
                        </div>
                      </td>
                      <td className="cell-executions">
                        <div className={`execution-count ${instance.executionCount > 0 ? 'has-executions' : 'no-executions'}`}>
                          {instance.executionCount}
                          <span>execution{instance.executionCount !== 1 ? 's' : ''}</span>
                        </div>
                      </td>
                      <td className="cell-triggered-by">
                        <div className="triggered-by-value">
                          {instance.triggeredBy}
                        </div>
                      </td>
                      <td className="cell-actions">
                        <div className="action-buttons">
                          <button
                            className="btn-action btn-info"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedInstanceForParams(instance.id);
                            }}
                            title="View Parameters"
                          >
                            <Info size={16} />
                          </button>

                          <button
                            className={`btn-action btn-stop ${shouldShowStopButton(instance.lastStatus) ? 'active' : 'disabled'}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              if (shouldShowStopButton(instance.lastStatus)) {
                                handleStopInstance(instance.id);
                              }
                            }}
                            disabled={!shouldShowStopButton(instance.lastStatus) || actionLoading[instance.id]}
                            title={shouldShowStopButton(instance.lastStatus) ? 'Stop Instance' : 'Can only stop running instances'}
                          >
                            {actionLoading[instance.id] ? (
                              <div className="button-spinner"></div>
                            ) : (
                              <Square size={16} />
                            )}
                          </button>

                          <button
                            className={`btn-action btn-resume ${shouldShowResumeButton(instance.lastStatus) ? 'active' : 'disabled'}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              if (shouldShowResumeButton(instance.lastStatus)) {
                                handleResumeInstance(instance.id);
                              }
                            }}
                            disabled={!shouldShowResumeButton(instance.lastStatus) || actionLoading[instance.id]}
                            title={shouldShowResumeButton(instance.lastStatus) ? 'Resume Instance' : 'Can only resume stopped instances'}
                          >
                            {actionLoading[instance.id] ? (
                              <div className="button-spinner"></div>
                            ) : (
                              <PlayCircle size={16} />
                            )}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {!tableLoading && !loading && instances && currentInstances.length > 0 && totalPages > 1 && (
            <div className="pagination-container">
              <div className="pagination-info">
                Page {currentPage + 1} of {totalPages}
              </div>
              <div className="pagination-controls">
                <button
                  className="pagination-btn"
                  onClick={() => handlePageChange(0)}
                  disabled={currentPage === 0}
                  title="First Page"
                >
                  <ChevronsLeft size={14} />
                </button>
                <button
                  className="pagination-btn"
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 0}
                  title="Previous Page"
                >
                  <ChevronLeft size={14} />
                </button>

                {getVisiblePages().map(pageNum => (
                  <button
                    key={pageNum}
                    className={`pagination-btn ${currentPage === pageNum ? 'active' : ''}`}
                    onClick={() => handlePageChange(pageNum)}
                  >
                    {pageNum + 1}
                  </button>
                ))}

                <button
                  className="pagination-btn"
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage >= totalPages - 1}
                  title="Next Page"
                >
                  <ChevronRight size={14} />
                </button>
                <button
                  className="pagination-btn"
                  onClick={() => handlePageChange(totalPages - 1)}
                  disabled={currentPage >= totalPages - 1}
                  title="Last Page"
                >
                  <ChevronsRight size={14} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      <JobParametersModal
        isOpen={selectedInstanceForParams !== null}
        onClose={() => setSelectedInstanceForParams(null)}
        instanceId={selectedInstanceForParams || 0}
      />
    </div>
  );
};

export default RelatedRetriesPage;
// src/pages/JobsListPage.tsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronRight, Play, Home, Database, Activity, Search, X } from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import TriggerJobModal from '../components/TriggerJobModal';
import Loader from '../components/Loader'; // Import the Loader
import { Job, JobParam } from '../types/batch.types';
import '../styles/JobListPage.css';
// import '../styles/UnifiedStyles.css';
import batchApiService from '../services/batchApiService';

const JobsListPage: React.FC = () => {
  const navigate = useNavigate();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [filteredJobs, setFilteredJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showTriggerModal, setShowTriggerModal] = useState<boolean>(false);
  const [selectedJobForTrigger, setSelectedJobForTrigger] = useState<Job | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const Notification: React.FC<{ message: string; type: 'success' | 'error'; onClose: () => void }> = ({
      message,
      type,
      onClose
    }) => {
      React.useEffect(() => {
        const timer = setTimeout(onClose, 3000);
        return () => clearTimeout(timer);
      }, [onClose]);

      return (
        <div className={`notification ${type}`}>
          <div className="notification-content">
            <span>{message}</span>
            <button onClick={onClose} className="notification-close">
              ×
            </button>
          </div>
        </div>
      );
    };
  const handleTriggerSuccess = (message: string) => {
    setNotification({ message, type: message.includes('❌') ? 'error' : 'success' });
  };

  useEffect(() => {
    fetchJobs();
  }, []);

  useEffect(() => {
    // Filter jobs based on search query
    if (searchQuery.trim() === '') {
      setFilteredJobs(jobs);
    } else {
      const filtered = jobs.filter(job =>
        job.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredJobs(filtered);
    }
  }, [searchQuery, jobs]);

  const fetchJobs = async (): Promise<void> => {
    try {
      setLoading(true);
      setError(null);
      const data = await batchApiService.getAllJobs();
      setJobs(data);
      setFilteredJobs(data);
    } catch (error) {
      console.error('Failed to fetch jobs:', error);
      setError('Failed to load jobs. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // UPDATED: Fixed navigation to include jobName
  const handleJobClick = (job: Job): void => {
    console.log('Navigating to instances for job:', job);
    navigate(`/jobs/${job.id}/instances`, { 
      state: { 
        job,           // Pass the job object
        jobName: job.name  // Pass jobName explicitly for JobInstancesPage
      }
    });
  };

  const clearSearch = (): void => {
    setSearchQuery('');
  };

  // Show loader when loading
  if (loading) {
    return <Loader hidden={false} />;
  }

  // Show error state if fetch failed
  if (error && !loading) {
    return (
      <div className="jobs-page-wrapper">
        <div className="jobs-page-container">
          <div className="jobs-error-state">
            <Database size={64} className="jobs-error-icon" />
            <h3>{error}</h3>
            <button
              onClick={fetchJobs}
              className="jobs-btn jobs-btn-primary"
              style={{ marginTop: '1rem' }}
            >
              Retry
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="jobs-page-wrapper">
      <div className="jobs-page-container">
        {/* Title and Actions */}
        {/*<div className="jobs-title-header">*/}
        {/*  <div className="jobs-title-section">*/}
        {/*    <h1 className="jobs-page-title">Spring Batch Jobs</h1>*/}
        {/*    <p className="jobs-page-subtitle">*/}
        {/*      Manage and monitor all batch job executions*/}
        {/*    </p>*/}
        {/*  </div>*/}
        {/*</div>*/}

        {/* Search Bar */}
        <div className="jobs-search-container">
          <div className="jobs-search-wrapper">
            <Search size={20} className="jobs-search-icon" />
            <input
              type="text"
              placeholder="Search jobs by name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="jobs-search-input"
            />
            {searchQuery && (
              <button onClick={clearSearch} className="jobs-search-clear">
                <X size={18} />
              </button>
            )}
          </div>
          <div className="jobs-search-results-count">
            {filteredJobs.length} {filteredJobs.length === 1 ? 'job' : 'jobs'} found
          </div>
        </div>

        {/* Jobs Grid */}
        {filteredJobs.length === 0 ? (
          <div className="jobs-empty-state">
            <Database size={64} className="jobs-empty-icon" />
            <h3>No jobs found</h3>
            <p>Try adjusting your search query</p>
          </div>
        ) : (
          <div className="jobs-scrollable-container">
            <div className="jobs-grid">
              {filteredJobs.map((job) => (
                <div key={job.id} className="job-card" onClick={() => handleJobClick(job)}>
                  <div className="job-card-content">
                    {/* Title */}
                    <h3 className="job-card-title">
                      <Activity size={28} />
                      {job.name}
                    </h3>

                    {/* Info Grid */}
                    <div className="job-info-grid">
                      <div className="job-info-label">
                        <Database size={16} />
                        Instances:
                      </div>
                      <div className="job-info-value">{job.totalInstances}</div>

                      <div className="job-info-label">Last run:</div>
                      <div className="job-info-value">{job.lastRun}</div>
                    </div>

                    {/* Actions Bottom */}
                    <div className="job-card-actions">
                      <div className="job-card-actions-left">
                        <StatusBadge status={job.status} />
                      </div>
                      <div className="job-card-actions-right">
                        <button
                          className="jobs-btn jobs-btn-success"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedJobForTrigger(job);
                            setShowTriggerModal(true);
                          }}
                        >
                          <Play size={16} />
                          Trigger
                        </button>
                        <button className="jobs-btn jobs-btn-icon">
                          <ChevronRight size={24} />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Trigger Modal */}
        {showTriggerModal && selectedJobForTrigger && (
          <TriggerJobModal
            job={selectedJobForTrigger}
            onClose={() => setShowTriggerModal(false)}
            onTriggerSuccess={handleTriggerSuccess}
          />
        )}

        <div className="notification-container">
          {notification && (
            <Notification
              message={notification.message}
              type={notification.type}
              onClose={() => setNotification(null)}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default JobsListPage;
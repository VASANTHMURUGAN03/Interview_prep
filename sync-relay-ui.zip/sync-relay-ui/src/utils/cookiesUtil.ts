// src/utils/cookiesUtil.ts

import Cookies from 'js-cookie';

export const getPartnerAccessToken = (): string | undefined => Cookies.get('employee_accessToken');
export const getPartnerChannelName = (): string | undefined => Cookies.get('employee_channelName');
export const getPartnerAccessTokenExpiry = (): string | undefined => Cookies.get('employee_accessTokenExpiry');
export const getPartnerRefreshToken = (): string | undefined => Cookies.get('employee_refreshToken');
export const getPartnerRefreshTokenExpiry = (): string | undefined => Cookies.get('employee_refreshTokenExpiry');
export const getPartnerUserProfile = (): string | undefined => Cookies.get('employee_userProfile');

const getPath = (): string => {
  const getDomainName = window.location.hostname;
  return getDomainName === 'localhost' ? '/sso' : '/';
};

const getDomain = (): string => {
  const getDomainName = window.location.hostname;
  return getDomainName === 'localhost' ? 'localhost' : '.star-app.in';
};

export const clearCookies = (): void => {
  const path = getPath();
  const domain = getDomain();
  
  Cookies.remove('employee_accessToken', { path, domain });
  Cookies.remove('employee_accessTokenExpiry', { path, domain });
  Cookies.remove('employee_channelName', { path, domain });
  Cookies.remove('employee_refreshToken', { path, domain });
  Cookies.remove('employee_refreshTokenExpiry', { path, domain });
  Cookies.remove('employee_userProfile', { path, domain });
};
// src/types/batch.types.ts

export interface Summary {
  summaryId: string;
  batchId: string;
  status: 'COMPLETED' | 'FAILED' | 'NO_DATA' | 'RUNNING';
  requestedStartIndex: number;
  requestedEndIndex: number;
  requestedPageSize: number;
  totalReadItems: number;
  readStartTime: string;
  readEndTime: string;
  processStartTime: string | null;
  processEndTime: string | null;
  writeStartTime: string | null;
  writeEndTime: string | null;
  readDurationMs: number | null;
  processDurationMs: number | null;
  writeDurationMs: number | null;
  writtenPerentage: number | null;
  writtenRecord: number | null;
  clientIdentifier: string | null;
}

export interface PageResponse<T> {
  content: T[];
  currentPage: number;
  pageSize: number;
  totalElements: number;
  totalPages: number;
  first: boolean;
  last: boolean;
}

export interface Job {
  id: number;
  name: string;
  totalInstances: number;
  lastRun: string;
  status: string;
  paramDetail?: ParamDetail[];
  searchParams?: SearchParam[];
}

export interface RecordSearchResponse {
  // Define properties if needed
}

export interface SearchParam {
  placeholder: string;
  type: string;
  filterName: string;
}

export interface JobInstance {
  id: number;
  lastUpdated: string;
  executionCount: number;
  lastStatus: string;
  duration: string;
  triggeredBy: string;
}

export interface SalesforceBatch {
  id: string;
  status: string;
  recordCount: number;
  chunkNumber: number;
  error?: string;
  retryJobInstanceId?: number;
}

export interface Step {
  id: string;
  name: string;
  status: string;
  readCount?: number;
  writeCount?: number;
  startTime: string;
  endTime: string;
  salesforceJobId?: string;
  stepBatchesInfo?: StepBatchInfo[] | null;
  summaries: Summary[] | null;
}

export interface ExecutionDetail {
  id: number;
  instanceId: number;
  jobName: string;
  status: string;
  batchStatus?: string;
  actualStatus?: string;
  startTime: string;
  endTime: string;
  steps: Step[];
}

export interface JobParam {
  key: string;
  value: string;
}

export interface TriggerJobRequest {
  jobId: number;
  parameters: JobParam[];
}

export interface RetryStepRequest {
  executionId: number;
  stepId: string;
  startIndex: number;
  endIndex: number;
}

export interface MigrationRecord {
  id: string;
  searchKey: string;
  jobName: string;
  jobId: string;
  jobStatus: 'SUCCESS' | 'FAILED' | 'RUNNING';
  transferOn: string; // ISO date string
}

export interface MigrationSearchFilters {
  fromDate?: string;
  toDate?: string;
  jobName?: string;
  searchKey?: string;
  jobStatus?: string;
  jobId?: string;
}

export interface StepBatchInfo {
  id: string | null;
  chunkStatus: string;
  actualStatus: string;
  startIndex: number;
  endIndex: number;
  chunkNumber: string;
  error: string | null;
  retryJobInstanceId: number | null;
  chunkId: string;
}

export interface ParamDetail {
  paramName: string;
  type: string;
  mandatory: boolean;
  defaultDisabled: boolean;
  defaultValue: string[];
  labelName: string;
}

// ADD THIS INTERFACE - BatchSummaryDTO
export interface BatchSummaryDTO {
  summaryId: string;
  batchId: string;
  status: string;
  requestedStartIndex: number;
  requestedEndIndex: number;
  requestedPageSize: number;
  totalReadItems: number;
  readStartTime: string;
  readEndTime: string;
  processStartTime: string;
  processEndTime: string;
  writeStartTime: string;
  writeEndTime: string;
  readDurationMs: number;
  processDurationMs: number;
  writeDurationMs: number;
  writtenRecord: number;
  writtenPerentage: number; // Note: Typo in property name matches backend
  clientIdentifier: string;
}
// src/App.tsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import HomePage from './pages/HomePage';
import JobsListPage from './pages/JobsListPage';
import JobInstancesPage from './pages/JobInstancesPage';
import ExecutionDetailPage from './pages/ExecutionDetailPage';
import DataMigrationSearchPage from './pages/DataMigrationSearchPage';
import RelatedRetriesPage from './pages/RelatedRetriesPage';
import './App.css';
 
const App: React.FC = () => {
  return (
<Router basename="/sync-relay">
<div className="app-container">
<Sidebar />
<main className="main-content">
<Routes>
            {/* Home page */}
<Route path="/" element={<HomePage />} />
            {/* Jobs list page */}
<Route path="/jobs" element={<JobsListPage />} />
            {/* Job instances page */}
<Route path="/jobs/:jobId/instances" element={<JobInstancesPage />} />
<Route
              path="/executions/:executionId/related-retries"
              element={<RelatedRetriesPage />}
            />
            {/* Execution detail page */}
<Route path="/jobs/:jobId/instances/:instanceId/execution" element={<ExecutionDetailPage />} />
            {/* Data Migration Search page */}
<Route path="/data-migration-search" element={<DataMigrationSearchPage />} />
            {/* 404 - Not Found */}
<Route path="*" element={<Navigate to="/" replace />} />
</Routes>
</main>
</div>
</Router>
  );
};
 
export default App;
package com.demo.feature_flag.service;

import com.demo.feature_flag.enums.MyFeatures;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.togglz.core.manager.FeatureManager;

@Service
@RequiredArgsConstructor
public class CustomerService {

    private final FeatureManager featureManager;

    public String process() {
        if (featureManager.isActive(MyFeatures.MOBILE_HASHING)) {
            // call hashing
             System.out.print("Toggle Enabled");
             return "Toggle Enabled";
        } else {
            // fallback logic
            System.out.print("Toggle Disabled");
            return "Toggle Disabled";
        }
    }
}